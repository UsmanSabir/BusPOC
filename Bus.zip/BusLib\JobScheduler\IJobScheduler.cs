﻿using System.Collections.Generic;
using BusLib.BatchEngineCore;

namespace BusLib.JobSchedular
{
    public interface IJobScheduler //
    {
        long CreateJob(int groupKey, List<JobCriteria> criteria, string submittedBy, bool isResubmission = false); 

        long CreateJob(List<int> processKeys, List<JobCriteria> criteria, string submittedBy, bool isResubmission = false);

        long CreateQueueJob(List<int> processKeys, List<JobCriteria> criteria, string queueName, string submittedBy, bool isResubmission = false);
    }
}
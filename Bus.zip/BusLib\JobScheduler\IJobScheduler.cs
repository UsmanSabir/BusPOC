﻿using System.Collections.Generic;
using BusLib.BatchEngineCore;

namespace BusLib.JobSchedular
{
    public interface IJobScheduler //
    {
        long CreateProcessJob(int processId, List<JobCriteria> criteria, string submittedBy, bool hasPriority = false, bool isResubmission = false);
        
        long CreateJob(int groupId, List<JobCriteria> criteria, string submittedBy, bool hasPriority=false, bool isResubmission = false); 

        long CreateJob(List<int> processIds, List<JobCriteria> criteria, string submittedBy, bool hasPriority = false, bool isResubmission = false);

        long CreateQueueJob(List<int> processIds, List<JobCriteria> criteria, string queueName, string submittedBy, bool hasPriority = false, bool isResubmission = false);
    }
}
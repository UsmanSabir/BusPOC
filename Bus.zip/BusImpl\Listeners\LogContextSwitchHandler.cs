﻿using BusLib.BatchEngineCore;

namespace BusImpl.Listeners
{
    public class LogContextSwitchHandler: IContextSwitchHandler
    {
        public void ContextSwitchStarting()
        {
            ContextHost.SetAppContext();
        }

        public void ContextSwitchCompleted()
        {
            ContextHost.SetAppContext();
        }
    }
}
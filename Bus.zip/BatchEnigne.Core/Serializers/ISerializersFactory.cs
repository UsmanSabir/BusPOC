﻿using System;
using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core.Serializers
{
    internal interface ISerializersFactory
    {
        ISerializer GetSerializer(Type type);
        ISerializer GetSerializer<T>();
    }
}
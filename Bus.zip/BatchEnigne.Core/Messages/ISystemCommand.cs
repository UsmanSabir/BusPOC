﻿namespace BatchEngine.Core.Messages
{
    public interface ISystemCommand:IMessage
    {
        string PipeLineKey { get; }
    }
}

﻿using System.Threading;
using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core
{
    public interface IPubSubFactory
    {
        IDistributedMessagePublisher GetPublisher(CancellationToken token, ILogger logger, string channelName = null);

        IDistributedMessageSubscriber GetSubscriber(CancellationToken token, ILogger logger, string channelName = null);
    }
}
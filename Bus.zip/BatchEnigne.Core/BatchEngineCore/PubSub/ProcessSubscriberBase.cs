﻿using BatchEngine.Core;
using BatchEngine.Core.Helper;

namespace BatchEngine.Core.Subscribers
{
    public abstract class ProcessSubscriberBase:SafeDisposable, IProcessSubscriber
    {
        public int Sequence { get; protected set; } = 1000;
        public abstract int ProcessId { get; }

        public virtual bool CanExecute(IProcessExecutionContext context)
        {
            return true;
        }

        public virtual void ProcessStarting(IProcessExecutionContext context)
        {
            
        }

        public virtual void OnProcessSubmitted(IProcessSubmittedContext context)
        {
            
        }

        public virtual void OnProcessComplete(IProcessCompleteContext context)
        {
            
        }

        public virtual void OnProcessFinalized(IProcessCompleteContext context)
        {
            
        }

        public virtual void OnProcessStop(IProcessStoppedContext context)
        {
            
        }

        public virtual void OnProcessResume(IProcessResumeContext context)
        {
            
        }

        public virtual void BeforeVolumeGenerating(IProcessExecutionContext context)
        {
            
        }

        public virtual void OnProcessRetry(IProcessRetryContext context)
        {
            
        }

        public virtual void ProcessFailed(IProcessCompleteContext context)
        {
            
        }
    }
}
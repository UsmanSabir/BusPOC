﻿namespace BatchEngine.Core.StatePersistence.Adapters
{
    public interface ITypeConverterVolumeAdapter<out T, in TU>:IVolumeAdapter<T,TU>
    {
        
    }
}
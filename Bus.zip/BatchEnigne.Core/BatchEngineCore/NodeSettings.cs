﻿using System.Configuration;

namespace BatchEngine.Core
{
    public class NodeSettings
    {
        private static NodeSettings _instance;

        public NodeSettings()
        {
            LockKey = "BatchEngine"; // + System.Diagnostics.Process.GetCurrentProcess().Id
            var throttlingSettings = ConfigurationManager.AppSettings["Throttling"];
            if (!string.IsNullOrWhiteSpace(throttlingSettings) &&
                int.TryParse(throttlingSettings, out int throttling) && throttling >= 0)
            {
                Throttling = throttling;
            }
        }

        public static NodeSettings Instance => _instance ?? (_instance = new NodeSettings()); //todo

        public string Name { get; internal set; } = ConfigurationManager.AppSettings["NodeId"]?? "Node"; 
        public int Throttling { get; internal set; } = 0;
        public string LockKey { get; private set; }

        public int SubTenantId { get; internal set; }

        public bool ProcessStopInd { get; internal set; } = true;

        public string ConnectionString { get; internal set; }
    }
}
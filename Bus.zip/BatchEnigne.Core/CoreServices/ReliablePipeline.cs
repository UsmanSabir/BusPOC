﻿using System;
using System.Threading;
using BatchEngine.Core.Messages;
using BatchEngine.Core.PipelineFilters;

namespace BatchEngine.Core.CoreServices
{
    public class ReliablePipeline<T> : Pipeline<T> where T : IMessage
    {
        public ReliablePipeline(IHandler<T> handler, string name, ILogger logger, int maxRetries, int delayInRetries,
            CancellationToken token, Action<Exception> errorAction=null) : base(handler)
        {
            //RegisterFeatureDecorator(new CircuitBreakerFeatureHandler<T>(name, logger, token));
            //RegisterFeatureDecorator(new RetryFeatureHandler<T>(maxRetries, delayInRetries, logger, token, errorAction));
            RegisterFeatureDecorator(new RetryCircuitBreakerFeatureHandler<T>(name, maxRetries, logger, token, delayInRetries, errorAction));
        }
    }
}
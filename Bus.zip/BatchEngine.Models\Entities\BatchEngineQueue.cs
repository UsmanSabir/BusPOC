
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchQueue
	public partial class BatchEngineQueue : BaseModel
	{
		
				private Int32 _id;
				private String _queuename;
				private Int32 _queueseq;
				private Int64 _refid;
				private Boolean _isfinished;
		
		//public BatchEngineQueue BatchEngineQueue { get { return this; } } //Self reference property

		
		public Int32 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public String QUEUENAME
		{
			get { return _queuename; }
			set
			{
				CheckSetProperty(ref _queuename, value);
			}
		}

		
		public Int32 QUEUESEQ
		{
			get { return _queueseq; }
			set
			{
				CheckSetProperty(ref _queueseq, value);
			}
		}

		
		public Int64 REFID
		{
			get { return _refid; }
			set
			{
				CheckSetProperty(ref _refid, value);
			}
		}

		
		public Boolean ISFINISHED
		{
			get { return _isfinished; }
			set
			{
				CheckSetProperty(ref _isfinished, value);
			}
		}

		

		
	}

		public class BatchEngineQueueValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "QUEUENAME", "QUEUESEQ", "REFID", "ISFINISHED"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		    ["QUEUENAME"] = 50
		    
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
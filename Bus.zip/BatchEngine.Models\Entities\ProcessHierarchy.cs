
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessConfig
	public partial class ProcessHierarchy : BaseModel
	{
		
				private Int32 _id;
				private Int32 _processid;
				private Int32? _prntprcsid;
				private Boolean _act_ind;
		
		//public ProcessHierarchy ProcessHierarchy { get { return this; } } //Self reference property

		
		public Int32 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Int32 PROCESSID
		{
			get { return _processid; }
			set
			{
				CheckSetProperty(ref _processid, value);
			}
		}

		
		public Int32? PRNTPRCSID
		{
			get { return _prntprcsid; }
			set
			{
				CheckSetProperty(ref _prntprcsid, value);
			}
		}

		
		public Boolean ACT_IND
		{
			get { return _act_ind; }
			set
			{
				CheckSetProperty(ref _act_ind, value);
			}
		}

		

		
	}

		public class ProcessHierarchyValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "PROCESSID", "ACT_IND"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		     
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
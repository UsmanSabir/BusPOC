﻿using System.Threading;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;

namespace BusImpl.PubSubImpl.Udp
{
    public class UdpPubSubFactory: IPubSubFactory
    {
        private readonly string _ip;
        private readonly int _port;

        public UdpPubSubFactory(string ip, int port)
        {
            _ip = ip;
            _port = port;
        }

        public IDistributedMessagePublisher GetPublisher(CancellationToken token, ILogger logger, string channelName = null)
        {
            return new UdpPublisher(_ip, _port, channelName, logger);
        }

        public IDistributedMessageSubscriber GetSubscriber(CancellationToken token, ILogger logger, string channelName = null)
        {
            return new UdpSubscriber(_ip, _port, channelName, logger);
        }
    }
}
﻿using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.PubSub;

namespace BatchBootstrapper
{
    public class BisProcess: ProcessSubscriberBase
    {
        public override int ProcessKey { get; } = 0;

        //public override bool CanExecute(IProcessExecutionContext context)
        //{
        //    return false;
        //}
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using NFS.Business.CommonHelper;
using NS.ExceptionHandling;
using NS.Utilities.Enums;
using NFS.Models.Common.Custom;
using NFS.Models.BusinessPartner;
using NS.ORM;
using BatchEngine.Core.Subscribers;
using BatchEngine.Core.Groups;
using BatchEngine.Core.BatchEngineCore;

namespace BatchBootstrapper.Process.Subscriber
{
    public class DayEndGroupSubscriber : IGroupSubscriber
    {
        public int GroupKey { get; } = 2800;

        #region Interface Method
        public void OnGroupComplete(IGroupCompleteContext context)
        {
            try
            {
                List<JobCriteria> jobList = new List<JobCriteria>();

                foreach (var criteria in context.Criteria)
                {
                    var CPD = GetTenantPartitionEntity(criteria.BranchId, criteria.CompanyId, criteria.SubTenantId);

                    WorkingDayCalcParam param = new WorkingDayCalcParam();
                    param.CompanyId = criteria.CompanyId;
                    param.BranchId = criteria.BranchId;
                    param.ValueDte = CPD;
                    criteria.ProcessingDate = CPD;

                    if (!CommonHelper.IsWorkingDayConfigured(param))
                    {
                        var exception = "Working Days are not configured against branch:" + param.BranchId;
                        ExceptionHandler.HandleException(new Exception(exception), ExceptionHandlingPolicy.LogOnlyPolicy);
                    }
                    else
                    {
                        var IsWorkingDay = CommonHelper.IsWorkingDay(criteria.CompanyId, criteria.BranchId, CPD);
                        if (!IsWorkingDay) // CPD Day is not working day --
                            jobList.Add(criteria);
                    }
                }

                if (jobList.Count > 0)
                    context.Resubmit(jobList,"Upfront Calling");  // Invoke Upfront for submitted processes
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void OnGroupStarting(IGroupStartContext context)
        {
            
        }

        public void OnGroupSubmitted(IGroupStartContext context)
        {
            
        }
        #endregion

        #region Helper Method
        private DateTime GetTenantPartitionEntity(int BranchId, int companyId, int SubTenantId)
        {
            var contextExt = EntityContextExt.Create<TenantPartitionEntity>();

            var entityTnntPart = contextExt.Read(x => x.BRNC_ID == BranchId && x.CMPY_ID == companyId && x.SUB_TNNT_ID == SubTenantId)?.Entity?.FirstOrDefault();
            return (DateTime)entityTnntPart.PRCG_DTE;

        }
        #endregion
    }
}

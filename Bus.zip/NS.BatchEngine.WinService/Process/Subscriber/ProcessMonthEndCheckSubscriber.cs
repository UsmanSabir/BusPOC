﻿using System;
using NS.Resources.Enums.Common;
using NFS.Business.CommonHelper;
using BatchEngine.Core.Subscribers;
using BatchEngine.Core;

namespace BatchBootstrapper.Process
{
    public class ProcessMonthEndCheckSubscriber : ProcessSubscriberBase
    {
        public override int ProcessId { get; } = 0;

        public override bool CanExecute(IProcessExecutionContext context)
        {
            bool canExeMonthEnd = true;

            if (context.Configuration.IsMonthEnd)  // Check either is it MonthEnd or DayEnd process
            {
                canExeMonthEnd = CommonHelper.IsMonthEnd(context.ProcessingDate, (DaysYearType)Enum.Parse(typeof(DaysYearType), context.Configuration.DaysYearTypeKey.Replace(" ", string.Empty)), context.ProcessState.CompanyId, context.ProcessState.BranchId);
                if (!canExeMonthEnd)
                    context.Logger.Info("NotMonthEnd: " + string.Format("Process No: {0} can only be executed on month end.", context.ProcessState.ProcessId));
                return canExeMonthEnd;
            }
            return true;
        }

    }
}

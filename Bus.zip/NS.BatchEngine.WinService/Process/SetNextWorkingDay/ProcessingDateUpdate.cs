﻿using BatchBootstrapper.Common;
using BatchEngine.Core;

using NFS.Models.BatchProcess.Custom;
using NFS.Models.BusinessPartner;
using NFS.Models.Common.Custom;
using NS.BaseModels;
using NS.BatchEngine.Logs;
using NS.BatchProcessing.Business.Helpers;
using NS.ORM;
using NS.Resources.Enums.Common;
using NS.Utilities.Context;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchBootstrapper.Process
{
    public class ProcessingDateUpdate : StatelessProcess<int>
    {
        public override int ProcessKey => 5303;//2795;//

        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            List<int> volume = new List<int>();
            volume.Add(2);
            return volume;
        }

        public override void Execute(int id, ITaskContext context)
        {
            var processContext = context.ProcessExecutionContext;

            try
            {
                RequestObject<BatchProcessParam> request = new RequestObject<BatchProcessParam>(LogContext.ContextToLog, new BatchProcessParam() { BranchId = context.ProcessExecutionContext.Criteria.BranchId, CompanyId = context.ProcessExecutionContext.Criteria.CompanyId, SubTenantId = context.ProcessExecutionContext.Criteria.SubTenantId, ProcessingDate = context.ProcessExecutionContext.Criteria.ProcessingDate, WorkingDay = (DaysYearType)Enum.Parse(typeof(DaysYearType), context.ProcessExecutionContext.Configuration.DaysYearTypeKey.Replace(" ", string.Empty)) });
                DateTime responseCPD = SetNextProcessingDate(request);  
                //NS.BatchEngine.Logs.CtxExt.GetCurrentLogContext
                if (CommonHelper.IsWorkingDay(processContext.Criteria.CompanyId, processContext.Criteria.BranchId, responseCPD) || !CommonHelper.IsWorkingDayConfigured(new WorkingDayCalcParam() { CompanyId = processContext.Criteria.CompanyId, BranchId = processContext.Criteria.BranchId, ValueDte = responseCPD }))
                    BatchProcessCommon.PublishDayEndCompletion(new BatchProcessCriteria() { BranchId = processContext.Criteria.BranchId, CompanyId = processContext.Criteria.CompanyId }, LogContext.ContextToLog.GetBaseContext());
            }
            catch(Exception ex)
            {
                throw;
            }
        }
        #region Helpers Function

        /// <summary>
        /// SetNextProcessingDate
        /// </summary>
        /// <param name="DayEndParam"></param>
        /// <returns></returns>


        public DateTime SetNextProcessingDate(RequestObject<BatchProcessParam> dayEndParam)
        {
            WorkingDayCalcParam param = new WorkingDayCalcParam() { BranchId = dayEndParam.Object.BranchId, CompanyId = dayEndParam.Object.CompanyId, ValueDte = dayEndParam.Object.ProcessingDate };
            var nextProcessingDate = CommonHelper.GetNextWorkinDay(dayEndParam.Object.WorkingDay, param, 1);

            var contextExt = EntityContextExt.Create<TenantPartitionEntity>();
            TenantPartitionEntity objTenantPartitionEntity = contextExt.Read(x => x.BRNC_ID == dayEndParam.Object.BranchId && x.SUB_TNNT_ID == dayEndParam.Object.SubTenantId && x.CMPY_ID == dayEndParam.Object.CompanyId).Entity.FirstOrDefault();

            objTenantPartitionEntity.PRCG_DTE = nextProcessingDate;
            contextExt.Persist();
            return nextProcessingDate;
        }
        #endregion

    }
}
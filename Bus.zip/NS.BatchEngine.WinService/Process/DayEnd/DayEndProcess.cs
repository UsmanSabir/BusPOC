﻿using BatchBootstrapper.Common;
using BusImpl;
using BusLib.BatchEngineCore;
using BusLib.JobSchedular;
using CMS.ServiceContracts;
using NFS.BatchProcessing.Business;
using NFS.Business;
using NFS.Models.BatchProcess.Custom;
using NFS.Models.BatchProcessModel;
using NFS.Models.Common.Custom;
using NFS.Models.Custom.Param;
using NFS.Models.ExternalInterfaces;
using NFS.Models.ExternalInterfaces.Custom.Param;
using NS.BaseModels;
using NS.BatchProcessing.Business.Helpers;
using NS.ExceptionHandling;
using NS.ORM;
using NS.Resources.Enums.InvokeType;
using NS.Utilities;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchBootstrapper.Process
{
    public class DayEndProcess : StatelessProcess<int>
    {
        //private readonly NFS.BatchProcessing.Business.BatchProcessLogic _logicInstance = new NFS.BatchProcessing.Business.BatchProcessLogic();
        public override int ProcessKey => 5304;


        public override void Execute(int item, ITaskContext context)
        {

        }

        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            IEnumerable<int> list = null;
            return list;
        }
        public override void ProcessCompleted(IProcessExecutionContext processContext)
        {
            base.ProcessCompleted(processContext);
        }
        public override void ProcessFinalizer(IProcessFinalizedContext context)
        {
            
            base.ProcessFinalizer(context);
            IProcessExecutionContext processContext = context.ExecutionContext;
            
            try
            {
                BatchProcessLogic _logicInstance = new BatchProcessLogic();
                BatchProcessCriteria criteria = new BatchProcessCriteria();
                criteria.BranchId = processContext.ProcessState.BranchId;
                criteria.CompanyId = processContext.ProcessState.CompanyId;

                if (CommonHelper.IsWorkingDay(processContext.ProcessState.CompanyId, processContext.ProcessState.BranchId, (DateTime)processContext.ProcessingDate) || !CommonHelper.IsWorkingDayConfigured(new WorkingDayCalcParam() { CompanyId = processContext.Criteria.CompanyId, BranchId = processContext.Criteria.BranchId, ValueDte = (DateTime)processContext.ProcessingDate }))
                    BatchProcessCommon.PublishDayEndCompletion(criteria, LogContext.ContextToLog);

                //RequestObject<int> requestObject = new RequestObject<int>(ctxt, (int)processContext.ProcessState.GroupId);
                //if (batchProcess.UPFR_IND && _logicInstance.SetNextWorkingDaySubmitted(requestObject).ResultSet)

                if (processContext.Configuration.RollOverInd)
                {

                    WorkingDayCalcParam param = new WorkingDayCalcParam();
                    param.CompanyId = processContext.ProcessState.CompanyId;
                    param.BranchId = processContext.ProcessState.BranchId;
                    param.ValueDte = processContext.ProcessingDate;

                    if (!CommonHelper.IsWorkingDayConfigured(param))
                    {
                        var exception = "Working Days are not configured against branch:" + param.BranchId;

                        ExceptionHandler.HandleException(new Exception(exception), ExceptionHandlingPolicy.LogOnlyPolicy);
                    }
                    else
                    {
                        var IsWorkingDay = CommonHelper.IsWorkingDay(processContext.ProcessState.CompanyId, processContext.ProcessState.BranchId, processContext.ProcessingDate);

                        if (!IsWorkingDay)
                        {
                            //var container = Bootstrap.Initialize(NS.Configurations.Models.BpemSettings.SubtenantId,"raheelm2" , null, NS.Configurations.Models.BpemSettings.DependProcessComp, 0);
                            //var scheduler = container.Resolve<IJobScheduler>();
                          //  context.Resubmit(new List<JobCriteria>() { processContext.Criteria }, "For Upfront");// ((int)processContext.ProcessState.GroupId, new List<JobCriteria>() { new JobCriteria() { BranchId = processContext.ProcessState.BranchId, CompanyId = processContext.ProcessState.CompanyId, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } }, "raheelm2");
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw;
            }
        }


       
    }
}

﻿using BatchEngine.Core;
using NFS.Models.BatchProcess.Custom;
using NS.BatchEngine.Logs;
using NS.BatchProcessing.Business.Helpers;
using NS.ExceptionHandling;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;

namespace BatchBootstrapper.Process
{
    public class PreDayEndMonthEnd : StatelessProcess<int>
    {
        public override int ProcessKey => 5307; //3344; // 

        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            try
            {
                BatchProcessCriteria criteria = new BatchProcessCriteria();
                criteria.BranchId = processContext.Criteria.BranchId;
                criteria.CompanyId = processContext.Criteria.CompanyId;

                BatchProcessCommon.PublishDayEndStart(criteria, LogContext.ContextToLog.GetCurrentLogContext());
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
            }

            IEnumerable<int> volume = null;
            return volume;
        }
        public override void Execute(int item, ITaskContext context)
        {
            
        }
        public override void ProcessStarting(IProcessExecutionContext processContext)
        {
            
            
        }
    }
}

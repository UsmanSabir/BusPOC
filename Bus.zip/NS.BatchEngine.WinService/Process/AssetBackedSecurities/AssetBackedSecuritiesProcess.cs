﻿using BatchEngine.Core;
using BatchEngine.Core.BatchEngineCore;
using CMS.Business;
using CMS.Models.Custom.Param;
using NFS.Models.BatchProcess.Custom;
using NS.BaseModels;
using NS.Resources.Enums.BatchProcess;
using NS.Resources.Enums.Common;
using NS.ServiceContracts;
using NS.Utilities.Context;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchBootstrapper.Process
{
    public class AssetBackedSecuritiesProcess : StatelessProcess<int>
    {
        public override int ProcessKey => 5302; //2914; 

        private AssetBackedSecuritiesLogic _logicInstance;
        private IIntegrationHubService _integrationHubServiceInstnace { get; set; }

        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            IEnumerable<int> volume = null;
            if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
                return null;
            

            RequestObject<BatchProcessParam> request = new RequestObject<BatchProcessParam>(LogContext.ContextToLog,
           new BatchProcessParam() { BranchId = processContext.ProcessState.BranchId, CompanyId = processContext.ProcessState.CompanyId, BatchProcessType = ProcessType.MoveRequestsToHistory.ToString(), WorkingDay = (DaysYearType)Enum.Parse(typeof(DaysYearType), "NonWorkingDays"/*ProcessCnfg.DAYS_YEAR_TYPE_KEY.Replace(" ", string.Empty)*/), CriteriaMatchDateType = (NS.Resources.Enums.BatchProcess.CriteriaMatchDateType)0/*ProcessCnfg.CRIT_MTCH_DTE_ID*/ });

            IEnumerable<int> response = _logicInstance?.GetReportingContractList(request).ResultSet;
            if (response != null && response.Count<int>() > 0)
            {
                volume = response;
            }
            return volume;
        }
        public override void Execute(int Id, ITaskContext context)
        {
            try
            {
                var param = new AssetBackedSecuritiesParam() { ApplicationId = Id, RetryCount = context.State.FailedCount };
                RequestObject<AssetBackedSecuritiesParam> requestObject = new RequestObject<AssetBackedSecuritiesParam>(LogContext.ContextToLog, param);
                var response = _logicInstance.AbsExtractionMain(requestObject).ResultSet;
                
                if (response == false)
                {
                    context.SetResult(ResultStatus.Invalid);
                    return;
                    //taskCustomResp = new TaskCustomResp("Error", TaskResp.BusinessError);
                    //return Task.FromResult(true);
                }
                return;
                //return Task.FromResult(response);
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                //  throw;
                //  ProcessLogger.Log(ex.StackTrace + "SP NAME: " + Convert.ToString(ex.Procedure) + "Line # " + Convert.ToString(ex.LineNumber) + "Ref Id:" + Convert.ToString(taskItem.REF_ID), ProcessCxt, taskItem.BPEM_STS_KEY, taskItem.RTRY_CNT, taskItem.REF_ID, taskItem.STRT_DTE, DateTime.UtcNow, false, NSLogLevel.Error);
                //taskItem.BPEM_STS_KEY = ProcessHelper.GetStatus(Status.Error);
                //return Task.FromResult(false);
                throw;
                //UpdateTaskItemStatus(taskItem);

            }
            catch (Exception ex)
            {
                //  throw;
              //  ProcessLogger.Log("An error has occurred while executing ABS item." + ex.StackTrace, null, context.State, taskItem.RTRY_CNT, taskItem.REF_ID, taskItem.STRT_DTE, DateTime.UtcNow, false, NSLogLevel.Error);
                //taskItem.BPEM_STS_KEY = ProcessHelper.GetStatus(Status.Error);
                context.SetResult(ResultStatus.Error);
                return;
                //UpdateTaskItemStatus(taskItem);

            }
            context.SetResult(ResultStatus.Error);
            //return Task.FromResult(false);
        }

     
    }
}

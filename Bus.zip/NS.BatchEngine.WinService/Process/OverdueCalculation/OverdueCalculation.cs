﻿using BatchEngine.Core;
using CMS.Business;
using CMS.Models.OverdueCalculation.Custom;
using NFS.Models.BatchProcess.Custom;
using NFS.Models.BatchProcessModel;
using NS.BaseModels;
using NS.ExceptionHandling;
using NS.Resources.Enums.BatchProcess;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchBootstrapper.Process
{
    public class OverdueCalculation : StatelessProcess<int>,IHaveSupportingData
    {
        private List<OdCalcParam> BatchData { get; set; }
       
        public override int ProcessKey => 5315;

        public override void Execute(int Id, ITaskContext context)
        {
            ResponseObject<OdCalcResponseParam> response = null;
            //taskCustomResp = null;
            try
            {
                OverdueCalculationLogic _overdueCalculationInstance = new OverdueCalculationLogic();
                if (context.ProcessExecutionContext.Criteria != null)
                {
                    //LogContext.ContextToLog = ProcessCxt;
                    int contractId = Id;//XmlSerializationHelper.DeSerializeFromString<int>(batchItem.CRIT);
                    OdCalcParam param = new OdCalcParam();
                    if (!BatchData.FirstOrDefault().IsDayEnd)
                    {
                        var data = BatchData.FirstOrDefault(p => p.ContractIds.FirstOrDefault(t => t == contractId) == contractId);

                        param.ContractIds = new List<int>() { contractId };
                        param.IsDayEnd = data.IsDayEnd;
                        param.BatchProcessCriteria.CompanyId = data.BatchProcessCriteria.CompanyId;
                        param.BatchProcessCriteria.BranchId = data.BatchProcessCriteria.BranchId;
                        param.BatchProcessCriteria.ProcessingDate = data.BatchProcessCriteria.ProcessingDate?.AddDays(1);
                        param.IsDeallocation = data.IsDeallocation;
                        param.IsReceiptCancellation = data.IsReceiptCancellation;
                        param.IsPreOdCalculation = data.IsPreOdCalculation;
                        param.IsPostOdCalculation = data.IsPostOdCalculation;
                        param.ValueDate = data.ValueDate;
                        param.ProcessQueuId = data.ProcessQueuId;
                    }
                    else
                    {
                        param = new OdCalcParam() { ContractIds = new List<int> { contractId }, BatchProcessCriteria = new BatchProcessCriteria { CompanyId = BatchData.FirstOrDefault().BatchProcessCriteria.CompanyId, BranchId = BatchData.FirstOrDefault().BatchProcessCriteria.BranchId, ProcessingDate = BatchData.FirstOrDefault().BatchProcessCriteria.ProcessingDate?.AddDays(1) }, IsDayEnd = true, ProcessQueuId = BatchData.FirstOrDefault().ProcessQueuId };
                    }
                    var cntx = LogContext.ContextToLog;
                    cntx.ReferenceId = Id;
                    param.LogInstallmentSettlement = BatchData.FirstOrDefault().LogInstallmentSettlement;
                    param.LogTransactionDetail = BatchData.FirstOrDefault().LogTransactionDetail;
                    RequestObject<OdCalcParam> request = new RequestObject<OdCalcParam>(cntx, param);
                    response = _overdueCalculationInstance.CalculateOverdue(request);
                }

            }
            catch
            {
                throw;
            }

            //return Task.FromResult(true);
        }

        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            OverdueCalculationLogic _overdueCalculationInstance = new OverdueCalculationLogic();
            IEnumerable<int> volume = null;
            List<int> response = new List<int>();
            if (processContext.ProcessState.Criteria.Contains("OdCalcParam"))
            {
                response = new List<int>() { processContext.Criteria.ReferenceId };//XmlSerializationHelper.DeSerializeFromString<List<OdCalcParam>>(batchProcess.CRIT)?.FirstOrDefault()?.ContractIds;
            }
            else
            {
                if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
                    return null;
                //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(batchProcess.CRIT);
                //if (criteria != null)
                //{
                    BatchProcessParam param = new BatchProcessParam() { BranchId = processContext.Criteria.BranchId, CompanyId = processContext.Criteria.CompanyId, ProcessingDate = processContext.Criteria.ProcessingDate };
                    response = _overdueCalculationInstance.GetBatchProcessVolume(param);
                //}
            }
            if (response != null && response.Count > 0)
            {
                volume = response;//response.ConvertAll(x => x.ToString());

            }
            return volume;
        }


        #region Helper Function
        private void SetParentQueueId(BatchProcess batchProcess)
        {
            try
            {
                int odAccountingProcessId = Convert.ToInt32(ProcessName.GenerateOverdueofContractsAccounting.GetKey());
                //BatchProcessCommon.SetParentQueue(batchProcess, odAccountingProcessId);
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
            }
        }
        public override void ProcessCompleted(IProcessExecutionContext processContext)
        {
            SetParentQueueId(new BatchProcess());
        }

        public void InitializeSupportingData(IProcessExecutionContext context)
        {
            if (context.ProcessState.Criteria.Contains("OdCalcParam"))
            {
                BatchData = new List<OdCalcParam>();//XmlSerializationHelper.DeSerializeFromString<List<OdCalcParam>>(batch.CRIT);
                BatchData.Add(new OdCalcParam() {ContractIds = new List<int>() {context.Criteria.ReferenceId}});
            }
            else
            {
                //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(batch.CRIT);
                BatchProcessCriteria criteria = new BatchProcessCriteria();
                criteria.BranchId = context.ProcessState.BranchId;
                criteria.CompanyId = context.ProcessState.CompanyId;
                BatchData = new List<OdCalcParam>();
                BatchData.Add(new OdCalcParam() { BatchProcessCriteria = criteria });
                BatchData.FirstOrDefault().IsDayEnd = true;
                BatchData.FirstOrDefault().ProcessQueuId = (int)context.ProcessState.Id;//batch.PRCS_QUEU_ID;
                OverdueCalculationLogic.SetLogRequestEvent(BatchData.FirstOrDefault());
            }

        }
        #endregion
    }
}

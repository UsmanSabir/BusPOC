﻿//using System;
//using System.Collections.Generic;
//using CMS.Models.ContractActivation;
//using NFS.Models.BatchProcess.Custom;
//using NS.BaseModels;
//using CMS.Business;
//using NS.Utilities.Context;
//using CMS.Models.Custom.Param;
//using NS.Resources.Enums.Common;
//using NFS.Business.CommonHelper;
//using NS.Models.Setups;
//using NFS.Models.TaxConfiguration;
//using NS.ServiceModel;
//using NFS.ServiceContracts;
//using NS.Models.BusinessRules.Custom;
//using NS.ServiceContracts;
//using BatchEngine.Core;
//using BatchEngine.Core.BatchEngineCore;

//namespace NS.BatchProcessing.Business.Processes.SetFloatingInterestRate
//{
//    public class SetFloatingInterestRate : StatelessProcess<int>//, IHaveSupportingData
//    {
//        //private List<FpRentalTemplateForBaseRate> _fpRentalTemplateBaseRate;
//        ////public List<RentalFrequencyTypeCode> _frequencies { get; set; }
//        //public int _countryID { get; set; }
//        //public List<AllComponentTaxConfiguration> _TaxComponentPriority { get; set; }
//        //public List<FpChartInfo> _MasterIdResponse { get; set; }
//        public override int ProcessKey => 5305; // 2844;
//        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
//        {

//            var logicContractActivationInstance = new ContractActivationServiceLogic();

//            IEnumerable<int> volume = null;
//            if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
//                return null;
//            //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(batchProcess.CRIT);
//            RequestObject<BatchProcessParam> request = new RequestObject<BatchProcessParam>(LogContext.ContextToLog,
//            new BatchProcessParam()
//            {
//                BranchId = processContext.Criteria.BranchId,
//                CompanyId = processContext.Criteria.CompanyId,
//                ProcessingDate = CommonHelper.GetNextWorkingDay(processContext.Criteria.ProcessingDate, (DaysYearType)Enum.Parse(typeof(DaysYearType),
//                        processContext.Configuration.DaysYearTypeKey.Replace(" ", string.Empty)),
//                        processContext.Criteria.CompanyId, processContext.Criteria.BranchId)
//            });

//            List<int> response = logicContractActivationInstance.VaraibleIntersetRateGenerateVolume(request);
//            //response.Add(1663);// _logicContractActivationInstance.VaraibleIntersetRateGenerateVolume(request);
//            //if (response != null && response.Count > 0)
//            //{
//            //    volume = response.ConvertAll(x => x.ToString());
//            //    //ProcessLogger.Log(string.Format("Volume for VIR is {0}.", volume.Count), ProcessCxt.GetContextObject(), "Completed", 0, 0, DateTime.Now, null, false, NSLogLevel.Info);

//            //}
//            if (response != null && response.Count > 0)
//                volume = response;
//            return volume;
//        }

       
//        public override void Execute(int id, ITaskContext context)
//        {
//            bool response = true;
//            try
//            {
//                ContractActivationServiceLogic logicContractActivationInstance = new ContractActivationServiceLogic();

//                if (context.ProcessExecutionContext.Criteria != null)
//                {
//                    //LogContext.ContextToLog = ProcessCxt;

//                    //int contractId = XmlSerializationHelper.DeSerializeFromString<int>(batchItem.CRIT);
//                    //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(ProcessInstance.CRIT);

//                    var freq = context.ProcessExecutionContext.GetTempData<List<RentalFrequencyTypeCode>>("Freq");
//                    var rentalTempl = context.ProcessExecutionContext.GetTempData<List<FpRentalTemplateForBaseRate>>("rentalTempl");
//                    var taxComp = context.ProcessExecutionContext.GetTempData<List<AllComponentTaxConfiguration>>("taxComp");
//                    var contry = context.ProcessExecutionContext.GetTempData<int> ("contry");
//                    var mstrId = context.ProcessExecutionContext.GetTempData<List<FpChartInfo>>("mstrId");

//                    VariableRateParam param = new VariableRateParam()
//                    {
//                        ContractId = id,
//                        ProcessingDate = CommonHelper.GetNextWorkingDay(context.ProcessExecutionContext.Criteria.ProcessingDate, (DaysYearType)Enum.Parse(typeof(DaysYearType),
//                        context.ProcessExecutionContext.Configuration.DaysYearTypeKey.Replace(" ", string.Empty)),
//                        context.ProcessExecutionContext.Criteria.CompanyId, context.ProcessExecutionContext.Criteria.BranchId),
//                        Frequencies = freq,
//                        BaseRateConfiguration = rentalTempl,
//                        TaxComponentPriority = taxComp,
//                        CountryID = contry,
//                        MasterIdResponse = mstrId,
//                        CurrentProcessingDate = context.ProcessExecutionContext.Criteria.ProcessingDate,
//                    };
//                    var cntx = LogContext.ContextToLog;
//                    cntx.ReferenceId = id;
//                    RequestObject<VariableRateParam> request = new RequestObject<VariableRateParam>(cntx, param);

//                    request.Object.Frequencies = freq;
//                    //logicContractActivationInstance.ConnectionString = NS.Configurations.Models.BpemSettings.BusinessDatabase.ConnectionString;
//                    logicContractActivationInstance.IsDayend = true;
//                    response = logicContractActivationInstance.ProcessVariableInterestRateContracts(request).ResultSet;

//                    if (response == false)
//                    {
//                        context.SetResult(ResultStatus.Invalid);
//                    }
//                }
//            }
//            catch
//            {
//                throw;
//            }
//            context.SetResult(ResultStatus.Success);
//        }
//        public override void ProcessStarting(IProcessExecutionContext processContext)
//        {
//            var ctx = LogContext.ContextToLog;


//            var _frequencies = GetRentalFrequencyTypeCode(processContext);
//            var _fpRentalTemplateBaseRate = GetFpRentalTemplateBaseRate(processContext);
//            var _countryID = ReadCountry(processContext);
//            var _TaxComponentPriority = GetTaxComponentPriority(processContext, _countryID);
//            var _MasterIdResponse = GetChartIds(processContext, _countryID);

//            processContext.SetTempData("Freq", _frequencies);
//            processContext.SetTempData("rentalTempl", _fpRentalTemplateBaseRate);
//            processContext.SetTempData("taxComp", _TaxComponentPriority);
//            processContext.SetTempData("contry", _countryID);
//            processContext.SetTempData("mstrId", _MasterIdResponse);

//            base.ProcessStarting(processContext);
//        }

//        #region Private
//        private int ReadCountry(IProcessExecutionContext processContext)
//        {
//            try
//            {
//                int response = 0;
//                if (processContext.Criteria.CompanyId > 0)
//                {

//                    var srv = ChannelFactory.CreateChannel<IBusinessPartnerService>();
//                    var requestParam = new RequestObject<int>(LogContext.ContextToLog, processContext.Criteria.CompanyId);
//                    var responseObject = srv.ReadFCCountry(requestParam);
//                    if (responseObject != null)
//                    {
//                        response = Convert.ToInt16(responseObject?.ResultSet.CTRY_ID);
//                    }
//                    return response;
//                }
//                return 0;
//            }
//            catch (Exception ex)
//            {
//                return 0;
//            }
//        }
//        List<FpRentalTemplateForBaseRate> GetFpRentalTemplateBaseRate(IProcessExecutionContext processContext)
//        {

//            DateTime expiry = DateTime.Now;
//            var cacheSrv = ChannelFactory.CreateChannel<NS.ServiceContracts.ICacheService>();
//            var items = new List<Tuple<NS.Resources.Enums.Cache.CustomCacheItems, DateTime>>
//            {
//                new Tuple<Resources.Enums.Cache.CustomCacheItems, DateTime>(Resources.Enums.Cache.CustomCacheItems.Processconfigcache, expiry)
//            };
//            var cacheParam = new Models.Cache.CacheParam<NS.Resources.Enums.Cache.CustomCacheItems> { CacheItems = items };

//            var request = new RequestObject<NS.Models.Cache.CacheParam<NS.Resources.Enums.Cache.CustomCacheItems>>(LogContext.ContextToLog, cacheParam);
//            var data = cacheSrv.GetFpRentalTemplateBaseRate(request);

//            return data.ResultSet.CacheData;


//        }
//        private List<RentalFrequencyTypeCode> GetRentalFrequencyTypeCode(IProcessExecutionContext processContext)
//        {
//            DateTime expiry = DateTime.Now;
//            var cacheSrv = NS.ServiceModel.ChannelFactory.CreateChannel<NS.ServiceContracts.ICacheService>();
//            var items = new List<Tuple<NS.Resources.Enums.Cache.CustomCacheItems, DateTime>>
//            {
//                new Tuple<NS.Resources.Enums.Cache.CustomCacheItems, DateTime>(NS.Resources.Enums.Cache.CustomCacheItems.Processconfigcache, expiry)
//            };
//            var cacheParam = new NS.Models.Cache.CacheParam<NS.Resources.Enums.Cache.CustomCacheItems> { CacheItems = items };

//            var request = new RequestObject<NS.Models.Cache.CacheParam<NS.Resources.Enums.Cache.CustomCacheItems>>(LogContext.ContextToLog, cacheParam);
//            var data = cacheSrv.GetRentalFrequencyTypeCode(request);

//            return data.ResultSet.CacheData;


//        }

//        private List<AllComponentTaxConfiguration> GetTaxComponentPriority(IProcessExecutionContext processContext, int countryID)
//        {
//            DateTime expiry = DateTime.Now;
//            var cacheSrv = NS.ServiceModel.ChannelFactory.CreateChannel<NS.ServiceContracts.ICacheService>();
//            var items = new List<Tuple<NS.Resources.Enums.Cache.CustomCacheItems, DateTime>>
//            {
//                new Tuple<NS.Resources.Enums.Cache.CustomCacheItems, DateTime>(NS.Resources.Enums.Cache.CustomCacheItems.Processconfigcache, expiry)
//            };
//            var cacheParam = new NS.Models.Cache.CacheParam<NS.Resources.Enums.Cache.CustomCacheItems> { CacheItems = items };

//            cacheParam.CompanyId = processContext.Criteria.CompanyId;
//            cacheParam.ScreenId = countryID;
//            var request = new RequestObject<NS.Models.Cache.CacheParam<NS.Resources.Enums.Cache.CustomCacheItems>>(LogContext.ContextToLog, cacheParam);
//            var data = cacheSrv.GetTaxComponentPriority(request);

//            return data.ResultSet.CacheData;


//        }
//        private List<FpChartInfo> GetChartIds(IProcessExecutionContext processContext, int countryID)
//        {
//            DateTime expiry = DateTime.Now;
//            using (var serviceInstance = new ProxyClient<ICacheService>())
//            {
//                var items = new List<Tuple<NS.Resources.Enums.Cache.CustomCacheItems, DateTime>>
//            {
//                new Tuple<NS.Resources.Enums.Cache.CustomCacheItems, DateTime>(NS.Resources.Enums.Cache.CustomCacheItems.Etandstructuredrequest, expiry)
//            };
//                var cacheParam = new NS.Models.Cache.CacheParam<NS.Resources.Enums.Cache.CustomCacheItems> { CacheItems = items };
//                cacheParam.CompanyId = processContext.Criteria.CompanyId;
//                cacheParam.ScreenId = countryID;
//                var request = new RequestObject<NS.Models.Cache.CacheParam<NS.Resources.Enums.Cache.CustomCacheItems>>(LogContext.ContextToLog, cacheParam);
//                var data = serviceInstance.ClientInstance.GetChartIds(request);
//                return data.ResultSet.CacheData;
//            }

//        }
//        #endregion
//    }
//}

﻿using BatchEngine.Core;
using CMS.Business;
using CMS.Models.DirectDebit.Custom;
using NS.BaseModels;
using NS.Utilities.Context;
using NS.Utilities.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace BatchBootstrapper.Process
{
    class TestEEProcess : StatefulProcess<int>
    {
        public override int ProcessKey => 5305;
        Context ctxt = new Context()
        {
            ApplicationCode = "BPEM",
            ContextId = Guid.NewGuid(),
            SessionId = 12,
            SessionCode = "14",
            LoginId = "BPEM", //Environment.UserName,
            MachineIp = "127.0.0.1",
            UserName = "BPEM", //Environment.UserName,
            SubTenantId = 1,
            ReferenceId = 1,

            CustomParameters = new NS.Utilities.SerializableDictionary<string, object>()
                    {
                        { "ServerIP", ConfigurationManager.AppSettings["ApplicationServer"]}
                    }
        };

        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            IEnumerable<int> volume = null;
            var xml = processContext.Criteria.Tag;

            if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
                return null;

            DirectDebitLogic _ddLogicInstance = new DirectDebitLogic();
            IEnumerable<int> ddVolume;
            try
            {
                if (xml.Contains("DirectDebit"))
                {
                    DirectDebitParam criteria = XmlSerializationHelper.DeSerializeFromString<DirectDebitParam>(xml);
                    criteria.ProcessQueueId = (int)processContext.ProcessState.Id;
                    volume = _ddLogicInstance.GetDirectDebitVolumeForBatchProcess(new RequestObject<DirectDebitParam>(ctxt, criteria)).ResultSet;
                }
                else
                {
                    volume = _ddLogicInstance.GetDirectDebitVolumeForBatchProcess(new RequestObject<DirectDebitParam>(ctxt,
                            new DirectDebitParam
                            {
                                BranchId = processContext.ProcessState.BranchId,
                                FinanceCompanyId = processContext.ProcessState.CompanyId,
                                CurrentProcessingDate = processContext.ProcessingDate,
                                ProcessQueueId = (int)processContext.ProcessState.Id, //batchProcess.PRCS_QUEU_ID
                            })).ResultSet;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return volume;
        }

        public override void InitializeStates()
        {
            //DefineState("Settlment", DoSettlment);
            //DefineState("Reciept", DoRecpt);
        }

        //private void DoRecpt(int id, ITaskContext context)
        //{
            
        //}

        //private void DoSettlment(int id, ITaskContext context)
        //{
            
        //}
    }
}

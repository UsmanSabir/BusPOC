﻿using BatchEngine.Core;
using NFS.Business;
using NFS.Business.Helper;
using NFS.Models.Accounting.Custom.Param;
using NS.Resources.Enums.Common;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;

namespace BatchBootstrapper.Process
{
    public class AccountingEntries : StatelessProcess<int>
    {
        public override int ProcessKey => 5309;//2910; //
        private readonly AccountingLogic _logicInstance = new AccountingLogic();
        public override void Execute(int id, ITaskContext context)
        {
            if (context.ProcessExecutionContext.Criteria != null)
            {
                int eventLogId = context.ProcessExecutionContext.Criteria.ReferenceId;//XmlSerializationHelper.DeSerializeFromString<int>(batchItem.CRIT);
                var cntx = LogContext.ContextToLog;
                cntx.ReferenceId = id;
                var result = _logicInstance.ReadEventLog(new NS.BaseModels.RequestObject<int>(cntx, eventLogId)).ResultSet;

                var param = new AccParam { EventId = result.EVNT_ID, RefId1 = result.REF_ID_1, RefId2 = result.REF_ID_2, RefId3 = result.REF_ID_3, RequestTypeKey = result.REQT_TYPE_KEY, EventLogId = result.EVNT_LOG_ID, CompanyId = result.FC_ID.Value };
                AccountingListener helper = new AccountingListener(context.ProcessExecutionContext.Criteria.ProcessingDate);

                if (param.RequestTypeKey.Contains(RequestTypeCodes.TransactionDetail.GetKey()))
                {
                    helper.GenerateGeneralAccountingEntries(param, cntx);
                }
                else
                {
                    helper.GenerateAccountingEntries(param, cntx);
                }
            }
            //return Task.FromResult(response);
        }
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            List<int> volume = new List<int>();

            if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
                return null;
            volume.Add(processContext.Criteria.ReferenceId);
            return volume;
        }
    }
}

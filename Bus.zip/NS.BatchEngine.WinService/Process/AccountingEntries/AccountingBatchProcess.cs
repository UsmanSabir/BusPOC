﻿using BatchEngine.Core;
using NFS.Business;
using NFS.Business.Helper;
using NFS.Models.Accounting;
using NFS.Models.Accounting.Custom.Param;
using NS.ExceptionHandling;
using NS.ORM;
using NS.Resources.Enums.Common;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchBootstrapper.Process
{
    public class AccountingBatchProcess : StatelessProcess<int>
    {
        public override int ProcessKey => 10000; // Call from different classes
       
        public override void Execute(int id, ITaskContext context)
        {
            try
            {
                if (context.ProcessExecutionContext.Criteria != null)
                {
                    AccountingLogic logicInstance = new AccountingLogic();

                    int eventLogId = context.ProcessExecutionContext.Criteria.ReferenceId;//XmlSerializationHelper.DeSerializeFromString<int>(batchItem.CRIT);
                    var cntx = LogContext.ContextToLog;
                    cntx.ReferenceId = id;
                    var result = logicInstance.ReadEventLog(new NS.BaseModels.RequestObject<int>(cntx, eventLogId)).ResultSet;

                    var param = new AccParam { EventId = result.EVNT_ID, RefId1 = result.REF_ID_1, RefId2 = result.REF_ID_2, RefId3 = result.REF_ID_3, RequestTypeKey = result.REQT_TYPE_KEY, EventLogId = result.EVNT_LOG_ID, CompanyId = result.FC_ID.Value };
                    AccountingListener helper = new AccountingListener(context.ProcessExecutionContext.Criteria.ProcessingDate);

                    if (param.RequestTypeKey.Contains(RequestTypeCodes.TransactionDetail.GetKey()))
                    {
                        helper.GenerateGeneralAccountingEntries(param, cntx);
                    }
                    else
                    {
                        helper.GenerateAccountingEntries(param, cntx);
                    }
                }
            }
            catch
            {
                throw;
            }
            //return Task.FromResult(response);
        }
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            IEnumerable<int> volume = null;
            if (String.IsNullOrEmpty(processContext.ProcessState.Criteria) || processContext.ProcessState.ParentId.HasValue == false)
            {
                //ProcessLogger.LogMessage($"NULL VOLUME: Empty {(batchProcess.PRNT_QUEU_ID.HasValue ? "CRIT" : "PRNT_QUEU_ID")}", ProcessCxt, NSLogLevel.Error);
                return null;
            }
            
            List<int> response = GetAccountingData(processContext.ProcessState.ParentId.ToString());
            if (response != null && response.Count > 0)
            {
                volume = response;//response.ConvertAll(x => x.ToString());

            }
            return volume;
        }
        #region Private Memebers
        /// <summary>
        /// GetDayEndAccountingContracts
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private List<int> GetAccountingData(string proessQueueId)
        {
            List<int> volume = null;
            try
            {
                var contextExt = EntityContextExt.Create<AccountingBatchVolume>();
                contextExt.Read(p => p.REF_ID_4 == proessQueueId);
                var data = contextExt.Entity;
                if (data != null && data.Count > 0)
                {
                    volume = data.Select(p => Convert.ToInt32(p.EVNT_LOG_ID)).ToList();
                    ////testing
                    //volume = volume.GetRange(0, 1);
                    //volume[0] = 457;
                    ////
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                volume = null;
            }
            return volume;
        }
        #endregion
    }
}

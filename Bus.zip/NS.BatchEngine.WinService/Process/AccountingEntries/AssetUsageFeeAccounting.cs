﻿using BatchEngine.Core;
using CMS.Models.ContractActivation;
using NFS.Models.BatchProcess.Custom;
using NFS.SchedulerEventDispatcher;
using NS.BaseModels;
using NS.ExceptionHandling;
using NS.Models.Events.Custom;
using NS.ORM;
using NS.Resources.Enums.Charges;
using NS.Resources.Enums.Common;
using NS.Resources.Enums.EventDispatcher;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchBootstrapper.Process
{
    public class AssetUsageFeeAccounting : StatelessProcess<int>
    {
        public override int ProcessKey => 5310;//3270;//
        public override void Execute(int Id, ITaskContext context)
        {
            try
            {
                if (context.ProcessExecutionContext.Criteria !=null)
                {
                    //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(ProcessInstance.CRIT);
                    int referenceId = context.ProcessExecutionContext.Criteria.ReferenceId;//XmlSerializationHelper.DeSerializeFromString<int>(batchItem.CRIT);
                }
            }
            catch
            {
                throw;
            }
        }
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(batchProcess.CRIT);
            //List<string> volume = null;
            //if (String.IsNullOrEmpty(batchProcess.CRIT))
            //    return null;

            //DateTime NextProcessingDate = CommonHelper.GetNextWorkingDay(criteria.ProcessingDate.Value, (DaysYearType)Enum.Parse(typeof(DaysYearType), ProcessCnfg.DAYS_YEAR_TYPE_KEY.Replace(" ", string.Empty)), criteria.CompanyId, criteria.BranchId);
            //BatchProcessParam param = new BatchProcessParam() { BranchId = criteria.BranchId, CompanyId = criteria.CompanyId, ProcessingDate = criteria.ProcessingDate.Value, NextProcessingDate = NextProcessingDate };

            //List<int> response = GetAssetUsageFeeCharges(param);
            //if (response != null && response.Count > 0)
            //{
            //    volume = response.ConvertAll(x => x.ToString());

            //}
            IEnumerable<int> volume = null;
            return volume;
        }
        #region Private Memebers

        /// <summary>
        /// GetAssetUsageFeeCharges
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private List<int> GetAssetUsageFeeCharges(BatchProcessParam param)
        {
            List<int> volume = null;
            try
            {
                var contextExt = EntityContextExt.Create<ContractCharge>();
                int assetUsageFeeChargeTypeId = Convert.ToInt16(ChargeReceivableType.AssetUsageFee.GetKey());
                var localdata = contextExt.Read(x => x.CHRG_TYPE_ID == assetUsageFeeChargeTypeId && x.DUE_DTE == param.ProcessingDate);
                var data = localdata.Entity;

                if (data != null && data.Count > 0)
                {
                    volume = data.Select(p => Convert.ToInt32(p.CONT_CHRG_ID)).ToList();
                    ////testing
                    //volume = volume.GetRange(0, 1);
                    //volume[0] = 457;
                    ////
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                volume = null;
            }
            return volume;
        }
        public void GenerateAccountEntryForExcessMileageCharge(Context context, int ChargeRefId, int companyId = 0, int brancId = 0)
        {
            try
            {
                var logic = new EventDispatcherLogicNfs();
                var parm = new EventParm()
                {
                    ApplicationKey = context.ApplicationCode,
                    ModuleKey = ModuleTypeCode.OPTION_TO_PURCHASE.GetKey(),
                    EventId = 11,
                    RefId = Convert.ToString(ChargeRefId),
                    RefId1 = Convert.ToString(ChargeRefId),
                    RequestType = RequestTypeCodes.CreationAndWaiver.GetKey(),
                    ContextData = context,
                    BranchID = brancId,
                    FcId = companyId,
                    PostActionsEnum = new List<EventDispatcherEnum>() { EventDispatcherEnum.AccountingListenerEvent }
                };
                var request = new RequestObject<EventParm>(context, parm);
                logic.TriggerEvent(request);

            }
            catch (Exception)
            {
            }
        }
        #endregion
    }
}

﻿using BatchEngine.Core;
using NFS.Models.Accounting;
using NFS.Models.BatchProcess.Custom;
using NS.BatchProcessing.Business.Helpers;
using NS.ExceptionHandling;
using NS.ORM;
using NS.Resources.Enums.Common;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchBootstrapper.Process
{
    public class DayEndAccountingProcess : StatelessProcess<int>
    {
        public override int ProcessKey => 5306; //3024;//
        public override void Execute(int id, ITaskContext context)
        {
            try
            {
                if (context.ProcessExecutionContext.Criteria != null)
                {
                    //LogContext.ContextToLog = ProcessCxt;
                    //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(ProcessInstance.CRIT);
                    BatchProcessCriteria criteria = new BatchProcessCriteria();
                    criteria.BranchId = context.ProcessExecutionContext.ProcessState.BranchId;
                    criteria.CompanyId = context.ProcessExecutionContext.ProcessState.CompanyId;
                    int contractId = id;//XmlSerializationHelper.DeSerializeFromString<int>(batchItem.CRIT);
                    BatchProcessCommon.CallAccountingEntries(criteria, contractId, LogContext.ContextToLog, RequestTypeCodes.DayEnd, EventCode.OnApproved);
                }
            }
            catch (Exception)
            {

                throw;
            }
            //return Task.FromResult(true);
        }
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(batchProcess.CRIT);
            //List<string> volume = null;
            IEnumerable<int> volume = null;
            if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
                return null;

            BatchProcessParam param = new BatchProcessParam() { BranchId = processContext.Criteria.BranchId, CompanyId = processContext.Criteria.CompanyId, ProcessingDate = processContext.Criteria.ProcessingDate };
            //Pass Company and BrnachId as well
            List<int> response = GetDayEndAccountingContracts(param);
            if (response != null && response.Count > 0)
            {
                volume = response;//response.ConvertAll(x => x.ToString());

            }
            return volume;
        }
        #region Private Memebers

        /// <summary>
        /// GetDayEndAccountingContracts
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private List<int> GetDayEndAccountingContracts(BatchProcessParam param)
        {
            List<int> volume = null;
            try
            {
                var contextExt = EntityContextExt.Create<DayEndAccountingVolume>();
                contextExt.Read(param.ProcessingDate, param.CompanyId, param.BranchId);
                var data = contextExt.Entity;
                if (data != null && data.Count > 0)
                {
                    volume = data.Select(p => Convert.ToInt32(p.CONT_ID)).ToList();
                    ////testing
                    //volume = volume.GetRange(0, 1);
                    //volume[0] = 457;
                    ////
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                volume = null;
            }
            return volume;
        }
        #endregion
    }
}

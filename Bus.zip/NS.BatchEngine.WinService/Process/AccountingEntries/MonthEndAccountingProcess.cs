﻿using BatchEngine.Core;
using NFS.Models.Accounting;
using NFS.Models.BatchProcess.Custom;
using NS.BatchProcessing.Business.Helpers;
using NS.ExceptionHandling;
using NS.ORM;
using NS.Resources.Enums.Common;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchBootstrapper.Process
{
    public class MonthEndAccountingProcess : StatelessProcess<int>
    {
        public override int ProcessKey => 5308;//3025;//
        public override void Execute(int id, ITaskContext context)
        {
            //taskCustomResp = null;
            try
            {
                if (context.ProcessExecutionContext.Criteria!=null)
                {
                    //LogContext.ContextToLog = ProcessCxt;
                    //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(ProcessInstance.CRIT);
                    BatchProcessCriteria criteria = new BatchProcessCriteria();
                    criteria.BranchId = context.ProcessExecutionContext.ProcessState.BranchId;
                    criteria.CompanyId = context.ProcessExecutionContext.ProcessState.CompanyId;
                    int contractId = id;//XmlSerializationHelper.DeSerializeFromString<int>(batchItem.CRIT);
                    //PublishAccountingEntries(criteria, contractId);
                    BatchProcessCommon.CallAccountingEntries(criteria, contractId, LogContext.ContextToLog, RequestTypeCodes.MonthEnd, EventCode.OnSave);
                }
            }
            catch (Exception)
            {

                throw;
            }
            //return Task.FromResult(true);
        }
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            //BatchProcessCriteria criteria = XmlSerializationHelper.DeSerializeFromString<BatchProcessCriteria>(batchProcess.CRIT);
            //List<string> volume = null;
            IEnumerable<int> volume = null;
            if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
                return null;

            BatchProcessParam param = new BatchProcessParam() { BranchId = processContext.Criteria.BranchId, CompanyId = processContext.Criteria.CompanyId, ProcessingDate = processContext.Criteria.ProcessingDate };
            //Pass Company and BrnachId as well
            List<int> response = GetMonthEndAccountingContractsByPagging(param);
            if (response != null && response.Count > 0)
            {
                volume = response;//response.ConvertAll(x => x.ToString());

            }
            return volume;
        }
        #region Private Memebers
        /// <summary>
        /// 
        /// </summary>
        /// <param name="criteria"></param>
        /// <param name="contId"></param>
        //private void PublishAccountingEntries(BatchProcessCriteria criteria, int contId)
        //{
        //    //todo use microworkflow that will have EventDispatcherActivity activity instead of service call
        //    var context = ProcessCxt.GetContextObject();
        //    var eventParam = new EventParm()
        //    {
        //        RequestType = RequestTypeCodes.MonthEnd.GetKey(),
        //        ApplicationKey = "CMS",
        //        BranchID = criteria.BranchId,
        //        EventId = 5, //Convert.ToInt32(EventCode.Save)
        //        ContextData = context,
        //        ModuleKey = ModuleTypeCode.BATCH_PROCESS_EXECUTION.GetKey(),
        //        RefId1 = contId.ToString(),
        //        FcId = criteria.CompanyId,
        //        PostActionsEnum = new List<Resources.Enums.EventDispatcher.EventDispatcherEnum> { Resources.Enums.EventDispatcher.EventDispatcherEnum.AccountingListenerEvent }
        //    };
        //    //todo use microworkflow that will have EventDispatcherActivity activity instead of service call

        //    var request = new RequestObject<EventParm>(context, eventParam);
        //    using (var svc = new ProxyClient<IEventDispatcherLogicService>())
        //    {
        //        svc.ClientInstance.TriggerEvent(request);
        //    }
        //}
        private List<int> GetMonthEndAccountingContracts(BatchProcessParam param, int startContId, int endContId)
        {
            var data = MonthEndAccounting.ReadMonthEndVolum(param.ProcessingDate, param.CompanyId, param.BranchId, startContId, endContId, 300);
            if (data != null && data.Count > 0)
            {
                return data.Select(p => Convert.ToInt32(p.CONT_ID)).ToList();
            }

            return null;
        }
        private List<int> GetMonthEndAccountingContractsByPagging(BatchProcessParam param)
        {
            List<int> volume = null;
            int pageSize = 5000;
            try
            {
                volume = new List<int>();
                var contextExt = EntityContextExt.Create<ContIdsByGroupPagging>(commandTimeOut: 300);
                contextExt.Read(param.CompanyId, param.BranchId, pageSize);
                var data = contextExt.Entity;

                if (data != null && data.Count > 0)
                {
                    foreach (var contRange in data.ToList())
                    {
                        var pageVolume = GetMonthEndAccountingContracts(param, contRange.MIN_CONT_ID.Value, contRange.MAX_CONT_ID.Value);

                        if (pageVolume != null)
                            volume.AddRange(pageVolume);
                    }

                }

            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                volume = null;
            }

            return volume;

        }
        #endregion
    }
}

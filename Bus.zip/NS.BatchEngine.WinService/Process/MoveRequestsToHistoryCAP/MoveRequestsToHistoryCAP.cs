﻿using System.Collections.Generic;
using System.Linq;
using System;
using NS.Business;
using NS.BaseModels;
using NS.Resources.Enums.BatchProcess;
using NS.Resources.Enums.Common;
using NFS.Models.BatchProcess.Custom;
using NS.Utilities.Context;
using NLog;
using BatchEngine.Core;
using BatchEngine.Core.BatchEngineCore;

namespace BatchBootstrapper.Process
{
    public class MoveRequestsToHistoryCAP : StatelessProcess<int>
    {
        public override int ProcessKey => 5301;//3243; 

        TaskQueueLogic logicInstance = new TaskQueueLogic();
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            IEnumerable<int> volume = null;
            //if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
            //    return null;
            
            RequestObject<BatchProcessParam> request = new RequestObject<BatchProcessParam>(LogContext.ContextToLog,
            new BatchProcessParam() { BranchId = processContext.ProcessState.BranchId, CompanyId = processContext.ProcessState.CompanyId,ProcessingDate = processContext.Criteria.ProcessingDate ,BatchProcessType = ProcessType.MoveRequestsToHistory.ToString(), WorkingDay = (DaysYearType)Enum.Parse(typeof(DaysYearType), processContext.Configuration.DaysYearTypeKey.Replace(" ", string.Empty)/*ProcessCnfg.DAYS_YEAR_TYPE_KEY.Replace(" ", string.Empty)*/), CriteriaMatchDateType = (NS.Resources.Enums.BatchProcess.CriteriaMatchDateType)0/*ProcessCnfg.CRIT_MTCH_DTE_ID*/ });
            
            volume = logicInstance.GetBatchProcessVolumeCAP(request);
            
            if (volume != null && volume.Count<int>() > 0)
            {
                return volume;
            }
            return volume;
        }
        public override void Execute(int TaskQueueId, ITaskContext context)
        {
            try
            {
                RequestObject<int> request = new RequestObject<int>(LogContext.ContextToLog, TaskQueueId); // 

                bool response = logicInstance.MoveRequestToHistory(request);
                if (!response)
                    context.SetResult(ResultStatus.Error);               
            }
            catch(Exception ex)
            {
                throw;
            }

            #region default Implementation
            //var processData = context.ProcessExecutionContext.GetProcessData<string>("test_w");
            //context.Logger.Info($"Data read from store= {processData}");


            //if (id % 5 == 0 && context.DeferredCount < 30)
            //{
            //    context.Logger.Info("Going to defer");
            //    var isDeferred = context.Defer();
            //    if (isDeferred)
            //    {
            //        context.Logger.Info($"Task deferred {context.State.DeferredCount}");
            //        return;
            //    }
            //    else
            //    {
            //        context.Logger.Warn($"Task deferred Failed {context.State.DeferredCount}");
            //    }
            //}

            //Thread.Sleep(2000);
            #endregion
        }

     
    }
}
﻿using BatchEngine.Core;
using System;
using System.Collections.Generic;

namespace BatchBootstrapper.Process
{
    public class DDFileUploadProcess : StatelessProcess<int>
    {
        public override int ProcessKey => 1000000;
       

        public override void Execute(int item, ITaskContext context)
        {
            //throw new NotImplementedException();
        }

        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            throw new NotImplementedException();
        }
    }
}

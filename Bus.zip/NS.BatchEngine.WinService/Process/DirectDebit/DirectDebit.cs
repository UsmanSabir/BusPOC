﻿using BatchEngine.Core;
using BatchEngine.Core.BatchEngineCore;
using CMS.Business;
using CMS.Models.DirectDebit;
using CMS.Models.DirectDebit.Custom;
using NS.BaseModels;
using NS.Resources.Enums.Common;
using NS.Utilities.Context;
using NS.Utilities.Helper;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchBootstrapper.Process
{
    public class DirectDebit : StatelessProcess<int>, IHaveSupportingData
    {
        static readonly object _object = new object();
        private static Dictionary<int, TaskData> TaskDataSet = new Dictionary<int, TaskData>();
        //private DirectDebitParam _ddParam;
        public override int ProcessKey => 5304; //2537; //
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            IEnumerable<int> volume = null;
            var xml = processContext.Criteria.Tag;



            if (String.IsNullOrEmpty(processContext.ProcessState.Criteria))
                return null;

            DirectDebitLogic _ddLogicInstance = new DirectDebitLogic();
            IEnumerable<int> ddVolume;
            try
            {
                
                if (xml.Contains("DirectDebit"))
                {
                    DirectDebitParam criteria = XmlSerializationHelper.DeSerializeFromString<DirectDebitParam>(xml);
                    criteria.ProcessQueueId = (int)processContext.ProcessState.Id;
                    
                    ddVolume = _ddLogicInstance.GetDirectDebitVolumeForBatchProcess(new RequestObject<DirectDebitParam>(LogContext.ContextToLog, criteria)).ResultSet;
                }
                else
                {
                    ddVolume = _ddLogicInstance.GetDirectDebitVolumeForBatchProcess(new RequestObject<DirectDebitParam>(LogContext.ContextToLog,
                            new DirectDebitParam
                            {
                                BranchId = processContext.ProcessState.BranchId,
                                FinanceCompanyId = processContext.ProcessState.CompanyId,
                                CurrentProcessingDate = processContext.ProcessingDate,
                                ProcessQueueId = (int)processContext.ProcessState.Id, //batchProcess.PRCS_QUEU_ID
                        })).ResultSet;
                }
            }
            catch(Exception ex)
            {
                throw;
            }

            if (ddVolume != null && ddVolume.Count<int>() > 0)
            {
                volume = ddVolume;
            }
            return volume;
        }

        public override void Execute(int Id, ITaskContext context)
        {
            bool response = true;
            var _ddParam = context.ProcessExecutionContext.GetSetTempData<DirectDebitParam>("DDParam", ()=> GetParam(context.ProcessExecutionContext));

            try
            {
                DirectDebitLogic _ddLogicInstance = new DirectDebitLogic();

                int contractId = Id;

                if (!(context.State.FailedCount > 0))
                {
                    //AddTaskData(batchItem.BTCH_ITEM_QUEU_ID);
                    AddTaskData((int)context.State.Id);
                }

                RequestObject<Tuple<DirectDebitParam, int, int>> requestObject1 = new RequestObject<Tuple<DirectDebitParam, int, int>>
                    (LogContext.ContextToLog, Tuple.Create(_ddParam, contractId, context.State.FailedCount));

                requestObject1.Context.WorkDate = context.ProcessExecutionContext.ProcessingDate;
                requestObject1.Object.Item1.Context.WorkDate = context.ProcessExecutionContext.ProcessingDate;

                //response = _ddLogicInstance.ExecuteFileGenerationTask(requestObject1, TaskDataSet.ContainsKey((int)context.State.Id) ? TaskDataSet[(int)context.State.Id] : null).ResultSet;

                //final persistence
                // batchItem.RESN_ID = null;
                //var taskItemContext = NS.ORM.EntityContextExt.Create(new[] { batchItem });
                //taskItemContext.Persist();

                //clearance
                //RemoveTaskData(batchItem.BTCH_ITEM_QUEU_ID);
                RemoveTaskData((int)context.State.Id);

                

                if (response == false)
                {
                    context.SetResult(ResultStatus.Invalid);
                    //taskCustomResp = new TaskCustomResp("Error", TaskResp.BusinessError);
                    //return Task.FromResult(true);
                }
            }
            catch (Exception ex)
            {
                if (context.State.FailedCount > 0)
                {
                    RemoveTaskData((int)context.State.Id);
                }
                throw;

                // ProcessLogger.Log("An error has occurred while executing DD item: " + ex.Message + "", ProcessCxt, batchItem.BPEM_STS_KEY, batchItem.RTRY_CNT, batchItem.REF_ID, batchItem.STRT_DTE, DateTime.UtcNow, false, NSLogLevel.Error);
                //batchItem.BPEM_STS_KEY = ProcessHelper.GetStatus(Status.Error);
                //UpdateTaskItemStatus(batchItem);

            }
            // return Task.FromResult(false);
        }


        #region Helper Function
        private static void AddTaskData(int key)
        {
            lock (_object)
            {
                if (!TaskDataSet.ContainsKey(key))
                    TaskDataSet.Add(key, new TaskData());
            }
        }
        private static void RemoveTaskData(int key)
        {
            lock (_object)
            {
                if (TaskDataSet.ContainsKey(key))
                    TaskDataSet.Remove(key);
            }
        }

        public void InitializeSupportingData(IProcessExecutionContext context)
        {
            //GetParam(context);

            //context.SetTempData("DDParam", _ddParam);
            //return true;
        }

        public override void ProcessStarting(IProcessExecutionContext processContext)
        {
            base.ProcessStarting(processContext);

        }

        private DirectDebitParam GetParam(IProcessExecutionContext context)
        {
            DirectDebitLogic _ddLogicInstance = new DirectDebitLogic();
            var _ddParam = _ddLogicInstance.GetDdParamAgainstProcessQueueId(new RequestObject<int>(LogContext.ContextToLog, (int)context.ProcessState.Id)).ResultSet;
            if (_ddParam.ProcessQueueId == null)
            {
                //return false;
            }
            // Read FC Configuration for DD
            //_fcDdConfig = _ddLogicInstance.ReadMiscDDConfig(_ddParam);
            _ddParam.DDMiscConfig = _ddLogicInstance.ReadMiscDDConfig(_ddParam);
            _ddParam.DDHeaders = DdGenerationHeader.GetHeaderByProcessQueueId(context.ProcessState.Id).Select(p => new DDHeaders() { HeaderId = p.DD_GENR_HEDR_ID, FcBankId = p.FC_BP_BANK_ID }).ToList();
            _ddParam.IncludeOdRental = _ddParam.DdTemplate?.DdReceivable?.Count > 0 && _ddParam.DdTemplate.DdReceivable.Exists(p => p.DD_RECV_ABLE_ID == (int)DdReceivableCodeEnum.OverdueRentals);

            try
            {
                //var AMNT_PER_TRANS = System.Configuration.ConfigurationManager.AppSettings["AMNT_PER_TRANS"];
                //decimal amountPerTrans = 0;
                //decimal.TryParse(AMNT_PER_TRANS, out amountPerTrans);
                //_ddParam.AMNT_PER_TRANS = amountPerTrans;
            }
            catch
            {
                _ddParam.AMNT_PER_TRANS = 0;
                // CommonHelper.Log("AMNT_PER_TRANS is missing.", _ddParam.Context, 0, false, NSLogLevel.Error);

            }
            #region Logging
            //CommonHelper.Log("No DD Template Receivables information exist for Contract ID: " + contId, param.Context, contId, false, NSLogLevel.Info);
            #endregion
            DirectDebitLogic.SetLogRequestEvent(_ddParam);
            return _ddParam;
        }
        #endregion
    }
}

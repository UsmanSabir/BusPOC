﻿using CMS.Business;
using CMS.Business.Helper.Manage;
using CMS.Business.Helper.Utility;
using CMS.Models.ContractActivation;
using CMS.Models.DirectDebit;
using CMS.Models.DirectDebit.Custom;
using CMS.Models.Receipting;
using CMS.Models.Receipting.Custom;
using CMS.ServiceContracts;
using CMS.Services;
using NFS.Business.CommonHelper;
using NFS.Models.BusinessPartner;
using NFS.Models.BusinessPartner.Custom.Enum;
using NFS.ServiceContracts;
using NS.BaseModels;
using NS.ExceptionHandling;
using NS.ORM;
using NS.Resources.Enums.Common;
using NS.Resources.Enums.Receipt;
using NS.ServiceModel;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CMS.DirectDebit.Business.Settlement
{
    public abstract class DirectDebitSettlementBase
    {

        /// <summary>
        /// Prepares the direct debit receipt.
        /// Base implemetation contain Manual Settlement
        /// </summary>
        /// <param name="ddGenDetail">The dd gen detail.</param>
        /// <param name="ddParam">The dd parameter.</param>
        /// <returns></returns>
        public virtual ReceiptParam PrepareDirectDebitReceipt(List<DdGenerationDetail> ddGenDetails, DirectDebitParam ddParam, ReceiptParam receiptParam)
        {
            if (ddGenDetails == null) { return receiptParam; }
            var payerDetail = PayerDetail(ddGenDetails[0].CONT_ID);
            foreach (var ddGenDetail in ddGenDetails.Where(p=>p.AMNT > 0))
            {
                Receipt receipt = new Receipt();
                receipt.SRC = PaymentSource.DirectDebit.GetKey();
                receipt.REF_CONT_ID = ddGenDetails[0].CONT_ID;
                receipt.DD_GENR_DET_ID = ddGenDetail.DD_GENR_DET_ID.ToString();
                receipt.BP_ROLE_ID = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BP_ROLE_ID;
                receipt.BUSS_PTNR_ID = ddGenDetail.BUSS_PTNR_ID;
                receipt.BRNC_ID = ddParam.BranchId;
                receipt.CMPY_ID = ddParam.FinanceCompanyId;
                receipt.EXTR_RCPT_NUMB = ReceiptingRepository.GetReceiptRunningNumber(ddParam.Context, ddParam.FinanceCompanyId, ddParam.BranchId);
                receipt.PYMT_MODE_ID = int.Parse(PaymentModeType.DirectDebit.GetKey());
                receipt.RCPT_PYMT_MODE_NME = PaymentModeType.DirectDebit.ToString();
                receipt.RCPT_AMNT = ddGenDetail.AMNT;
                //receipt.RCPT_CRCY_ID = Convert.ToInt32(GetCurrencyCode(ddGenDetail.CONT_ID));
                //BPCurrencies.

                var res = BPCurrencies.ReadCrcyDescByContId(ddGenDetail.CONT_ID);
                if (res != null && res.Count > 0) { receipt.RCPT_CRCY_NME = res[0].DSCR; receipt.RCPT_CRCY_ID = res[0].CRCY_ID; }

                
                receipt.RCPT_DTE = ddParam.CurrentProcessingDate;
                if (ddParam.DDMiscConfig.RCPT_VAL_DTE_BSIS == "Current Processing Date")
                {
                    receipt.VAL_DTE = ddParam.CurrentProcessingDate;
                }
                else
                {
                    var valueDate = ddGenDetail.AMNT_DUE_DTE;
                    if (!CommonHelper.IsWorkingDay(ddParam.FinanceCompanyId, ddParam.BranchId, Convert.ToDateTime(valueDate)))
                    {
                        valueDate = CommonHelper.AddBusinessDays(Convert.ToDateTime(valueDate), 1, DaysYearType.FinancialWorkingDays, ddParam.FinanceCompanyId, ddParam.BranchId);
                    }
                    receipt.VAL_DTE = valueDate;
                }

                receipt.PYER_BSB_CODE = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BSP_CODE;
                receipt.PYER_ACCT_NUMB = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).ACCT_NUMB;
                receipt.PYER_BANK_ID = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BANK_ID;
                receipt.PYER_BRNC_ID = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BRNC_ID;
                receipt.DRWR_NME = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BPNAME;

                receipt.PYEE_BSB_CODE = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BSP_CODE;
                receipt.PYEE_ACCT_NUMB = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).FC_ACCT_NUMB;
                receipt.PYEE_BANK_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BANK_ID;
                receipt.PYEE_BRNC_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BRNC_ID;

                receipt.STS_KEY = StatusCode.Draft.GetKey();
                ReceiptDetail receiptDetail = new ReceiptDetail();
                receiptDetail.RCPT_AMNT = ddGenDetail.AMNT;
                receiptDetail.RCPT_TYPE_ID = int.Parse(ReceiptType.NormalReceipt.GetKey());
                receiptDetail.RCPT_TYPE_NME = ReceiptType.NormalReceipt.ToString();
                receiptDetail.STS_KEY = StatusCode.Draft.GetKey();
                receipt.ReceiptDetail = new List<ReceiptDetail>();
                receipt.ReceiptDetail.Add(receiptDetail);

                ReceiptAmountDistribution receiptAmntDist = new ReceiptAmountDistribution();
                receiptAmntDist.AMNT = ddGenDetail.AMNT;
                receiptAmntDist.AMNT_CMPT_TYPE_KEY = ddGenDetail.AMNT_CMPT_TYPE_KEY;//  AmountComponentCodes.Rental.GetKey();
                receiptAmntDist.CONT_ID = ddGenDetail.CONT_ID;
                receiptAmntDist.RNTL_ID = ddGenDetail.RNTL_ID;
                receiptAmntDist.CHRG_SEQ = ddGenDetail.CHRG_ID;
                receiptDetail.ReceiptAmountDistribution = new List<ReceiptAmountDistribution>();
                receiptDetail.ReceiptAmountDistribution.Add(receiptAmntDist);
                ddGenDetail.RCPT_TYPE_ID = receiptDetail.RCPT_TYPE_ID;
                ReceiptContractAssociation receiptContAsoc = new ReceiptContractAssociation();
                receiptContAsoc.CONT_ID = ddGenDetail.CONT_ID;
                receiptContAsoc.RCPT_AMNT = ddGenDetail.AMNT;
                receiptContAsoc.STS_KEY = StatusCode.Draft.GetKey();
                receiptDetail.ReceiptContractAssociation = new List<ReceiptContractAssociation>();
                receiptDetail.ReceiptContractAssociation.Add(receiptContAsoc);
                receiptParam.Receipts.Add(receipt);
                //   receiptParam.ReceiptDdMapping.Add(new ReceiptDDMapping() { DdDetailSeq = ddGenDetail.DD_GENR_DET_ID, ReceiptSeq = receiptParam.Receipts.Count });

                FillDDReceiptInfo(receiptParam, ddGenDetail);
            }

            #region Receipt Param
            receiptParam.BranchId = ddParam.BranchId;
            receiptParam.CompanyId = ddParam.FinanceCompanyId;
            receiptParam.InvokeWorkflow = false;
            receiptParam.IsPreactivation = false;
            receiptParam.IsManualReceipt = false;
            receiptParam.ValueDte = ddParam.EffectiveToDate;
            receiptParam.ProcessingDte = ddParam.CurrentProcessingDate;
            receiptParam.ReceiptType = ReceiptType.NormalReceipt;
            receiptParam.DepositType = DepositTypes.None;
            receiptParam.IsEtFinalReceipt = false;
            receiptParam.LogInstallmentSettlement = ddParam.LogInstallmentSettlement;
            receiptParam.LogTransactionDetail = ddParam.LogTransactionDetail;
            #endregion

            return receiptParam;
        }


        public virtual Tuple<List<Receipt>,SettlementResponse> SettleDirectDebit(Context context, ReceiptParam param)
        {
            SettlementResponse settlementResponse = null;
            List<Receipt> result = null;
            try
            {
                context.Action = "Submit";
                context.ScreenId = 2412;
                //var srv = ChannelFactory.CreateChannel<IReceiptingService>();
                ReceiptingLogic srv = new ReceiptingLogic();
                var requestObject = new RequestObject<ReceiptParam>(context, param);

                //Ensuring that ET receipt will be settled first.
                //SortReceipts(param);

                //Only persist Receipt, Workflow will not be invoked
                var response = srv.PersistReceipts(requestObject);

                if (response.Message.Type == MessageType.Success && response.ResultSet != null)
                {
                    RequestObject<ReceiptParam> processReceiptRequest = new RequestObject<ReceiptParam>(context, param);

                    //Perform Settlement 
                    settlementResponse = srv.ProcessReceipt(requestObject).ResultSet;                    
                    CommonHelper.Log("Receipts Settled Successfully.", context, 0, NSLogLevel.Info);
                    result = response.ResultSet;
                }
            }
            catch (Exception ex)
            {
                CommonHelper.Log("Receipts Settlement Fail.", context, 0, NSLogLevel.Info);
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return new Tuple<List<Receipt>, SettlementResponse>(result, settlementResponse);
        }
        
        private void SortReceipts(ReceiptParam param)
        {
            var receipts = param.Receipts.Where(c => c.ReceiptDetail.Any(o => o.RCPT_TYPE_ID == Convert.ToInt32(ReceiptType.EarlyTerminationReceipt.GetKey())));

            foreach (var item in receipts)
            {
                Move(param.Receipts, param.Receipts.IndexOf(item));
            }
        }

        public void Move(IList<Receipt> list, int index)
        {
            var item = list[index];
            list.RemoveAt(index);
            list.Insert(0, item);

        }

        public virtual int? GetCurrencyCode(int contid)
        {
            EntityContextExt<Contract> dbCtx = EntityContextExt<Contract>.Create();
            return dbCtx.WithEntityScope((childType, parent, aggregateId, xyz) =>
            {
                return (childType == typeof(Contract));
            }).Read(r => r.CONT_ID == contid).Entity.FirstOrDefault().CRCY_ID;

            //return dbCtx.Read(r => r.CONT_ID == contid).Entity.FirstOrDefault().CRCY_ID;
        }

        public List<DdPayerBankDetail> PayerDetail(int contractId)
        {            
            EntityContextExt<DdPayerBankDetail> dbCtx = EntityContextExt<DdPayerBankDetail>.Create();
            var result = dbCtx.Read(contractId).Entity;
            return result;
        }

        protected void FillDDReceiptInfo(ReceiptParam receiptParam, DdGenerationDetail ddGenDetail)
        {
            if (ddGenDetail != null && ddGenDetail.AMNT_CMPT_TYPE_KEY == AmountComponents.Rental.GetKey())
            {
                receiptParam.DDReceiptInfo = new DDReceiptInfo();
                receiptParam.DDReceiptInfo.DueDate = ddGenDetail.AMNT_DUE_DTE;
                receiptParam.DDReceiptInfo.RentalAmount = ddGenDetail.AMNT;
                receiptParam.DDReceiptInfo.IsAdhocDD = ddGenDetail.DD_ADHC_CONF_ID > 0;
            }
        }

        protected void MarkInvalidAdhoc(int? DD_ADHC_CONF_ID, DateTime CurrentProcessingDate)
        {
            var stsKey = StatusCode.Invalid.GetKey();
            DbController controller = DbController.Create();
            string sql = "BEGIN TRANSACTION; UPDATE CONT_DD_ADHC_CONF SET DD_STS_KEY = @DdStatusKey, ADHC_DD_SENT_DTE = @AdhcDdSentDate WHERE DD_ADHC_CONF_ID = @DdAdhcConfId;COMMIT TRANSACTION;";
            controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "DdStatusKey", stsKey }, { "DdAdhcConfId", DD_ADHC_CONF_ID }, { "AdhcDdSentDate", CurrentProcessingDate } });
        }
    }
}

﻿using NS.ServiceModel;
using NS.Models.IntegrationHub.Custom.Param;
using IHEnums = NS.Models.IntegrationHub.Enums;
using CMS.ServiceContracts;
using NFS.Models.BPE;
using NS.BaseModels;
using NS.ORM;
using NS.Resources.Enums.Common;
using NS.Utilities;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using CMS.Models.Custom.Param;
using CMS.Models.AssetBackedSecurities;
using NS.ExceptionHandling;
using NFS.Models.BatchProcess.Custom;
using NS.Utilities.Context;
using BatchBootstrapper.Common;
using NFS.Models.Common.Custom;
using NS.ServiceContracts;
using NFS.ServiceContracts;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using NFS.Models.Accounting.Custom.Param;
using System.IO;
using NS.Models.IntegrationHub;

namespace CMS.Business
{
    public class AssetBackedSecuritiesLogic : BusinessBase, IAssetBackedSecuritiesService
    {
        #region Public Properties
        public int BatchNo { get; set; }
        public DateTime? ProcessingDate { get; set; }
        public DateTime? AbsProcessingDate { get; set; }
        public DateTime? NextWorkingDate { get; set; }
        public volatile int NewActivatedInBatch;
        public volatile int TotalInBatchPortfolio;
        public volatile int TotalInBatchPaymentPlan;
        public volatile int TotalInBatchTransaction;
        public static int FileId { get; set; }
        public List<Portfolio> NFSPortfolios { get; set; }
        public List<PaymentPlan> NFSPaymentPlans { get; set; }
        public List<Transaction> NFSTransactions { get; set; }
        #endregion

        # region Constructor
        public AssetBackedSecuritiesLogic()
        {
        }
        #endregion

        #region Private Methods
        private int AbsExtractionHeader(DateTime processingDate, int companyId, int branchId, DaysYearType workingDayType)
        {
            var contextExt = EntityContextExt.Create<AbsBatchNo>();
            var res = contextExt.ReadFromSp("ABS_LOG_EXTRACTION_HEADER", new Dictionary<string, object>() { { "abs_process_dte", CommonHelper.GetLastWorkingDay(processingDate, workingDayType, companyId, branchId) }, { "cms_processing_date", processingDate } });
            var data = res.Entity;

            return data.Select(x => x.BATCH_NO).FirstOrDefault();
        }
        private void LogError(Context context, int contId, string errMsg)
        {
            try
            {
              //  CommonHelper.Log(errMsg, context, contId, NSLogLevel.Error);
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }
        private bool LoadPortfolio(Context context, int contId, int? retryCount)
        {
            try
            {
                using (var contextExt = DbController.Create())
                {
                    var res = contextExt.SpCallSingle<dynamic>("ABS_PROCESS_PORTFOLIO", new Dictionary<string, object>() { { "P_BATCH_NO", BatchNo }, { "P_CONT_ID", contId }, { "P_ABS_PROCESS_DTE", AbsProcessingDate }, { "PROCESS_DTE", ProcessingDate }, { "NEXT_DTE", NextWorkingDate }, { "RTRY_CNT", retryCount } });
                    if (res.ERRCODE == 1)
                        return true;
                    else if (res.ERRCODE == -1)
                    {
                        LogError(context, contId, res.ERRDESC);
                        return false;
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private void LoadPaymentPlan(Context context, int contId, int? retryCount)
        {
            try
            {
                using (var contextExt = DbController.Create())
                {
                    var res = contextExt.SpCallSingle<dynamic>("ABS_PROCESS_PAYMENTPLAN", new Dictionary<string, object>() { { "P_BATCH_NO", BatchNo }, { "P_CONT_ID", contId }, { "RTRY_CNT", retryCount } });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private void LoadTransaction(Context context, int contId, int? retryCount, int transactionCount)
        {
            try
            {
                using (var contextExt = DbController.Create())
                {
                    if (transactionCount < 2000)
                    {
                        var res = contextExt.SpCallSingle<dynamic>("ABS_PROCESS_TRANSACTIONPLAN", new Dictionary<string, object>() { { "P_BATCH_NO", BatchNo }, { "P_CONT_ID", contId }, { "RTRY_CNT", retryCount } });
                    }
                    else {
                        int totalIteration = transactionCount / 2000;
                        int totalProccessedRecords = 0;
                        int lastPageNumber = 0;
                        for (int i = 1; i <= totalIteration; i++)
                        {
                            var res = contextExt.SpCallSingle<dynamic>("ABS_PROCESS_TRANSACTIONPLAN", new Dictionary<string, object>() { { "P_BATCH_NO", BatchNo }, { "P_CONT_ID", contId }, { "RTRY_CNT", retryCount }, { "PageNumber", i }, { "PageSize", 2000 }, { "TotalRecords", transactionCount } });
                            lastPageNumber += 1;
                        }
                        totalProccessedRecords = totalIteration * 2000;
                        int remainingRecords = transactionCount - totalProccessedRecords;
                        if (remainingRecords > 0)
                        {
                            var res = contextExt.SpCallSingle<dynamic>("ABS_PROCESS_TRANSACTIONPLAN", new Dictionary<string, object>() { { "P_BATCH_NO", BatchNo }, { "P_CONT_ID", contId }, { "RTRY_CNT", retryCount }, { "PageNumber", lastPageNumber + 1 }, { "PageSize", 2000 }, { "TotalRecords", transactionCount } });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private int GetTransactionCount(Context context, int contId, int? retryCount)
        {
            int transactionCount = 0;
            try
            {
                using (var contextExt = DbController.Create())
                {
                    IList<int> res = contextExt.GetCustomList<int>("SELECT Count(*) As TransactionCount FROM GENL_TRAN_DET GTD WITH (NOLOCK) WHERE cont_id = @P_CONT_ID", new NS.Utilities.SerializableDictionary<string, object>() { { "P_CONT_ID", contId } });
                    if (res != null && res.Count>0)
                    {
                        transactionCount = Convert.ToInt32(res.First());
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return transactionCount;
        }
        private ResponseObject<bool> PersistAbsLogSummary()
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            response.Message = new MessageInfo();
            try
            {
                var contextExt = EntityContextExt.Create<AbsProcessSummary>();
                contextExt.ReadFromSp("ABS_PROCESS_SUMMARY", new Dictionary<string, object>() {
                    { "P_NEW_BATCH_NO", BatchNo },
                    { "P_NEW_ACTIVATED_IN_BATCH", NewActivatedInBatch },
                    { "P_TOTAL_IN_BATCH_PORTFOLIO", TotalInBatchPortfolio },
                    { "P_TOTAL_IN_BATCH_PAYMENTPLAN", TotalInBatchPaymentPlan },
                    { "P_TOTAL_IN_BATCH_TRANSACTION", TotalInBatchTransaction },
                    { "p_Process_date", AbsProcessingDate } });
                response.ResultSet = true;
                response.Message.Type = MessageType.Success;
            }
            catch (Exception ex)
            {
                response.ResultSet = false;
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        private int ReadFileId()
        {
            var contextExt = EntityContextExt.Create<ReadFileId>();
            contextExt.Read();
            return contextExt.Entity.LastOrDefault().FILEID + 1;
        }
        private ResponseObject<List<ReadContractByContNumb>> UpdateContract(Context context, List<AbsFlaggingFileDetail> filteredData, string fileType, int branchId, DateTime processingDate, List<ReadContractByContNumb> lstContract)
        {

            List<ReadContractByContNumb> conts = new List<ReadContractByContNumb>();
            ResponseObject<List<ReadContractByContNumb>> response = new ResponseObject<List<ReadContractByContNumb>>();
            try
            {
                Parallel.ForEach(filteredData, item =>
                  {
                      LogContext.ContextToLog = context;
                      var contItem = lstContract.FirstOrDefault(s => s.CONT_NUMB.Trim() == item.PCD_ACCT_NBR.Trim());
                      if (contItem != null)
                      {
                          ReadContractByContNumb cont = contItem;
                          if (fileType == AbsFileTypeCode.Sale.GetKey())
                          {
                              if (item.PCD_SALE_DTE != null)
                                  cont.SOLD_DTE = item.PCD_SALE_DTE.Value.Date;
                              if (item.ABS_CLOSING_DTE != null)
                              {
                                  cont.TRST_CLSG_DTE = item.ABS_CLOSING_DTE.Value.Date;
                                  if (item.ABS_CLOSING_DTE.Value.Date == processingDate.Date)
                                  {
                                      cont.SOLD_IND = true;
                                  }
                              }
                              cont.SOLD_CODE = item.PCD_SALE_ID;
                              cont.FILE_TYPE_CODE_ID = (int)AbsFileTypeCode.Sale;
                          }
                          else if (fileType == AbsFileTypeCode.UnFlag.GetKey())
                          {
                              cont.FILE_TYPE_CODE_ID = (int)AbsFileTypeCode.UnFlag;
                          }
                          else if (fileType == AbsFileTypeCode.Repurchase.GetKey())
                          {
                              if (item.REP_CLEAN_DTE != null)
                                  cont.RE_PRCH_DTE = item.REP_CLEAN_DTE.Value.Date;
                              if (item.INVESTOR_REPORTING_DTE != null)
                              {
                                  cont.IVST_RPRT_DTE = item.INVESTOR_REPORTING_DTE.Value.Date;
                                  if (item.INVESTOR_REPORTING_DTE.Value.Date == processingDate.Date)
                                  {
                                      cont.SOLD_IND = false;
                                      cont.RE_PRCH_IND = true;
                                  }
                              }
                              cont.FILE_TYPE_CODE_ID = (int)AbsFileTypeCode.Repurchase;
                          }
                          else if (fileType == AbsFileTypeCode.CleanUp.GetKey())
                          {
                              if (item.REP_CLEAN_DTE != null)
                                  cont.RE_PRCH_DTE = item.REP_CLEAN_DTE.Value.Date;
                              if (item.INVESTOR_REPORTING_DTE != null)
                              {
                                  cont.IVST_RPRT_DTE = item.INVESTOR_REPORTING_DTE.Value.Date;
                                  if (item.INVESTOR_REPORTING_DTE.Value.Date == processingDate.Date)
                                  {
                                      cont.SOLD_IND = false;
                                      cont.CLEN_UP_IND = true;
                                  }
                              }
                              cont.FILE_TYPE_CODE_ID = (int)AbsFileTypeCode.CleanUp;
                          }

                          var contextExt = EntityContextExt.Create(new List<ReadContractByContNumb> { cont });
                          contextExt.Persist();
                          response.ResultSet = contextExt.Entity;
                      }
                  });

                return response;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }

        private ResponseObject<List<AbsFlaggingFileDetail>> ValidateFlaggingFileDetail(Context context, List<AbsFlaggingFileDetail> requestObject, string fileType, List<ReadContractByContNumb> lstCont, List<ValidateSaleFile> lstSaleFile)
        {
            ResponseObject<List<AbsFlaggingFileDetail>> response = new ResponseObject<List<AbsFlaggingFileDetail>>();
            try
            {
                var listSaleFile = new List<ValidateSaleFile>();
                Parallel.For(0, requestObject.Count, item =>
                {
                    LogContext.ContextToLog = context;

                    var contExt = lstCont?.FirstOrDefault(s => s.CONT_NUMB.Trim() == requestObject[item]?.PCD_ACCT_NBR?.Trim());
                    if (string.IsNullOrEmpty(requestObject[item]?.PCD_ACCT_NBR) || requestObject[item]?.PCD_ACCT_NBR?.Trim().Count() == 0)
                    {
                        requestObject[item].STS = "Fail";
                        requestObject[item].MSG = "Contract no. is missing.";
                        requestObject[item].ROW_NO = (item + 3).ToString();
                    }
                    else if (contExt == null)
                    {
                        requestObject[item].STS = "Fail";
                        requestObject[item].MSG = "The contract no. in the file doesn’t exist.";
                        requestObject[item].ROW_NO = (item + 3).ToString();
                    }
                    else if (fileType == AbsFileTypeCode.Sale.GetKey())
                    {
                        if (string.IsNullOrEmpty(requestObject[item].TRUST_ID))
                        {
                            requestObject[item].STS = "Fail";
                            requestObject[item].MSG = "Trust ID is missing.";
                            requestObject[item].ROW_NO = (item + 3).ToString();
                        }
                        else
                            requestObject[item].STS = "Success";
                    }
                    else if (fileType == AbsFileTypeCode.UnFlag.GetKey() || fileType == AbsFileTypeCode.Repurchase.GetKey() || fileType == AbsFileTypeCode.CleanUp.GetKey())
                    {
                        if (lstSaleFile.Where(x => x.PCD_ACCT_NBR.Trim() == requestObject[item].PCD_ACCT_NBR.Trim()).ToList().Count <= 0)
                        {
                            requestObject[item].STS = "Fail";
                            requestObject[item].MSG = "There was no sale file uploaded against the record.";
                            requestObject[item].ROW_NO = (item + 3).ToString();
                        }
                        else if (!requestObject[item].REP_CLEAN_DTE.HasValue && fileType != AbsFileTypeCode.UnFlag.GetKey())
                        {
                            requestObject[item].STS = "Fail";
                            requestObject[item].MSG = "Repurchase date is missing.";
                            requestObject[item].ROW_NO = (item + 3).ToString();
                        }
                        else if (contExt?.SOLD_IND == true && fileType == AbsFileTypeCode.UnFlag.GetKey())
                        {
                            requestObject[item].STS = "Fail";
                            requestObject[item].MSG = "The contract was already marked “Sold” by the sale file uploaded against it.";
                            requestObject[item].ROW_NO = (item + 3).ToString();
                        }
                        else if (contExt?.SOLD_IND == false)
                        {
                            requestObject[item].STS = "Fail";
                            requestObject[item].MSG = "The contract  was not marked “Sold” yet.";
                            requestObject[item].ROW_NO = (item + 3).ToString();
                        }
                        else
                            requestObject[item].STS = "Success";
                    }
                });
                response.ResultSet = requestObject;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        private bool ValidateSold(string ContNumber)
        {
            using (var contextExt = EntityContextExt.Create<ValidateSold>())
            {
                contextExt.Read(s => s.CONT_NUMB == ContNumber);
                if (contextExt.Entity != null && contextExt.Entity.Count() > 0)
                {
                    if (contextExt.Entity.FirstOrDefault().SOLD_IND == true)
                        return true;
                    else
                        return false;
                }
            }
            return true;
        }
        private bool ValidateSaleFile(string ContNumber)
        {
            using (var contextExt = EntityContextExt.Create<ValidateSaleFile>())
            {
                contextExt.Read(s => s.PCD_ACCT_NBR == ContNumber);
                if (contextExt.Entity?.Count > 0)
                    return false;
                else
                    return true;
            }
        }
        private bool ValidateContract(string ContNumber)
        {
            using (var contextExt = EntityContextExt.Create<ValidateContract>())
            {
                contextExt.Read(s => s.CONT_NUMB == ContNumber);
                if (contextExt.Entity?.Count > 0)
                    return false;
                else
                    return true;
            }
        }
        private ResponseObject<List<AbsFlaggingContractList>> UpdateAbsFlaggingContract(Context context, int contId, int branchId, DateTime processingDate, int processQueueId)
        {
            ResponseObject<List<AbsFlaggingContractList>> response = new ResponseObject<List<AbsFlaggingContractList>>();
            try
            {
                response.Message = new MessageInfo();
                using (var contextExt = EntityContextExt.Create<AbsFlaggingContractList>())
                {
                    contextExt.Read(r => r.CONT_ID == contId);
                    List<AbsFlaggingContractList> AbFlaggingConts = new List<AbsFlaggingContractList>();
                    if (contextExt.Entity?.Count > 0)
                    {
                        AbsFlaggingContractList AbsCont = contextExt.Entity.FirstOrDefault();
                        if (AbsCont.FILE_TYPE_CODE_ID == (int)AbsFileTypeCode.Sale)
                        {
                            if (AbsCont.TRST_CLSG_DTE != null)
                                if (AbsCont.TRST_CLSG_DTE.Value.Date == processingDate.Date)
                                {
                                    AbsCont.SOLD_IND = true;
                                    InvokeWorkflow(contextExt.Entity.First().CONT_ID, OnApprove(), RequestTypeCodes.Securitization.GetKey(), 2914, context, branchId, processQueueId);
                                }
                        }
                        else if (AbsCont.FILE_TYPE_CODE_ID == (int)AbsFileTypeCode.Repurchase)
                        {
                            if (AbsCont.IVST_RPRT_DTE != null)
                                if (AbsCont.IVST_RPRT_DTE.Value.Date == processingDate.Date)
                                {
                                    AbsCont.SOLD_IND = false;
                                    AbsCont.RE_PRCH_IND = true;
                                    InvokeWorkflow(contextExt.Entity.First().CONT_ID, OnApprove(), RequestTypeCodes.UnSecuritization.GetKey(), 2914, context, branchId, processQueueId);
                                }
                        }
                        else if (AbsCont.FILE_TYPE_CODE_ID == (int)AbsFileTypeCode.CleanUp)
                        {
                            if (AbsCont.IVST_RPRT_DTE != null)
                                if (AbsCont.IVST_RPRT_DTE.Value.Date == processingDate.Date)
                                {
                                    AbsCont.SOLD_IND = false;
                                    AbsCont.CLEN_UP_IND = true;
                                    //AbsCont.RE_PRCH_DTE = processingDate.Date;
                                    InvokeWorkflow(contextExt.Entity.First().CONT_ID, OnApprove(), RequestTypeCodes.UnSecuritization.GetKey(), 2914, context, branchId, processQueueId);
                                }
                        }
                        contextExt.Persist();
                        response.ResultSet = contextExt.Entity;
                        response.Message.Type = MessageType.Success;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        private void InvokeWorkflow(int contId, int eventId, string requestType, int screenId, Context context, int branchId, int processQueueId)
        {
            try
            {
                using (var srv = new ProxyClient<IWorkflowEngineService>())
                {
                    WorkflowInputParams workflowParams = new WorkflowInputParams()
                    {
                        ScreenId = screenId,
                        BranchId = branchId,
                        ScreenAction = "Execute",
                        RequestType = requestType,
                        Module = "BPEM",
                        Session = context,
                        PostAction = true,
                        ReferenceId = contId,
                        ReferenceIdsList = new string[] { processQueueId.ToString() },
                        ExternalKey = eventId.ToString(),
                    };

                    RequestObject<WorkflowInputParams> reqObj = new RequestObject<WorkflowInputParams>(context, workflowParams);
                    srv.ClientInstance.InvokeMicroWorkflow(reqObj);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }
        private static int OnApprove()
        {
            return 5;
        }
        #endregion

        #region Public Methods
        public ResponseObject<bool> InvokePreMessageFlow(Context context)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            response.Message = new MessageInfo();
            try
            {
                IIntegrationHubService srv = ChannelFactory.CreateChannel<IIntegrationHubService>();
                var preMesgFlowParam = new MessageFlowExecParam
                {
                    MesgFlowName = "Abs Crawler Data Transfer Pre-Condition",
                    Params = new Dictionary<string, object>()
                        {
                            { "BatchNo", BatchNo},
                            { "Skip", 0},
                            { "Take", 1000},
                        },
                    InvokeType = IHEnums.InvokeTypeCodeEnum.Event
                };
                var preResponse = preMesgFlowParam.ExecuteMessageFlow(context, srv);

                if (preResponse.ResultSet != null &&
                    preResponse.ResultSet.ExecutionStatus == IHEnums.MessageFlowExecutionStatusCodeEnum.Success &&
                    preResponse.ResultSet.Params["StoppedProcessingReason"] == null)
                {
                    response.ResultSet = true;
                    response.Message.Type = MessageType.Success;
                }
                else
                {
                    //CommonHelper.Log("'Ready' status was not found at Crawler end.", context, 2914, NSLogLevel.Error);
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<List<int>> GetReportingContractList(RequestObject<BatchProcessParam> requestObject)
        {
            ResponseObject<List<int>> response = new ResponseObject<List<int>>();
            response.Message = new MessageInfo();
            List<int> ContList = new List<int>();
            try
            {
                BatchNo = AbsExtractionHeader(requestObject.Object.ProcessingDate, requestObject.Object.CompanyId, requestObject.Object.BranchId, requestObject.Object.WorkingDay);
                var contextExt = EntityContextExt.Create<AbsReportingContractList>();
                contextExt.Read(CommonHelper.GetLastWorkingDay(requestObject.Object.ProcessingDate, requestObject.Object.WorkingDay, requestObject.Object.CompanyId, requestObject.Object.BranchId));
                var data = contextExt.Entity;
                if (data?.Count > 0)
                {
                    foreach (var item in data)
                    {
                        ContList.Add(item.CONTRACT_ID);
                    }
                    response.ResultSet = ContList;
                    response.Message.Type = MessageType.Success;
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> AbsExtractionMain(RequestObject<AssetBackedSecuritiesParam> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
                response.Message = new MessageInfo();

                if (LoadPortfolio(requestObject.Context, requestObject.Object.ApplicationId, requestObject.Object.RetryCount) == true)
                {
                    LoadPaymentPlan(requestObject.Context, requestObject.Object.ApplicationId, requestObject.Object.RetryCount);
                    //GetTransactionCount(requestObject.Context, requestObject.Object.ApplicationId, requestObject.Object.RetryCount);
                    LoadTransaction(requestObject.Context, requestObject.Object.ApplicationId, requestObject.Object.RetryCount, GetTransactionCount(requestObject.Context, requestObject.Object.ApplicationId, requestObject.Object.RetryCount));
                    response.ResultSet = true;
                    response.Message.Type = MessageType.Success;
                }
                else
                {
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> AbsInitialization(RequestObject<BatchProcessParam> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            response.Message = new MessageInfo();
            try
            {
                using (var contextExt = EntityContextExt.Create<AbsExtractionHeader>())
                {
                    var data = contextExt.Read().Entity.LastOrDefault();

                    BatchNo = data.BATCH_NO;
                    AbsProcessingDate = data.ABS_PROCESSING_DTE;
                    ProcessingDate = data.CMS_PROCESSING_DTE;
                }
                NextWorkingDate = CommonHelper.GetNextWorkingDay(requestObject.Object.ProcessingDate, requestObject.Object.WorkingDay, requestObject.Object.CompanyId, requestObject.Object.BranchId);
                response.ResultSet = true;
                response.Message.Type = MessageType.Success;
            }
            catch (Exception ex)
            {
                response.ResultSet = false;
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> InvokePostMessageFlow(RequestObject<BatchProcessParam> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
                response.Message = new MessageInfo();

                AbsInitialization(requestObject);
                PersistAbsLogSummary();

                IIntegrationHubService srv = ChannelFactory.CreateChannel<IIntegrationHubService>();
                var postMesgFlowParam = new MessageFlowExecParam
                {
                    MesgFlowName = "Abs Crawler Data Transfer Post Condition",
                    Params = new Dictionary<string, object>()
                    {
                        { "BatchNo", BatchNo},
                    },
                    InvokeType = IHEnums.InvokeTypeCodeEnum.Event
                };
                postMesgFlowParam.ExecuteMessageFlow(requestObject.Context, srv);
                response.ResultSet = true;
                response.Message.Type = MessageType.Success;
            }
            catch (Exception ex)
            {
                response.ResultSet = false;
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<List<AbsLogSummary>> ReadAbsLogSummary(RequestObject<int> requestObject)
        {
            ResponseObject<List<AbsLogSummary>> response = new ResponseObject<List<AbsLogSummary>>();
            try
            {
                response.Message = new MessageInfo();
                var contextExt = EntityContextExt.Create<AbsLogSummary>();
                contextExt.Read(s => s.BATCH_NO == requestObject.Object && s.LOG_LOAD_IND == "F");
                var data = contextExt.Entity;

                if (data != null)
                {
                    response.ResultSet = data;
                    response.Message.Type = MessageType.Success;
                    return response;
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> UpdateAbsLogSummaryLoadInd(RequestObject<AssetBackedSecuritiesParam> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
                response.Message = new MessageInfo();
                var contextExt = EntityContextExt.Create<AbsLogSummary>();
                contextExt.Read(s => s.BATCH_NO == requestObject.Object.BatchNum && s.INTF_TABLE == requestObject.Object.IntfTable);
                if (contextExt.Entity?.Count > 0)
                {
                    AbsLogSummary dataAbsLogSummary = contextExt.Entity.FirstOrDefault();
                    dataAbsLogSummary.LOG_LOAD_IND = "T";
                    contextExt.Persist();
                    response.Message.Type = MessageType.Success;
                    response.ResultSet = true;
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                response.ResultSet = false;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> UpdateAbsExtractionHeaderProcessInd(RequestObject<int> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
                response.Message = new MessageInfo();
                var contextExt = EntityContextExt.Create<AbsExtractionHeader>();
                contextExt.Read(s => s.BATCH_NO == requestObject.Object);
                if (contextExt.Entity?.Count > 0)
                {
                    AbsExtractionHeader dataAbsExtHeader = contextExt.Entity.FirstOrDefault();
                    dataAbsExtHeader.PROCESS_IND = "T";
                    contextExt.Persist();
                    response.ResultSet = true;
                    response.Message.Type = MessageType.Success;
                }
            }
            catch (Exception ex)
            {
                response.ResultSet = false;
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> PersistAbsFlaggingFileHeaderTrailor(RequestObject<List<AbsFlaggingFileHeaderTrailor>> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
                response.Message = new MessageInfo();
                using (var contextExt = EntityContextExt.Create(requestObject.Object))
                {
                    FileId = ReadFileId();
                    contextExt.Entity.FirstOrDefault().FILE_ID = FileId;
                    contextExt.Persist();
                }
                response.Message.Type = MessageType.Success;
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public static List<List<AbsFlaggingFileDetail>> splitList(List<AbsFlaggingFileDetail> requestObject, int nSize = 2000)
        {
            var list = new List<List<AbsFlaggingFileDetail>>();

            for (int i = 0; i < requestObject.Count; i += nSize)
            {
                list.Add(requestObject.GetRange(i, Math.Min(nSize, requestObject.Count - i)));
            }

            return list;
        }
        public ResponseObject<List<AbsFlaggingFileDetail>> PersistAbsFlaggingFileDetail(RequestObject<AssetBackedSecuritiesParam> requestObject)
        {
            ResponseObject<List<AbsFlaggingFileDetail>> response = new ResponseObject<List<AbsFlaggingFileDetail>>();
            try
            {
                response.Message = new MessageInfo();

                object lockContList = new object();
                object lockSaleList = new object();
                var listCont = new List<ReadContractByContNumb>();
                var listSaleFile = new List<ValidateSaleFile>();
                var absList = new List<AbsFlaggingFileDetail>();
                var splitedData = splitList(requestObject.Object.AbsFlaggingFileDetail, 2000);
                
                Parallel.ForEach(splitedData, item =>
                     {
                         LogContext.ContextToLog = requestObject.Context;
                         var contList = item.Select(s => s.PCD_ACCT_NBR.Trim()).ToList();
                         var contextExt = EntityContextExt.Create<ReadContractByContNumb>();
                         var contItemList = contextExt.Read(x => contList.Contains(x.CONT_NUMB)).Entity.ToList();
                         lock(lockContList)
                         {
                             listCont.AddRange(contItemList);
                         }
                     });

                if (requestObject.Object.FileType != AbsFileTypeCode.Sale.GetKey())
                {
                    Parallel.ForEach(splitedData, item =>
                    {
                        LogContext.ContextToLog = requestObject.Context;
                        var saleFile = item.Select(s => s.PCD_ACCT_NBR.Trim()).ToList();
                        var contextExtSale = EntityContextExt.Create<ValidateSaleFile>();
                        var saleItemsList = contextExtSale.Read(s => saleFile.Contains(s.PCD_ACCT_NBR)).Entity.ToList();
                        ConcurrentBag<ValidateSaleFile> concurrentSalesFiles = new ConcurrentBag<ValidateSaleFile>(saleItemsList);
                        lock(lockSaleList)
                        {
                            listSaleFile.AddRange(concurrentSalesFiles.ToList());
                        }
                    });
                }
                var distinctItems = listSaleFile?.GroupBy(x => x.PCD_ACCT_NBR.Trim()).Select(y => y.First()).ToList();
                var validatedData = ValidateFlaggingFileDetail(requestObject.Context, requestObject.Object.AbsFlaggingFileDetail, requestObject.Object.FileType, listCont, distinctItems);

                if (!validatedData.ResultSet.AsParallel().Any(x => x.STS == "Fail"))
                {
                    UpdateContract(requestObject.Context, validatedData.ResultSet, requestObject.Object.FileType, requestObject.Object.BranchId, requestObject.Object.ProcessingDate, listCont);
                    var contextExtCont = EntityContextExt.Create(validatedData.ResultSet.ToList());
                    Parallel.ForEach(contextExtCont.Entity, f =>
                    {
                        LogContext.ContextToLog = requestObject.Context;
                        f.FILE_ID = FileId;
                        f.PCD_ACCT_NBR = f.PCD_ACCT_NBR.Trim();
                    });
                    var persistList = splitList(contextExtCont.Entity, 4000).ToList();
                    Parallel.ForEach(persistList, item =>
                    {
                        LogContext.ContextToLog = requestObject.Context;
                        var contextExtContList = EntityContextExt.Create(item);
                        contextExtContList.Persist();
                    });
                }
                absList.AddRange(validatedData.ResultSet);

                response.ResultSet = absList?.ToList();
                response.Message.Type = MessageType.Success;
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<List<int>> GetAbsFlaggingContractList(RequestObject<BatchProcessParam> requestObject)
        {
            ResponseObject<List<int>> response = new ResponseObject<List<int>>();
            List<int> ContList = new List<int>();
            try
            {
                response.Message = new MessageInfo();
                using (var contextExt = EntityContextExt.Create<AbsFlaggingContractList>())
                {
                    contextExt.Read(x => x.TRST_CLSG_DTE == requestObject.Object.ProcessingDate || x.IVST_RPRT_DTE == requestObject.Object.ProcessingDate);
                    var data = contextExt.Entity;
                    if (data?.Count > 0)
                    {
                        foreach (var item in data)
                        {
                            ContList.Add(item.CONT_ID);
                        }
                        response.ResultSet = ContList;
                        response.Message.Type = MessageType.Success;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> AbsFlaggingMain(RequestObject<BatchProcessParam> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
                response.Message = new MessageInfo();
                UpdateAbsFlaggingContract(requestObject.Context, requestObject.Object.ReferenceId, requestObject.Object.BranchId, requestObject.Object.ProcessingDate, requestObject.Object.ProcessQueueId);
                response.ResultSet = true;
                response.Message.Type = MessageType.Success;
            }
            catch (Exception ex)
            {
                response.ResultSet = false;
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        #region Read Data Batch wise 
        public ResponseObject<List<Portfolio>> ReadNfsPortfolio(RequestObject<AssetBackedSecuritiesParam> requestObject)
        {
            ResponseObject<List<Portfolio>> response = new ResponseObject<List<Portfolio>>();
            try
            {
                response.Message = new MessageInfo();
                using (var contextExt = EntityContextExt.Create<Portfolio>())
                {
                    contextExt.Read(requestObject.Object.StartId, requestObject.Object.EndId);
                    var data = contextExt.Entity;

                    if (data != null)
                    {
                        response.ResultSet = data;
                        response.Message.Type = MessageType.Success;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<List<PaymentPlan>> ReadNfsPaymentPlan(RequestObject<AssetBackedSecuritiesParam> requestObject)
        {
            ResponseObject<List<PaymentPlan>> response = new ResponseObject<List<PaymentPlan>>();
            try
            {
                response.Message = new MessageInfo();
                using (var contextExt = EntityContextExt.Create<PaymentPlan>())
                {
                    contextExt.Read(requestObject.Object.StartId, requestObject.Object.EndId);
                    var data = contextExt.Entity;

                    if (data != null)
                    {
                        response.ResultSet = data;
                        response.Message.Type = MessageType.Success;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<List<Transaction>> ReadNfsTransaction(RequestObject<AssetBackedSecuritiesParam> requestObject)
        {
            ResponseObject<List<Transaction>> response = new ResponseObject<List<Transaction>>();
            try
            {
                response.Message = new MessageInfo();
                using (var contextExt = EntityContextExt.Create<Transaction>())
                {
                    contextExt.Read(requestObject.Object.StartId, requestObject.Object.EndId);
                    var data = contextExt.Entity;

                    if (data != null)
                    {
                        response.ResultSet = data;
                        response.Message.Type = MessageType.Success;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        #endregion

        #region Transfer Data Batch wise 
        public ResponseObject<List<SAPFilePageInfo>> GetNfsPortfolioList(RequestObject<Tuple<string, DateTime, int>> requestObject)
        {
            ResponseObject<List<SAPFilePageInfo>> response = new ResponseObject<List<SAPFilePageInfo>>();
            response.Message = new MessageInfo();
            try
            {
                using (var contextExt = EntityContextExt.Create<NfsPortfolioPaging>())
                {
                    contextExt.Read();
                    var data = contextExt.Entity;
                    if (data?.Count > 0)
                    {
                        int batchSize = requestObject.Object.Item3;
                        List<SAPFilePageInfo> lstFilePageInfo = new List<SAPFilePageInfo>();
                        List<int> tranMainIds = new List<int>();
                        foreach (var item in data)
                        {
                            lstFilePageInfo.Add(new SAPFilePageInfo() { PageNumber = (int)item.PAGE_NUMB, StartId = (int)item.STRT_ID, EndId = (int)item.END_ID });
                        }
                        response.ResultSet = lstFilePageInfo;
                        response.Message.Type = MessageType.Success;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> NfsPortfolioTransfer(SAPPostingSummaryParam param, Context context)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            IIntegrationHubService srv = null;
            try
            {
                response.Message = new MessageInfo();
                srv = ChannelFactory.CreateChannel<IIntegrationHubService>();
                RequestObject<AssetBackedSecuritiesParam> AbsPagingrequestObject = new RequestObject<AssetBackedSecuritiesParam>(context,
                new AssetBackedSecuritiesParam() { StartId = param.StartId, EndId = param.EndId });
                NFSPortfolios = ReadNfsPortfolio(AbsPagingrequestObject).ResultSet;
                var mesgFlowParam = new MessageFlowExecParam
                {
                    MesgFlowName = "Abs Crawler Data Transfer",
                    Params = new Dictionary<string, object>()
                    {
                        { "Portfolio", NFSPortfolios},
                        { "PaymentPlan", new List<PaymentPlan>()},
                        { "Transaction", new List<Transaction>()},
                    },
                    InvokeType = IHEnums.InvokeTypeCodeEnum.Event,
                    ParamsMetaData = new Dictionary<string, NS.Models.IntegrationHub.MessageFlowParameter>() { { "Portfolio", new MessageFlowParameter { CMPR_IND = true } }, { "PaymentPlan", new MessageFlowParameter { CMPR_IND = true } }, { "Transaction", new MessageFlowParameter { CMPR_IND = true } } }
                };
                var result = mesgFlowParam.ExecuteMessageFlow(context, srv);
                if (result.ResultSet.ExecutionStatus == IHEnums.MessageFlowExecutionStatusCodeEnum.Failure)
                {
                    throw new Exception($"Message flow failed while transferring Portfolio for page {param.PageNumber}");
                }
                else
                {
                    response.ResultSet = true;
                    response.Message.Type = MessageType.Success;
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                response.ResultSet = false;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            finally
            {
                ChannelFactory.CloseChannel(srv);
            }
            return response;
        }
        public ResponseObject<List<SAPFilePageInfo>> GetNfsPaymentPlanList(RequestObject<Tuple<string, DateTime, int>> requestObject)
        {
            ResponseObject<List<SAPFilePageInfo>> response = new ResponseObject<List<SAPFilePageInfo>>();
            response.Message = new MessageInfo();
            try
            {
                using (var contextExt = EntityContextExt.Create<NfsPaymentPlanPaging>())
                {
                    contextExt.Read();
                    var data = contextExt.Entity;
                    if (data?.Count > 0)
                    {
                        int batchSize = requestObject.Object.Item3;
                        List<SAPFilePageInfo> lstFilePageInfo = new List<SAPFilePageInfo>();
                        List<int> tranMainIds = new List<int>();
                        foreach (var item in data)
                        {
                            lstFilePageInfo.Add(new SAPFilePageInfo() { PageNumber = (int)item.PAGE_NUMB, StartId = (int)item.STRT_ID, EndId = (int)item.END_ID });
                        }
                        response.ResultSet = lstFilePageInfo;
                        response.Message.Type = MessageType.Success;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> NfsPaymentPlanTransfer(SAPPostingSummaryParam param, Context context)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            IIntegrationHubService srv = null;
            try
            {
                response.Message = new MessageInfo();
                srv = ChannelFactory.CreateChannel<IIntegrationHubService>();
                RequestObject<AssetBackedSecuritiesParam> AbsPagingrequestObject = new RequestObject<AssetBackedSecuritiesParam>(context,
                new AssetBackedSecuritiesParam() { StartId = param.StartId, EndId = param.EndId });
                NFSPaymentPlans = ReadNfsPaymentPlan(AbsPagingrequestObject).ResultSet;
                var mesgFlowParam = new MessageFlowExecParam
                {
                    MesgFlowName = "Abs Crawler Data Transfer",
                    Params = new Dictionary<string, object>()
                    {
                        { "Portfolio", new List<Portfolio>()},
                        { "PaymentPlan", NFSPaymentPlans},
                        { "Transaction", new List<Transaction>()},
                    },
                    InvokeType = IHEnums.InvokeTypeCodeEnum.Event,
                    ParamsMetaData = new Dictionary<string, NS.Models.IntegrationHub.MessageFlowParameter>() { { "Portfolio", new MessageFlowParameter { CMPR_IND = true } }, { "PaymentPlan", new MessageFlowParameter { CMPR_IND = true } }, { "Transaction", new MessageFlowParameter { CMPR_IND = true } } }
                };
                var result = mesgFlowParam.ExecuteMessageFlow(context, srv);
                if (result.ResultSet.ExecutionStatus == IHEnums.MessageFlowExecutionStatusCodeEnum.Failure)
                {
                    throw new Exception($"Message flow failed while transferring PaymentPlan for page {param.PageNumber}");
                }
                else
                {
                    response.ResultSet = true;
                    response.Message.Type = MessageType.Success;
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                response.ResultSet = false;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            finally
            {
                ChannelFactory.CloseChannel(srv);
            }
            return response;
        }
        public ResponseObject<List<SAPFilePageInfo>> GetNfsTransactionList(RequestObject<Tuple<string, DateTime, int>> requestObject)
        {
            ResponseObject<List<SAPFilePageInfo>> response = new ResponseObject<List<SAPFilePageInfo>>();
            response.Message = new MessageInfo();
            try
            {
                using (var contextExt = EntityContextExt.Create<NfsTransactionPaging>())
                {
                    contextExt.Read();
                    var data = contextExt.Entity;
                    if (data?.Count > 0)
                    {
                        int batchSize = requestObject.Object.Item3;
                        List<SAPFilePageInfo> lstFilePageInfo = new List<SAPFilePageInfo>();
                        List<int> tranMainIds = new List<int>();
                        foreach (var item in data)
                        {
                            lstFilePageInfo.Add(new SAPFilePageInfo() { PageNumber = (int)item.PAGE_NUMB, StartId = (int)item.STRT_ID, EndId = (int)item.END_ID });
                        }
                        response.ResultSet = lstFilePageInfo;
                        response.Message.Type = MessageType.Success;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ResponseObject<bool> NfsTransactionTransfer(SAPPostingSummaryParam param, Context context)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            IIntegrationHubService srv = null;
            try
            {
                response.Message = new MessageInfo();
                srv = ChannelFactory.CreateChannel<IIntegrationHubService>();
                RequestObject<AssetBackedSecuritiesParam> AbsPagingrequestObject = new RequestObject<AssetBackedSecuritiesParam>(context,
                new AssetBackedSecuritiesParam() { StartId = param.StartId, EndId = param.EndId });
                NFSTransactions = ReadNfsTransaction(AbsPagingrequestObject).ResultSet;
                var mesgFlowParam = new MessageFlowExecParam
                {
                    MesgFlowName = "Abs Crawler Data Transfer",
                    Params = new Dictionary<string, object>()
                    {
                        { "Portfolio", new List<Portfolio>()},
                        { "PaymentPlan", new List<PaymentPlan>() },
                        { "Transaction", NFSTransactions},
                    },
                    InvokeType = IHEnums.InvokeTypeCodeEnum.Event,
                    ParamsMetaData = new Dictionary<string, NS.Models.IntegrationHub.MessageFlowParameter>() { { "Portfolio", new MessageFlowParameter { CMPR_IND = true } }, { "PaymentPlan", new MessageFlowParameter { CMPR_IND = true } }, { "Transaction", new MessageFlowParameter { CMPR_IND = true } } }
                };
                var result = mesgFlowParam.ExecuteMessageFlow(context, srv);
                if (result.ResultSet.ExecutionStatus == IHEnums.MessageFlowExecutionStatusCodeEnum.Failure)
                {
                    throw new Exception($"Message flow failed while transferring Transaction for page {param.PageNumber}");
                }
                else
                {
                    response.ResultSet = true;
                    response.Message.Type = MessageType.Success;
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                response.ResultSet = false;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            finally
            {
                ChannelFactory.CloseChannel(srv);
            }
            return response;
        }
        #endregion

        #region Batch Process Volume
        public ResponseObject<List<int>> GetBatchProcessVolume(RequestObject<BatchProcessParam> requestObject)
        {
            ResponseObject<List<int>> response = new ResponseObject<List<int>>();
            List<int> ContList = new List<int>();
            try
            {
                response.Message = new MessageInfo();
                using (var contextExt = EntityContextExt.Create<AbsBatchVolume>())
                {
                    requestObject.Object.NextProcessingDate = CommonHelper.GetNextWorkingDay(requestObject.Object.ProcessingDate, requestObject.Object.WorkingDay, requestObject.Object.CompanyId, requestObject.Object.BranchId);
                    contextExt.Read(requestObject.Object.ProcessingDate, requestObject.Object.NextProcessingDate);
                    var data = contextExt.Entity;
                    if (data?.Count > 0)
                    {
                        foreach (var item in data)
                        {
                            ContList.Add(item.CONT_ID.GetValueOrDefault());
                        }
                        response.ResultSet = ContList;
                        response.Message.Type = MessageType.Success;
                    }
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;

        }
        #endregion

        #endregion
    }
}

﻿using NS.Resources.Enums.Common;

namespace CMS.DirectDebit.Business.Settlement
{
   public class DirectDebitSettlementFactory
    {
        static public DirectDebitSettlementBase GetSettlementType(AmountComponents component)
        {
            DirectDebitSettlementBase settlementType = null;

            switch (component)
            {
                case AmountComponents.NormalReceivables:
                    settlementType = new DdNormalReceiptSettlement();
                    break;
                case AmountComponents.Rental:
                    settlementType = new DdRentalSettlement();
                    break;
                case AmountComponents.Overdue:
                    settlementType = new DdOverdueSettlement();
                    break;
                case AmountComponents.Charges:
                    settlementType = new DdChargesSettlement();
                    break;
                case AmountComponents.ChargeReceivable:
                    settlementType = new DdChargesSettlement();
                    break;
                case AmountComponents.ETReceivables:
                    settlementType = new DdEarlyTerminationSettlement();
                    break;
                case AmountComponents.RestructuringRCBL:
                    settlementType = new DdRestructuringSettlement();
                    break;
                case AmountComponents.IntroducerSubsidy:
                    settlementType = new DdComponentSettlement(AmountComponents.IntroducerSubsidy);
                    break;
                case AmountComponents.ManufacturerSubsidy:
                    settlementType = new DdComponentSettlement(AmountComponents.ManufacturerSubsidy);
                    break;
                case AmountComponents.PurchaseInvoiceRCBL:
                    settlementType = new DdPurchaseInvoiceSettlement();
                    break;
                case AmountComponents.HTRCBL:
                    settlementType = new DdHostileTerminationSettlement();
                    break;
                case AmountComponents.ShortFallRCBL:
                    settlementType = new DdShortFallSettlement();
                    break;
                case AmountComponents.WriteOffRCBL:
                    settlementType = new DdWriteOffSettlement();
                    break;

                case AmountComponents.DownPayment:
                    settlementType = new DdComponentSettlement(AmountComponents.DownPayment);
                    break;
                case AmountComponents.SecurityDeposit:
                    settlementType = new DdComponentSettlement(AmountComponents.SecurityDeposit);
                    break;

                default:
                    settlementType = null;
                    break;
            }
            return settlementType;
            
        }
    }
}

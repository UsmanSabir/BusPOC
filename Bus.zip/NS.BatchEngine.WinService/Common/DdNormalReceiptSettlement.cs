﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Models.DirectDebit;
using CMS.Models.DirectDebit.Custom;
using CMS.Models.Receipting.Custom;
using NS.Resources.Enums.Common;
using CMS.Models.Receipting;
using NS.Resources.Enums.Receipt;
using NS.ServiceModel;
using CMS.ServiceContracts;
using NS.Utilities.Enums;
using CMS.Business.Helper.Utility;
using NFS.Models.BusinessPartner.Custom.Enum;
using NFS.Models.BusinessPartner;
using NFS.Business.CommonHelper;

namespace CMS.DirectDebit.Business.Settlement
{
    public class DdNormalReceiptSettlement : DirectDebitSettlementBase
    {
      
        public override ReceiptParam PrepareDirectDebitReceipt(List<DdGenerationDetail> ddGenDetail, DirectDebitParam ddParam, ReceiptParam receiptParam)
        {           

            if (ddGenDetail != null && ddGenDetail.Count > 0 && ddGenDetail.Sum(p => p.AMNT) > 0)
            {
                var payerDetail = PayerDetail(ddGenDetail[0].CONT_ID);

                Receipt receipt = new Receipt();
                receipt.SRC = PaymentSource.DirectDebit.GetKey();
                receipt.REF_CONT_ID = ddGenDetail[0].CONT_ID;
                receipt.DD_GENR_DET_ID = String.Join(",",ddGenDetail.Select(p=>p.DD_GENR_DET_ID));// ddGenDetail[0].DD_GENR_DET_ID.ToString();
                receipt.MNUL_RCPT_IND = false;
                receipt.AUTO_RCPT_IND = false;
                receipt.BP_ROLE_ID = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BP_ROLE_ID;//int.Parse(BusinessPartnerRole.Borrower.GetKey());
                receipt.BUSS_PTNR_ID = ddGenDetail[0].BUSS_PTNR_ID;
                receipt.BRNC_ID = ddParam.BranchId;
                receipt.CMPY_ID = ddParam.FinanceCompanyId;                
                receipt.EXTR_RCPT_NUMB = ReceiptingRepository.GetReceiptRunningNumber(ddParam.Context, ddParam.FinanceCompanyId, ddParam.BranchId);
                receipt.PYMT_MODE_ID = int.Parse(PaymentModeType.DirectDebit.GetKey());
                receipt.RCPT_PYMT_MODE_NME = PaymentModeType.DirectDebit.ToString();
                receipt.RCPT_AMNT = ddGenDetail.Sum(p=>p.AMNT);
                
                var res = BPCurrencies.ReadCrcyDescByContId(ddGenDetail[0].CONT_ID);
                if (res != null && res.Count > 0) { receipt.RCPT_CRCY_NME = res[0].DSCR; receipt.RCPT_CRCY_ID = res[0].CRCY_ID; }

                receipt.RCPT_DTE = ddParam.CurrentProcessingDate;
                
                if (ddParam.DDMiscConfig?.RCPT_VAL_DTE_BSIS == "Current Processing Date")
                {
                    receipt.VAL_DTE = ddParam.CurrentProcessingDate;
                }
                else
                {
                    var valueDate = ddGenDetail.Max(p => p.AMNT_DUE_DTE);
                    if (!CommonHelper.IsWorkingDay(ddParam.FinanceCompanyId, ddParam.BranchId, Convert.ToDateTime(valueDate)))
                    {
                        valueDate = CommonHelper.AddBusinessDays(Convert.ToDateTime(valueDate), 1, DaysYearType.FinancialWorkingDays, ddParam.FinanceCompanyId, ddParam.BranchId);
                    }
                    receipt.VAL_DTE = valueDate;
                }
                receipt.STS_KEY = StatusCode.Draft.GetKey();               

                receipt.PYER_BSB_CODE = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BSP_CODE;
                receipt.PYER_ACCT_NUMB = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).ACCT_NUMB;
                receipt.PYER_BANK_ID = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BANK_ID;
                receipt.PYER_BRNC_ID = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BRNC_ID;
                receipt.DRWR_NME = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BPNAME;

                receipt.PYEE_BSB_CODE = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BSP_CODE;
                receipt.PYEE_ACCT_NUMB = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).FC_ACCT_NUMB;
                receipt.PYEE_BANK_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BANK_ID;
                receipt.PYEE_BRNC_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BRNC_ID;


                ReceiptDetail receiptDetail = new ReceiptDetail();
                receiptDetail.RCPT_AMNT = ddGenDetail.Sum(p => p.AMNT);
                receiptDetail.RCPT_TYPE_ID = int.Parse(ReceiptType.NormalReceipt.GetKey());
                receiptDetail.RCPT_TYPE_NME = ReceiptType.NormalReceipt.ToString();
                receiptDetail.STS_KEY = StatusCode.Draft.GetKey();
                receipt.ReceiptDetail = new List<ReceiptDetail>();
                receipt.ReceiptDetail.Add(receiptDetail);
                if(ddGenDetail != null && ddGenDetail.Count > 0)
                    ddGenDetail.ForEach(p=>p.RCPT_TYPE_ID = receiptDetail.RCPT_TYPE_ID);
                ReceiptContractAssociation receiptContAsoc = new ReceiptContractAssociation();
                receiptContAsoc.CONT_ID = ddGenDetail[0].CONT_ID;
                receiptContAsoc.RCPT_AMNT = ddGenDetail.Sum(p => p.AMNT);
                receiptContAsoc.STS_KEY = StatusCode.Draft.GetKey();
                receiptDetail.ReceiptContractAssociation = new List<ReceiptContractAssociation>();
                receiptDetail.ReceiptContractAssociation.Add(receiptContAsoc);

                receiptParam.BranchId = ddParam.BranchId;
                receiptParam.CompanyId = ddParam.FinanceCompanyId;
                receiptParam.Receipts = new List<Receipt>() { receipt };               
                receiptParam.InvokeWorkflow = true;
                receiptParam.IsPreactivation = false;
                receiptParam.IsManualReceipt = false;
                receiptParam.ValueDte = ddParam.EffectiveToDate;
                receiptParam.ProcessingDte = ddParam.CurrentProcessingDate;
                receiptParam.ReceiptType = ReceiptType.NormalReceipt;
                receiptParam.DepositType = DepositTypes.None;
                receiptParam.IsEtFinalReceipt = false;
                receiptParam.LogInstallmentSettlement = ddParam.LogInstallmentSettlement;
                receiptParam.LogTransactionDetail = ddParam.LogTransactionDetail;
                FillDDReceiptInfo(receiptParam, ddGenDetail?.Find(p => p.AMNT_CMPT_TYPE_KEY == AmountComponents.Rental.GetKey()));                
            }
            return receiptParam;
        }
    }
}

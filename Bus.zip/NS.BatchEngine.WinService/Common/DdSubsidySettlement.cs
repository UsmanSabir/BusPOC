﻿using CMS.Business.Helper.Utility;
using CMS.Models.DirectDebit;
using CMS.Models.DirectDebit.Custom;
using CMS.Models.Receipting;
using CMS.Models.Receipting.Custom;
using CMS.ServiceContracts;
using NFS.Business.CommonHelper;
using NFS.Models.BusinessPartner;
using NFS.Models.BusinessPartner.Custom.Enum;
using NS.Resources.Enums.Common;
using NS.Resources.Enums.Receipt;
using NS.ServiceModel;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.DirectDebit.Business.Settlement
{
    class DdSubsidySettlement : DirectDebitSettlementBase
    {
        ReceiptType subsidyRecetiptType = ReceiptType.None;
        public DdSubsidySettlement(AmountComponents subsidyComponent )
        {
            if (subsidyComponent == AmountComponents.IntroducerSubsidy)
            {
                subsidyRecetiptType = ReceiptType.IntroducerSubsidyReceipt;
            }
            else if (subsidyComponent == AmountComponents.ManufacturerSubsidy)
            {
                subsidyRecetiptType = ReceiptType.ManufacturerSubsidyReceipt;
            }
        }
        public override ReceiptParam PrepareDirectDebitReceipt(List<DdGenerationDetail> ddGenDetails, DirectDebitParam ddParam, ReceiptParam receiptParam)
        {
            if (ddGenDetails != null && ddGenDetails.Count > 0)
            {
                var payerDetail = PayerDetail(ddGenDetails[0].CONT_ID);

                foreach (var ddGenDetail in ddGenDetails.Where(p => p.AMNT > 0))
                {
                    Receipt receipt = new Receipt();
                    receipt.DD_GENR_DET_ID = ddGenDetail.DD_GENR_DET_ID.ToString();
                    receipt.REF_CONT_ID = ddGenDetails[0].CONT_ID;
                    receipt.MNUL_RCPT_IND = false;
                    receipt.AUTO_RCPT_IND = false;
                    if (subsidyRecetiptType == ReceiptType.IntroducerSubsidyReceipt)
                    {
                        receipt.BP_ROLE_ID = int.Parse(BusinessPartnerRole.Introducer.GetKey());                        
                    }

                    else if (subsidyRecetiptType == ReceiptType.ManufacturerSubsidyReceipt)
                    {
                        receipt.BP_ROLE_ID = int.Parse(BusinessPartnerRole.Manufacturer.GetKey());                        
                    }
                    receipt.SRC = PaymentSource.DirectDebit.GetKey();
                    receipt.BUSS_PTNR_ID = ddGenDetail.BUSS_PTNR_ID;
                    receipt.BRNC_ID = ddParam.BranchId;
                    receipt.CMPY_ID = ddParam.FinanceCompanyId;
                    receipt.EXTR_RCPT_NUMB = ReceiptingRepository.GetReceiptRunningNumber(ddParam.Context, ddParam.FinanceCompanyId, ddParam.BranchId);
                    receipt.PYMT_MODE_ID = int.Parse(PaymentModeType.DirectDebit.GetKey());
                    receipt.RCPT_PYMT_MODE_NME = PaymentModeType.DirectDebit.ToString();
                    receipt.RCPT_AMNT = ddGenDetail.AMNT;
                    //  receipt.RCPT_CRCY_ID = Convert.ToInt32(GetCurrencyCode(ddGenDetail.CONT_ID));

                    var res = BPCurrencies.ReadCrcyDescByContId(ddGenDetail.CONT_ID);
                    if (res != null && res.Count > 0) { receipt.RCPT_CRCY_NME = res[0].DSCR; receipt.RCPT_CRCY_ID = res[0].CRCY_ID; }

                    receipt.RCPT_DTE = ddParam.CurrentProcessingDate;
                    if (ddParam.DDMiscConfig.RCPT_VAL_DTE_BSIS == "Current Processing Date")
                    {
                        receipt.VAL_DTE = ddParam.CurrentProcessingDate;
                    }
                    else
                    {
                        var valueDate = ddGenDetail.AMNT_DUE_DTE;
                        if (!CommonHelper.IsWorkingDay(ddParam.FinanceCompanyId, ddParam.BranchId, Convert.ToDateTime(valueDate)))
                        {
                            valueDate = CommonHelper.AddBusinessDays(Convert.ToDateTime(valueDate), 1, DaysYearType.FinancialWorkingDays, ddParam.FinanceCompanyId, ddParam.BranchId);
                        }
                        receipt.VAL_DTE = valueDate;
                    }
                    receipt.STS_KEY = StatusCode.Draft.GetKey();

                    //receipt.PYER_BSB_CODE = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 3).BSP_CODE;
                    //receipt.PYER_ACCT_NUMB = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 3).ACCT_NUMB;
                    //receipt.PYER_BANK_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 3).BANK_ID;
                    //receipt.PYER_BRNC_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 3).BRNC_ID;
                    //receipt.DRWR_NME = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 3).BPNAME;

                    //receipt.PYER_BSB_CODE = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BSP_CODE;
                    //receipt.PYER_ACCT_NUMB = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).ACCT_NUMB;
                    //receipt.PYER_BANK_ID = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BANK_ID;
                    //receipt.PYER_BRNC_ID = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BRNC_ID;
                    //receipt.DRWR_NME = payerDetail.FirstOrDefault(p => p.CONT_PYER_IND == true).BPNAME;
                    if (receipt?.BP_ROLE_ID > 0)
                    {
                        receipt.PYER_BSB_CODE = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == receipt.BP_ROLE_ID).BSP_CODE;
                        receipt.PYER_ACCT_NUMB = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == receipt.BP_ROLE_ID).ACCT_NUMB;
                        receipt.PYER_BANK_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == receipt.BP_ROLE_ID).BANK_ID;
                        receipt.PYER_BRNC_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == receipt.BP_ROLE_ID).BRNC_ID;
                        receipt.DRWR_NME = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == receipt.BP_ROLE_ID).BPNAME;
                    }                

                    receipt.PYEE_BSB_CODE = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BSP_CODE;
                    receipt.PYEE_ACCT_NUMB = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).FC_ACCT_NUMB;
                    receipt.PYEE_BANK_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BANK_ID;
                    receipt.PYEE_BRNC_ID = payerDetail.FirstOrDefault(p => p.BP_ROLE_ID == 41).BRNC_ID;


                    ReceiptDetail receiptDetail = new ReceiptDetail();
                    receiptDetail.RCPT_AMNT = ddGenDetail.AMNT;
                    receiptDetail.RCPT_TYPE_ID = int.Parse(subsidyRecetiptType.GetKey());
                    receiptDetail.RCPT_TYPE_NME = subsidyRecetiptType.ToString();

                    receiptDetail.STS_KEY = StatusCode.Draft.GetKey();
                    receipt.ReceiptDetail = new List<ReceiptDetail>();
                    receipt.ReceiptDetail.Add(receiptDetail);
                    ddGenDetail.RCPT_TYPE_ID = receiptDetail.RCPT_TYPE_ID;
                    ReceiptContractAssociation receiptContAsoc = new ReceiptContractAssociation();
                    receiptContAsoc.CONT_ID = ddGenDetail.CONT_ID;
                    receiptContAsoc.RCPT_AMNT = ddGenDetail.AMNT;
                    receiptContAsoc.STS_KEY = StatusCode.Draft.GetKey();
                    receiptDetail.ReceiptContractAssociation = new List<ReceiptContractAssociation>();
                    receiptDetail.ReceiptContractAssociation.Add(receiptContAsoc);
                    receiptParam.Receipts.Add(receipt);
                    //receiptParam.ReceiptDdMapping.Add(new ReceiptDDMapping() { DdDetailSeq = ddGenDetail.DD_GENR_DET_ID, ReceiptSeq = receiptParam.Receipts.Count });
                }

                receiptParam.BranchId = ddParam.BranchId;
                receiptParam.CompanyId = ddParam.FinanceCompanyId;
                receiptParam.InvokeWorkflow = true;
                receiptParam.IsPreactivation = false;
                receiptParam.IsManualReceipt = false;
                receiptParam.ValueDte = ddParam.EffectiveToDate;
                receiptParam.ProcessingDte = ddParam.CurrentProcessingDate;
                receiptParam.ReceiptType = subsidyRecetiptType;
                receiptParam.DepositType = DepositTypes.None;
                receiptParam.IsEtFinalReceipt = false;
                receiptParam.LogInstallmentSettlement = ddParam.LogInstallmentSettlement;
                receiptParam.LogTransactionDetail = ddParam.LogTransactionDetail;
            }
            return receiptParam;
        }
    }
}

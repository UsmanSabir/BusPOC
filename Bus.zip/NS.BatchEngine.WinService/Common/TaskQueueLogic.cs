﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using NS.BaseModels;
using NS.ExceptionHandling;
using NFS.Models.BPE;
using NFS.Models.BPE.Params;
using NFS.Models.BPM;
using NFS.Models.BPM.Params;
//using NS.Models.Screen;
using NS.ORM;
using NS.Utilities;
using NS.Utilities.Context;
using NS.Utilities.Enums;
//using NS.Models.UserManagement;
using System.Text;
//using NFS.ServiceContracts;
using NS.Resources.Enums;
using NS.Resources.Enums.Common;
using NFS.Models.BatchProcess.Custom;
//using NS.ServiceModel;
//using NS.ServiceContracts;
//using NFS.Models.BusinessPartner.Custom.Param;
//using CMS.ServiceContracts;
using NFS.Models.DayEnd;
using NS.ORM.UoW;
using System.Dynamic;
using NFS.Models.Common.Custom;
using BatchBootstrapper.Common;
using NFS.Models.BPE.Custom;
//using NFS.Business.BPE.Helper;
//using CMS.Models.ContractClosing;
//using POS.Models.Application;
using NS.Utilities.Helper;
using NS.Resources.Enums.Cache;
//using NS.Models.Cache.Helpers;
using NS.Utilities.Enums.Cache;
using NFS.Models;
using POS.Models.Application;
//using CAP.Business.FA.Helper;
//using NS.Business.Configurations.Helper;
//using NS.Models.Metadata.Custom;

namespace NS.Business
{
    /// <summary>
    /// Class which inherits <see cref="BusinessBase"/> and implements  <see cref="ITaskQueueService"/>, it serves as logic class for TaskQueueService.
    /// </summary>
    public class TaskQueueLogic : BusinessBase//, ITaskQueueService
    {



        
        public List<int> GetBatchProcessVolume(RequestObject<BatchProcessParam> requestObject)
        {
            List<int> response = new List<int>();

            try
            {
                var contextExt = EntityContextExt.Create<RequestsToHistoryVolumeCAP>();
                if (requestObject.Object.BranchId > 0)
                {
                    contextExt.Read(requestObject.Object.BranchId, requestObject.Object.ProcessingDate, DateTime.UtcNow);

                    if (contextExt.Entity != null && contextExt.Entity.Count > 0)
                    {
                        List<RequestsToHistoryVolumeCAP> list = contextExt.Entity.Where(x => x.ISCOMPLIANCEAPPROVAL == false).ToList();
                        foreach (var item in list)
                        {
                            WorkingDayCalcParam param = new WorkingDayCalcParam() { BranchId = requestObject.Object.BranchId, CompanyId = requestObject.Object.CompanyId, ValueDte = item.STS_CHNG_DTE.Value };
                            //var modifiedDate = CommonHelper.GetNextWorkinDay(requestObject.Object.WorkingDay, param, Convert.ToInt32(item.CSHN_DAYS));

                            //if (modifiedDate <= item.PRCG_DTE)
                            //{
                                response.Add(item.TASK_QUEU_ID);

                            //}
                        }
                        var complianceApprovalList = contextExt.Entity.Where(x => x.ISCOMPLIANCEAPPROVAL == true).Select(x => x.TASK_QUEU_ID).ToList();
                        if (complianceApprovalList != null && complianceApprovalList.Count > 0)
                        {
                            response.AddRange(complianceApprovalList);
                        }
                        //response = contextExt.Entity.Select(p => p.TASK_QUEU_ID).ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }

        public List<int> GetBatchProcessVolumeCAP(RequestObject<BatchProcessParam> requestObject)
        {
            List<int> response = new List<int>();

            try
            {
                var contextExt = EntityContextExt.Create<RequestsToHistoryVolumeCAP>();
                if (requestObject.Object.BranchId > 0)
                {
                    //contextExt.Read(requestObject.Object.BranchId, requestObject.Object.ProcessingDate, DateTime.UtcNow);
                    contextExt.Read(requestObject.Object.BranchId, requestObject.Object.ProcessingDate, DateTime.UtcNow);
                    if (contextExt.Entity != null && contextExt.Entity.Count > 0)
                    {
                        List<RequestsToHistoryVolumeCAP> list = contextExt.Entity.Where(x => x.ISCOMPLIANCEAPPROVAL == false).ToList();
                        foreach (var item in list)
                        {
                            WorkingDayCalcParam param = new WorkingDayCalcParam() { BranchId = requestObject.Object.BranchId, CompanyId = requestObject.Object.CompanyId, ValueDte = item.STS_CHNG_DTE.Value };
                            var modifiedDate = CommonHelper.GetNextWorkinDay(requestObject.Object.WorkingDay, param, Convert.ToInt32(item.CSHN_DAYS));

                            if (modifiedDate <= item.PRCG_DTE)
                            {
                                response.Add(item.TASK_QUEU_ID);

                            }
                        }
                        var complianceApprovalList = contextExt.Entity.Where(x => x.ISCOMPLIANCEAPPROVAL == true).Select(x => x.TASK_QUEU_ID).ToList();
                        if (complianceApprovalList != null && complianceApprovalList.Count > 0)
                        {
                            response.AddRange(complianceApprovalList);
                        }
                        //response = contextExt.Entity.Select(p => p.TASK_QUEU_ID).ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public bool MoveRequestToHistory(RequestObject<int> requestObject)
        {
            bool response = true;
            try
            {
                var ctx = EntityContextExt.Create<DayEndTaskQueueRequest>();
                ctx.Read(x => x.TASK_QUEU_ID == requestObject.Object, 2);

                if (ctx.Entity != null && ctx.Entity.Count > 0)
                {
                    List<DayEndTaskQueueRequest> childTasks = ctx.Entity?.FirstOrDefault()?.TaskQueueChildren;
                    //Convert Child Tasks to History Objects
                    List<DayEndTaskQueueRequestHistory> moveToHistory = childTasks?.ConvertAll(x => new DayEndTaskQueueRequestHistory
                    {
                        TASK_QUEU_ID = x.TASK_QUEU_ID,
                        APPL_KEY = x.APPL_KEY,
                        STS_KEY = x.STS_KEY,
                        REQT_TYPE_KEY = x.REQT_TYPE_KEY,
                        NEXT_STS_KEY = x.NEXT_STS_KEY,
                        MDUL_KEY = x.MDUL_KEY,
                        REF_NUMB = x.REF_NUMB,
                        QUEU_ID = x.QUEU_ID,
                        CMNT = x.CMNT,
                        DUE_DTE = x.DUE_DTE,
                        TASK_STRT_TIME = x.TASK_STRT_TIME,
                        TASK_CMPL_TIME = x.TASK_CMPL_TIME,
                        LOCK_IND = x.LOCK_IND,
                        ASGN_USR = x.ASGN_USR,
                        PRNT_TASK = x.PRNT_TASK,
                        SCRN_ID = x.SCRN_ID,
                        SCRN_NME = x.SCRN_NME,
                        PRTY = x.PRTY,
                        SUB_STS_KEY = x.SUB_STS_KEY,
                        STS_CHNG_DTE = x.STS_CHNG_DTE,
                        RESN_ID = x.RESN_ID,
                        PRTY_SET_BY = x.PRTY_SET_BY,
                        RCMD_CNT = x.RCMD_CNT,
                        REQT_TABS = x.REQT_TABS,
                        INSR_BY = x.INSR_BY,
                        UPDT_BY = x.UPDT_BY,
                        INSR_DTE = x.INSR_DTE,
                        UPDT_DTE = x.UPDT_DTE,
                        TOTL_RCMD_CMPL = x.TOTL_RCMD_CMPL,
                        MDUL_REF = x.MDUL_REF,
                        BRNC_ID = x.BRNC_ID,
                        REQT_CRTN_DTE = x.REQT_CRTN_DTE,
                        STS_CHNG_PRCG_DTE = x.STS_CHNG_PRCG_DTE
                    });

                    //Add Parent Task to History Objects
                    DayEndTaskQueueRequest parentTask = ctx.Entity.FirstOrDefault();
                    if (moveToHistory == null)
                    {
                        moveToHistory = new List<DayEndTaskQueueRequestHistory>();
                    }
                    moveToHistory.Add(new DayEndTaskQueueRequestHistory
                    {
                        TASK_QUEU_ID = parentTask.TASK_QUEU_ID,
                        APPL_KEY = parentTask.APPL_KEY,
                        STS_KEY = parentTask.STS_KEY,
                        REQT_TYPE_KEY = parentTask.REQT_TYPE_KEY,
                        NEXT_STS_KEY = parentTask.NEXT_STS_KEY,
                        MDUL_KEY = parentTask.MDUL_KEY,
                        REF_NUMB = parentTask.REF_NUMB,
                        QUEU_ID = parentTask.QUEU_ID,
                        CMNT = parentTask.CMNT,
                        DUE_DTE = parentTask.DUE_DTE,
                        TASK_STRT_TIME = parentTask.TASK_STRT_TIME,
                        TASK_CMPL_TIME = parentTask.TASK_CMPL_TIME,
                        LOCK_IND = parentTask.LOCK_IND,
                        ASGN_USR = parentTask.ASGN_USR,
                        PRNT_TASK = parentTask.PRNT_TASK,
                        SCRN_ID = parentTask.SCRN_ID,
                        SCRN_NME = parentTask.SCRN_NME,
                        PRTY = parentTask.PRTY,
                        SUB_STS_KEY = parentTask.SUB_STS_KEY,
                        STS_CHNG_DTE = parentTask.STS_CHNG_DTE,
                        RESN_ID = parentTask.RESN_ID,
                        PRTY_SET_BY = parentTask.PRTY_SET_BY,
                        RCMD_CNT = parentTask.RCMD_CNT,
                        REQT_TABS = parentTask.REQT_TABS,
                        INSR_BY = parentTask.INSR_BY,
                        UPDT_BY = parentTask.UPDT_BY,
                        INSR_DTE = parentTask.INSR_DTE,
                        UPDT_DTE = parentTask.UPDT_DTE,
                        TOTL_RCMD_CMPL = parentTask.TOTL_RCMD_CMPL,
                        MDUL_REF = parentTask.MDUL_REF,
                        BRNC_ID = parentTask.BRNC_ID,
                        REQT_CRTN_DTE = parentTask.REQT_CRTN_DTE,
                        STS_CHNG_PRCG_DTE = parentTask.REQT_CRTN_DTE
                    });
                    string creditApproval = RequestTypeCodes.CreditApproval.GetKey();
                    DayEndTaskQueueRequest objDayEndTaskQueueRequest = ctx.Entity.FirstOrDefault();
                    var moveToHistoryCtx = EntityContextExt.Create(moveToHistory);
                    using (IUnitOfWork uow = moveToHistoryCtx.InitiateUnitOfWork())
                    {
                        if (objDayEndTaskQueueRequest.REQT_TYPE_KEY == creditApproval && objDayEndTaskQueueRequest.APPL_KEY.ToUpper() == "CAP")
                        {
                            var applicationContext = EntityContextExt.Create<ApplicationDayEnd>();
                            applicationContext.Read(x => x.APPL_ID == objDayEndTaskQueueRequest.REF_NUMB, 1);
                            //Mark History Indicator
                            //Request will be moved to history once "Move Request to History" Batch process is executed.
                            if (applicationContext.Entity != null && applicationContext.Entity.Count > 0)
                            {
                                ApplicationDayEnd application = applicationContext.Entity.FirstOrDefault();
                                application.HIST_IND = true;
                            }
                            applicationContext.UsingUnitOfWork(uow).Persist();
                        }
                        ctx.Entity.ForEach(x => x.State = EntityState.Delete);
                        ctx.UsingUnitOfWork(uow).Persist();
                        //Persist Task
                        //if (objDayEndTaskQueueRequest.REQT_TYPE_KEY == creditApproval && objDayEndTaskQueueRequest.APPL_KEY.ToUpper() == "CAP")
                        {
                            moveToHistoryCtx.Persist(extendedSkipList: true);
                        }
                        //else
                        //{
                        //    moveToHistoryCtx.Persist();
                        //}
                        uow.Save();
                    }

                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                response = false;
            }
            return response;
        }

        //        /// <inheritdoc/>
        //        public ResponseObject<bool> RequestExistsWithoutFinalStatus(RequestObject<TaskQueueRequestSearchParam> request)
        //        {
        //            var resp = new ResponseObject<bool>() { Message = new MessageInfo() { Type = MessageType.Success } };
        //            try
        //            {
        //                int? reqtCount;
        //                int refId = Convert.ToInt32(request.Object.ReferenceId);
        //                List<string> reqtTypes = new List<string>();

        //                if ((request.Object.RequestTypeCodes?.Any()).GetValueOrDefault())
        //                    reqtTypes.AddRange(request.Object.RequestTypeCodes);

        //                if (!string.IsNullOrEmpty(request.Object.RequestType) && !reqtTypes.Any(x => x == request.Object.RequestType))
        //                    reqtTypes.Add(request.Object.RequestType);

        //                string reqtType = string.Join(",", reqtTypes);

        //                if (request.Object.RequestType == RequestTypeCodes.WriteOffRequest.GetKey())
        //                {
        //                    reqtCount = TaskQueueCount.WoffExistsWithoutFinalStatus(reqtType, refId)?.FirstOrDefault().REQT_CNT;
        //                }
        //                else
        //                {
        //                    ModuleTypeCode module = EnumExtensions.GetEnumValueFromKey<ModuleTypeCode>(request.Object.ModuleKey);
        //                    switch (module)
        //                    {
        //                        case ModuleTypeCode.BUSINESS_PARTNER:
        //                            reqtCount = TaskQueueCount.BpExistsWithoutFinalStatus(reqtType, refId)?.FirstOrDefault().REQT_CNT;
        //                            break;
        //                        case ModuleTypeCode.FINANCIAL_PRODUCT:
        //                            reqtCount = TaskQueueCount.FpExistsWithoutFinalStatus(reqtType, refId)?.FirstOrDefault().REQT_CNT;
        //                            break;
        //                        case ModuleTypeCode.FINANCIAL_PRODUCT_GROUP:
        //                            reqtCount = TaskQueueCount.FpgExistsWithoutFinalStatus(reqtType, refId)?.FirstOrDefault().REQT_CNT;
        //                            break;
        //                        case ModuleTypeCode.ASSET:
        //                            reqtCount = TaskQueueCount.AssetExistsWithoutFinalStatus(reqtType, refId)?.FirstOrDefault().REQT_CNT;
        //                            break;
        //                        case ModuleTypeCode.CHART:
        //                            reqtCount = TaskQueueCount.ChartExistsWithoutFinalStatus(reqtType, refId)?.FirstOrDefault().REQT_CNT;
        //                            break;
        //                        default:
        //                            reqtCount = TaskQueueCount.RequestExistsWithoutFinalStatus(reqtType, refId)?.FirstOrDefault().REQT_CNT;
        //                            break;
        //                    }
        //                }
        //                resp.ResultSet = reqtCount.GetValueOrDefault() > 0;
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return resp;
        //        }

        //        public ResponseObject<bool> RequestExistsWithSpecifiedStatus(RequestObject<TaskQueueRequestSearchParam> request)
        //        {
        //            var resp = new ResponseObject<bool>() { Message = new MessageInfo() { Type = MessageType.Success } };
        //            try
        //            {
        //                int? reqtCount;
        //                int refId = Convert.ToInt32(request.Object.ReferenceId);
        //                List<string> reqtTypes = new List<string>();

        //                if ((request.Object.RequestTypeCodes?.Any()).GetValueOrDefault())
        //                    reqtTypes.AddRange(request.Object.RequestTypeCodes);

        //                if (!string.IsNullOrEmpty(request.Object.RequestType) && !reqtTypes.Any(x => x == request.Object.RequestType))
        //                    reqtTypes.Add(request.Object.RequestType);

        //                string reqtType = string.Join(",", reqtTypes);

        //                ModuleTypeCode module = EnumExtensions.GetEnumValueFromKey<ModuleTypeCode>(request.Object.ModuleKey);
        //                switch (module)
        //                {
        //                    case ModuleTypeCode.BUSINESS_PARTNER:
        //                        reqtCount = TaskQueueCount.BpExistsWithStatus(reqtType, refId, request.Object.RequestStatus)?.FirstOrDefault().REQT_CNT;
        //                        break;
        //                    case ModuleTypeCode.FINANCIAL_PRODUCT:
        //                        reqtCount = TaskQueueCount.FpExistsWithStatus(reqtType, refId, request.Object.RequestStatus)?.FirstOrDefault().REQT_CNT;
        //                        break;
        //                    case ModuleTypeCode.FINANCIAL_PRODUCT_GROUP:
        //                        reqtCount = TaskQueueCount.FpgExistsWithStatus(reqtType, refId, request.Object.RequestStatus)?.FirstOrDefault().REQT_CNT;
        //                        break;
        //                    case ModuleTypeCode.ASSET:
        //                        reqtCount = TaskQueueCount.AssetExistsWithStatus(reqtType, refId, request.Object.RequestStatus)?.FirstOrDefault().REQT_CNT;
        //                        break;
        //                    default:
        //                        reqtCount = TaskQueueCount.RequestExistsWithStatus(reqtType, refId, request.Object.RequestStatus)?.FirstOrDefault().REQT_CNT;
        //                        break;
        //                }
        //                resp.ResultSet = reqtCount.GetValueOrDefault() > 0;
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return resp;
        //        }
        //        public ResponseObject<bool> RequestExistsWithSpecifiedStatusByContractNum(RequestObject<TaskQueueRequestSearchParam> request)
        //        {
        //            var resp = new ResponseObject<bool>() { Message = new MessageInfo() { Type = MessageType.Success } };
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                contextExt.Read(r => r.REQT_TYPE_KEY == request.Object.RequestType && r.MDUL_REF == request.Object.ReferenceId && r.STS_KEY == request.Object.RequestStatus);
        //                var data = contextExt.Entity;
        //                if (data != null && data.Count > 0)
        //                    resp.ResultSet = true;
        //                else
        //                    resp.ResultSet = false;
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return resp;
        //        }
        //        #region Private Methods

        //        private string ToStringTimeSpan(TimeSpan span)
        //        {
        //            if (span == TimeSpan.Zero) return "0 minutes";

        //            var sb = new StringBuilder();
        //            if (span.Days > 0)
        //                sb.AppendFormat("{0} day{1} ", span.Days, span.Days > 1 ? "s" : string.Empty);
        //            if (span.Hours > 0)
        //                sb.AppendFormat("{0} hour{1} ", span.Hours, span.Hours > 1 ? "s" : string.Empty);
        //            if (string.IsNullOrEmpty(sb.ToString()) && span.Minutes > 0)
        //                sb.AppendFormat("{0} minute{1} ", span.Minutes, span.Minutes > 1 ? "s" : string.Empty);
        //            if (string.IsNullOrEmpty(sb.ToString()) && span.Seconds > 0)
        //            {
        //                sb.AppendFormat("{0} second{1} ", span.Seconds, span.Seconds > 1 ? "s" : string.Empty);
        //            }
        //            return sb.ToString();
        //        }
        //        /// <summary>
        //        /// Method to Read Task By ID
        //        /// </summary>
        //        /// <param name="requestObject">Task Id</param>
        //        /// <returns>TaskQueueRequest Object</returns>
        //        public ResponseObject<TaskQueueRequest> ReadTaskById(RequestObject<int> requestObject)
        //        {
        //            ResponseObject<TaskQueueRequest> response = new ResponseObject<TaskQueueRequest>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();

        //                contextExt.Read(a => a.TASK_QUEU_ID == requestObject.Object);
        //                if (contextExt.Entity != null)
        //                    response.ResultSet = contextExt.Entity.FirstOrDefault();
        //            }

        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Method to Read compliance task by provided PaymentApproval Task Id
        //        /// </summary>
        //        /// <param name="requestObject">Task Id</param>
        //        /// <returns>TaskQueueRequest Object</returns>
        //        public ResponseObject<List<BpmWorkflowHistory>> ReadComplianceHistoryByPaymentTaskId(int refNumb)
        //        {
        //            ResponseObject<List<BpmWorkflowHistory>> response = new ResponseObject<List<BpmWorkflowHistory>>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                var reqtTypeKey = RequestTypeCodes.ComplianceApproval.GetKey();
        //                contextExt.Read(a => a.REF_NUMB == refNumb && a.REQT_TYPE_KEY == reqtTypeKey);
        //                if (contextExt.Entity != null && contextExt.Entity.Any())
        //                {
        //                    var complianceTaskId = contextExt.Entity.FirstOrDefault().TASK_QUEU_ID;
        //                    using (var historyContext = EntityContextExt.Create<BpmWorkflowHistory>())
        //                    {
        //                        historyContext.Read(p => p.REQT_ID == complianceTaskId);
        //                        if (historyContext.Entity != null)
        //                        {
        //                            response.ResultSet = historyContext.Entity;
        //                            response.Message.Type = MessageType.Success;
        //                        }
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Method to Read Cap Task By ID
        //        /// </summary>
        //        /// <param name="requestObject">Task Id</param>
        //        /// <returns>TaskQueueRequest Object</returns>
        //        public ResponseObject<TaskQueueRequestCAP> ReadCapTaskById(RequestObject<int> requestObject)
        //        {
        //            ResponseObject<TaskQueueRequestCAP> response = new ResponseObject<TaskQueueRequestCAP>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequestCAP>();

        //                contextExt.Read(a => a.TASK_QUEU_ID == requestObject.Object);
        //                if (contextExt.Entity != null)
        //                    response.ResultSet = contextExt.Entity.FirstOrDefault();
        //            }

        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        public ResponseObject<List<TaskQueueRequest>> WithdrawTaskQueueRequest(RequestObject<AssignmentParams> requestObject)
        //        {
        //            AssignmentParams assignmentParams = requestObject.Object;
        //            ResponseObject<List<TaskQueueRequest>> response = new ResponseObject<List<TaskQueueRequest>>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };

        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                foreach (var requestId in requestObject.Object.RequestIds)
        //                {
        //                    contextExt.Read(a => a.TASK_QUEU_ID == requestId);
        //                    TaskQueueRequest taskQueueRequest = contextExt.Entity.First();
        //                    if (!taskQueueRequest.LOCK_IND && taskQueueRequest.ASGN_USR != assignmentParams.SelectedUserLoginId)
        //                    {
        //                        taskQueueRequest.RESN_ID = assignmentParams.WithdrawReason;
        //                        taskQueueRequest.CMNT = assignmentParams.Comments ?? assignmentParams.Comments;
        //                        taskQueueRequest.STS_KEY = assignmentParams.SelecteRequestStatus;
        //                        contextExt.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                        if (response.ResultSet == null)
        //                            response.ResultSet = new List<TaskQueueRequest>();
        //                        response.ResultSet.Add(taskQueueRequest);

        //                        response.WorkflowInput = GetWorkflowParams(requestObject.Context, taskQueueRequest);
        //                        //if (response.Message.Type == MessageType.Success)
        //                        //{
        //                        //    WorkflowInputParams workflowParams = new WorkflowInputParams()
        //                        //    {
        //                        //        ScreenId = requestObject.Context.ScreenId,
        //                        //        ScreenAction = requestObject.Context.Action,
        //                        //        RequestType = RequestTypeCodes.CreditApproval.GetKey(),
        //                        //        Module = ModuleTypeCode.Proposal.GetKey(),
        //                        //        StatusTo = StatusCode.Withdrawn.GetKey(),
        //                        //        ReferenceId = "1",
        //                        //        Session = requestObject.Context,
        //                        //    };
        //                        //    response.WorkflowInput = workflowParams;
        //                        //}
        //                    }
        //                }
        //                return response;
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //                response.ResultSet = null;
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Withdraws task queue request
        //        /// </summary>
        //        /// <param name="requestObject">TaskQueueRequest Object</param>
        //        /// <returns>Submit Task Queue Request Instance</returns>
        //        public ResponseObject<TaskQueueRequestCAP> WithdrawTaskQueueRequest(RequestObject<TaskQueueRequestCAP> requestObject)
        //        {
        //            ResponseObject<TaskQueueRequestCAP> response = new ResponseObject<TaskQueueRequestCAP>
        //            {
        //                Message = new MessageInfo() { Message = "INFORMATION_SAVED", Type = MessageType.Success }
        //            };

        //            try
        //            {
        //                if (requestObject.Object.MDUL_KEY == ModuleTypeCode.APPLICATION.GetKey()
        //                    && requestObject.Object.APPL_KEY == ApplicationCodes.Cap.GetKey()
        //                    && requestObject.Object.TASK_QUEU_ID > 0
        //                    && requestObject.Context.ApplicationCode == ApplicationCodes.Pos.GetKey())
        //                {
        //                    var contextPosExt = EntityContextExt.Create<TaskQueueRequestCAP>();
        //                    var result =
        //                        contextPosExt.Read(p => p.TASK_QUEU_ID == requestObject.Object.TASK_QUEU_ID)
        //                            .Entity.FirstOrDefault();
        //                    if (result != null)
        //                    {
        //                        result.CMNT = requestObject.Object.CMNT;
        //                        result.RESN_ID = requestObject.Object.RESN_ID;
        //                        result.NEXT_STS_KEY = StatusCode.WithdrawRequestPending.GetKey();
        //                        result.STS_CHNG_DTE = DateTime.Now;
        //                        requestObject.Object = result;
        //                    }

        //                }
        //                else
        //                {
        //                    if (requestObject.Object.NEXT_STS_KEY == StatusCode.Approved.GetKey())
        //                    {
        //                        // status Withdrawn if BO User Approves Request initiated from POS
        //                        requestObject.Object.NEXT_STS_KEY = StatusCode.Withdrawn.GetKey();
        //                        requestObject.Object.STS_CHNG_DTE = DateTime.Now;
        //                        requestObject.Object.PRTY = null;
        //                        requestObject.Object.TASK_CMPL_TIME = DateTime.UtcNow;

        //                        FinancialAnalysisLogicHelper.UpdateFa(Convert.ToInt32(requestObject.Object.REF_NUMB), Convert.ToInt32(requestObject.Object.RESN_ID), requestObject.Context.LoginId);

        //                    }
        //                    else if (requestObject.Object.NEXT_STS_KEY == StatusCode.Declined.GetKey())
        //                    {
        //                        // status revert if BO User Declines Request
        //                        string requestStatusTo = string.Empty;
        //                        requestStatusTo = ReadRequestPreviousStatus(Convert.ToInt32(requestObject.Object.TASK_QUEU_ID), StatusCode.WithdrawRequestPending.GetKey());
        //                        requestObject.Object.STS_CHNG_DTE = DateTime.Now;
        //                        requestObject.Object.NEXT_STS_KEY = requestStatusTo;
        //                        requestObject.Object.PRTY = null;
        //                    }
        //                    else
        //                    {
        //                        // from CAP side - directly withdrawn
        //                        requestObject.Object.STS_CHNG_DTE = DateTime.Now;
        //                        requestObject.Object.NEXT_STS_KEY = StatusCode.Withdrawn.GetKey();
        //                        requestObject.Object.PRTY = null;
        //                        requestObject.Object.TASK_CMPL_TIME = DateTime.UtcNow;

        //                        FinancialAnalysisLogicHelper.UpdateFa(Convert.ToInt32(requestObject.Object.REF_NUMB), Convert.ToInt32(requestObject.Object.RESN_ID), requestObject.Context.LoginId);
        //                    }
        //                }
        //                var contextExt = EntityContextExt.Create(new[] { requestObject.Object });
        //                contextExt.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                if (contextExt.Entity != null)
        //                {
        //                    response.ResultSet = contextExt.Entity[0];

        //                    List<string> referenceIdsList = new List<string>();
        //                    referenceIdsList.Add(response.ResultSet.TASK_QUEU_ID.ToString());
        //                    response.WorkflowInput = (new WorkflowInputParams
        //                    {
        //                        Module = response.ResultSet.MDUL_KEY,
        //                        ReferenceId = response.ResultSet.REF_NUMB ?? 0,
        //                        ReferenceIdsList = referenceIdsList,
        //                        StatusFrom = response.ResultSet.STS_KEY,
        //                        StatusTo = response.ResultSet.NEXT_STS_KEY,
        //                        ScreenId = 2668,
        //                        ScreenAction = "Submit",
        //                        PostAction = true,
        //                        Session = requestObject.Context,
        //                        RequestType = response.ResultSet.REQT_TYPE_KEY,
        //                        CreditReqManualAction = CreditRequestManualActions.WithdrawRequest.GetKey()
        //                    });
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        public ResponseObject<TaskQueueRequest> ReadTaskQueueCreditApproval(RequestObject<int> requestObject)
        //        {
        //            ResponseObject<TaskQueueRequest> response = new ResponseObject<TaskQueueRequest>();
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                string requestType = RequestTypeCodes.CreditApproval.GetKey();
        //                contextExt.Read(r => r.REF_NUMB == requestObject.Object
        //                                    && r.REQT_TYPE_KEY == requestType);
        //                if (contextExt.Entity != null)
        //                {
        //                    response.ResultSet = contextExt.Entity.SingleOrDefault();
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Read Task Queue Request by Specified Refrence Id and Request Type and Request Status
        //        /// </summary>
        //        /// <param name="request">TaskQueueRequestSearchParam wrapped in RequestObject.</param>
        //        /// <returns>TaskQueueRequest</returns>
        //        public ResponseObject<TaskQueueRequest> ReadTaskQueueRequest(RequestObject<TaskQueueRequestSearchParam> request)
        //        {
        //            ResponseObject<TaskQueueRequest> response = new ResponseObject<TaskQueueRequest>();
        //            try
        //            {
        //                int refId = Convert.ToInt32(request.Object.ReferenceId);
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                if (request.Object.TaskQueueId > 0)
        //                {
        //                    contextExt.Read(r => r.TASK_QUEU_ID == request.Object.TaskQueueId);
        //                }
        //                else
        //                {
        //                    contextExt.Read(r => r.REQT_TYPE_KEY == request.Object.RequestType && r.STS_KEY == request.Object.RequestStatus && r.REF_NUMB == refId);
        //                }
        //                if (contextExt.Entity != null)
        //                    response.ResultSet = contextExt.Entity.FirstOrDefault();
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }
        //        /// <summary>
        //        /// Read Task Queue Request
        //        /// </summary>
        //        /// <param name="requestObject">Application Id</param>
        //        /// <returns>Task Queue Request</returns>
        //        public ResponseObject<TaskQueueRequestPos> ReadTaskQueueByApplicationId(RequestObject<int> requestObject)
        //        {
        //            ResponseObject<TaskQueueRequestPos> response = new ResponseObject<TaskQueueRequestPos>();
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequestPos>();
        //                string requestType = RequestTypeCodes.CreditApproval.GetKey();
        //                contextExt.Read(r => r.REF_NUMB == requestObject.Object && r.REQT_TYPE_KEY == requestType);

        //                if (contextExt.Entity != null)
        //                {
        //                    response.ResultSet = contextExt.Entity.SingleOrDefault();
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        public ResponseObject<IList<NfsQueue>> ReadUserQueues(RequestObject<List<int>> requestObject)
        //        {
        //            ResponseObject<IList<NfsQueue>> response = new ResponseObject<IList<NfsQueue>>
        //            {
        //                Message = new MessageInfo()
        //            };
        //            try
        //            {
        //                List<NfsQueue> localData = new List<NfsQueue>();
        //                var list = requestObject.Object;
        //                if (list != null && list.Count > 0)
        //                {
        //                    using (var contextExt = EntityContextExt.Create<NfsQueue>())
        //                    {
        //                        contextExt.Read(x => list.Contains(x.QUEU_ID));

        //                        if (contextExt.Entity.Any())
        //                            localData.AddRange(contextExt.Entity);
        //                    }
        //                }
        //                string userName = ReadUserName(requestObject.Context);
        //                // Added two new records for Current Logged In User and Data Access
        //                localData.Add(new NfsQueue { QUEU_ID = -1, DSCR = userName, NME = userName, QUEU_TYPE_KEY = "User" });
        //                localData.Add(new NfsQueue { QUEU_ID = -2, DSCR = "Data Access", NME = "Data Access", QUEU_TYPE_KEY = "Data Access" });
        //                response.Message.Type = MessageType.Success;
        //                response.ResultSet = localData;
        //                return response;
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return null;
        //        }

        //        private string ReadUserName(Context context)
        //        {
        //            ISecurityService srv = null;
        //            string userName = string.Empty;
        //            try
        //            {
        //                RequestObject<List<string>> requestObject = new RequestObject<List<string>>(context, new List<string>());
        //                requestObject.Object.Add(context.LoginId);

        //                srv = ChannelFactory.CreateChannel<ISecurityService>();
        //                var responseObject = srv.ReadSystemUserLight(requestObject);
        //                if (responseObject != null)
        //                    userName = (responseObject.ResultSet.FirstOrDefault().USR_FIRT_NME + responseObject.ResultSet.FirstOrDefault().USR_LAST_NME);
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            finally
        //            {
        //                ChannelFactory.CloseChannel(srv);
        //            }
        //            return userName;
        //        }

        //        private string ReadRequestPreviousStatus(int requestId, string statusCode)
        //        {
        //            string prevStatus = StatusCode.RTO.GetKey(); // In worst case status should be valid not empty or null.

        //            try
        //            {
        //                var data = BpmWorkflowHistory.RecentRequestHistory(requestId);

        //                if (data != null && data.Count > 0)
        //                {
        //                    var filteredData = data.Where(a => a.TO_STS != a.FRM_STS);
        //                    if (filteredData != null && filteredData.ToList().Count > 0)
        //                    {
        //                        var desiredValue = filteredData.OrderByDescending(p => p.WKF_HIST_ID).FirstOrDefault();
        //                        if (!string.IsNullOrEmpty(desiredValue.FRM_STS) && desiredValue.FRM_STS != StatusCode.InProcess.GetKey())
        //                            prevStatus = desiredValue.FRM_STS;
        //                        else
        //                        {
        //                            if (!string.IsNullOrEmpty(desiredValue.TO_STS) && desiredValue.FRM_STS != StatusCode.InProcess.GetKey())
        //                                prevStatus = desiredValue.TO_STS;
        //                            else
        //                                prevStatus = StatusCode.RTO.GetKey();
        //                        }
        //                    }
        //                    else
        //                    {
        //                        prevStatus = StatusCode.RTO.GetKey();
        //                    }
        //                }
        //                else // In worst case when there is no row in DB due to any reason then dafault status should be R.T.O
        //                {
        //                    prevStatus = StatusCode.RTO.GetKey();
        //                }

        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }

        //            return prevStatus;
        //        }

        //        private string ReadRequestPreviousStatus(int requestId)
        //        {
        //            string prevStatus = string.Empty;
        //            try
        //            {
        //                var historydata = BpmWorkflowHistory.RecentRequestHistory(requestId);
        //                if (historydata != null && historydata.Count > 0)
        //                    prevStatus = historydata?.FirstOrDefault(x => x.ACTN_KEY == TaskQueueRequestActionCode.ChangeStatus.GetKey()).FRM_STS;
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }

        //            return prevStatus;
        //        }

        //        public ResponseObject<BpmWorkflowHistory> ReadRequestPreviousComments(RequestObject<TaskQueueRequestSearchParam> param)
        //        {
        //            ResponseObject<BpmWorkflowHistory> response = new ResponseObject<BpmWorkflowHistory>
        //            {
        //                Message = new MessageInfo()
        //            };
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<BpmWorkflowHistory>();
        //                contextExt.Read(p => p.REQT_ID == param.Object.TaskQueueId && p.TO_STS == param.Object.RequestStatus);
        //                var data = contextExt.Entity;

        //                if (data != null)
        //                {
        //                    data = data.Where(s => s.FRM_STS != s.TO_STS).ToList();
        //                    response.ResultSet = data.OrderByDescending(p => p.UPDT_DTE).FirstOrDefault();
        //                }

        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }

        //            return response;
        //        }

        //        public ResponseObject<string> ReadRequestPreviousStatus(RequestObject<int> requestObject)
        //        {
        //            ResponseObject<string> response = new ResponseObject<string>
        //            {
        //                Message = new MessageInfo()
        //            };
        //            try
        //            {
        //                string prevStatus = ReadRequestPreviousStatus(requestObject.Object);
        //                if (prevStatus != null)
        //                {
        //                    response.ResultSet = prevStatus;
        //                }

        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }

        //            return response;
        //        }

        //        private bool ReadEntityByRefId(string moduleKey, string referenceId, Context session, out string refEntityId)
        //        {
        //            refEntityId = null;
        //            ModuleTypeCode module = EnumExtensions.GetEnumValueFromKey<ModuleTypeCode>(moduleKey);

        //            switch (module)
        //            {
        //                case ModuleTypeCode.BUSINESS_PARTNER:

        //                    IBusinessPartnerService bpSvc = ChannelFactory.CreateChannel<IBusinessPartnerService>();
        //                    var bpReq = new RequestObject<BPParam>(session, new BPParam() { BPId = Convert.ToInt32(referenceId), EntityReadDepth = 1 });
        //                    var bpResp = bpSvc.ReadBusinessPartnerByRefId(bpReq);
        //                    ChannelFactory.CloseChannel(bpSvc);
        //                    refEntityId = Convert.ToString(bpResp?.ResultSet?.BUSS_PTNR_ID);
        //                    break;
        //                case ModuleTypeCode.FINANCIAL_PRODUCT:
        //                    IFinancialProductService fpSvc = ChannelFactory.CreateChannel<IFinancialProductService>();
        //                    var fpReq = new RequestObject<int>(session, Convert.ToInt32(referenceId));
        //                    var fpResp = fpSvc.ReadFpByRefId(fpReq);
        //                    ChannelFactory.CloseChannel(fpSvc);
        //                    refEntityId = Convert.ToString(fpResp?.ResultSet?.FNCL_PROD_ID);
        //                    break;
        //                case ModuleTypeCode.FINANCIAL_PRODUCT_GROUP:
        //                    IFinancialProductService fpgSvc = ChannelFactory.CreateChannel<IFinancialProductService>();
        //                    var fpgReq = new RequestObject<int>(session, Convert.ToInt32(referenceId));
        //                    var fpgResp = fpgSvc.ReadFpgByRefId(fpgReq);
        //                    ChannelFactory.CloseChannel(fpgSvc);
        //                    refEntityId = Convert.ToString(fpgResp?.ResultSet?.FNCL_PROD_GRP_ID);
        //                    break;
        //                case ModuleTypeCode.FINANCE_COMPANY:
        //                    break;
        //                case ModuleTypeCode.ASSET:
        //                    IAssetManagementService assetSvc = ChannelFactory.CreateChannel<IAssetManagementService>();
        //                    var assetReq = new RequestObject<int>(session, Convert.ToInt32(referenceId));
        //                    var assetResp = assetSvc.ReadAssetModelByRefId(assetReq);
        //                    ChannelFactory.CloseChannel(assetSvc);
        //                    refEntityId = Convert.ToString(assetResp?.ResultSet?.MODL_ID);
        //                    break;
        //                default:
        //                    break;
        //            }
        //            return (!string.IsNullOrEmpty(refEntityId));
        //        }

        //        public ResponseObject<bool> ChangeRequestStatus(RequestObject<ChangeStatusParams> requestObject)
        //        {
        //            ChangeStatusParams changeStatusParams = requestObject.Object;
        //            ResponseObject<bool> response = new ResponseObject<bool>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };

        //            try
        //            {
        //                var taskqueueContext = EntityContextExt.Create<TaskQueueRequest>();
        //                //string referenceId = changeStatusParams.ReferenceId.ToString();
        //                taskqueueContext.Read(a => a.REF_NUMB == changeStatusParams.ReferenceId);
        //                TaskQueueRequest taskQueueRequest = taskqueueContext.Entity.First();


        //                taskQueueRequest.STS_KEY = changeStatusParams.StatusTo;
        //                taskQueueRequest.STS_CHNG_DTE = DateTime.Now;
        //                taskqueueContext.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }
        //        public ResponseObject<bool> ChangeRequestOrHistoryStatus(RequestObject<ChangeStatusParams> requestObject)
        //        {
        //            ResponseObject<bool> response = new ResponseObject<bool>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success },
        //                ResultSet = true
        //            };

        //            try
        //            {
        //                string moduleKey = ModuleTypeCode.APPLICATION.GetKey();
        //                //MDUL_KEY='APPL' AND REF_NUMB='919933'
        //                if ((requestObject?.Object?.isHistryQueue ?? false) == false)
        //                {

        //                    var taskQueueContext = EntityContextExt.Create<TaskQueueRequest>();
        //                    taskQueueContext.Read(t => t.MDUL_KEY == moduleKey && t.REF_NUMB == requestObject.Object.ReferenceNumber);
        //                    TaskQueueRequest taskQueueRequest = taskQueueContext.Entity.First();


        //                    taskQueueRequest.STS_KEY = requestObject.Object.StatusTo;
        //                    taskQueueRequest.STS_CHNG_DTE = DateTime.Now;
        //                    taskQueueRequest.STS_CHNG_PRCG_DTE = requestObject.Context.WorkDate;
        //                    taskQueueContext.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                }
        //                else
        //                {
        //                    var taskQueueHistoryContext = EntityContextExt.Create<TaskQueueRequestHistory>();
        //                    taskQueueHistoryContext.Read(a => a.MDUL_KEY == moduleKey && a.REF_NUMB == requestObject.Object.ReferenceNumber);
        //                    TaskQueueRequestHistory taskQueueRequestHistory = taskQueueHistoryContext.Entity.First();


        //                    taskQueueRequestHistory.STS_KEY = requestObject.Object.StatusTo;
        //                    taskQueueRequestHistory.STS_CHNG_DTE = DateTime.UtcNow;
        //                    taskQueueRequestHistory.STS_CHNG_PRCG_DTE = requestObject.Context.WorkDate;
        //                    taskQueueHistoryContext.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                }

        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }
        //        #endregion

        //        /// <summary>
        //        /// Method to Read Task Queue By Request Type and Status
        //        /// </summary>
        //        /// <param name="requestObject"></param>
        //        /// <returns>Specified Task Queue Data</returns>
        //        public ResponseObject<IList<TaskQueueRequest>> ReadRequestsByTypeAndStatus(RequestObject<Tuple<RequestTypeCodes, List<StatusCode>>> requestObject)
        //        {
        //            ResponseObject<IList<TaskQueueRequest>> response = new ResponseObject<IList<TaskQueueRequest>>();
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                string _requestType = requestObject.Object.Item1.GetKey();
        //                List<string> _statuses = new List<string>();
        //                requestObject.Object.Item2.ForEach(each => _statuses.Add(each.GetKey()));
        //                contextExt.Read(r => r.REQT_TYPE_KEY == _requestType && _statuses.Contains(r.STS_KEY));
        //                if (contextExt.Entity != null)
        //                    response.ResultSet = contextExt.Entity;
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Method to Read Task Queue By Request Type
        //        /// </summary>
        //        /// <param name="requestObject"></param>
        //        /// <returns>Specified Task Queue Data</returns>
        //        public ResponseObject<IList<TaskQueueRequest>> ReadRequestsByType(RequestObject<string> requestObject)
        //        {
        //            ResponseObject<IList<TaskQueueRequest>> response = new ResponseObject<IList<TaskQueueRequest>>();
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                contextExt.Read(r => r.REQT_TYPE_KEY == requestObject.Object);
        //                if (contextExt.Entity != null)
        //                    response.ResultSet = contextExt.Entity;
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <inheritdoc/>
        //        public ResponseObject<TaskQueueRequest> SubmitWrappedTaskQueueRequest(RequestObject<TaskQueueRequestWrapper> requestObject)
        //        {
        //            var response = new ResponseObject<TaskQueueRequest>
        //            {
        //                Message = new MessageInfo() { Message = "RequestSubmit", Type = MessageType.Success }
        //            };
        //            try
        //            {
        //#if BPMExtensiveLog
        //                dynamic obj = requestObject.Object;
        //                var ctx = new Context(requestObject.Context, $"SubmitWrappedTaskQueueRequest() called for RefId='{obj.REF_NUMB.GetValueOrDefault()}', RefNumb='{obj.MDUL_REF}'.") { LogLevel = NSLogLevel.Info };
        //                ExceptionHandler.Log(ctx);
        //#endif
        //                //if (requestObject.Object.TaskQueueRequest.REQT_TYPE_KEY == RequestTypeCodes.ContractCreation.GetKey()
        //                //    || requestObject.Object.TaskQueueRequest.REQT_TYPE_KEY == RequestTypeCodes.ComplianceApproval.GetKey()
        //                //    || requestObject.Object.TaskQueueRequest.REQT_TYPE_KEY == RequestTypeCodes.PaymentApproval.GetKey()
        //                //    || requestObject.Object.TaskQueueRequest.REQT_TYPE_KEY == RequestTypeCodes.ContractActivation.GetKey())
        //                //{
        //                //    int finalDecisionCount = (TaskQueueCount.RequestExistsWithFinalStatus(requestObject.Object.TaskQueueRequest.REQT_TYPE_KEY, requestObject.Object.TaskQueueRequest.REF_NUMB.GetValueOrDefault())
        //                //        ?.FirstOrDefault().REQT_CNT).GetValueOrDefault();
        //                //    if (finalDecisionCount > 0)//already submitted.
        //                //    {
        //                //        response.Message.Type = MessageType.Error;
        //                //        response.Message.Message = "InvalidReqtStsAction";
        //                //        response.ResultSet = requestObject.Object.TaskQueueRequest;
        //                //        return response;
        //                //    }
        //                //}

        //                int taskId = requestObject.Object.TaskQueueRequest.TASK_QUEU_ID;
        //                var ctxOld = EntityContextExt.Create<TaskQueueRequestListItem>();
        //                ctxOld.Read(x => x.TASK_QUEU_ID == taskId);
        //                if (ctxOld.Entity[0].ASGN_USR != requestObject.Object.TaskQueueRequest.ASGN_USR)//not assigned to user
        //                {
        //                    response.Message.Type = MessageType.Error;
        //                    response.Message.Message = "SubmissionlockingCheck";
        //                    response.ResultSet = requestObject.Object.TaskQueueRequest;
        //                    return response;
        //                }

        //                TaskQueueRequest resultEntity = null;
        //                using (var contextExt = EntityContextExt.Create(new[] { requestObject.Object.TaskQueueRequest }))
        //                {
        //                    contextExt.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                    resultEntity = contextExt.Entity[0];
        //                }

        //                if (resultEntity == null)
        //                    throw new Exception("Failed to submit task queue request.");

        //                response.ResultSet = resultEntity;

        //                var wkfParams = GetWorkflowParams(requestObject.Context, resultEntity);
        //                wkfParams.EntityList = requestObject.Object.EntityList;

        //                response.WorkflowInput = wkfParams;

        //#if BPMExtensiveLog
        //                obj = requestObject.Object;
        //                ctx = new Context(requestObject.Context, $"SubmitWrappedTaskQueueRequest() completed for RefId='{obj.REF_NUMB.GetValueOrDefault()}', RefNumb='{obj.MDUL_REF}'.") { LogLevel = NSLogLevel.Info };
        //                ExceptionHandler.Log(ctx);
        //#endif
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        public ResponseObject<bool> UpdateRequestTabs(RequestObject<RequestTabParams> requestObject)
        //        {

        //            RequestTabParams requestTabParams = requestObject.Object;
        //            ResponseObject<bool> response = new ResponseObject<bool>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                RequestTabType requestTabsToShow = RequestTabType.Approve;
        //                if (requestTabParams.IsApproval && requestTabParams.IsRecommendation)
        //                {
        //                    requestTabsToShow = RequestTabType.ApproveRecommend;
        //                }
        //                else if (requestTabParams.IsRecommendation)
        //                {
        //                    requestTabsToShow = RequestTabType.Recommend;
        //                }
        //                int requestId = requestTabParams.RequestId;
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                contextExt.Read(a => a.TASK_QUEU_ID == requestId);
        //                TaskQueueRequest taskQueueRequest = contextExt.Entity.First();
        //                taskQueueRequest.REQT_TABS = requestTabsToShow.GetKey();
        //                contextExt.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                response.ResultSet = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                response.ResultSet = false;
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }


        //        /// <summary>
        //        /// Methos read the task queue by request type and refererce no and update the request status
        //        /// </summary>
        //        /// <param name="request">REQT_TYPE_KEY use for read</param>
        //        /// <param name="request">ReferenceNo use for read</param>
        //        /// <param name="request">RequestStatus use for update</param>
        //        /// <returns></returns>
        //        public ResponseObject<bool> ReadUpdateStatusbyRequestTypeRefNo(RequestObject<TaskQueueRequestSearchParam> request)
        //        {
        //            ResponseObject<bool> response = new ResponseObject<bool>();
        //            try
        //            {
        //                int refId = Convert.ToInt32(request.Object.ReferenceId);
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                contextExt.Read(x => x.REQT_TYPE_KEY == request.Object.RequestType && x.REF_NUMB == request.Object.ReferenceNo);
        //                if (contextExt.Entity != null)
        //                {
        //                    TaskQueueRequest taskqueue = contextExt.Entity.LastOrDefault();
        //                    taskqueue.STS_KEY = request.Object.RequestStatus;
        //                    contextExt.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                    response.ResultSet = true;
        //                }

        //            }
        //            catch (Exception ex)
        //            {
        //                response.ResultSet = false;
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        public ResponseObject<bool> PersistDmsDocGenerationRequest(RequestObject<IList<DmsManualGeneration>> requestObject)
        //        {
        //            var response = new ResponseObject<bool>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                DmsManualGeneration.Persist(requestObject.Object);
        //                response.ResultSet = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message.Type = MessageType.Error;
        //                response.Message.Message = ex.Message;

        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }


        //        public ResponseObject<List<DmsManualGeneration>> ReadDocumentTypesByTaskId(RequestObject<int> requestObject)
        //        {
        //            ResponseObject<List<DmsManualGeneration>> response = new ResponseObject<List<DmsManualGeneration>>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                using (var contextExt = EntityContextExt.Create<DmsManualGeneration>())
        //                {
        //                    contextExt.Read(p => p.TASK_QUEU_ID == requestObject.Object);
        //                    if (contextExt.Entity != null)
        //                    {
        //                        response.ResultSet = contextExt.Entity;
        //                        response.Message.Type = MessageType.Success;
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;

        //        }



        //        /// <summary>
        //        /// Updates the request status.
        //        /// </summary>
        //        /// <param name="requestObject">The request object.</param>
        //        /// <returns></returns>
        //        public ResponseObject<TaskQueueRequest> UpdateRequestStatus(RequestObject<RequestTabParams> requestObject)
        //        {
        //            ResponseObject<TaskQueueRequest> response = new ResponseObject<TaskQueueRequest>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();

        //                contextExt.Read(a => a.TASK_QUEU_ID == requestObject.Object.RequestId);
        //                if (contextExt.Entity != null)
        //                {
        //                    contextExt.Entity.FirstOrDefault().STS_KEY = requestObject.Object.RequestStatus;
        //                    contextExt.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                    response.ResultSet = contextExt.Entity.FirstOrDefault();
        //                }

        //            }

        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }


        //        public ResponseObject<bool> UpdateDMRequest(RequestObject<int> requestObject)
        //        {
        //            ResponseObject<bool> response = new ResponseObject<bool>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                string sysRcmdStsKey = string.Empty;
        //                var contextExtDm = EntityContextExt.Create<TaskQueueDM>();
        //                contextExtDm.Read(p => p.REF_ID == requestObject.Object);
        //                var result = contextExtDm.Entity.FirstOrDefault();
        //                if (result != null)
        //                {
        //                    result.PROC_IND = true;
        //                    contextExtDm.Persist();
        //                }
        //                response.ResultSet = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                response.ResultSet = false;
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Mark request read flag
        //        /// </summary>
        //        /// <param name="requestObject">task queue Id, Read falg </param>
        //        /// <returns>returns true if the flag marked correctly, false otherwise.</returns>
        //        public ResponseObject<bool> MarkRequestReadFlag(RequestObject<Tuple<int, bool>> requestObject)
        //        {
        //            ResponseObject<bool> response =
        //                new ResponseObject<bool>
        //                {
        //                    Message = new MessageInfo() { Type = MessageType.Success }
        //                };

        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                contextExt.Read(x => x.TASK_QUEU_ID == requestObject.Object.Item1, 1);
        //                var data = contextExt.Entity?.FirstOrDefault();
        //                if (data != null && requestObject.Context.UserName == data.ASGN_USR)
        //                {
        //                    data.REQT_READ_IND = requestObject.Object.Item2;
        //                    contextExt.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                    response.ResultSet = true;
        //                    return response;
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            response.ResultSet = false;
        //            return response;
        //        }

        //        /// <summary>
        //        /// Mark read/unread task queue request based on params (POS)
        //        /// </summary>
        //        /// <param name="requestObject">Task queue Id, Read falg.</param>
        //        /// <returns>returns true if the indicator marked correctly, false otherwise.</returns>
        //        public ResponseObject<bool> MarkRequestReadIndicator(RequestObject<Tuple<int, bool>> requestObject)
        //        {
        //            ResponseObject<bool> response =
        //                new ResponseObject<bool>
        //                {
        //                    Message = new MessageInfo() { Type = MessageType.Success }
        //                };

        //            try
        //            {
        //                var contextExt = EntityContextExt.Create<TaskQueueRequest>();
        //                contextExt.Read(x => x.TASK_QUEU_ID == requestObject.Object.Item1, 1);
        //                var data = contextExt.Entity?.FirstOrDefault();
        //                if (data != null)
        //                {
        //                    data.REQT_READ_IND = requestObject.Object.Item2;
        //                    contextExt.Persist(useIdentityType: InsertIdentityType.UseSequence);
        //                    response.ResultSet = true;
        //                    return response;
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            response.ResultSet = false;
        //            return response;
        //        }

        //        /// <summary>
        //        /// read associated Reasons
        //        /// </summary>
        //        /// <param name="requestObject">modul key</param>
        //        /// <returns>returns associated reasons.</returns>
        //        public ResponseObject<List<AssociatedReasons>> ReadAssociatedReasons(RequestObject<Tuple<int, string, string>> requestObject)
        //        {

        //            ResponseObject<List<AssociatedReasons>> response = new ResponseObject<List<AssociatedReasons>>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                using (var contextExt = EntityContextExt.Create<AssociatedReasons>())
        //                {
        //                    contextExt.Read(requestObject.Object.Item1, requestObject.Object.Item2, requestObject.Object.Item3);
        //                    if (contextExt.Entity != null)
        //                    {
        //                        response.ResultSet = contextExt.Entity;
        //                        response.Message.Type = MessageType.Success;
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// read associated Reasons
        //        /// </summary>
        //        /// <param name="requestObject">modul key</param>
        //        /// <returns>returns associated reasons.</returns>
        //        public ResponseObject<List<RequestAssociatedReasons>> ReadAssociatedReasonsFromRequestReasonMain(RequestObject<Tuple<int>> requestObject)
        //        {

        //            ResponseObject<List<RequestAssociatedReasons>> response = new ResponseObject<List<RequestAssociatedReasons>>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                using (var contextExt = EntityContextExt.Create<RequestAssociatedReasons>())
        //                {
        //                    contextExt.Read(requestObject.Object.Item1);
        //                    if (contextExt.Entity != null)
        //                    {
        //                        response.ResultSet = contextExt.Entity;
        //                        response.Message.Type = MessageType.Success;
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Save associated Reasons with request
        //        /// </summary>
        //        /// <param name="requestObject">List of associated Reasons</param>
        //        /// <returns>returns list of saved associated Reasons.</returns>
        //        public ResponseObject<IList<RequestReasonMain>> SaveReasonAssociatedWithRequest(RequestObject<IList<RequestReasonMain>> requestObject)
        //        {
        //            ResponseObject<IList<RequestReasonMain>> response = new ResponseObject<IList<RequestReasonMain>>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };

        //            try
        //            {
        //                var contextExt = EntityContextExt.Create(requestObject.Object);
        //                contextExt.Persist();
        //                if (contextExt.Entity != null)
        //                    response.ResultSet = contextExt.Entity;
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }


        //        private void RemoveStatusConfigurationFromCache(Context context, string requestType, string status)
        //        {
        //            ICacheService svc = null;
        //            if (string.IsNullOrEmpty(requestType) || string.IsNullOrEmpty(status))
        //                return;
        //            try
        //            {
        //                var cacheKey = CacheKeys.CreateRelatedKey(CustomCacheItems.RequestStatusConfiguration.GetCacheKey(), requestType, status);
        //                svc = ChannelFactory.CreateChannel<ICacheService>();
        //                svc.RemoveCache(new RequestObject<CacheRemovalParam>(context, new CacheRemovalParam()
        //                {
        //                    CacheKey = cacheKey,
        //                    CacheType = CacheType.SvrDistClMem,
        //                }));
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            finally
        //            {
        //                ChannelFactory.CloseChannel(svc);
        //            }
        //        }
        //        /// <summary>
        //        /// Method to read request status history
        //        /// </summary>
        //        /// <param name="requestObject">task queue id</param>
        //        /// <returns>returns request history.</returns>
        //        public ResponseObject<List<BpmWorkflowHistory>> ReadRequestStatusHistory(RequestObject<int> requestObject)
        //        {
        //            ResponseObject<List<BpmWorkflowHistory>> response = new ResponseObject<List<BpmWorkflowHistory>>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                using (var contextExt = EntityContextExt.Create<BpmWorkflowHistory>())
        //                {
        //                    contextExt.Read(p => p.REQT_ID == requestObject.Object);
        //                    if (contextExt.Entity != null)
        //                    {
        //                        response.ResultSet = contextExt.Entity;
        //                        response.Message.Type = MessageType.Success;
        //                    }
        //                }
        //                var task = ReadTaskById(requestObject);
        //                if (task != null && task.ResultSet?.REQT_TYPE_KEY == RequestTypeCodes.PaymentApproval.GetKey())
        //                {
        //                    var complianceHistory = ReadComplianceHistoryByPaymentTaskId((int)task.ResultSet.REF_NUMB);
        //                    if (complianceHistory.ResultSet != null && complianceHistory.ResultSet.Any())
        //                    {
        //                        response.ResultSet.InsertRange(0, complianceHistory.ResultSet);
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Method to read request status history
        //        /// </summary>
        //        /// <param name="requestObject">task queue id</param>
        //        /// <returns>returns request history.</returns>
        //        public ResponseObject<BpmWorkflowHistory> ReadRequestStatusHistoryByIdAndStatus(RequestObject<Tuple<int, string>> requestObject)
        //        {
        //            ResponseObject<BpmWorkflowHistory> response = new ResponseObject<BpmWorkflowHistory>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };
        //            try
        //            {
        //                using (var contextExt = EntityContextExt.Create<BpmWorkflowHistory>())
        //                {
        //                    contextExt.Read(p => p.REQT_ID == requestObject.Object.Item1 && p.TO_STS == requestObject.Object.Item2);
        //                    if (contextExt.Entity != null)
        //                    {
        //                        response.ResultSet = contextExt.Entity.FirstOrDefault();
        //                        response.Message.Type = MessageType.Success;
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <inheritdoc/>
        //     //   public ResponseObject<List<TaskQueueRequestListItem>> GetRequestByReference(RequestObject<TaskQueueRequestSearchParam> requestObject)
        //        public ResponseObject<TaskQueueRequest> GetRequestByReference(RequestObject<TaskQueueRequestSearchParam> requestObject)

        //        {
        //            var response = new ResponseObject<TaskQueueRequest>() { Message = new MessageInfo() { Type = MessageType.Success } };

        //            try
        //            {
        //                using (var tqCtx = EntityContextExt.Create<TaskQueueRequest>())
        //                {
        //                    var tqeEntity = new EntityContextExt<TaskQueueRequest>();

        //                    if (requestObject.Object.ReferenceNo != 0)
        //                    {
        //                        tqeEntity = tqCtx.Read(x => x.MDUL_KEY == requestObject.Object.ModuleKey &&
        //                        x.REQT_TYPE_KEY == requestObject.Object.RequestType &&
        //                        x.REF_NUMB == requestObject.Object.ReferenceNo);
        //                    }
        //                    else
        //                    {
        //                        //below case is added for retrieving exisitng request before BMR submission
        //                        tqeEntity = tqCtx.Read(x => x.MDUL_KEY == requestObject.Object.ModuleKey &&
        //                        x.REQT_TYPE_KEY == requestObject.Object.RequestType &&
        //                        x.MDUL_REF == requestObject.Object.ReferenceId &&
        //                        x.STS_KEY == requestObject.Object.RequestStatus);
        //                    }


        //                    if (!tqeEntity.Entity.Any())
        //                    {
        //                        response.Message.Type = MessageType.Warning;
        //                        response.Message.CustomMessage = "No task queue request found.";
        //                        return response;
        //                    }

        //                    //  response.ResultSet = new List<TaskQueueRequest>();
        //                    var tqResponse = tqeEntity?.Entity?.OrderByDescending(x => x.TASK_QUEU_ID).FirstOrDefault();

        //                    var taskQueueRequestListItem = new TaskQueueRequest()
        //                    {
        //                        TASK_QUEU_ID = tqResponse.TASK_QUEU_ID,
        //                        LOCK_BY = tqResponse.LOCK_BY,
        //                        LOCK_IND = tqResponse.LOCK_IND,
        //                        ASGN_USR = tqResponse.ASGN_USR,
        //                        CMNT = tqResponse.CMNT,
        //                        REQT_READ_IND = tqResponse.REQT_READ_IND,
        //                        NEXT_STS_KEY = tqResponse.NEXT_STS_KEY,
        //                        REQT_TYPE_KEY = tqResponse.REQT_TYPE_KEY,
        //                        STS_KEY = tqResponse.STS_KEY,
        //                        State = EntityState.NotModified,
        //                        REF_NUMB = tqResponse.REF_NUMB,
        //                        MDUL_REF = tqResponse.MDUL_REF,
        //                    };

        //                    response.ResultSet = taskQueueRequestListItem;

        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message.Type = MessageType.Error;
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //            }
        //            return response;
        //        }

        //        /// <summary>
        //        /// Move Requests from Main Queue to History and Vice Versa
        //        /// </summary>
        //        /// <param name="requestObject">RequestParams Object</param>
        //        /// <returns>Intance of <see also cref="TaskQueueRequest"/></returns>
        //        public ResponseObject<bool> TransferRequest(RequestObject<TransferRequestParams> requestObject)
        //        {
        //            TransferRequestParams requestParams = requestObject.Object;
        //            ResponseObject<bool> response = new ResponseObject<bool>
        //            {
        //                Message = new MessageInfo() { Type = MessageType.Success }
        //            };

        //            try
        //            {
        //                TaskQueueRequest taskQueueRequest = null;
        //                TaskQueueRequestHistory taskQueueHistoryRequest = null;

        //                #region Move To History
        //                if (requestParams.IsTransferToHistory)
        //                {
        //                    using (var contextExt = EntityContextExt.Create<TaskQueueRequest>())
        //                    {
        //                        contextExt.Read(a => a.TASK_QUEU_ID == requestParams.RequestId, 1);
        //                        taskQueueRequest = contextExt.Entity.First();

        //                        if (taskQueueRequest != null)
        //                        {
        //                            taskQueueHistoryRequest = new TaskQueueRequestHistory
        //                            {
        //                                APPL_KEY = taskQueueRequest.APPL_KEY,
        //                                ASGN_USR = taskQueueRequest.ASGN_USR,
        //                                CMNT = taskQueueRequest.CMNT,
        //                                DUE_DTE = taskQueueRequest.DUE_DTE,
        //                                LOCK_IND = taskQueueRequest.LOCK_IND,
        //                                MDUL_KEY = taskQueueRequest.MDUL_KEY,
        //                                NEXT_STS_KEY = taskQueueRequest.NEXT_STS_KEY,
        //                                PRNT_TASK = taskQueueRequest.PRNT_TASK,
        //                                PRTY = taskQueueRequest.PRTY,
        //                                PRTY_SET_BY = taskQueueRequest.PRTY_SET_BY,
        //                                QUEU_ID = taskQueueRequest.QUEU_ID,
        //                                RCMD_CNT = taskQueueRequest.RCMD_CNT,
        //                                REF_NUMB = taskQueueRequest.REF_NUMB,
        //                                REQT_TABS = taskQueueRequest.REQT_TABS,
        //                                REQT_TYPE_KEY = taskQueueRequest.REQT_TYPE_KEY,
        //                                RESN_ID = taskQueueRequest.RESN_ID,
        //                                SCRN_ID = taskQueueRequest.SCRN_ID,
        //                                SCRN_NME = taskQueueRequest.SCRN_NME,
        //                                STS_KEY = taskQueueRequest.STS_KEY,
        //                                TASK_CMPL_TIME = taskQueueRequest.TASK_CMPL_TIME,
        //                                TASK_QUEU_ID = taskQueueRequest.TASK_QUEU_ID,
        //                                TASK_STRT_TIME = taskQueueRequest.TASK_STRT_TIME,
        //                                INSR_BY = taskQueueRequest.INSR_BY,
        //                                UPDT_BY = taskQueueRequest.UPDT_BY,
        //                                INSR_DTE = taskQueueRequest.INSR_DTE,
        //                                UPDT_DTE = taskQueueRequest.UPDT_DTE,
        //                                STS_CHNG_DTE = taskQueueRequest.STS_CHNG_DTE,
        //                                SUB_STS_KEY = taskQueueRequest.SUB_STS_KEY,
        //                                TOTL_RCMD_CMPL = taskQueueRequest.TOTL_RCMD_CMPL,
        //                                MDUL_REF = taskQueueRequest.MDUL_REF,
        //                            };
        //                            if (taskQueueRequest.TaskQueueRequests != null && taskQueueRequest.TaskQueueRequests.Count > 0)
        //                            {
        //                                taskQueueHistoryRequest.TaskQueueHistoryRequests = new List<TaskQueueRequestHistory>();

        //                                foreach (var item in taskQueueRequest.TaskQueueRequests)
        //                                {
        //                                    taskQueueHistoryRequest.TaskQueueHistoryRequests.Add(new TaskQueueRequestHistory
        //                                    {
        //                                        APPL_KEY = item.APPL_KEY,
        //                                        ASGN_USR = item.ASGN_USR,
        //                                        CMNT = item.CMNT,
        //                                        DUE_DTE = item.DUE_DTE,
        //                                        LOCK_IND = item.LOCK_IND,
        //                                        MDUL_KEY = item.MDUL_KEY,
        //                                        NEXT_STS_KEY = item.NEXT_STS_KEY,
        //                                        PRNT_TASK = item.PRNT_TASK,
        //                                        PRTY = item.PRTY,
        //                                        PRTY_SET_BY = item.PRTY_SET_BY,
        //                                        QUEU_ID = item.QUEU_ID,
        //                                        RCMD_CNT = item.RCMD_CNT,
        //                                        REF_NUMB = item.REF_NUMB,
        //                                        REQT_TABS = item.REQT_TABS,
        //                                        REQT_TYPE_KEY = item.REQT_TYPE_KEY,
        //                                        RESN_ID = item.RESN_ID,
        //                                        SCRN_ID = item.SCRN_ID,
        //                                        SCRN_NME = item.SCRN_NME,
        //                                        STS_KEY = item.STS_KEY,
        //                                        TASK_CMPL_TIME = item.TASK_CMPL_TIME,
        //                                        TASK_QUEU_ID = item.TASK_QUEU_ID,
        //                                        TASK_STRT_TIME = item.TASK_STRT_TIME,
        //                                        INSR_BY = item.INSR_BY,
        //                                        UPDT_BY = item.UPDT_BY,
        //                                        INSR_DTE = item.INSR_DTE,
        //                                        UPDT_DTE = item.UPDT_DTE,
        //                                        STS_CHNG_DTE = item.STS_CHNG_DTE,
        //                                        SUB_STS_KEY = item.SUB_STS_KEY,
        //                                        TOTL_RCMD_CMPL = item.TOTL_RCMD_CMPL,
        //                                        MDUL_REF = item.MDUL_REF,
        //                                    });
        //                                    item.State = EntityState.Delete;
        //                                }
        //                            }
        //                        }
        //                        taskQueueRequest.State = EntityState.Delete;

        //                        var uow = contextExt.InitiateUnitOfWork();
        //                        var contextExtForHistory = EntityContextExt.Create(new[] { taskQueueHistoryRequest }).UsingUnitOfWork(uow);
        //                        contextExtForHistory.Persist(extendedSkipList: true);

        //                        contextExt.Persist();
        //                        uow.Save();
        //                    }
        //                }
        //                #endregion

        //                #region Move From History
        //                else
        //                {
        //                    using (var contextExt = EntityContextExt.Create<TaskQueueRequestHistory>())
        //                    {
        //                        contextExt.Read(a => a.TASK_QUEU_ID == requestParams.RequestId, 1);
        //                        taskQueueHistoryRequest = contextExt.Entity.First();

        //                        if (taskQueueHistoryRequest != null)
        //                        {
        //                            taskQueueRequest = new TaskQueueRequest
        //                            {
        //                                APPL_KEY = taskQueueHistoryRequest.APPL_KEY,
        //                                ASGN_USR = taskQueueHistoryRequest.ASGN_USR,
        //                                CMNT = taskQueueHistoryRequest.CMNT,
        //                                DUE_DTE = taskQueueHistoryRequest.DUE_DTE,
        //                                LOCK_IND = taskQueueHistoryRequest.LOCK_IND,
        //                                MDUL_KEY = taskQueueHistoryRequest.MDUL_KEY,
        //                                NEXT_STS_KEY = taskQueueHistoryRequest.NEXT_STS_KEY,
        //                                PRNT_TASK = taskQueueHistoryRequest.PRNT_TASK,
        //                                PRTY = taskQueueHistoryRequest.PRTY,
        //                                PRTY_SET_BY = taskQueueHistoryRequest.PRTY_SET_BY,
        //                                QUEU_ID = taskQueueHistoryRequest.QUEU_ID,
        //                                RCMD_CNT = taskQueueHistoryRequest.RCMD_CNT,
        //                                REF_NUMB = taskQueueHistoryRequest.REF_NUMB,
        //                                REQT_TABS = taskQueueHistoryRequest.REQT_TABS,
        //                                REQT_TYPE_KEY = taskQueueHistoryRequest.REQT_TYPE_KEY,
        //                                RESN_ID = taskQueueHistoryRequest.RESN_ID,
        //                                SCRN_ID = taskQueueHistoryRequest.SCRN_ID,
        //                                SCRN_NME = taskQueueHistoryRequest.SCRN_NME,
        //                                STS_KEY = taskQueueHistoryRequest.STS_KEY,
        //                                TASK_CMPL_TIME = taskQueueHistoryRequest.TASK_CMPL_TIME,
        //                                TASK_QUEU_ID = taskQueueHistoryRequest.TASK_QUEU_ID,
        //                                TASK_STRT_TIME = taskQueueHistoryRequest.TASK_STRT_TIME,
        //                                INSR_BY = taskQueueHistoryRequest.INSR_BY,
        //                                UPDT_BY = taskQueueHistoryRequest.UPDT_BY,
        //                                INSR_DTE = taskQueueHistoryRequest.INSR_DTE,
        //                                UPDT_DTE = taskQueueHistoryRequest.UPDT_DTE,
        //                                STS_CHNG_DTE = taskQueueHistoryRequest.STS_CHNG_DTE,
        //                                SUB_STS_KEY = taskQueueHistoryRequest.SUB_STS_KEY,
        //                                TOTL_RCMD_CMPL = taskQueueHistoryRequest.TOTL_RCMD_CMPL,
        //                                MDUL_REF = taskQueueHistoryRequest.MDUL_REF,
        //                            };
        //                            if (taskQueueHistoryRequest.TaskQueueHistoryRequests != null && taskQueueHistoryRequest.TaskQueueHistoryRequests.Count > 0)
        //                            {
        //                                taskQueueRequest.TaskQueueRequests = new List<TaskQueueRequest>();

        //                                foreach (var item in taskQueueHistoryRequest.TaskQueueHistoryRequests)
        //                                {
        //                                    taskQueueRequest.TaskQueueRequests.Add(new TaskQueueRequest
        //                                    {
        //                                        APPL_KEY = item.APPL_KEY,
        //                                        ASGN_USR = item.ASGN_USR,
        //                                        CMNT = item.CMNT,
        //                                        DUE_DTE = item.DUE_DTE,
        //                                        LOCK_IND = item.LOCK_IND,
        //                                        MDUL_KEY = item.MDUL_KEY,
        //                                        NEXT_STS_KEY = item.NEXT_STS_KEY,
        //                                        PRNT_TASK = item.PRNT_TASK,
        //                                        PRTY = item.PRTY,
        //                                        PRTY_SET_BY = item.PRTY_SET_BY,
        //                                        QUEU_ID = item.QUEU_ID,
        //                                        RCMD_CNT = item.RCMD_CNT,
        //                                        REF_NUMB = item.REF_NUMB,
        //                                        REQT_TABS = item.REQT_TABS,
        //                                        REQT_TYPE_KEY = item.REQT_TYPE_KEY,
        //                                        RESN_ID = item.RESN_ID,
        //                                        SCRN_ID = item.SCRN_ID,
        //                                        SCRN_NME = item.SCRN_NME,
        //                                        STS_KEY = item.STS_KEY,
        //                                        TASK_CMPL_TIME = item.TASK_CMPL_TIME,
        //                                        TASK_QUEU_ID = item.TASK_QUEU_ID,
        //                                        TASK_STRT_TIME = item.TASK_STRT_TIME,
        //                                        INSR_BY = item.INSR_BY,
        //                                        UPDT_BY = item.UPDT_BY,
        //                                        INSR_DTE = item.INSR_DTE,
        //                                        UPDT_DTE = item.UPDT_DTE,
        //                                        STS_CHNG_DTE = item.STS_CHNG_DTE,
        //                                        SUB_STS_KEY = item.SUB_STS_KEY,
        //                                        TOTL_RCMD_CMPL = item.TOTL_RCMD_CMPL,
        //                                        MDUL_REF = item.MDUL_REF,
        //                                    });
        //                                    item.State = EntityState.Delete;
        //                                }
        //                            }
        //                        }
        //                        taskQueueHistoryRequest.State = EntityState.Delete;

        //                        var uow = contextExt.InitiateUnitOfWork();
        //                        var contextExtMainRequest = EntityContextExt.Create(new[] { taskQueueRequest }).UsingUnitOfWork(uow);
        //                        contextExtMainRequest.Persist(useIdentityType: InsertIdentityType.UseSequence, extendedSkipList: true);

        //                        contextExt.Persist();
        //                        uow.Save();
        //                    }
        //                }
        //                #endregion

        //                response.ResultSet = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                response.Message = new MessageInfo() { Type = MessageType.Error };
        //                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //                response.ResultSet = false;
        //            }
        //            return response;
        //        }
    }
}

﻿using NFS.Models.Accounting.Custom.Param;
using NFS.Models.BatchProcess.Custom;
using NFS.Models.BatchProcessModel;
using NFS.Models.BusinessPartner;
using NFS.Models.Custom.Param;
using NFS.ServiceContracts;
using NS.BaseModels;
using NS.ExceptionHandling;
using NS.ORM;
using NS.Resources.Enums;
using NS.Resources.Enums.BatchProcess;
using NS.Resources.Enums.Common;
using NS.Resources.Enums.EventDispatcher;
using NS.Resources.Enums.InvokeType;
using NS.ServiceModel;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using NS.Utilities.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using NS.Utilities;
using NS.Models.Events.Custom;
using NS.Models.EventsLog;
using NFS.Business.Helper;

namespace NS.BatchProcessing.Business.Helpers
{
    public class BatchProcessCommon
    {
        private static List<EventDispatcherEnum> GetDayEndRegisteredListeners()
        {
            List<EventDispatcherEnum> Listeners = new List<EventDispatcherEnum> { EventDispatcherEnum.AssetBackedSecuritiesPostDayEndEvent };

            return Listeners;
        }
        private static List<EventDispatcherEnum> GetMonthEndAccounintgRegisteredListeners()
        {
            List<EventDispatcherEnum> Listeners = new List<EventDispatcherEnum> { EventDispatcherEnum.SAPFilePostDayEndEvent };

            return Listeners;
        }

        public static void PublishDayEndStart(BatchProcessCriteria criteria, Context context)
        {
            try
            {
                var eventParam = new EventParm()
                {
                    ApplicationKey = ApplicationCodes.Cms.GetKey(),
                    ModuleKey = ModuleTypeCode.BATCH_PROCESS_EXECUTION.GetKey(),
                    EventId = Convert.ToInt32(EventCode.OnDayendStarted),
                    ContextData = context,
                    BranchID = criteria.BranchId,
                    FcId = criteria.CompanyId,
                };
                
                using (var svc = new ProxyClient<IEventDispatcherLogicService>())
                {
                    var request = new RequestObject<EventParm>(context, eventParam);
                    svc.ClientInstance.TriggerEvent(request);
                }


            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
            }


        }

        public static void PublishDayEndCompletion(BatchProcessCriteria criteria, Context context)
        {
            try
            {
                //var context1 = new BusImpl.Logs.ProcessContext()
                //{
                //    Action = context.Action,
                //    UserName = context.UserName,
                //    ContextId=context.ContextId,
                //    SessionId=context.SessionId
                //};
                var eventParam = new EventParm()
                {
                    ApplicationKey = ApplicationCodes.Cms.GetKey(),
                    ModuleKey = ModuleTypeCode.BATCH_PROCESS_EXECUTION.GetKey(),
                    EventId = Convert.ToInt32(EventCode.OnDayendCompleted),
                    ContextData = context,
                    BranchID = criteria.BranchId,
                    FcId = criteria.CompanyId,
                    PostActionsEnum = GetDayEndRegisteredListeners()
                };
                //todo: Ask EventDispatcher team to use enum for listeners and change API call of TriggerEvent 
               
                using (var svc = new ProxyClient<IEventDispatcherLogicService>())
                {
                    var request = new RequestObject<EventParm>(context, eventParam);
                    svc.ClientInstance.TriggerEvent(request);
                }

            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
            }


        }
        /// <summary>
        /// PublishMonthEndAccounitngCompletion
        /// </summary>
        /// <param name="criteria"></param>
        /// <param name="context"></param>
        //public static void PublishMonthEndAccounitngCompletion(BatchProcessCriteria criteria, Context context)
        //{
        //    try
        //    {
        //        var eventParam = new EventParm()
        //        {
        //            RequestType = RequestTypeCodes.MonthEnd.GetKey(),// to do use "month end accounintng "request  type
        //            ModuleKey = ModuleTypeCode.BATCH_PROCESS_EXECUTION.GetKey(),
        //            EventId = Convert.ToInt32(EventCode.OnStatusChange), // use save here
        //            ContextData = context,
        //            BranchID = criteria.BranchId,
        //            FcId = criteria.CompanyId,
        //            PostActionsEnum = GetMonthEndAccounintgRegisteredListeners()
        //        };

        //        /* processing get change during async call so use direct SAP file submission
        //        var svc = ChannelFactory.CreateChannel<IEventDispatcherLogicService>();
        //        var request = new RequestObject<EventParm>(context, eventParam);
        //        svc.TriggerEvent(request);
        //        */

        //        SubmitProcessSAPFileDayEnd(eventParam);

        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
        //    }


        //}

        #region AccountingGeneration
        /// <summary>
        /// CallAccountingEntries
        /// </summary>
        /// <param name="criteria"></param>
        /// <param name="contId"></param>
        /// <param name="processCxt"></param>
        /// <param name="requestTypeCode"></param>
        /// <param name="eventCode"></param>
        public static void CallAccountingEntries(BatchProcessCriteria criteria, int contId, Context context, RequestTypeCodes requestTypeCode, EventCode eventCode)
        {
            int eventId = Convert.ToInt32(eventCode);
            AccountingListener helper = new AccountingListener(criteria.SubmittedProcessingDate);
            EventParm eventParam = GetEventParam(criteria, contId, context, requestTypeCode, eventId);
            var param = new AccParam { EventId = eventParam.EventId, RefId1 = eventParam.RefId1, RefId2 = eventParam.RefId2, RefId3 = eventParam.RefId3, RequestTypeKey = eventParam.RequestType, EventLogId = eventParam.EventLogId, ProcessingDate = criteria.ProcessingDate, BranchId = criteria.BranchId, CompanyId = criteria.CompanyId };

            helper.GenerateAccountingEntries(param, context);

        }
        /// <summary>
        /// GetEventParam
        /// </summary>
        /// <param name="criteria"></param>
        /// <param name="contId"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        private static EventParm GetEventParam(BatchProcessCriteria criteria, int contId, Context context, RequestTypeCodes requestTypeCode, int eventId)
        {
            var eventParam = new EventParm()
            {
                //todo RequestTypeCodes to dayend accoutning or use different event Id
                RequestType = requestTypeCode.GetKey(),
                ApplicationKey = "CMS",
                BranchID = criteria.BranchId,
                EventId = eventId,
                ContextData = context,
                ModuleKey = ModuleTypeCode.BATCH_PROCESS_EXECUTION.GetKey(),
                RefId1 = contId.ToString(),
                FcId = criteria.CompanyId,
            };

            SaveEventLog(eventParam);
            return eventParam;
        }
        /// <summary>
        /// SaveEventLog
        /// </summary>
        /// <param name="eventParam"></param>
        private static void SaveEventLog(EventParm eventParam)
        {
            LogContext.ContextToLog = eventParam.ContextData;
            var eventLog = new EventLog();
            {
                eventLog.REQT_TYPE_KEY = eventParam.RequestType;
                eventLog.EVNT_ID = eventParam.EventId;
                eventLog.MDUL_KEY = eventParam.ModuleKey;
                eventLog.REF_ID_1 = eventParam.RefId1;
                eventLog.REF_ID_2 = eventParam.RefId2;
                eventLog.REF_ID_3 = eventParam.RefId3;
                eventLog.FC_ID = eventParam.FcId;
                eventLog.BRNC_ID = eventParam.BranchID;
                if (eventParam.ExtraData != null)
                    foreach (var logDetails in eventParam.ExtraData.Select(pair => new EventLogData
                    {
                        DATA_KEY = pair.Key,
                        DATA_VAL = pair.Value
                    }))
                    {
                        eventLog.data.Add(logDetails);
                    }

                var coll = new List<EventLog>() { eventLog };
                var context = EntityContextExt.Create(coll);
                context.Persist();
                var firstOrDefault = context.Entity.FirstOrDefault();

                if (firstOrDefault != null)
                {
                    eventParam.EventLogId = firstOrDefault.EVNT_LOG_ID;
                }

            }
        }
        #endregion AccountingGeneration

        #region Helpers
        //private static bool SubmitProcessSAPFileDayEnd(EventParm eventParam)
        //{
        //    try
        //    {
        //        Context context = eventParam.ContextData;
        //        BatchProcessCriteria criteria = new BatchProcessCriteria();
        //        criteria.BranchId = eventParam.BranchID;
        //        criteria.CompanyId = eventParam.FcId;
        //        criteria.SubTenantId = context.SubTenantId;
        //        criteria.SubmittedProcessingDate = GetProcessingDate(eventParam.BranchID);
        //        criteria.Criteria = Guid.NewGuid().ToString();


        //        int processId = Convert.ToInt32(ProcessName.SAPFileGenerationDayEnd.GetKey());
        //        RequestObject<int> objRequest = new RequestObject<int>(context, processId);
        //        using (var srv = new ProxyClient<IBatchProcessControllerService>())
        //        {
        //            if (srv.ClientInstance.IsProcessEnabed(objRequest).ResultSet)
        //            {
        //                ResponseObject<bool> response = new ResponseObject<bool>();
        //                BatchProcessRequestParam objBatchProcessRequestParam = new BatchProcessRequestParam();

        //                BatchProcessRequestParam requestParam = GetNewBatchProcessRequestParam(processId, 1, XmlSerializationHelper.SerializeToString(criteria), context.ContextId.ToString(), criteria.BranchId, criteria.CompanyId, criteria.SubTenantId, false, Convert.ToInt32(InvokeTypes.Event.GetKey()));
        //                List<BatchProcessRequestParam> requestParamList = new List<BatchProcessRequestParam> { requestParam };
        //                RequestObject<List<BatchProcessRequestParam>> requestList = new RequestObject<List<BatchProcessRequestParam>>(context, requestParamList);
        //                response = srv.ClientInstance.StartBatchProcessList(requestList);
        //            }
        //            else
        //            {
        //                ExceptionHandler.Log(new Context(context, "Process is not enable in process configuration screen.") { LogLevel = NSLogLevel.Error });
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);

        //    }
        //    return true;

        //}
        private static BatchProcessRequestParam GetNewBatchProcessRequestParam(int screenId, int topFetchedRows, string criteria, string contextId, int branchId, int companyId, int subTennatId, bool priorityQueueInd, int? invokeTypeId = null)
        {
            return new BatchProcessRequestParam
            {
                RowCount = topFetchedRows,
                ScreenId = screenId,
                ProcessId = screenId,
                InsertedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow,
                Criteria = criteria,
                InvokeTypeId = invokeTypeId,
                ContextId = contextId,
                PriorityQueueInd = priorityQueueInd,
                BranchId = branchId,
                CompanyId = companyId,
                SubTennatId = subTennatId


            };
        }
        /// <summary>
        /// GetProcessingDate
        /// </summary>
        /// <param name="branchId"></param>
        /// <returns></returns>
        public static DateTime GetProcessingDate(int branchId)
        {
            var contextExt = EntityContextExt.Create<TenantPartitionEntity>();
            DateTime? cpd = contextExt.Read(x => x.BRNC_ID == branchId)?.Entity?.Select(x => x.PRCG_DTE).FirstOrDefault();
            return cpd.Value;

        }
        /// <summary>
        /// SetParentQueue
        /// </summary>
        /// <param name="batchProcess"></param>
        /// <param name="ddAccountingProcessId"></param>
        //public static void SetParentQueue(BatchProcess batchProcess, int processId)
        //{
        //    var contextExt = EntityContextExt.Create<BatchProcess>();
        //    var ddAccountingBatchProcess = contextExt.Read(p => p.GRP_DPCY_ID == batchProcess.GRP_DPCY_ID && p.BRNC_ID == batchProcess.BRNC_ID && p.PRCS_ID == processId);

        //    if (ddAccountingBatchProcess != null && ddAccountingBatchProcess.Entity.Count > 0)
        //    {
        //        var result = ddAccountingBatchProcess.Entity.First();
        //        result.PRNT_QUEU_ID = batchProcess.PRCS_QUEU_ID;

        //        using (var c = DbController.Create())
        //        {
        //            var processQueIds = c.GetCustomList<int>(Constant.SqlUpdateAccParentId, new SerializableDictionary<string, object>()
        //            {
        //                {"p_PQID", batchProcess.PRCS_QUEU_ID},
        //                {"p_PID", result.PRCS_QUEU_ID}
        //            });
        //        }
        //    }
        //}

        public static void InvokeABSDataTransferProcesses(BatchProcessRequestParam requestParam, Context context)
        {
            IBatchProcessControllerService srv = null;
            try
            {

                BatchProcessCriteria criteria = new BatchProcessCriteria();
                criteria.BranchId = requestParam.BranchId;
                criteria.CompanyId = requestParam.CompanyId;
                criteria.SubTenantId = context.SubTenantId;
                srv = ChannelFactory.CreateChannel<IBatchProcessControllerService>();

                ResponseObject<bool> response = new ResponseObject<bool>();
                BatchProcessRequestParam objBatchProcessRequestParam = new BatchProcessRequestParam();

                BatchProcessRequestParam requestParamABSPortfolioProcess = GetNewBatchProcessRequestParam(Convert.ToInt32(ProcessName.ABSPortfolioProcess.GetKey()), 1, XmlSerializationHelper.SerializeToString(criteria), context.ContextId.ToString(), criteria.BranchId, criteria.CompanyId, criteria.SubTenantId, false, Convert.ToInt32(InvokeTypes.Event.GetKey()));
                BatchProcessRequestParam requestParamABSPaymentProcess = GetNewBatchProcessRequestParam(Convert.ToInt32(ProcessName.ABSPaymentProcess.GetKey()), 1, XmlSerializationHelper.SerializeToString(criteria), context.ContextId.ToString(), criteria.BranchId, criteria.CompanyId, criteria.SubTenantId, false, Convert.ToInt32(InvokeTypes.Event.GetKey()));
                BatchProcessRequestParam requestParamABSTransactionProcess = GetNewBatchProcessRequestParam(Convert.ToInt32(ProcessName.ABSTransactionProcess.GetKey()), 1, XmlSerializationHelper.SerializeToString(criteria), context.ContextId.ToString(), criteria.BranchId, criteria.CompanyId, criteria.SubTenantId, false, Convert.ToInt32(InvokeTypes.Event.GetKey()));
               
                BatchProcessRequestParam requestParamABSSummaryProcess = GetNewBatchProcessRequestParam(Convert.ToInt32(ProcessName.ABSSummaryProcess.GetKey()), 1, XmlSerializationHelper.SerializeToString(criteria), context.ContextId.ToString(), criteria.BranchId, criteria.CompanyId, criteria.SubTenantId, false, Convert.ToInt32(InvokeTypes.Event.GetKey()));

                List<BatchProcessRequestParam> requestParamList = new List<BatchProcessRequestParam> { requestParamABSPortfolioProcess, requestParamABSPaymentProcess, requestParamABSTransactionProcess,  requestParamABSSummaryProcess };
               // requestParamList.ForEach(x => x.IsGetNewGroupId = true);
                RequestObject<List<BatchProcessRequestParam>> requestList = new RequestObject<List<BatchProcessRequestParam>>(context, requestParamList);

                response = srv.StartBatchProcessList(requestList);

            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);

            }
            finally
            {
                ChannelFactory.CloseChannel(srv);
            }

        }

        public static void PublishBatchProcessFinalize(BatchProcessCriteria criteria, Context context, int processQueueId)
        {
            try
            {
                var eventParam = new EventParm()
                {
                    ApplicationKey = ApplicationCodes.Bpem.GetKey(),
                    ModuleKey = ModuleTypeCode.BATCH_PROCESS_EXECUTION.GetKey(),
                    EventId = Convert.ToInt32(EventCode.OnComplete),
                    ContextData = context,
                    BranchID = criteria.BranchId,
                    FcId = criteria.CompanyId,
                    PostActionsEnum = new List<Resources.Enums.EventDispatcher.EventDispatcherEnum> { EventDispatcherEnum.BatchProcessEvent },
                    RefId1 = processQueueId.ToString()
                };


                using (var svc = new ProxyClient<IEventDispatcherLogicService>())
                {
                    var request = new RequestObject<EventParm>(context, eventParam);
                    svc.ClientInstance.TriggerEvent(request);
                }

            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
            }


        }

        #endregion
    }
}

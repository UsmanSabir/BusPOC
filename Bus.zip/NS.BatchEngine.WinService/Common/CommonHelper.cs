﻿using NFS.Models.Accounting.Custom.Param;
using NFS.Models.Common;
using NFS.Models.Common.Custom;
using NFS.ServiceContracts;
using NS.BaseModels;
using NS.ExceptionHandling;
using NS.ORM;
using NS.Resources.Enums.Common;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using NFS.Models.DayEnd;

namespace BatchBootstrapper.Common
{
    /// <summary>
    /// This class wil be moved to utillity Project once created in NFS
    /// </summary>
    public class CommonHelper
    {
        private static int _intMaxCount;
        static CommonHelper()
        {
            //int.TryParse(ConfigurationManager.AppSettings["NextWorkingDayCount"].ToString(), out _intMaxCount); ;
        }
        /// <summary>
        /// HasData
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns></returns>
        public static bool HasData<T>(ICollection<T> collection)
        {
            return collection != null && collection.Count > 0;
        }

        /// <summary>
        /// This method adds no of days to creation date based on WorkingDays settings 
        /// </summary>
        /// <param name="workingDayType"></param>
        /// <param name="workingDayCalcParam"></param>
        /// <param name="noOfDays"></param>
        /// <returns></returns>
        public static DateTime GetNextWorkinDay(DaysYearType workingDayType, WorkingDayCalcParam workingDayCalcParam, int noOfDays)
        {

            int holidays_count = 0;
            DateTime creationDate = workingDayCalcParam.ValueDte;
            //int iMaxCount = 0;
            //int.TryParse(ConfigurationManager.AppSettings["NextWorkingDayCount"].ToString(), out iMaxCount);
            bool workingDaysConfigured = false;
            for (int i = 0; i < noOfDays; i++)
            {
                creationDate = creationDate.AddDays(1);
                workingDayCalcParam.ValueDte = creationDate;
                for (int j = 0; j < 1; j++)
                {
                    if (!IsWorkingDay(workingDayType, workingDayCalcParam))
                    {
                        workingDayCalcParam.ValueDte = workingDayCalcParam.ValueDte.AddDays(1);
                        holidays_count++;
                    }
                    else
                    {
                        workingDaysConfigured = true;
                        break;
                    }
                }
                if (holidays_count > 0)
                {
                    creationDate = creationDate.AddDays(holidays_count);
                    holidays_count = 0;
                }
            }
            //if (!workingDaysConfigured)
            //{
            //    throw new Exception("Working Days are not configured against Day End branch.");
            //}
            return creationDate;
        }

        /// <summary>
        /// GetWorkingDay
        /// </summary>
        /// <param name="workingDayType"></param>
        /// <param name="dayEndParam"></param>
        /// <returns></returns>
        private static bool IsWorkingDay(DaysYearType workingDayType, WorkingDayCalcParam dayEndParam)
        {
            if (workingDayType == DaysYearType.NonWorkingDays)
            {
                return true;
            }
            else if (workingDayType == DaysYearType.FinancialWorkingDays)
            {
                return IsWorkingDay(dayEndParam, false);
            }
            else if (workingDayType == DaysYearType.NonFinancialWorkingDays)
            {
                return IsWorkingDay(dayEndParam, true);
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// IsWorkingDay
        /// </summary>
        /// <param name="dayEndParam"></param>
        /// <param name="includeNonFinancialWorkingDays">True means non-Financial Day will be considered as working day. False means, it will be considered as Off day </param>
        /// <returns></returns>
        public static bool IsWorkingDay(WorkingDayCalcParam dayEndParam, bool includeNonFinancialWorkingDays)
        {
            // Check if input date is in regular days of week.
            bool isWorkingDay = IsWorkingDayOfWeek(dayEndParam, includeNonFinancialWorkingDays);

            //Further check if input date is marked as holiday (1st May can be marked as Labor Day) or holiday is marked as working day. i.e. 14th August can be marked as working day.
            using (var holidayExt = EntityContextExt.Create<PrcgDayHolidayConfiguration>())
            {

                holidayExt.Read(x => x.FC_CMPY_ID == dayEndParam.CompanyId && x.BRNC_ID == dayEndParam.BranchId );
                if (holidayExt.Entity?.Count > 0)
                {
                    List<PrcgDayHolidayConfiguration> list = holidayExt.Entity;

                    // This filtered list checks for specific date whether it is working day or not
                    List<PrcgDayHolidayConfiguration> filteredList = list.Where(p => p.HLDY_DTE == dayEndParam.ValueDte && (p.WORK_HLDY_IND == true || p.NON_FINL_DAY_IND == true)).ToList();
                    if (HasData(filteredList))
                    {
                        if (includeNonFinancialWorkingDays)
                        {
                            if (HasData(filteredList))
                            {
                                isWorkingDay = true;
                            }
                        }
                        else
                        {

                            filteredList = filteredList.Where(p => p.WORK_HLDY_IND == true).ToList();
                            if (HasData(filteredList))
                            {
                                isWorkingDay = true;
                            }
                        }
                    }
                    else
                    {
                        //Specific Day is Holiday but may or may not be annual holiday
                        List<PrcgDayHolidayConfiguration> specificDateHoliday = list.Where(p => p.HLDY_DTE == dayEndParam.ValueDte && (p.WORK_HLDY_IND == false && p.NON_FINL_DAY_IND == false)).ToList();
                        if (HasData(specificDateHoliday))
                        {
                            isWorkingDay = false;
                        }
                        //Check for annual holiday
                        else
                        {
                            list = list.Where(p =>
                            {
                                if (p.HLDY_DTE != null && (p.HLDY_DTE.Value.Day == dayEndParam.ValueDte.Day && p.HLDY_DTE.Value.Month == dayEndParam.ValueDte.Month && p.ANUL_HLDY_IND == true && p.HLDY_DTE.Value.Year == dayEndParam.ValueDte.Year))
                                {
                                    return true;
                                }
                                return false;
                            }).ToList();

                            //Means, if data is found is holidays configuration, it is holiday.
                            if (HasData(list))
                            {
                                isWorkingDay = false;
                            }
                        }
                    }
                }
            }
            return isWorkingDay;
        }

        /// <summary>
        /// This method returns whether input date is working or not
        /// </summary>
        /// <param name="companyId"></param>
        /// <param name="branchId"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        public static bool IsWorkingDay(int companyId, int branchId, DateTime date)
        {
            WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = date };
            return IsWorkingDay(param, true);
        }

        public static bool IsWorkingDayConfigured(WorkingDayCalcParam dayEndParam)
        {
            bool _isWorkingDayConfigured = false;
            using (var context = EntityContextExt.Create<ProcessingDaySection>())
            {
                context.Read(x => x.FC_CMPY_ID == dayEndParam.CompanyId && x.BRNC_ID == dayEndParam.BranchId && (x.PRCG_IND == true || x.NON_FINL_DAY_IND == true));
                _isWorkingDayConfigured = context.Entity?.Count > 0;
            }
            if (!_isWorkingDayConfigured)
            {
                using (var context = EntityContextExt.Create<ProcessingDayHolidayConfiguration>())
                {
                    context.Read(x => x.FC_CMPY_ID == dayEndParam.CompanyId && x.BRNC_ID == dayEndParam.BranchId && x.HLDY_DTE >= dayEndParam.ValueDte && (x.WORK_HLDY_IND == true || x.NON_FINL_DAY_IND == true));
                    _isWorkingDayConfigured = context.Entity?.Count > 0;
                }
            }
            return _isWorkingDayConfigured;
        }

        /// <summary>
        /// IsWorkingDayOfWeek
        /// </summary>
        /// <param name="dayEndParam"></param>
        /// <param name="includeNonFinancialWorkingDays"></param>
        /// <returns></returns>
        private static bool IsWorkingDayOfWeek(WorkingDayCalcParam dayEndParam, bool includeNonFinancialWorkingDays)
        {
            bool isWorkingDayOfWeek = false;
            string dayOfWeek = dayEndParam.ValueDte.DayOfWeek.ToString();
            using (var context = EntityContextExt.Create<ProcessingDaySection>())
            {
                if (includeNonFinancialWorkingDays)
                {
                    context.Read(x => x.FC_CMPY_ID == dayEndParam.CompanyId && x.BRNC_ID == dayEndParam.BranchId && x.PRCG_DAY_KEY == dayOfWeek && x.PRCG_IND == true);
                }
                else
                {
                    context.Read(x => x.FC_CMPY_ID == dayEndParam.CompanyId && x.BRNC_ID == dayEndParam.BranchId && x.PRCG_DAY_KEY == dayOfWeek && x.PRCG_IND == true && x.NON_FINL_DAY_IND == false);
                }
                isWorkingDayOfWeek = context.Entity?.Count > 0;
            }

            return isWorkingDayOfWeek;
        }

        /// <summary>
        /// This method returns next working date
        /// </summary>
        /// <param name="date"></param>
        /// <param name="daysYearType"></param>
        /// <param name="companyId"></param>
        /// <param name="branchId"></param>
        /// <returns></returns>
        public static DateTime GetNextWorkingDay(DateTime date, DaysYearType daysYearType, int companyId, int branchId)
        {
            WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = date };
            var nextWorkingDay = GetNextWorkinDay(daysYearType, param, 1);
            return nextWorkingDay;
        }

        /// <summary>
        /// This method returns last working date
        /// </summary>
        /// <param name="date"></param>
        /// <param name="daysYearType"></param>
        /// <param name="companyId"></param>
        /// <param name="branchId"></param>
        /// <returns></returns>
        public static DateTime GetLastWorkingDay(DateTime date, DaysYearType daysYearType, int companyId, int branchId)
        {
            WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = date };
            int holidays_count = 0;
            DateTime inputDate = date;
            //int iMaxCount = 0;
            //int.TryParse(ConfigurationManager.AppSettings["NextWorkingDayCount"].ToString(), out iMaxCount);
            bool workingDaysConfigured = false;

            inputDate = inputDate.AddDays(-1);
            param.ValueDte = inputDate;
            for (int i = _intMaxCount; i >= 0; i--)
            {
                if (!IsWorkingDay(daysYearType, param))
                {
                    param.ValueDte = param.ValueDte.AddDays(-1);
                    holidays_count++;
                }
                else
                {
                    workingDaysConfigured = true;
                    break;
                }
            }
            if (holidays_count > 0)
            {
                inputDate = inputDate.AddDays(-1 * holidays_count);
                holidays_count = 0;
            }
            //if (!workingDaysConfigured)
            //{
            //    throw new Exception("Working Days are not configured against Day End branch.");
            //}
            return inputDate;
        }

        /// <summary>
        /// This method returns if input date is first working day
        /// </summary>
        /// <param name="date"></param>
        /// <param name="daysYearType"></param>
        /// <param name="companyId"></param>
        /// <param name="branchId"></param>
        /// <returns></returns>
        public static bool IsDateFirstWorkingDay(DateTime date, DaysYearType daysYearType, int companyId, int branchId)
        {
            var dayBeforeProcessingDate = date.AddDays(-1);
            WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = dayBeforeProcessingDate };
            return !IsWorkingDay(daysYearType, param);

        }
        /// <summary>
        /// This method returns if input date is last working day
        /// </summary>
        /// <param name="date"></param>
        /// <param name="daysYearType"></param>
        /// <param name="companyId"></param>
        /// <param name="branchId"></param>
        /// <returns></returns>
        public static bool IsDateLastWorkingDay(DateTime date, DaysYearType daysYearType, int companyId, int branchId)
        {
            var dayAfterLastDdDate = date.AddDays(1);
            WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = dayAfterLastDdDate };
            return !IsWorkingDay(daysYearType, param);

        }
        /// <summary>
        /// This method returns no. of days added to input date
        /// </summary>
        /// <param name="date"></param>
        /// <param name="days"></param>
        /// <param name="daysYearType"></param>
        /// <param name="companyId"></param>
        /// <param name="branchId"></param>
        /// <returns></returns>
        public static DateTime AddBusinessDays(DateTime date, int days, DaysYearType daysYearType, int companyId, int branchId)
        {
            WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = date };
            var newDate = GetNextWorkinDay(daysYearType, param, days);
            return newDate;
        }

        public static bool IsMonthEnd(DateTime date, DaysYearType daysYearType, int companyId, int branchId)
        {
            int daysInMonth = DateTime.DaysInMonth(date.Year, date.Month);

            try
            {
                var branchConfig = BranchConfig.ReadBranchConfig(companyId, branchId)?.FirstOrDefault();
                if (branchConfig?.MNTH_END_DTE != null && branchConfig.MNTH_END_DTE.Value > 0 && branchConfig.MNTH_END_DTE.Value <= daysInMonth)
                {
                    //var isMonthEndDate = date.Day== branchConfig.MNTH_END_DTE;
                    daysInMonth = branchConfig.MNTH_END_DTE.Value; //Math.Min(branchConfig.MNTH_END_DTE.Value, daysInMonth);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
            }

            bool isMonthEnd = true;
            if (date.Day == daysInMonth)
            {
                WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = date };
                return IsWorkingDay(daysYearType, param);
            }
            else if (date.Day > daysInMonth)
            {
                isMonthEnd = false;
            }
            else
            {
                int currentDay = date.Day;
                for (int i = currentDay; i < daysInMonth; i++)
                {
                    date = date.AddDays(1);
                    WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = date };
                    if (IsWorkingDay(daysYearType, param))
                    {
                        isMonthEnd = false;
                        break;
                    }
                }
            }
            return isMonthEnd;
        }
        public static bool IsMonthEnd(DateTime date)
        {
            return date.Day == DateTime.DaysInMonth(date.Year, date.Month);
        }

        public static DateTime? GetUpCommingMonthEndDate(int companyId, int branchId, DaysYearType daysYearType = DaysYearType.FinancialWorkingDays)
        {
            var contextExt = EntityContextExt.Create<TenantPartForDayEnd>();
            DateTime? dateEndDate = null;
            var branchConfigData = contextExt.Read(x => x.BRNC_ID == branchId && x.CMPY_ID == companyId)?.Entity?.FirstOrDefault();

            int? dayOfMonthEnd = branchConfigData?.MNTH_END_DTE;
            using (var context = EntityContextExt.Create<ProcessingDaySection>())
            {
                context.Read(x => x.FC_CMPY_ID == companyId && x.BRNC_ID == branchId && x.PRCG_IND == true);

                bool isWorkingDaysConfigured = context.Entity?.Count > 0;

                if (isWorkingDaysConfigured == false)
                {
                    return null;
                }
            }

            if (dayOfMonthEnd != null && dayOfMonthEnd != 0 && branchConfigData.PRCG_DTE != null)
            {
                dateEndDate = new DateTime(branchConfigData.PRCG_DTE.Value.Year, branchConfigData.PRCG_DTE.Value.Month, dayOfMonthEnd.Value);

                if (dateEndDate.GetValueOrDefault().Date < branchConfigData.PRCG_DTE.Value.Date)
                {
                    dateEndDate = dateEndDate.GetValueOrDefault().AddMonths(1);
                }

                WorkingDayCalcParam param = new WorkingDayCalcParam { CompanyId = companyId, BranchId = branchId, ValueDte = dateEndDate.GetValueOrDefault() };

                while (IsWorkingDay(daysYearType, param) == false)
                {
                    dateEndDate = dateEndDate.GetValueOrDefault().AddDays(1);
                    param.ValueDte = dateEndDate.GetValueOrDefault();

                }
            }

            return dateEndDate;
        }

        //public static void Log(String customMessage, Context context, int referenceId, NSLogLevel logLevel = NSLogLevel.Info)
        //{
        //    context.LogLevel = logLevel;
        //    context.ReferenceId = referenceId;
        //    context.ServerIp = GetMachineIpOrName() + "_" + context.SubTenantId;
        //    context.CustomMessage = customMessage;
        //    ExceptionHandler.Log(context);

        //}

        //public static void Log(String customMessage, Context context, int referenceId, bool logServerIp, NSLogLevel logLevel = NSLogLevel.Info)
        //{
        //    context.LogLevel = logLevel;
        //    context.ReferenceId = referenceId;
        //    if (logServerIp) context.ServerIp = GetMachineIpOrName() + "_" + context.SubTenantId;
        //    context.CustomMessage = customMessage;
        //    ExceptionHandler.Log(context);
        //}


        //private static string GetMachineIpOrName()
        //{
        //    try
        //    {
        //        return ConfigUtility.GetIPv4Address();
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);

        //    }
        //    return Environment.MachineName;

        //}


        //public static void AddDiary(string customMsg, string RefModule, string RefNum, Context ctx)
        //{
        //    try
        //    {
        //        DiaryLogic diaryLogic = new DiaryLogic();
        //        DiaryEntry diary = new DiaryEntry();
        //        diary.CMNT = customMsg;
        //        diary.CTXT_ID = ctx.ContextId.ToString();
        //        diary.DIRY_IND = true;
        //        diary.EVNT_DTE_TIME = DateTime.Now;
        //        diary.USR_NME = ctx.UserName;
        //        diary.ENRY_TYPE_KEY = "Manual";
        //        diary.REF_NUMB = RefNum;
        //        diary.REF_MDUL_KEY = RefModule;
        //        diary.CMNT = customMsg;

        //        RequestObject<Models.Diary.DiaryEntry> request = new RequestObject<DiaryEntry>(ctx, diary);

        //        // diaryLogic.PersistDiaryEntry(request); TODO Temp Commented
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
        //    }


        //}
        /// <summary>
        /// InvokeActivity
        /// </summary>
        /// <param name="accParam"></param>
        /// <param name="context"></param>
        /// <param name="branchId"></param>
        /// <param name="processId"></param>
        public static void InvokeActivity(AccParam accParam, Context context, int branchId, int processId, IWorkflowEngineService workflowEngineLogicInstance)
        {
            try
            {
                if (workflowEngineLogicInstance != null)
                {
                    WorkflowInputParams workflowInput = new WorkflowInputParams();
                    workflowInput.PostAction = true;
                    workflowInput.ScreenId = processId;
                    workflowInput.ScreenAction = "Submit";
                    workflowInput.Session = context;
                    workflowInput.Entity = accParam;
                    workflowInput.EntityType = typeof(AccParam).ToString();
                    workflowInput.BranchId = branchId;
                    workflowInput.ApplicationKey = "CMS";
                    workflowInput.Module = ModuleTypeCode.BATCH_PROCESS_EXECUTION.GetKey();
                    workflowInput.ReferenceId = Convert.ToInt32(accParam.RefId1);

                    RequestObject<WorkflowInputParams> workflowInputParams = new RequestObject<WorkflowInputParams>(context, workflowInput);
                    workflowEngineLogicInstance.InvokeMicroWorkflow(workflowInputParams);
                }

            }
            catch { /*TODO: replace with proper handling*/ }
        }

        internal static void Log(string v, Context context, int tenantid, NSLogLevel info)
        {
            //throw new NotImplementedException();
        }
    }
}

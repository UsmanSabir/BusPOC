﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using NS.BaseModels;
using NS.ExceptionHandling;
using NS.ORM;
using NS.Resources.Enums.Common;
using NS.Resources.Enums.Receipt;
using NS.Resources.Enums.Search;
using NS.Utilities;
using NS.Utilities.Enums;
using NS.Utilities.Context;
using NS.ServiceModel;
using NS.ORM.UoW;
using NS.Resources.Enums.Diary;
using NFS.Models.Payables;
using NFS.Business.CommonHelper;
using NFS.Models.Common.Custom;
using NFS.Models.BPM.Params;
using NFS.Models.Diary;
using NFS.ServiceContracts;
using CMS.Models.OverdueCalculation;
using CMS.Models.EarlyTermination;
using CMS.Models.ContractClosing;
using CMS.Models.ContractActivation;
using CMS.Models.Receipting;
using CMS.Models.Receipting.Custom;
using CMS.Models.Receipting.Custom.Criteria;
using CMS.Models.Custom.Param;
using CMS.ServiceContracts;
using CMS.Business.Helper.Settlement;
using CMS.Models.FinancialProduct;
using CMS.Business.Helper.Manage;
using NS.Models.Events.Custom;
using CMS.Models.Disbursement;
using NS.Resources.Enums.EventDispatcher;

namespace CMS.Business.Helper.Utility
{
    public class ReceiptingRepository
    {
        #region Private Fields

        static string DRAFT_ALLOCATED_UNALLOCATED = "Draft,Allocated,UnAllocated";
        static string ALLOCATED_UNALLOCATED_SETTLED = "Allocated,UnAllocated,Settled";
        static string ALLOCATED_UNALLOCATED_SETTLED_DEALLOCATED = "Allocated,UnAllocated,Settled,DeAllocated";
        static string ALLOCATED_SETTLED = "Allocated,Settled";
        static string ALLOCATED_UNALLOCATED = "Allocated,UnAllocated";
        static string NON_REVERSIBLE_RECEIPTS = string.Join(",", AppendChar(ReceiptType.SaleProceedReceipt.GetKey(), "'"), //AppendChar(ReceiptType.WriteOffReceipt.GetKey(), "'"),
            AppendChar(ReceiptType.IntroducerFlatCancelReceipt.GetKey(), "'"), AppendChar(ReceiptType.CustomerFlatCancelReceipt.GetKey(), "'"), AppendChar(ReceiptType.RestructuringReceipt.GetKey(), "'"));

        public static Dictionary<string, string> PaymentSourceForAutoReceipt = new Dictionary<string, string>
        {
            { "NR","Normal"},
            { "SD","SD Adjustment"},
            { "IN","Insurance Adjustment"},
            { "DR","Dealer Deduction"},
            { "SP","Sold Price"},
            { "NP","Negative Pos"},
            { "DD","Direct Debit"},
            { "AV","Asset Value"}
        };

        #endregion

        //DB Operations

        #region Receipts

        /// <summary>
        /// Persists the receipts.
        /// </summary>
        /// <param name="receipts">The receipts.</param>
        /// <returns></returns>
        public static List<Receipt> PersistReceipts(List<Receipt> receipts)
        {
            try
            {
                var contextExt = EntityContextExt.Create(receipts);
                contextExt.Persist();
                return contextExt.Entity;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// Persists the Misc Register Request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        public static List<RequestMiscRegisterMain> PersistMiscRegisterRequest(List<RequestMiscRegisterMain> request)
        {
            try
            {
                var contextExt = EntityContextExt.Create(request);
                contextExt.IdInjector = (model, i) =>
                {
                    if (model is RequestMiscRegisterMain)
                    {
                        var mMiscRegisterMain = model as RequestMiscRegisterMain;
                        if (mMiscRegisterMain != null)
                        {
                            mMiscRegisterMain.RequestMiscRegisterDetail.ForEach(
                                x => x.REQT_MISC_REGT_MAIN_ID = i
                                );
                        }
                    }
                };
                contextExt.Persist();
                return contextExt.Entity;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }
        
        /// <summary>
        /// Gets the maximum receipt value date.
        /// </summary>
        /// <param name="contractIds">The contract ids.</param>
        /// <returns></returns>
        public static DateTime? GetMaxReceiptValueDate(List<int> contractIds)
        {
            try
            {
                if (HasData(contractIds))
                {
                    string csv = string.Join(",", contractIds);
                    //var sql = string.Concat("select max(VAL_DTE) as VAL_DTE from RCPT r join RCPT_DET rd on r.RCPT_ID = rd.RCPT_ID and r.STS_KEY in (", AppendCharAndJoin(ALLOCATED_UNALLOCATED_SETTLED), ") join CONT_RCPT_ASOC cra on rd.RCPT_DET_ID = cra.RCPT_DET_ID where cra.CONT_ID in (", csv, ")");
                    var sql = string.Concat("select max(VAL_DTE) as VAL_DTE from RCPT r join RCPT_DET rd on r.RCPT_ID = rd.RCPT_ID and r.STS_KEY in (", AppendCharAndJoin(ALLOCATED_UNALLOCATED_SETTLED), ") join CONT_RCPT_ASOC cra on rd.RCPT_DET_ID = cra.RCPT_DET_ID where cra.CONT_ID in (SELECT val FROM Fn_SplitStr(@ContIds,','))");
                    return ExecuteQuery<DateTime>(sql, new SerializableDictionary<string, object>() { { "ContIds", csv } }).First();
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// check shortfall writeoff request exist against contract and Asset id.
        /// </summary>
        /// <param name="contractIds">The contract ids.</param>
        /// <returns></returns>
        public static bool IsShortfallWriteoffExist(ReceiptParam param)
        {
            try
            {
                if (param.RequestId > 0)
                {
                    var sql = string.Concat("SELECT COUNT(1) from WOFF_RCVY_REQT_DET woff_reqt_detl join NFS_TASK_QUEU task_queue on task_queue.TASK_QUEU_ID = woff_reqt_detl.TASK_QUEU_ID and task_queue.STS_KEY = 'Approved' where woff_reqt_detl.BASE_REQT_TYPE_KEY = 'Shortfall Writeoff' and woff_reqt_detl.RCVY_REQT_DET_ID in (@RequestId)");
                    if (Convert.ToInt32(ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "RequestId", param.RequestId } }).First()) > 0)
                        return true;
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return false;
        }

        public static string AppendCharAndJoin(string str)
        {
            return string.Join(",", AppendChar(str.Split(',').ToList(), "'"));
        }

        /// <summary>
        /// Gets the latest receipt id of list of contracts.
        /// </summary>
        /// <param name="contractIds">The contract ids.</param>
        /// <returns></returns>
        public static int GetLatestReceiptId(List<int> contractIds,bool IsReceiptDeallocation = false)
        {
            try
            {
                if (HasData(contractIds))
                {
                    string csv = string.Join(",", contractIds);
                    string sql = null;
                    if (IsReceiptDeallocation)
                    {
                        sql = string.Concat("select ISNULL( max(rd.RCPT_DET_ID),0) as MaxReceiptId from RCPT r join RCPT_DET rd on r.RCPT_ID = rd.RCPT_ID and r.STS_KEY in (", AppendCharAndJoin(ALLOCATED_SETTLED), ") AND r.AUTO_RCPT_IND = 0 AND rd.RCPT_TYPE_ID NOT IN (", NON_REVERSIBLE_RECEIPTS, ") join CONT_RCPT_ASOC cra on rd.RCPT_DET_ID = cra.RCPT_DET_ID and cra.STS_KEY in (", AppendCharAndJoin(ALLOCATED_SETTLED), ") where cra.CONT_ID in (SELECT val FROM Fn_SplitStr(@ContIds,','))");
                    }
                    else
                    {
                        sql = string.Concat("select ISNULL( max(rd.RCPT_DET_ID),0) as MaxReceiptId from RCPT r join RCPT_DET rd on r.RCPT_ID = rd.RCPT_ID and r.STS_KEY in (", AppendCharAndJoin(ALLOCATED_SETTLED), ") AND r.AUTO_RCPT_IND = 0 AND rd.RCPT_TYPE_ID NOT IN (", NON_REVERSIBLE_RECEIPTS, ") join CONT_RCPT_ASOC cra on rd.RCPT_DET_ID = cra.RCPT_DET_ID and cra.STS_KEY in (", AppendCharAndJoin(ALLOCATED_SETTLED), ") where cra.CONT_ID in (SELECT val FROM Fn_SplitStr(@ContIds,','))");
                    }
                    return ExecuteQuery<Int32>(sql, new SerializableDictionary<string, object>() { { "ContIds", csv } }).First();
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return -1;
        }
        /// <summary>
        /// Gets the Max receipt det id.
        /// </summary>
        /// <param name="rcpt">The Receipt.</param>
        /// <returns></returns>
        /// 
        public static int GetMaxReceiptDetId(Receipt rcpt)
        {
            try
            {
                if (rcpt != null)
                {
                    if (rcpt.ReceiptDetail !=null && rcpt.ReceiptDetail.Count > 0) return rcpt.ReceiptDetail.Max(p=>p.RCPT_DET_ID);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return -1;
        }
        /// <summary>
        /// Get the Asset Model Group Id by Asset Id
        /// </summary>
        /// <param name="contractIds">The asset ids.</param>
        /// <returns></returns>
        public static IList<int> GetAssetModelGroupIdByAssetId(IList<int> asssetId)
        {
            try
            {
                if (HasData(asssetId))
                {
                    string assetIdList = string.Join(",", asssetId);
                    var sql = string.Concat("select MODL_GRP_ID as MODL_GRP_ID from CONT_ASET where ASET_ID in (SELECT val FROM Fn_SplitStr(@AssetIdList,','))");
                    var result = ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "AssetIdList", assetIdList } });
                    if (HasData(result))
                    {
                        return result.Distinct<int>().ToList();
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// Get the count of Receipts Settled against Security Deposit by ContractId.
        /// </summary>
        /// <param name="contractIds">The contract ids.</param>
        /// <returns></returns>
        public static int GetSDAdjustedReceiptsByContract(int contId)
        {
            try
            {
                if (contId > 0)
                {
                    var sql = string.Concat("select  COUNT( r.RCPT_ID) as ReceiptIdCount from RCPT r join RCPT_DET rd on r.RCPT_ID = rd.RCPT_ID AND r.SD_ADJT_IND =1 and r.STS_KEY in (", AppendCharAndJoin(ALLOCATED_UNALLOCATED_SETTLED), ") join CONT_RCPT_ASOC cra on rd.RCPT_DET_ID = cra.RCPT_DET_ID where cra.CONT_ID in (@ContId)");
                    return ExecuteQuery<Int32>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } }).First();
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return -1;
        }
        /// <summary>
        /// Get the article return request id generated against selected receipt contract
        /// </summary>
        /// <param name="contractIds">The article return request id.</param>
        /// <returns></returns>
        public static int GetArticleReturnRequestId(int contId)
        {
            try
            {
                if (contId > 0)
                {
                    var sql = string.Concat("select max(artl_rtrn_main_id) from reqt_artl_rtrn_main inner join nfs_task_queu on nfs_task_queu.task_queu_id = reqt_artl_rtrn_main.task_queu_id and nfs_task_queu.sts_key = 'Approved' where cont_id in (@ContId)");
                    return ExecuteQuery<Int32>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } }).First();
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return -1;
        }

        public static string GetReceiptStatus(int rcptId)
        {
            try
            {
                if (rcptId > 0)
                {
                    var sql = string.Concat("SELECT STS_KEY FROM dbo.RCPT WHERE RCPT_ID  =  @RCPT_ID");
                    var result = ExecuteQuery<string>(sql, new SerializableDictionary<string, object>() { { "RCPT_ID", rcptId } });
                    if (HasData(result))
                    {
                        return result.FirstOrDefault();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        public static string GetUnAllocatedReceiptStatus(int rcptId)
        {
            try
            {
                if (rcptId > 0)
                {
                    var sql = string.Concat("SELECT STS_KEY FROM RCPT WHERE RCPT_ID  =  @RCPT_ID AND MISC_AMNT = RCPT_AMNT");
                    var result = ExecuteQuery<string>(sql, new SerializableDictionary<string, object>() { { "RCPT_ID", rcptId } });
                    if (HasData(result))
                    {
                        return result.FirstOrDefault();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        public static List<int?> GetMiscReceiptIdsByReceiptId(RequestReceiptParam param)
        {
            var response = new ResponseObject<List<int?>>() { Message = new MessageInfo() { Type = MessageType.Success } };
            try
            {
                string query = "";
                string statusString = "";
                if (param.ReceiptAction == ARMProcessTypes.Cancel.ToString() || param.ReceiptAction == MiscRegisterActions.CancelReceipt.GetKey())
                {
                    statusString = ALLOCATED_UNALLOCATED_SETTLED_DEALLOCATED;
                }
                else if (param.ReceiptAction == ARMProcessTypes.Deallocate.ToString())
                {
                    statusString = ALLOCATED_UNALLOCATED_SETTLED;
                }
                else if (param.ReceiptAction == ARMProcessTypes.Posting.ToString() || param.ReceiptAction == MiscRegisterActions.NormalReceipt.GetKey())
                {
                    statusString = ALLOCATED_UNALLOCATED_SETTLED;
                }
                if (!string.IsNullOrWhiteSpace(statusString))
                {
                    List<int?> contList = new List<int?>();
                    if (param.RefId > 0)
                    {
                        var contQuery = @"SELECT
                               DISTINCT CONT_ID
                               FROM RCPT
                               JOIN dbo.RCPT_DET ON RCPT_DET.RCPT_ID = RCPT.RCPT_ID
                              JOIN dbo.CONT_RCPT_ASOC ON CONT_RCPT_ASOC.RCPT_DET_ID = RCPT_DET.RCPT_DET_ID
                              WHERE RCPT.RCPT_ID =@rcptId 
							  AND (CONT_RCPT_ASOC.STS_KEY IN (" + AppendCharAndJoin(statusString) + " ))";

                        using (var dbc = DbController.Create())
                        {
                            contList = (dbc.GetCustomList<int>(contQuery, new NS.Utilities.SerializableDictionary<string, object>() { ["rcptId"] = param.RefId }))?.Select(x => (int?)x).ToList();
                }
                    }
                    contList.AddRange(param.RefIds);
                    if (HasData(contList))
                {
                        string contractList = string.Join(",", contList);
                        query = @"SELECT RCPT.RCPT_ID
                                   FROM RCPT
                                  WHERE RCPT_ID in (SELECT RCPT_ID FROM RCPT_DET WHERE RCPT_DET_ID in (SELECT RCPT_DET_ID FROM CONT_RCPT_ASOC WHERE CONT_RCPT_ASOC.CONT_ID in (" + AppendCharAndJoin(contractList) + " ) AND (CONT_RCPT_ASOC.STS_KEY IN (" + AppendCharAndJoin(statusString) + ")))) UNION ALL SELECT DISTINCT RCPT_ID FROM dbo.REQT_MISC_REGT_MAIN JOIN dbo.REQT_MISC_REGT_DET ON REQT_MISC_REGT_DET.REQT_MISC_REGT_MAIN_ID = REQT_MISC_REGT_MAIN.REQT_MISC_REGT_MAIN_ID WHERE CONT_ID IN (" + AppendCharAndJoin(contractList) + " )";
                }                               
                }
                if (!string.IsNullOrEmpty(query))
                {
                using (var dbc = DbController.Create())
                {
                        var RecieptList = (dbc.GetCustomList<int>(query))?.Select(x => (int?)x).ToList();
                    if (HasData(RecieptList))
                    {
                        response.ResultSet = RecieptList;
                    }
                }
                }
                if (response.ResultSet == null) response.ResultSet = new List<int?>();
                response.ResultSet.Add(param.RefId);
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response.ResultSet;
        }

        public static List<ReceiptMiscDetail> ReadReceiptMiscDetail(int receiptId)
        {
            Expression<Func<ReceiptMiscDetail, bool>> readPredicate = null;
            if (receiptId > 0)
            {
                readPredicate = p => p.RCPT_ID == receiptId;
            }
            if (readPredicate != null)
            {
                var contextExt = EntityContextExt.Create<ReceiptMiscDetail>();
                if (contextExt != null)
                {
                    contextExt.Read(readPredicate);
                    return contextExt.Entity;
                }
            }
            return null;
        }

        /// <summary>
        /// Get local clearance days configured against branch
        /// </summary>
        /// <param name="branchId">The branch id.</param>
        /// <returns></returns>
        public static int ReadBranchClearanceDays(int branchId)
        {
            var sql = string.Concat("SELECT LOCL_CLRC_DAYS FROM BP_CMPY_ADDL WHERE BUSS_PTNR_ID = @BranchId");
            return Convert.ToInt32(ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "BranchId", branchId } }).FirstOrDefault());
        }

        /// <summary>
        /// Get Currency configured against company
        /// </summary>
        /// <param name="companyId">The company id.</param>
        /// <returns></returns>
        public static int ReadCurrencyByCompanyId(int companyId)
        {
            var sql = string.Concat("SELECT CRCY_ID FROM BP_MAIN WHERE BUSS_PTNR_ID = @CompanyId");
            return Convert.ToInt32(ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "CompanyId", companyId } }).FirstOrDefault());
        }

        /// <summary>
        /// Get local clearance days configured against payment mode
        /// </summary>
        /// <param name="paymentModeId">The payment mode id.</param>
        /// <returns></returns>
        public static int ReadPaymentModeClearanceDays(int paymentModeId)
        {
            var sql = string.Concat("SELECT LOCL_CLRC_DAYS FROM PYMT_MODE_CONF WHERE PYMT_MODE_ID = @PaymentModeId");
            return Convert.ToInt32(ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "PaymentModeId", paymentModeId } }).FirstOrDefault());
        }

        /// <summary>
        /// update clearance date against receipt id
        /// </summary>
        /// <param name="receiptId">The receipt id.</param>
        /// <param name="processingDate">The processing date.</param>
        /// <param name="loginId">The login id.</param>
        /// <returns></returns>
        public static bool UpdateReceiptClearanceDate(int? receiptId, DateTime? processingDate, string loginId)
        {
            try
            {
                var sql = string.Concat("UPDATE RCPT SET CLRC_DTE = @ProcessingDate, UPDT_BY = @UPDT_BY, UPDT_DTE = @UPDT_DTE WHERE RCPT_ID = @RCPT_ID");
                ExecuteQuery<bool>(sql, new SerializableDictionary<string, object> { { "ProcessingDate", processingDate }, { "UPDT_BY", loginId }, { "UPDT_DTE", SystemDateTime.UtcNow }, { "RCPT_ID", receiptId } }).FirstOrDefault();
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return true;
        }

        /// <summary>
        /// checks if the specified contract exists with park separate config
        /// </summary>
        /// <param name="contId">The contract id.</param>
        /// <returns></returns>
        public static int CheckParkSeparateConfig(int? contId)
        {
            try
            {
                var sql = string.Concat("SELECT COUNT(*) FROM CONT_RCPT_ASOC WHERE CONT_ID = @ContId AND STS_KEY IN (", AppendCharAndJoin(ALLOCATED_UNALLOCATED), ") AND UN_ALCT_AMNT > 0");
                return Convert.ToInt32(ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } }).FirstOrDefault());
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// checks if the specified contract exists with security deposite config
        /// </summary>
        /// <param name="contId">The contract id.</param>
        /// <returns></returns>
        public static int CheckSecurityDepositConfig(int? contId)
        {
            var sql = string.Concat("SELECT COUNT(*) FROM TMPL_CONT_ATCH WHERE CONT_ID = @ContId AND SECR_DPST_MTHD_TYPE_ID = ", Convert.ToInt32(SecurityDepositMethodType.AdjustmentinRentalsBalloonRV.GetKey()));
            return Convert.ToInt32(ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } }).FirstOrDefault());
        }

        /// <summary>
        /// gets borrower id associated with contract
        /// </summary>
        /// <param name="contId">The contract id.</param>
        /// <returns></returns>
        public static int GetActiveBorrower(int? contId)
        {
            var sql = string.Concat("SELECT BUSS_PTNR_ID FROM CONT_BP_ASOC WHERE CONT_ID = @ContId AND BP_ROLE_ID = 3 AND ACT_IND = 1");
            return Convert.ToInt32(ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } }).FirstOrDefault());
        }

        /// <summary>
        /// gets asset ids associated with contract
        /// </summary>
        /// <param name="contId">The contract id.</param>
        /// <returns></returns>
        public static List<int> GetContractAssets(int? contId)
        {
            var sql = string.Concat("SELECT ASET_ID FROM CONT_ASET WHERE CONT_ID = @ContId");
            return ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } }).ToList();
        }

        /// <summary>
        /// Reads payment Mode Id
        /// </summary>
        /// <param name="paymentMode">Payment Mode Name</param>
        /// <returns></returns>
        public static int ReadPaymentModeId(string paymentMode)
        {
            int paymentModeId = 0;
            var contextExt = EntityContextExt.Create<NS.Models.Setups.PaymentModeCode>();
            if (contextExt != null)
            {
                contextExt.Read(p => p.NME == paymentMode, 1);
                if (ReceiptingRepository.HasData(contextExt.Entity))
                {
                    paymentModeId = contextExt.Entity.FirstOrDefault().PYMT_MODE_ID;
                }
            }
            return paymentModeId;
        }

        #endregion

        #region Lock Handling

        /// <summary>
        /// Checks the state of the lock.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static bool CheckLock(Type type, object value, string loginId)
        {
            try
            {
                Dictionary<string, string> tableInfo = GetTableInfoByModel(type);
                if (HasData(tableInfo))
                {
                    var sql = string.Concat(" DECLARE @P_FLAG BIT = 0; UPDATE ", tableInfo.First().Key, " SET LOCK_IND = 0 ", ",", " UPDT_BY = ", AppendChar(loginId, "'"), ",", " UPDT_DTE = ", AppendChar(SystemDateTime.UtcNow.ToString(), "'"), " WHERE LOCK_IND IS NULL AND ", tableInfo.First().Value,
                        " IN ( ", value, " ); SET @P_FLAG = (SELECT TOP 1 LOCK_IND FROM ", tableInfo.First().Key, " WHERE ", tableInfo.First().Value, " IN ( ", value,
                        " ) AND (LOCK_IND = 0 OR LOCK_IND IS NULL)); IF(@P_FLAG = 0) BEGIN UPDATE ", tableInfo.First().Key, " SET LOCK_IND = 1 ", ",", " UPDT_BY = ", AppendChar(loginId, "'"), ",", " UPDT_DTE = ", AppendChar(SystemDateTime.UtcNow.ToString(), "'"), " WHERE ", tableInfo.First().Value, " IN (", value, " ) END; IF @P_FLAG IS NULL SELECT 1 ELSE SELECT @P_FLAG ; ");
                    return ExecuteQuery<bool>(sql).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return true;
        }

        /// <summary>
        /// Sets the lock status.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="value">The value.</param>
        /// <param name="flag">if set to <c>true</c> [flag].</param>
        /// <returns></returns>
        public static bool SetLockStatus(Type type, object value, bool flag, string loginId)
        {
            try
            {
                Dictionary<string, string> tableInfo = GetTableInfoByModel(type);
                if (HasData(tableInfo))
                {
                    var sql = string.Concat("UPDATE ", tableInfo.First().Key, " SET LOCK_IND = ", flag ? 1 : 0, ",", " UPDT_BY = ", AppendChar(loginId, "'"), ",", " UPDT_DTE = ", AppendChar(SystemDateTime.UtcNow.ToString(), "'"), " WHERE ", tableInfo.First().Value, " IN (", value, ")");
                    // ReSharper disable once ReturnValueOfPureMethodIsNotUsed
                    ExecuteQuery<bool>(sql).Any(p => p);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return false;
        }

        #endregion

        #region Misc. Register

        /// <summary>
        /// Persists the refund to customer.
        /// </summary>
        /// <param name="rcpt">The RCPT.</param>
        /// <param name="pybl">The pybl.</param>
        /// <returns></returns>
        public static bool PersistRefundToCustomer(Receipt rcpt, Payable pybl, ReceiptMiscDetail receiptMiscDetail)
        {
            try
            {
                var receiptContext = EntityContextExt.Create(new List<Receipt>() { rcpt });
                IUnitOfWork uow = receiptContext.InitiateUnitOfWork();
                receiptContext.Persist();
                var receiptMiscDetailCtxt = EntityContextExt.Create(new List<ReceiptMiscDetail>() { receiptMiscDetail }).UsingUnitOfWork(uow);
                receiptMiscDetailCtxt.Persist();
                pybl.RCPT_ID = rcpt.RCPT_ID;
                var payableContext = EntityContextExt.Create(new List<Payable>() { pybl }).UsingUnitOfWork(uow);
                payableContext.Persist();
                uow.Save();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return false;
            }
        }

        /// <summary>
        /// Persists the Income
        /// </summary>
        /// <param name="rcpt">The RCPT.</param>
        /// <returns></returns>
        public static bool PersistReceipt(Receipt rcpt)
        {
            try
            {
                if (rcpt != null)
                {
                    var receiptContext = EntityContextExt.Create(new List<Receipt>() { rcpt });
                    receiptContext.Persist();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return false;
            }
        }

        #region One Time Payment

        /// <summary>
        /// Persists the one time payment.
        /// </summary>
        /// <param name="oneTimePayment">The one time payment.</param>
        /// <returns></returns>
        /// <remarks>
        /// <para> [ZA] 21/12/2017 1.0 Documentation.</para>
        /// <para> [ZA] 21/12/2017 1.1 Update OTP in receipt.</para>
        /// </remarks>
        public static OneTimePayment PersistOneTimePayment(OneTimePayment oneTimePayment, string loginId)
        {
            try
            {
                var contextExt = EntityContextExt.Create(new[] { oneTimePayment });
                contextExt.Persist();

                string BpOTPmnt = BPOneTimePayment.OneTimePayment.GetKey();
                UpdateReceiptOneTimePayment(typeof(Receipt), string.Join(",", oneTimePayment.RCPT_ID), BpOTPmnt, loginId);

                return contextExt.Entity[0];

            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// Reads the one time payment.
        /// </summary>
        /// <param name="receiptId">The receipt identifier.</param>
        /// <returns></returns>
        public static OneTimePayment ReadOneTimePayment(int? receiptId)
        {
            try
            {
                Expression<Func<OneTimePayment, bool>> readPredicate = null;
                if (receiptId > 0)
                {
                    readPredicate = p => p.RCPT_ID == receiptId;
                }
                if (readPredicate != null)
                {
                    var contextExt = EntityContextExt.Create<OneTimePayment>();
                    if (contextExt != null)
                    {
                        contextExt.Read(readPredicate);
                        if (contextExt.Entity.Count > 0)
                            return contextExt.Entity.First();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }

            return null;
        }

        /// <summary>
        /// Sets the Bp/one time payment.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="value">The value.</param>
        /// <param name="Otpmnt">if set to <c>Bp/OneTimePayment</c> [Otpmnt].</param>
        /// <returns></returns>
        ///  /// <remarks>
        /// <para> [ZA] 21/12/2017 1.0 Documentation.</para>
        /// </remarks>
        public static bool UpdateReceiptOneTimePayment(Type type, object value, string Otpmnt, string loginId)
        {
            try
            {
                Dictionary<string, string> tableInfo = GetTableInfoByModel(type);
                if (HasData(tableInfo))
                {
                    //var sql = string.Concat("UPDATE ", tableInfo.First().Key, " SET BP_ONE_TIME_PYMT = ", "'", Otpmnt, "'", ",", " UPDT_BY = ", AppendChar(loginId, "'"), ",", " UPDT_DTE = ", AppendChar(SystemDateTime.UtcNow.ToString(), "'"), " WHERE ", tableInfo.First().Value, " =", value);
                    var sql = string.Concat("UPDATE ", tableInfo.First().Key, " SET BP_ONE_TIME_PYMT = @BP_ONE_TIME_PYMT, UPDT_BY = @UPDT_BY, UPDT_DTE = @UPDT_DTE WHERE ", tableInfo.First().Value, " = ", "@Value");
                    // ReSharper disable once ReturnValueOfPureMethodIsNotUsed
                    ExecuteQuery<bool>(sql, new SerializableDictionary<string, object> { { "BP_ONE_TIME_PYMT", Otpmnt }, { "UPDT_BY", loginId }, { "UPDT_DTE", SystemDateTime.UtcNow }, { "Value", value } }).Any(p => p);
                    if (Otpmnt == BPOneTimePayment.BusinessPartner.GetKey())
                    {
                        DeleteOneTimePayment(Convert.ToInt32(value));
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return false;
        }
        /// <summary>
        /// Sets the Bp/one time payment.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="value">The value.</param>
        /// <param name="Otpmnt">if set to <c>Bp/OneTimePayment</c> [Otpmnt].</param>
        /// <returns></returns>
        public static bool UpdateBpOneTimePayment(Type type, object value, string Otpmnt, string loginId)
        {
            try
            {
                Dictionary<string, string> tableInfo = GetTableInfoByModel(type);
                if (HasData(tableInfo))
                {
                    var sql = string.Concat("UPDATE ", tableInfo.First().Key, " SET BP_ONE_TIME_PYMT = @BP_ONE_TIME_PYMT, UPDT_BY = @UPDT_BY, UPDT_DTE = @UPDT_DTE WHERE ", tableInfo.First().Value, " = ", "@Value");
                    ExecuteQuery<bool>(sql, new SerializableDictionary<string, object> { { "BP_ONE_TIME_PYMT", Otpmnt }, { "UPDT_BY", loginId }, { "UPDT_DTE", SystemDateTime.UtcNow }, { "Value", value } }).Any(p => p);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return false;
        }
        /// <summary>
        /// Remove one time payment.
        /// </summary>
        /// <param name="ReceiptId">The type.</param>
        /// <returns></returns>
        /// <remarks>
        /// <para> [ZA] 21/12/2017 1.0 new method DeleteOneTimePayment Added.</para>
        /// </remarks>
        public static bool DeleteOneTimePayment(int ReceiptId)
        {
            try
            {
                if (ReceiptId > 0)
                {
                    var sql = string.Concat("DELETE FROM RCPT_ONE_TIME_PYMT WHERE RCPT_ID= @ReceiptId");
                    ExecuteQuery<bool>(sql, new SerializableDictionary<string, object>() { { "ReceiptId", ReceiptId } }).Any(p => p);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return false;
        }
        #endregion

        public static bool PersistPaybleDisbursement(Disbursements disb)
        {
            try
            {
                var disbContext = EntityContextExt.Create(new List<Disbursements>() { disb });
                //IUnitOfWork uow = disbContext.InitiateUnitOfWork();
                disbContext.Persist();
                return true;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return false;
            }
        }
        #endregion

        #region Contract

        public static int GetPaymendModeByContract(int? contId)
        {
            if (contId > 0)
            {
                var sql = string.Concat("Select PYMT_MODE_ID From Cont where CONT_ID = @ContId");
                var result = ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } });
                if (HasData(result) && HasValue(result.FirstOrDefault()))
                {
                    return result.FirstOrDefault();
                }
            }
            return Convert.ToInt32(PaymentModeType.Cash.GetKey());
        }

        public static int GetCurrencyByContract(int? contId)
        {
            if (contId > 0)
            {
                var sql = string.Concat("Select CRCY_ID From Cont where CONT_ID = @ContId");
                var result = ExecuteQuery<int>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } });
                if (HasData(result) && HasValue(result.FirstOrDefault()))
                {
                    return result.FirstOrDefault();
                }
            }
            return 1;
        }

        public static string GetFinanceType(int contId, int? assetId)
        {
            if (contId > 0 && assetId > 0)
            {
                var sql = string.Concat("Select FINC_TYPE_KEY From CONT_ASET_FNCL_DET where CONT_ID = @ContId and ASET_ID = @AssetId");
                var result = ExecuteQuery<string>(sql, new SerializableDictionary<string, object>() { { "ContId", contId }, { "AssetId", assetId } });
                if (HasData(result))
                {
                    return result.FirstOrDefault();
                }
            }
            return null;
        }

        public static string GetFinanceTypeByContractId(int contId)
        {
            if (contId > 0)
            {
                var sql = string.Concat("Select FINC_TYPE_KEY From CONT_ASET_FNCL_DET where CONT_ID = @ContId");
                var result = ExecuteQuery<string>(sql, new SerializableDictionary<string, object>() { { "ContId", contId } });
                if (HasData(result))
                {
                    return result.FirstOrDefault();
                }
            }
            return null;
        }

        public static List<int?> GetBorrowerContracts(int? bpId)
        {
            var bpAsocCntxt = EntityContextExt.Create<ContractBPAssociation>();
            bpAsocCntxt.Read(p => p.BUSS_PTNR_ID == bpId && p.BP_ROLE_ID == 3 && p.ACT_IND == true);
            List<int?> contIds = new List<int?>();
            if (HasData(bpAsocCntxt.Entity))
            {
                contIds = bpAsocCntxt.Entity.Select(p => p.CONT_ID).ToList();
            }
            return contIds;
        }

        #endregion

        #region Template

        /// <summary>
        /// This method will pick the Attached Template Id based on Template key, List of contract Ids and Template Priority
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private static void GetTemplateByContractIDs(ReceiptParam param)
        {
            try
            {
                var contextExt = EntityContextExt.Create<ContractTemplate>();
                if (contextExt != null)
                {
                    if (HasData(param?.ContractIds))
                    {
                        if (param != null)
                        {
                            string contractList = string.Join(",", param.ContractIds);
                            contextExt.Read(contractList, param.SettlementParam.TemplateType.GetKey());
                        }
                    }
                    if (param?.SettlementParam != null)
                        param.SettlementParam.ContractTemplateIds = contextExt.Entity;
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }

        /// <summary>
        /// Gets the template level.
        /// </summary>
        /// <param name="templateType">Type of the template.</param>
        /// <returns></returns>
        private static TemplateLevel GetTemplateLevel(TemplateTypes templateType)
        {
            try
            {
                if (templateType == TemplateTypes.FinancialParameterTemplate)
                {
                    return TemplateLevel.FinancialProduct;
                }
                else if (templateType == TemplateTypes.Settlement)
                {
                    return TemplateLevel.FinancialProduct;
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return TemplateLevel.None;
        }

        /// <summary>
        /// Reads the templates.
        /// </summary>
        /// <param name="param">The parameter.</param>
        public static void ReadTemplates(ReceiptParam param)
        {
            try
            {
                if (IsPriorityTemplateRequired(param))
                {
                    // Pick & Populate FP Settlement Priority/ Template, It will be the part of Pre Bulk settlement
                    PopulatePriorityTemplate(param);
                }
                if (IsOverpaymentTemplateRequired(param))
                {
                    // Pick & Populate FP OverPayment details, It will be the part of Pre Bulk settlement
                    GetOverPaymentConfig(param);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }

        #endregion

        #region Settlement Priority

        /// <summary>
        /// This method will pick the Settlement Template based on list of Attached Ids and Receipt Type Id
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private static void GetSettlementPriorityTemplate(ReceiptParam param)
        {
            try
            {
                if (param.SettlementParam != null)
                {
                    List<Tuple<int, bool>> receiptTypes = new List<Tuple<int, bool>>();
                    receiptTypes = GetReceiptTypes(param);
                    if (param.SettlementParam.PriorityTemplates == null) param.SettlementParam.PriorityTemplates = new List<ContractSettlementTemplate>();
                    if (param.SettlementParam.ContractTemplateIds != null)
                    {
                        param.SettlementParam.TemplateIds = param.SettlementParam.ContractTemplateIds.Select(p => p.ATTACHED_TEMPLATE_ID).ToList();
                        if (HasData(param.SettlementParam.TemplateIds))
                        {
                            string ids = string.Join(",", param.SettlementParam.TemplateIds);
                            if (receiptTypes.Exists(p => p.Item1 == Convert.ToInt32(ReceiptType.ShortfallReceipt.GetKey())))
                            {
                                Tuple<int, bool> receiptType = new Tuple<int, bool>(Convert.ToInt32(ReceiptType.WriteOffReceipt.GetKey()), false);
                                receiptTypes.Add(receiptType);
                            }
                            if (receiptTypes.Exists(p => p.Item1 == Convert.ToInt32(ReceiptType.PaymentWaiver.GetKey())))
                            {
                                Tuple<int, bool> receiptType = new Tuple<int, bool>(Convert.ToInt32(ReceiptType.NormalReceipt.GetKey()), false);
                                receiptTypes.Add(receiptType);
                            }
                            if (receiptTypes != null)
                            {
                                foreach (var receiptType in receiptTypes)
                                {
                                    var contextExt = EntityContextExt.Create<ContractSettlementTemplate>();
                                    contextExt.Read(ids, receiptType.Item1);
                                    param.SettlementParam.PriorityTemplates.AddRange(contextExt.Entity);
                                }
                            }
                        }
                    }
                    if (receiptTypes.Exists(p => p.Item1 == Convert.ToInt32(ReceiptType.RestructuringReceipt.GetKey())))
                    {
                        var contextExt = EntityContextExt.Create<ReceiptAmountComponentDetail>();
                        contextExt.Read(p => p.RCPT_TYPE_ID == 1 && p.RCPT_SETL_BSIS_ID == 1);
                        foreach (var data in contextExt.Entity)
                        {
                            ContractSettlementTemplate normalTemplate = new ContractSettlementTemplate();
                            normalTemplate.AMNT_CMPT_PRTY = 1;
                            normalTemplate.AMNT_CMPT_TYPE_KEY = data.AMNT_CMPT_TYPE_KEY;
                            normalTemplate.RCPT_SETL_BSIS_ID = data.RCPT_SETL_BSIS_ID;
                            normalTemplate.RCPT_TYPE_ID = Convert.ToInt32(ReceiptType.RestructuringReceipt.GetKey());
                            normalTemplate.SETL_MTHD_TYPE_KEY = SettlementMethodType.ComponentBased.GetKey();
                            normalTemplate.SUB_AMNT_CMPT_PRTY = 1;
                            normalTemplate.SUB_AMNT_CMPT_TYPE_KEY = data.SUB_AMNT_CMPT_TYPE_KEY;
                            param.SettlementParam.PriorityTemplates.Add(normalTemplate);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }

        /// <summary>
        /// Used to populate the settlement priority details
        /// </summary>
        private static void PopulatePriorityTemplate(ReceiptParam param)
        {
            try
            {
                if (GetTemplateLevel(TemplateTypes.Settlement) == TemplateLevel.FinancialProduct)
                {
                    PopulatePriorityTemplateByFp(param);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }

        /// <summary>
        /// Populates the priority template by fp.
        /// </summary>
        /// <param name="param">The parameter.</param>
        public static void PopulatePriorityTemplateByFp(ReceiptParam param)
        {
            try
            {
                param.SettlementParam.TemplateType = TemplateTypes.Settlement;
                GetTemplateByContractIDs(param);
                GetSettlementPriorityTemplate(param);
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }

        #endregion

        #region Over Payment Configuration 

        /// <summary>
        /// This method will get over payment configuration based on list of Attached Ids 
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private static void GetOverPaymentConfigurations(ReceiptParam param)
        {
            try
            {
                if (HasData(param?.ContractIds))
                {
                    var contextExt = EntityContextExt.Create<ContractOverPayment>();
                    if (contextExt != null)
                    {
                        string contractIds = string.Join(", ", param.ContractIds);
                        contextExt.Read(contractIds);
                        param.SettlementParam.ContractOverPaymentDetail = contextExt.Entity;
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }

        /// <summary>
        /// Prepares the over payment configuration.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <param name="overPaymentType">Type of the over payment.</param>
        public static void PrepareOverPaymentConfig(ReceiptParam param, OverPaymentType overPaymentType)
        {
            if (HasData(param.ContractIds))
            {
                param.SettlementParam.ContractOverPaymentDetail = new List<ContractOverPayment>();
                foreach (var id in param.ContractIds)
                {
                    param.SettlementParam.ContractOverPaymentDetail.Add(new ContractOverPayment()
                    {
                        CONT_ID = id,
                        OVER_PYMT_TYPE_KEY = overPaymentType.GetKey()
                    });
                }
            }
        }

        /// <summary>
        /// Used to populate the over payment configuration
        /// </summary>
        private static void GetOverPaymentConfig(ReceiptParam param)
        {
            try
            {
                if (GetTemplateLevel(TemplateTypes.FinancialParameterTemplate) == TemplateLevel.FinancialProduct)
                {
                    PopulateOverPaymentConfigByFp(param);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }

        /// <summary>
        /// Populates the over payment configuration by fp.
        /// </summary>
        /// <param name="param">The parameter.</param>
        private static void PopulateOverPaymentConfigByFp(ReceiptParam param)
        {
            try
            {
                GetOverPaymentConfigurations(param);
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
        }

        #endregion

        //Business Logic
        
        #region Receipts

        /// <summary>
        /// Reads the receipts.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static List<Receipt> ReadReceipts(ReceiptParam param)
        {
            try
            {
                ReceiptSearchParam searchParam = null;
                List<int> receiptIds;
                if (param.IsBulk)
                {
                    receiptIds = param.ReceiptCriteria.Select(p => p.ReceiptId).ToList();
                    searchParam = new ReceiptSearchParam() { Ids = receiptIds, Specification = ReceiptSearchSpecification.ReadReceiptsByReceiptIds };
                }
                else if (param.IsPreactivation)
                {
                    if (HasData(param.ContractIds))
                    {
                        searchParam = new ReceiptSearchParam() { ContId = param.ContractIds.First(), ReceiptType = param.ReceiptType, Specification = ReceiptSearchSpecification.PreActivationReceipt };
                    }
                }
                else if (param.DepositType == DepositTypes.ParkSeparate)
                {
                    if (HasData(param.ContractIds))
                    {
                        searchParam = new ReceiptSearchParam() { ContId = param.ContractIds.First(), ReceiptType = param.ReceiptType, Specification = ReceiptSearchSpecification.ReadParkSeparateReceiptByContractId };
                    }
                }
                if (searchParam != null)
                {
                    return ReadReceipts(searchParam);
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// Reads the receipts.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static List<Receipt> ReadReceipts(ReceiptSearchParam param)
        {
            Expression<Func<Receipt, bool>> readPredicate = null;
            Func<Type, string, string, string, bool> withEntityScopePredicate = null;
            PrepareReceiptPredicate(param, ref readPredicate, ref withEntityScopePredicate);
            if (readPredicate != null)
            {
                var contextExt = EntityContextExt.Create<Receipt>();
                if (contextExt != null)
                {
                    if (withEntityScopePredicate != null)
                    {
                        contextExt.WithEntityScope(withEntityScopePredicate);
                    }
                    contextExt.Read(readPredicate);
                    if (HasData(contextExt.Entity))
                    {
                        foreach (var item in contextExt.Entity)
                        {
                            UpdateAutoRecieptPaymentMode(item);
                        }
                        return OrderByReceipts(contextExt.Entity, true);
                    }
                }
            }
            return null;
        }

        private static void PrepareReceiptPredicate(ReceiptSearchParam param, ref Expression<Func<Receipt, bool>> readPredicate, ref Func<Type, string, string, string, bool> withEntityScopePredicate, bool isPaging = false)
        {
            string draftStatus = StatusCode.Draft.GetKey();
            if (param.Specification == ReceiptSearchSpecification.ReadMiscReceipts && param.ReceiptId > 0)
            {
                var miscReceiptStatuses = ALLOCATED_UNALLOCATED.Split(',').ToList();
                readPredicate = p => p.RCPT_ID == param.ReceiptId && p.MISC_AMNT > 0 && p.BRNC_ID == param.BrnchId && miscReceiptStatuses.Contains(p.STS_KEY);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadMiscReceipts && param.BpId == 0)
            {
                var miscReceiptStatuses = ALLOCATED_UNALLOCATED.Split(',').ToList();
                readPredicate = p => p.MISC_AMNT > 0 && p.BRNC_ID == param.BrnchId && miscReceiptStatuses.Contains(p.STS_KEY);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadUnAllocatedReceipts && param.BpId == 0 && param.ReceiptId == 0)
            {
                var unallocatedReceiptStatuses = ALLOCATED_UNALLOCATED.Split(',').ToList();
                readPredicate = p => p.UN_ALCT_AMNT > 0  && unallocatedReceiptStatuses.Contains(p.STS_KEY);
                withEntityScopePredicate = (childType, parent, aggregateId, p) => childType != typeof(ReceiptDetail);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadUnAllocatedReceipts && param.BpId > 0)
            {
                var unallocatedReceiptStatuses = ALLOCATED_UNALLOCATED.Split(',').ToList();
                readPredicate = p => p.UN_ALCT_AMNT > 0 && p.BUSS_PTNR_ID == param.BpId && p.BRNC_ID == param.BrnchId && unallocatedReceiptStatuses.Contains(p.STS_KEY);
                withEntityScopePredicate = (childType, parent, aggregateId, p) => childType != typeof(ReceiptDetail);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadUnAllocatedReceipts && param.ReceiptId > 0)
            {
                var unallocatedReceiptStatuses = ALLOCATED_UNALLOCATED.Split(',').ToList();
                readPredicate = p => p.RCPT_ID == param.ReceiptId && p.UN_ALCT_AMNT > 0 && p.BRNC_ID == param.BrnchId && unallocatedReceiptStatuses.Contains(p.STS_KEY);
                withEntityScopePredicate = (childType, parent, aggregateId, p) => childType != typeof(ReceiptDetail);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadMiscReceipts && param.BpId > 0 && param.BpRoleId > 0)
            {
                readPredicate = p => p.MISC_AMNT > 0 && p.BUSS_PTNR_ID == param.BpId && p.BP_ROLE_ID == param.BpRoleId && p.BRNC_ID == param.BrnchId && (p.STS_KEY == "Allocated" || p.STS_KEY == "UnAllocated");
                withEntityScopePredicate = (childType, parent, aggregateId, p) => childType != typeof(ReceiptDetail);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadMiscReceipts && param.BpId > 0)
            {
                readPredicate = p => p.MISC_AMNT > 0 && p.BUSS_PTNR_ID == param.BpId && p.BRNC_ID == param.BrnchId && (p.STS_KEY == "Allocated" || p.STS_KEY == "UnAllocated");
                withEntityScopePredicate = (childType, parent, aggregateId, p) => childType != typeof(ReceiptDetail);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadReceiptsByReceiptIds)
            {
                readPredicate = p => param.Ids.Contains(p.RCPT_ID);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadReceiptsByTaskId)
            {
                readPredicate = p => p.TASK_QUEU_ID == param.TaskId;
            }
            else if (param.Specification == ReceiptSearchSpecification.ReceiptSearch)
            {
                if (param.ReceiptSearchType == SearchTypeEnum.ReceiptBPSearch || param.ReceiptSearchType == SearchTypeEnum.ReceiptBPSearchByRole)
                {
                    readPredicate = p => p.BUSS_PTNR_ID == param.BpId && p.BRNC_ID == param.BrnchId;
                }
                else if (param.ReceiptSearchType == SearchTypeEnum.ReceiptContractSearch)
                {
                    List<Receipt> receiptList = Receipt.ReadReceiptByContractId(param.ContId);
                    readPredicate = PrepareReceiptPredicate(receiptList);
                }
                else if (param.ReceiptSearchType == SearchTypeEnum.ReceiptIdSearch)
                {
                    readPredicate = p => p.RCPT_ID == param.ReceiptId;
                }
            }
            else if (param.Specification == ReceiptSearchSpecification.ReceiptSearchForCancellation)
            {
                string cancelStatus = StatusCode.Cancelled.GetKey();
                if (param.ReceiptSearchType == SearchTypeEnum.ReceiptBPSearch || param.ReceiptSearchType == SearchTypeEnum.ReceiptBPSearchByRole)
                {
                    readPredicate = p => p.BUSS_PTNR_ID == param.BpId && p.BRNC_ID == param.BrnchId && (p.STS_KEY != cancelStatus && p.STS_KEY != draftStatus);
                }
                else if (param.ReceiptSearchType == SearchTypeEnum.ReceiptContractSearch)
                {
                    List<Receipt> receiptList = Receipt.ReadReceiptByContractId(param.ContId);
                    readPredicate = PrepareReceiptPredicate(receiptList.Where(p => p.STS_KEY != cancelStatus && p.STS_KEY != draftStatus).ToList());
                }
                else if (param.ReceiptSearchType == SearchTypeEnum.ReceiptIdSearch)
                {
                    readPredicate = p => p.RCPT_ID == param.ReceiptId && (p.STS_KEY != cancelStatus && p.STS_KEY != draftStatus);
                }
            }
            else if (param.Specification == ReceiptSearchSpecification.ReceiptSearchForDeallocation)
            {
                string cancelStatus = StatusCode.Cancelled.GetKey();
                string deAllocateStatus = StatusCode.UnAllocated.GetKey();

                var statusList = new List<string> { StatusCode.Cancelled.GetKey(), StatusCode.UnAllocated.GetKey(), StatusCode.Draft.GetKey() };
                if (param.ReceiptSearchType == SearchTypeEnum.ReceiptBPSearch || param.ReceiptSearchType == SearchTypeEnum.ReceiptBPSearchByRole)
                {
                    readPredicate = p => p.BUSS_PTNR_ID == param.BpId && p.BRNC_ID == param.BrnchId && (p.STS_KEY != cancelStatus && (p.STS_KEY != deAllocateStatus || p.UN_ALCT_AMNT > 0)  && p.STS_KEY != draftStatus);
                }
                else if (param.ReceiptSearchType == SearchTypeEnum.ReceiptContractSearch)
                {
                    List<Receipt> receiptList = Receipt.ReadReceiptByContIdForDeallocation(param.ContId);
                    readPredicate = PrepareReceiptPredicate(receiptList.Where(p => p.STS_KEY != cancelStatus && (p.STS_KEY != deAllocateStatus || p.UN_ALCT_AMNT > 0) && p.STS_KEY != draftStatus).ToList());
                }
                else if (param.ReceiptSearchType == SearchTypeEnum.ReceiptIdSearch)
                {
                    readPredicate = p => p.RCPT_ID == param.ReceiptId && (p.STS_KEY != cancelStatus && (p.STS_KEY != deAllocateStatus || p.UN_ALCT_AMNT > 0) && p.STS_KEY != draftStatus);
                }
            }
            else if (param.Specification == ReceiptSearchSpecification.PreActivationReceipt)
            {
                List<Receipt> receiptList = Receipt.ReadPreactivationUnAllocatedReceipt(param.ContId, ConvertToInt(param.ReceiptType.GetKey()));
                readPredicate = PrepareReceiptPredicate(receiptList);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadFutureReceiptsByContractIds)
            {
                List<Receipt> receiptList = new List<Receipt>();
                foreach (var id in param.Ids)
                {
                    var contRcpts = Receipt.ReadReceiptByContractId(id);
                    if (contRcpts != null)
                    {
                        int rcptId = param.RcptContList.Find(p => p.Item2.Exists(q => q == id)).Item1;
                        receiptList.AddRange(contRcpts.Where(p => ALLOCATED_SETTLED.Contains(p.STS_KEY) && p.RCPT_ID > rcptId));
                    }
                }
                if (HasData(receiptList))
                {
                    List<int> receiptIdsList = receiptList.Where(p => !param.Ids2.Contains(p.RCPT_ID)).Select(p => p.RCPT_ID).ToList();
                    readPredicate = p => receiptIdsList.Contains(p.RCPT_ID);
                }
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadETReceiptUnAllocatedAmount)
            {
                List<Receipt> receiptList = Receipt.ReadETUnallocatedReceipts(param.ContId, param.EtQuotId);
                readPredicate = PrepareReceiptPredicate(receiptList);
            }

            else if (param.Specification == ReceiptSearchSpecification.ReadParkSeparateReceiptByContractId)
            {
                List<Receipt> receiptList = Receipt.ReadParkSeparatelyReceiptByContId(param.ContId);
                readPredicate = PrepareReceiptPredicate(receiptList);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadUnAllocatedReceiptsByContId)
            {
                List<Receipt> receiptList = Receipt.ReadUnAllocatedReceiptByContId(param.ContId);
                readPredicate = PrepareReceiptPredicate(receiptList);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadETUnAllocatedAllocatedAndSettledReceipts)
            {
                List<Receipt> receiptList = Receipt.ReadETUnAlloctaedAllocatedAndSettledReceipts(param.EtQuotId, param.ContId).Where(x => x.RCPT_ID != param.ReceiptId).ToList();
                readPredicate = PrepareReceiptPredicate(receiptList);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadETUnAllocatedAllocatedAndSettledReceiptByContId)
            {
                List<Receipt> receiptList = Receipt.ReadETUnAllocatedAllocatedAndSettledReceiptByContId(param.ContId);
                readPredicate = PrepareReceiptPredicate(receiptList);
            }
            else if (param.Specification == ReceiptSearchSpecification.ReadOTPUnAllocatedAllocatedAndSettledReceipt)
            {
                List<Receipt> receiptList = Receipt.ReadOTPUnAllocatedAllocatedAndSettledReceipt(param.ContId,param.ReqtId);
                readPredicate = PrepareReceiptPredicate(receiptList);
            }
        }

        /// <summary>
        /// Reads the receipt page.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static PagedData<Receipt> ReadReceiptPage(ReceiptSearchParam param)
        {
            ResponseObject<PagedData<Receipt>> response = new ResponseObject<PagedData<Receipt>>
            {
                Message = new MessageInfo()
            };
            var countContext = DbController.Create();
            ConditionComposer<Receipt> conditionComposer = new ConditionComposer<Receipt>();
            Expression<Func<Receipt, bool>> readPredicate = null;
            Func<Type, string, string, string, bool> withEntityScopePredicate = null;
            PrepareReceiptPredicate(param, ref readPredicate, ref withEntityScopePredicate, true);
            conditionComposer.Where(readPredicate);
            var where = conditionComposer.GenerateWhereClause();
            string whereClause = where.Item1;
            response.ResultSet = new PagedData<Receipt>();
            if (!string.IsNullOrEmpty(whereClause))
                response.ResultSet.TotalRecords = countContext.Count<Receipt>(whereClause, @where.Item2);
            if (readPredicate != null)
            {
                var contextExt = EntityContextExt.Create<Receipt>(commandTimeOut: 600);
                if (contextExt != null)
                {
                    // ReSharper disable once ConditionIsAlwaysTrueOrFalse
                    if (withEntityScopePredicate != null)
                    {
                        contextExt.WithEntityScope(withEntityScopePredicate);
                    }
                    contextExt.ReadPage(readPredicate, param.PageSize, param.SkipRecords, param.OrderByClause);
                    if (HasData(contextExt.Entity))
                    {
                        //receipt Id collection from Receipt Collection
                        var ReceiptIdlst = new List<int?>();
                        foreach (var item in contextExt.Entity)
                        {
                            UpdateAutoRecieptPaymentMode(item);
                            ReceiptIdlst.Add(item.RCPT_ID);
                        }
                        if ((param.Specification == ReceiptSearchSpecification.ReadMiscReceipts && param.BpId > 0) || param.Specification == ReceiptSearchSpecification.ReadUnAllocatedReceipts)
                        {
                            //do nothing 
                        }
                        else
                        { 
                            //receipt Detail
                            var contextExtRcptDetl = EntityContextExt.Create<ReceiptDetail>();
                            if (contextExtRcptDetl != null)
                            {
                                contextExtRcptDetl.Read(p => ReceiptIdlst.Contains(p.RCPT_ID));
                                //return contextExtRcptDetl.Entity;
                            }
                            if (HasData(contextExtRcptDetl.Entity))
                            {
                                if (contextExt.Entity != null)
                                {
                                    foreach (var rcpt in contextExt.Entity)
                                    {
                                        if (rcpt.ReceiptDetail == null)
                                            rcpt.ReceiptDetail = new List<ReceiptDetail>();
                                        rcpt.ReceiptDetail.AddRange(contextExtRcptDetl.Entity.Where(p => p.RCPT_ID == rcpt.RCPT_ID));
                                    }
                                }
                            }
                        }
                    }
                    response.Message.Type = MessageType.Success;
                    response.ResultSet.Data = contextExt.Entity;
                    response.ResultSet.PageSize = param.PageSize;
                    response.ResultSet.CurrentPageIndex = param.PageIndex;
                }
            }
            return response.ResultSet;
        }

        /// <summary>
        /// Prepares the future receipts.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static SettlementLogTypes PrepareFutureReceipts(ReceiptParam param)
        {
            var contractIds = GetContractList(param, ARMProcessTypes.Deallocate);
            List<Tuple<int, List<int>>> rcptContList = new List<Tuple<int, List<int>>>();
            foreach (var rcpt in param.Receipts)
            {
                List<int> contIds = new List<int>();
                if (rcpt.ReceiptDetail != null)
                {
                    foreach (var rcptDetl in rcpt.ReceiptDetail)
                    {
                        if (rcptDetl.ReceiptContractAssociation != null)
                        {
                            contIds.AddRange(rcptDetl.ReceiptContractAssociation.Select(p => Convert.ToInt32(p.CONT_ID)));
                        }
                    }
                    rcptContList.Add(new Tuple<int, List<int>>(rcpt.RCPT_ID, contIds));
                }
            }
            ReceiptSearchParam searchParam = new ReceiptSearchParam() { Specification = ReceiptSearchSpecification.ReadFutureReceiptsByContractIds, Ids = contractIds, ValueDte = param.Receipts.First().VAL_DTE, Ids2 = param.Receipts.Select(p => p.RCPT_ID).ToList(), RcptContList = rcptContList };
            var receipts = ReadReceipts(searchParam);
            if (HasData(receipts))
            {
                if (ValidationHelper.ValidateReversal(receipts) == SettlementLogTypes.ReceiptCannotBeReversed) return SettlementLogTypes.ReceiptCannotBeReversed;
                param.Receipts.AddRange(receipts);
                param.Receipts = OrderByReceipts(param.Receipts, true);
            }
            return SettlementLogTypes.None;
        }

        /// <summary>
        /// Gets the receipt running number.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="branchId">The branch identifier.</param>
        /// <returns></returns>
        public static string GetReceiptRunningNumber(Context context, int? companyId, int? branchId)
        {
            string runningNumber = string.Empty;
            try
            {
                var req = new RequestObject<DngParam>(context, new DngParam() { FcId = ConvertToInt(companyId), ModuleKey = ModuleTypeCode.RECEIPT.GetKey(), BranchId = ConvertToInt(branchId) });

                using (ProxyClient<IDngService> svc = new ProxyClient<IDngService>(true))
                {
                    var resp = svc.ClientInstance.GenerateDocumentNumber(req);
                    if (resp.Message.Type == MessageType.Success)
                    {
                        runningNumber = resp.ResultSet;
                    }
                }
            }
            catch (Exception ex)
            {
                //Exception wrappedException;
                //ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.UiPolicy, out wrappedException,
                //    context);
                runningNumber = string.Empty;
            }
            return runningNumber;
        }

        /// <summary>
        /// Gets the receipt types.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static List<Tuple<int, bool>> GetReceiptTypes(string stsKey)
        {
            List<Tuple<int, bool>> receiptTypes = new List<Tuple<int, bool>>();
            if (stsKey == StatusCode.Current.GetKey() || stsKey == StatusCode.Overdue.GetKey() || stsKey == StatusCode.Repossessed.GetKey() ||
                stsKey == StatusCode.New.GetKey() || stsKey == StatusCode.PaymentAuthorized.GetKey() || stsKey == StatusCode.Void.GetKey() ||
                stsKey == StatusCode.Draft.GetKey() || stsKey == StatusCode.Complied.GetKey() || stsKey == StatusCode.Suspended.GetKey())
                receiptTypes.Add(new Tuple<int, bool>(ConvertToInt(ReceiptType.NormalReceipt.GetKey()), false));
            else if (stsKey == StatusCode.WriteOff.GetKey())
            {
                receiptTypes.Add(new Tuple<int, bool>(ConvertToInt(ReceiptType.WriteOffReceipt.GetKey()), false));
            }
            else if (stsKey == StatusCode.RedemptionExpired.GetKey()) {
                receiptTypes.Add(new Tuple<int, bool>(ConvertToInt(ReceiptType.SaleProceedReceipt.GetKey()), false));
            }

            return receiptTypes;
        }

        /// <summary>
        /// Gets the receipt types.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static List<Tuple<int, bool>> GetReceiptTypes(ReceiptParam param, ARMProcessTypes ARMProcessTypes = ARMProcessTypes.Posting)
        {
            List<Tuple<int, bool>> receiptTypes = new List<Tuple<int, bool>>();
            if (param != null)
            {
                receiptTypes.Add(new Tuple<int, bool>(ConvertToInt(param.ReceiptType.GetKey()), param.IsPreactivation));
                if (param.Receipts != null)
                {
                    foreach (var rcpt in param.Receipts.Where(p => IsReceiptValidForAction(p, ARMProcessTypes)))
                    {
                        if (rcpt.ReceiptDetail != null)
                        {
                            foreach (var rcptDetl in rcpt.ReceiptDetail.Where(p => IsReceiptValidForAction(p, ARMProcessTypes)))
                            {
                                if (!receiptTypes.Exists(p => p.Item1 == rcptDetl.RCPT_TYPE_ID && p.Item2 == rcptDetl.PRE_ACT_IND))
                                {
                                    receiptTypes.Add(new Tuple<int, bool>(ConvertToInt(rcptDetl.RCPT_TYPE_ID), rcptDetl.PRE_ACT_IND));
                                }
                            }
                        }
                    }
                }
            }
            return receiptTypes;
        }

        /// <summary>
        /// Prepares the receipt predicate.
        /// </summary>
        /// <param name="receiptList">The receipt list.</param>
        /// <returns></returns>
        private static Expression<Func<Receipt, bool>> PrepareReceiptPredicate(List<Receipt> receiptList)
        {
            if (HasData(receiptList))
            {
                List<int> receiptIdsList = receiptList.Select(p => p.RCPT_ID).ToList();
                return p => receiptIdsList.Contains(p.RCPT_ID);
            }
            return null;
        }

        /// <summary>
        /// Append char.
        /// </summary>
        /// <param name="status">The status.</param>
        /// <param name="c">char.</param>
        /// <returns></returns>
        public static string AppendChar(string status, string c)
        {
            return string.Concat(c, status, c);
        }

        /// <summary>
        /// Append char.
        /// </summary>
        /// <param name="list">status list.</param>
        /// <param name="c">char.</param>
        /// <returns></returns>
        private static List<string> AppendChar(List<string> list, string c)
        {
            List<string> list2 = new List<string>();
            list.ForEach(p => list2.Add(string.Concat(c, p, c)));
            return list2;
        }

        public static List<Receipt> OrderByReceipts(List<Receipt> receipts, bool isDescending = false)
        {
            if (isDescending)
            {
                receipts = receipts.OrderByDescending(p => p.RCPT_ID).ToList();
            }
            else
            {
                receipts = receipts.OrderBy(p => p.RCPT_ID).ToList();
            }
            return receipts;
        }

        public static List<Receipt> DistinctReceipts(List<Receipt> receipts)
        {
            receipts = receipts.GroupBy(p => p.RCPT_ID).Select(p => p.First()).ToList();
            return receipts;
        }

        //TODO: need optimization 
        public static bool UpdateReceiptRequestStatus(RequestReceiptParam requestReceiptParam, string loginId)
        {
            try
            {
                if (requestReceiptParam != null)
                {
                    //var sql = string.Concat("UPDATE RCPT SET REQT_STS_KEY = ", AppendChar(requestReceiptParam.StatusKey, "'"), ",", " UPDT_BY = ", AppendChar(loginId, "'"), ",", " UPDT_DTE = ", AppendChar(SystemDateTime.UtcNow.ToString(), "'"), " WHERE TASK_QUEU_ID = ", requestReceiptParam.RequestId);
                    //ExecuteQuery<bool>(sql).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return true;
        }
        public static bool UpdateReceiptRequestId(ReceiptParam _receiptParam, string loginId)
        {
            try
            {
                if (_receiptParam != null)
                {
                    foreach (var rcpt in _receiptParam.Receipts)
                    {
                        var sql = string.Concat("UPDATE RCPT SET TASK_QUEU_ID = @TASK_QUEU_ID, UPDT_BY = @UPDT_BY, UPDT_DTE = @UPDT_DTE WHERE RCPT_ID = @RCPT_ID");
                        ExecuteQuery<bool>(sql, new SerializableDictionary<string, object>() { { "TASK_QUEU_ID", rcpt.TASK_QUEU_ID }, { "UPDT_BY", loginId }, { "UPDT_DTE", SystemDateTime.UtcNow }, { "RCPT_ID", rcpt.RCPT_ID } }).FirstOrDefault();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return true;
        }
        public static bool UpdateReceiptRequestTaskQueueId(ReceiptParam receiptParam, string loginId)
        {
            try
            {
                if (receiptParam != null)
                {
                    foreach (var rcpt in receiptParam.Receipts)
                    {
                        if (rcpt.TASK_QUEU_ID > 0)
                        {
                            var sql = string.Concat("UPDATE RCPT_REQT SET TASK_QUEU_ID = @TASK_QUEU_ID, UPDT_BY = @UPDT_BY, UPDT_DTE = @UPDT_DTE WHERE RCPT_ID = @RCPT_ID");
                            ExecuteQuery<bool>(sql, new SerializableDictionary<string, object> { { "TASK_QUEU_ID", rcpt.TASK_QUEU_ID }, { "UPDT_BY", loginId }, { "UPDT_DTE", SystemDateTime.UtcNow }, { "RCPT_ID", rcpt.RCPT_ID } });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return true;
        }
        public static bool UpdateMiscRegisterRequestId(List<RequestMiscRegisterMain> _MisreceiptParam, string loginId)
        {
            try
            {
                if (_MisreceiptParam != null && _MisreceiptParam.Count > 0)
                {
                    foreach (var item in _MisreceiptParam)
                    {


                        var sql = string.Concat("UPDATE REQT_MISC_REGT_MAIN SET TASK_QUEU_ID = @TASK_QUEU_ID, UPDT_BY = @UPDT_BY, UPDT_DTE = @UPDT_DTE WHERE REQT_MISC_REGT_MAIN_ID = @REQT_MISC_REGT_MAIN_ID");
                        ExecuteQuery<bool>(sql, new SerializableDictionary<string, object> { { "TASK_QUEU_ID", item.TASK_QUEU_ID }, { "UPDT_BY", loginId }, { "UPDT_DTE", SystemDateTime.UtcNow }, { "REQT_MISC_REGT_MAIN_ID", item.REQT_MISC_REGT_MAIN_ID } }).FirstOrDefault();
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return true;
        }

        public static void ReadAllocation(List<ReceiptDetail> rcptDetls)
        {
            if (HasData(rcptDetls))
            {
                foreach (var rcptDetl in rcptDetls)
                {
                    if (HasData(rcptDetl.ReceiptContractAssociation))
                    {
                        foreach (var rcptCont in rcptDetl.ReceiptContractAssociation)
                        {
                            var contextExt = EntityContextExt.Create<ReceiptAllocation>();
                            contextExt.Read(p => p.CONT_RCPT_ASOC_ID == rcptCont.CONT_RCPT_ASOC_ID);
                            rcptCont.ReceiptAllocation = contextExt.Entity;
                        }
                    }
                }
            }
        }

        public static void ReadETReceiptAllocation(List<ReceiptDetail> rcptDetls)
        {
            if (HasData(rcptDetls))
            {
                foreach (var rcptDetl in rcptDetls)
                {
                    if (HasData(rcptDetl.ReceiptContractAssociation))
                    {
                        foreach (var rcptCont in rcptDetl.ReceiptContractAssociation)
                        {
                            rcptCont.ReceiptAllocation = ReceiptAllocation.ReadReceiptAllocationForET(rcptCont.CONT_RCPT_ASOC_ID);
                        }
                    }
                }
            }
        }
        public static void ReadWriteOffReceiptAllocation(List<ReceiptDetail> rcptDetls)
        {
            if (HasData(rcptDetls))
            {
                foreach (var rcptDetl in rcptDetls)
                {
                    if (HasData(rcptDetl.ReceiptContractAssociation))
                    {
                        foreach (var rcptCont in rcptDetl.ReceiptContractAssociation)
                        {
                            rcptCont.ReceiptAllocation = ReceiptAllocation.ReadReceiptAllocationForWOFF(rcptCont.CONT_RCPT_ASOC_ID);
                        }
                    }
                }
            }
        }
        public static void ReadSaleProceedReceiptAllocation(List<ReceiptDetail> rcptDetls)
        {
            if (HasData(rcptDetls))
            {
                foreach (var rcptDetl in rcptDetls)
                {
                    if (HasData(rcptDetl.ReceiptContractAssociation))
                    {
                        foreach (var rcptCont in rcptDetl.ReceiptContractAssociation)
                        {
                            rcptCont.ReceiptAllocation = ReceiptAllocation.ReadReceiptAllocationForSaleProceed(rcptCont.CONT_RCPT_ASOC_ID);
                        }
                    }
                }
            }
        }

        public static void ReadAllocation(List<Receipt> rcpts)
        {
            if (HasData(rcpts))
            {
                foreach (var rcpt in rcpts)
                {
                    ReadAllocation(rcpt.ReceiptDetail);
                }
            }
        }

        /// <summary>
        /// Sets REF_CONT_ID in Receipt
        /// </summary>
        /// <param name="receipt">Receipt.</param>
        /// <param name="contId">Contract Id.</param>
        public static void FillRefContId(Receipt receipt, int contId)
        {
            receipt.REF_CONT_ID = contId;
        }

        #region Update Receipt Status

        public static void UpdateReceiptStatus(ReceiptDetail rcptDetl)
        {
            if (rcptDetl.RCPT_SETL_AMNT == rcptDetl.RCPT_AMNT)
            {
                rcptDetl.STS_KEY = StatusCode.Settled.GetKey();
            }
            else if (rcptDetl.RCPT_SETL_AMNT > 0)
            {
                rcptDetl.STS_KEY = StatusCode.Allocated.GetKey();
            }
            else
            {
                rcptDetl.STS_KEY = StatusCode.UnAllocated.GetKey();
            }
        }

        public static void UpdateReceiptStatus(Receipt rcpt, ARMProcessTypes ARMProcessTypes = ARMProcessTypes.Posting)
        {
            if (rcpt.RCPT_SETL_AMNT == rcpt.RCPT_AMNT && ARMProcessTypes == ARMProcessTypes.Posting)
            {
                rcpt.STS_KEY = StatusCode.Settled.GetKey();                
            }
            else if (rcpt.RCPT_SETL_AMNT > 0)
            {
                rcpt.STS_KEY = StatusCode.Allocated.GetKey();
            }
            else
            {
                rcpt.STS_KEY = StatusCode.UnAllocated.GetKey();
            }
        }

        public static void UpdateReceiptStatus(ReceiptContractAssociation rcptCont)
        {
            if (rcptCont.RCPT_SETL_AMNT == rcptCont.RCPT_AMNT)
            {
                rcptCont.STS_KEY = StatusCode.Settled.GetKey();
            }
            else if (rcptCont.RCPT_SETL_AMNT > 0)
            {
                rcptCont.STS_KEY = StatusCode.Allocated.GetKey();
            }
            else
            {
                rcptCont.STS_KEY = StatusCode.UnAllocated.GetKey();
            }
        }

        #endregion

        #endregion

        #region Validation

        /// <summary>
        /// Determines whether [is working day] [the specified parameter].
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns>
        ///   <c>true</c> if [is working day] [the specified parameter]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsWorkingDay(ReceiptParam param)
        {
            bool isWorkingDay;
            WorkingDayCalcParam workingDayParam = new WorkingDayCalcParam();
            workingDayParam.BranchId = param.BranchId;
            workingDayParam.CompanyId = param.CompanyId;
            workingDayParam.ValueDte = Convert.ToDateTime(param.ValueDte);

            isWorkingDay = CommonHelper.IsWorkingDay(workingDayParam,false);

            return isWorkingDay;
        }

        /// <summary>
        /// Determines whether the specified collection has data.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection">The collection.</param>
        /// <returns>
        ///   <c>true</c> if the specified collection has data; otherwise, <c>false</c>.
        /// </returns>
        public static bool HasData<T>(ICollection<T> collection)
        {
            return collection != null && collection.Count > 0;
        }

        /// <summary>
        /// Determines whether the specified value has value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        ///   <c>true</c> if the specified value has value; otherwise, <c>false</c>.
        /// </returns>
        public static bool HasValue(int? value)
        {
            return value != null && value > 0;
        }

        /// <summary>
        /// Determines whether the specified value has value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        ///   <c>true</c> if the specified value has value; otherwise, <c>false</c>.
        /// </returns>
        public static bool HasValue(decimal? value)
        {
            return value != null && value > 0;
        }

        /// <summary>
        /// Determines whether [is receipt processable] [the specified p].
        /// </summary>
        /// <param name="p">The p.</param>
        /// <returns>
        ///   <c>true</c> if [is receipt processable] [the specified p]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsReceiptProcessable(Receipt p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : DRAFT_ALLOCATED_UNALLOCATED.Contains(p.STS_KEY);
        }

        public static bool IsReceiptValidForAction(Receipt p, ARMProcessTypes action)
        {
            if (action == ARMProcessTypes.Posting) return IsReceiptProcessable(p);
            else if (action == ARMProcessTypes.Deallocate) return IsReceiptDeallocatable(p);
            else if (action == ARMProcessTypes.Cancel) return IsReceiptCancelable(p);
            return false;
        }

        public static bool IsReceiptValidForAction(ReceiptDetail p, ARMProcessTypes action)
        {
            if (action == ARMProcessTypes.Posting) return IsReceiptProcessable(p);
            else if (action == ARMProcessTypes.Deallocate) return IsReceiptDeallocatable(p);
            else if (action == ARMProcessTypes.Cancel) return IsReceiptCancelable(p);
            return false;
        }

        /// <summary>
        /// Determines whether [is receipt processable] [the specified p].
        /// </summary>
        /// <param name="p">The p.</param>
        /// <returns>
        ///   <c>true</c> if [is receipt processable] [the specified p]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsReceiptProcessable(ReceiptDetail p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : DRAFT_ALLOCATED_UNALLOCATED.Contains(p.STS_KEY);
        }

        /// <summary>
        /// Determines whether [is receipt processable] [the specified p].
        /// </summary>
        /// <param name="p">The p.</param>
        /// <returns>
        ///   <c>true</c> if [is receipt processable] [the specified p]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsReceiptProcessable(ReceiptContractAssociation p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : DRAFT_ALLOCATED_UNALLOCATED.Contains(p.STS_KEY);
        }

        /// <summary>
        /// Determines whether [is status for misc RCPT] [the specified p].
        /// </summary>
        /// <param name="p">The p.</param>
        /// <returns>
        ///   <c>true</c> if [is status for misc RCPT] [the specified p]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsStatusForMiscRcpt(Receipt p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : ALLOCATED_UNALLOCATED.Contains(p.STS_KEY);
        }

        /// <summary>
        /// Determines whether [is receipt cancelable] [the specified p].
        /// </summary>
        /// <param name="p">The p.</param>
        /// <returns>
        ///   <c>true</c> if [is receipt cancelable] [the specified p]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsReceiptCancelable(Receipt p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : ALLOCATED_UNALLOCATED_SETTLED.Contains(p.STS_KEY);
        }

        public static bool IsReceiptCancelable(ReceiptDetail p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : ALLOCATED_UNALLOCATED_SETTLED.Contains(p.STS_KEY);
        }

        public static bool IsReceiptCancelable(ReceiptContractAssociation p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : ALLOCATED_UNALLOCATED_SETTLED.Contains(p.STS_KEY);
        }

        public static bool IsReceiptDeallocatable(Receipt p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : ALLOCATED_SETTLED.Contains(p.STS_KEY) || (p.STS_KEY == StatusCode.UnAllocated.GetKey() && p.UN_ALCT_AMNT > 0);
        }

        public static bool IsReceiptDeallocatable(ReceiptDetail p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : ALLOCATED_UNALLOCATED_SETTLED.Contains(p.STS_KEY);
        }

        public static bool IsReceiptDeallocatable(ReceiptContractAssociation p)
        {
            return string.IsNullOrWhiteSpace(p.STS_KEY) ? false : ALLOCATED_UNALLOCATED_SETTLED.Contains(p.STS_KEY);
        }

        /// <summary>
        /// Decides if priority template required
        /// </summary>
        /// <returns>Boolean flag.</returns>
        /// <remarks>
        /// <para> [FK] 29/06/2017 1.0 Documentation.</para>
        /// </remarks>
        public static bool IsPriorityTemplateRequired(ReceiptParam param)
        {
            var receiptTypes = GetReceiptTypes(param);
            return receiptTypes.Exists(p => p.Item1 == Convert.ToInt32(ReceiptType.NormalReceipt.GetKey())
                                        || p.Item1 == Convert.ToInt32(ReceiptType.EarlyTerminationReceipt.GetKey())
                                        || p.Item1 == Convert.ToInt32(ReceiptType.WriteOffReceipt.GetKey())
                                        || p.Item1 == Convert.ToInt32(ReceiptType.SaleProceedReceipt.GetKey())
                                        || p.Item1 == Convert.ToInt32(ReceiptType.ShortfallReceipt.GetKey())
                                        || p.Item1 == Convert.ToInt32(ReceiptType.RestructuringReceipt.GetKey())
                                        || p.Item1 == Convert.ToInt32(ReceiptType.PaymentWaiver.GetKey()));
        }

        /// <summary>
        /// Decides if overpayment template required
        /// </summary>
        /// <returns>Boolean flag.</returns>
        /// <remarks>
        /// <para> [FK] 29/06/2017 1.0 Documentation.</para>
        /// </remarks>
        private static bool IsOverpaymentTemplateRequired(ReceiptParam param)
        {
            var receiptTypes = GetReceiptTypes(param);
            return receiptTypes.Exists(p => p.Item1 == Convert.ToInt32(ReceiptType.NormalReceipt.GetKey()));
        }

        public static bool IsConfigRequired(ReceiptParam param)
        {
            return (!param.IsPreactivation || param.IsContractActivation || param.ReceiptType != ReceiptType.LitigationReceipt);
        }

        /// <summary>
        /// Distributions the predicate.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <param name="rcptAlcn">The RCPT alcn.</param>
        /// <returns></returns>
        public static bool CheckDistribution(ReceiptParam param, ReceiptAllocation rcptAlcn)
        {
            return !HasData(param.SettlementParam.Distribution) || param.SettlementParam.Distribution.Exists(p => p.DE_ALCT_IND && p.AMNT_CMPT_TYPE_KEY == rcptAlcn.AMNT_CMPT_TYPE_KEY &&
                                ((p.RNTL_ID > 0 && p.RNTL_ID == rcptAlcn.RNTL_ID && p.ARTL_CMPT_SEQ == 0) || //consolidated rental (asset rental, value added and financed charge)
                                (p.RNTL_ID == 0 && p.ARTL_CMPT_SEQ > 0 && p.ARTL_CMPT_SEQ == rcptAlcn.ARTL_CMPT_SEQ) || //other component
                                (p.RNTL_ID == rcptAlcn.RNTL_ID && p.CHRG_SEQ == rcptAlcn.CHRG_SEQ) ||  //upfront charge
                                (p.RNTL_ID == rcptAlcn.RNTL_ID && p.RNTL_OVRD_SEQ == rcptAlcn.RNTL_OVRD_SEQ)));
        }

        public static bool IsOtpNotApplicableOrPurchase(OtpDecisionInfo otpDecision)
        {
            return !otpDecision.IsOtpApplicable || (otpDecision.OtpDecision == OtpOptions.Purchase.GetKey() && !otpDecision.IsInvoiceBased);
        }


        public static void IsPostClosing(ReceiptParam param, List<ReceiptContract> receiptContracts)
        {
            param.IsPostClosing = receiptContracts.Exists(p => p.STS_KEY == StatusCode.WriteOff.GetKey() || p.STS_KEY == StatusCode.Payout.GetKey() || p.STS_KEY == StatusCode.EarlyPayout.GetKey() || p.STS_KEY == StatusCode.FlatCancelled.GetKey() || p.STS_KEY == StatusCode.RedemptionExpired.GetKey());
        }

        #endregion

        #region Reversal

        /// <summary>
        /// Reverses the common.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <param name="receiptsToBeReversed">The receipts to be reversed.</param>
        /// <param name="reverse">The reverse.</param>
        /// <param name="context">The context.</param>
        /// <returns></returns>
        internal static SettlementLog ReverseCommon(Receipt rcpt, DateTime? processingDte, List<int> receiptsToBeReversed, Action<int, SettlementBase, ReceiptParam> reverse, Context context, ARMProcessTypes ARMProcessTypes, bool logTransactionDetail, bool logInstallmentSettlement, int prcsQueuId)
        {
            //List<ReceiptParam> receiptDataList = new List<ReceiptParam>();            
            ReceiptParam receiptData = new ReceiptParam();
            receiptData.LogTransactionDetail = logTransactionDetail;
            receiptData.LogInstallmentSettlement = logInstallmentSettlement;
            receiptData.ProcessQueueId = prcsQueuId;
            receiptData.Receipts = new List<Receipt>() { rcpt };
            //if (PrepareFutureReceipts(receiptData) == SettlementLogTypes.ReceiptCannotBeReversed) return new SettlementLog() { MessageType = SettlementResponseTypes.Info.ToString(), MessageDescription = SettlementLogTypes.ReceiptCannotBeReversed.ToString() };
            receiptData.BranchId = rcpt.BRNC_ID;
            receiptData.CompanyId = rcpt.CMPY_ID;
            if (HasData(rcpt.ReceiptDetail))
            {
                receiptData.ReceiptType = (ReceiptType)Enum.Parse(typeof(ReceiptType), rcpt.ReceiptDetail.FirstOrDefault().RCPT_TYPE_ID.ToString());
            }
            else
            {
                receiptData.ReceiptType = ReceiptType.NormalReceipt;
            }
            receiptData.ProcessingDte = processingDte;
            receiptData.ContractIds = GetContractList(new ReceiptParam() { Receipts = receiptData.Receipts }, ARMProcessTypes);
            receiptData.IsZeroReceipt = rcpt.RCPT_AMNT == 0 ? true : false;
            if (receiptData.ReceiptType == ReceiptType.WriteOffReceipt)
            {
                receiptData.RequestId = Convert.ToInt32(rcpt?.ReceiptDetail?.FirstOrDefault(p => p.RCPT_TYPE_ID == Convert.ToInt32(ReceiptType.WriteOffReceipt.GetKey()))?.REQT_ID);
                receiptData.IsShortfallWriteOff = IsShortfallWriteoffExist(receiptData);
            }
            if (receiptData.ReceiptType == ReceiptType.OTPReceipt)
            {
                receiptData.RequestId = Convert.ToInt32(rcpt?.ReceiptDetail?.FirstOrDefault(p => p.RCPT_TYPE_ID == Convert.ToInt32(ReceiptType.OTPReceipt.GetKey()))?.REQT_ID);
            }
            SettlementBase instance = SettlementFactory.GetSettlementType(receiptData, context);
            instance.PrepareForReversal(receiptData, ARMProcessTypes);
            reverse(rcpt.RCPT_ID, instance, receiptData);
            instance.FinalizeReceipt(receiptData, ARMProcessTypes);
            instance.PostSettlement(receiptData, ARMProcessTypes);
            //instance.PostSettlementBpem(receiptData, ARMProcessTypes);
            //receiptDataList.Add(receiptData);
            AccountingHelper.InvokeActivity(instance.SettlementResponse, context, rcpt.BRNC_ID);
            //calcualte overdue

            //foreach (var receiptData2 in receiptDataList)
            //{
            //    if (!HasData(receiptData2.Receipts)) continue;
            //    receiptData2.DepositType = DepositTypes.AllocateFromMisc;
            //    SettlementBase instance2 = SettlementFactory.GetSettlementType(receiptData2, context);
            //    if (receiptsToBeReversed.Contains(receiptData2.Receipts.First().RCPT_ID))
            //    {
            //        //do nothing
            //    }
            //    else
            //    {
            //        instance2.ProcessReceipt(receiptData2);
            //    }
            //}

            return null;
        }

        #endregion

        #region Misc.

        /// <summary>
        /// Updates the allocation status.
        /// </summary>
        /// <param name="rcptAlcn">The RCPT alcn.</param>
        /// <param name="status">The status.</param>
        public static void UpdateAllocationStatus(ReceiptAllocation rcptAlcn, string status)
        {
            rcptAlcn.STS_KEY = status;
        }
        
        /// <summary>
        /// Gets the fp information.
        /// </summary>
        /// <param name="receipts">The receipts.</param>
        /// <param name="receiptContracts">The receipt contracts.</param>
        /// <returns></returns>
        public static void SetFpInfo(ReceiptParam param, List<ReceiptContract> receiptContracts)
        {
            if (HasData(param.FpInfo)) return;
            if (!HasData(receiptContracts)) return;
            List<Tuple<int, int?, int?>> fpInfo = new List<Tuple<int, int?, int?>>();
            foreach (var receiptContract in receiptContracts)
            {
                if (receiptContract != null)
                {
                    fpInfo.Add(new Tuple<int, int?, int?>(receiptContract.CONT_ID, receiptContract.FNCL_PROD_GRP_ID, receiptContract.FNCL_PROD_ID));
                }
            }
            param.FpInfo = fpInfo;
        }

        /// <summary>
        /// Gets the contract list.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <param name="armProcessTypes">The arm process types.</param>
        /// <returns></returns>
        public static List<int> GetContractList(ReceiptParam param, ARMProcessTypes armProcessTypes = ARMProcessTypes.Posting)
        {
            try
            {
                if (param.IsBulk)
                {
                    if (param.ReceiptCriteria != null)
                    {
                        return param.ReceiptCriteria.Where(p => p.ReceiptDetailList != null).SelectMany(rcpt => rcpt.ReceiptDetailList.Where(p => p.ContractList != null),
                            (rcpt, rcptDetail) => new { rcpt, rcptDetail })
                            .SelectMany(@t => @t.rcptDetail.ContractList,
                                (@t, rcptContract) => Convert.ToInt32(rcptContract)).ToList();
                    }
                }
                if (param.Receipts != null)
                {
                    if (armProcessTypes == ARMProcessTypes.Cancel)
                    {
                        return param.Receipts.Where(p => p.ReceiptDetail != null && IsReceiptCancelable(p)).SelectMany(rcpt => rcpt.ReceiptDetail.Where(q => q.ReceiptContractAssociation != null && IsReceiptCancelable(q)),
                            (rcpt, rcptDetail) => new { rcpt, rcptDetail })
                            .SelectMany(@t => @t.rcptDetail.ReceiptContractAssociation.Where(r => IsReceiptCancelable(r)),
                                (@t, rcptContract) => Convert.ToInt32(rcptContract.CONT_ID)).ToList();
                    }
                    if (armProcessTypes == ARMProcessTypes.Deallocate)
                    {
                        return param.Receipts.Where(p => p.ReceiptDetail != null && (IsReceiptDeallocatable(p) || p.UN_ALCT_AMNT > 0)).SelectMany(rcpt => rcpt.ReceiptDetail.Where(q => q.ReceiptContractAssociation != null && IsReceiptDeallocatable(q)),
                            (rcpt, rcptDetail) => new { rcpt, rcptDetail })
                            .SelectMany(@t => @t.rcptDetail.ReceiptContractAssociation.Where(r => IsReceiptDeallocatable(r)),
                                (@t, rcptContract) => Convert.ToInt32(rcptContract.CONT_ID)).ToList();
                    }
                    return param.Receipts.Where(p => p.ReceiptDetail != null && IsReceiptProcessable(p)).SelectMany(rcpt => rcpt.ReceiptDetail.Where(q => q.ReceiptContractAssociation != null && IsReceiptProcessable(q)),
                            (rcpt, rcptDetail) => new { rcpt, rcptDetail })
                            .SelectMany(@t => @t.rcptDetail.ReceiptContractAssociation.Where(r => IsReceiptProcessable(r)),
                                (@t, rcptContract) => Convert.ToInt32(rcptContract.CONT_ID)).ToList();
                }
                else if (param.IsContractActivation || param.DepositType == DepositTypes.ParkSeparate)
                {
                    return param.ContractIds;
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// Gets the table information by model.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        private static Dictionary<string, string> GetTableInfoByModel(Type type)
        {
            try
            {
                Dictionary<string, string> tableInfo = new Dictionary<string, string>();
                if (type == typeof(Contract))
                {
                    tableInfo.Add("CONT", "CONT_ID");
                }
                else if (type == typeof(Receipt))
                {
                    tableInfo.Add("RCPT", "RCPT_ID");
                }
                else if (type == typeof(ReceiptDetail))
                {
                    tableInfo.Add("RCPT_DET", "RCPT_DET_ID");
                }
                else if (type == typeof(ReceiptContractAssociation))
                {
                    tableInfo.Add("CONT_RCPT_ASOC", "CONT_RCPT_ASOC_ID");
                }
                else if (type == typeof(Receipt))
                {
                    tableInfo.Add("CONT_RCPT_ALCN", "CONT_RCPT_ALCN_ID");
                }
                else if (type == typeof(OneTimePayment))
                {
                    tableInfo.Add("RCPT_ONE_TIME_PYMT", "RCPT_ID");
                }
                return tableInfo;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// Executes the query.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sql">The SQL.</param>
        /// <returns></returns>
        public static IList<T> ExecuteQuery<T>(string sql)
        {
            try
            {
                DbController dbController = DbController.Create();
                return dbController.GetCustomList<T>(sql);
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// Executes the query.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sql">The SQL.</param>
        /// <returns></returns>
        public static IList<T> ExecuteQuery<T>(string sql, SerializableDictionary<string, object> parameters)
        {
            try
            {
                DbController dbController = DbController.Create();
                return dbController.GetCustomList<T>(sql, parameters);
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        /// <summary>
        /// Assigns the default value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj">The object.</param>
        public static void AssignDefaultValue<T>(T obj)
        {
            if (obj is ReceiptRepaymentPlan)
            {
                var item = (obj as ReceiptRepaymentPlan);
                if (item.CMPD_INRT_AMNT == null) item.CMPD_INRT_AMNT = 0;
                //if (item.CMPT_RCBL_AMNT == null) item.CMPT_RCBL_AMNT = 0;
                if (item.CPTL_AMNT == null) item.CPTL_AMNT = 0;
                if (item.GROS_RNTL_AMNT == null) item.GROS_RNTL_AMNT = 0;
                if (item.INRT_ADJT_AMNT == null) item.INRT_ADJT_AMNT = 0;
                if (item.INRT_AMNT == null) item.INRT_AMNT = 0;
                if (item.INRT_SETL_AMNT == null) item.INRT_SETL_AMNT = 0;
                if (item.INSU_ADJT_AMNT == null) item.INSU_ADJT_AMNT = 0;
                if (item.INSU_AMNT == null) item.INSU_AMNT = 0;
                if (item.INSU_SETL_AMNT == null) item.INSU_SETL_AMNT = 0;
                if (item.LUMP_SUM_AMNT == null) item.LUMP_SUM_AMNT = 0;
                if (item.MNTC_ADJT_AMNT == null) item.MNTC_ADJT_AMNT = 0;
                if (item.MNTC_AMNT == null) item.MNTC_AMNT = 0;
                if (item.MNTC_SETL_AMNT == null) item.MNTC_SETL_AMNT = 0;
                if (item.NET_RNTL_AMNT == null) item.NET_RNTL_AMNT = 0;
                if (item.PERD_INRT_AMNT == null) item.PERD_INRT_AMNT = 0;
                if (item.PRCH_TAX_AMNT == null) item.PRCH_TAX_AMNT = 0;
                if (item.PRNC_AJDT_AMNT == null) item.PRNC_AJDT_AMNT = 0;
                //if (item.PRNC_OTSD_AMNT == null) item.PRNC_OTSD_AMNT = 0;
                if (item.PRNC_RNTL_AMNT == null) item.PRNC_RNTL_AMNT = 0;
                if (item.PRNC_SETL_AMNT == null) item.PRNC_SETL_AMNT = 0;
                if (item.REGT_ADJT_AMNT == null) item.REGT_ADJT_AMNT = 0;
                if (item.REGT_AMNT == null) item.REGT_AMNT = 0;
                if (item.REGT_SETL_AMNT == null) item.REGT_SETL_AMNT = 0;
                if (item.SERV_TAX_AMNT == null) item.SERV_TAX_AMNT = 0;
            }
            else if (obj is SettlementRepaymentPlan)
            {
                var item = (obj as SettlementRepaymentPlan);
                if (item.CMPD_INRT_AMNT == null) item.CMPD_INRT_AMNT = 0;
                //if (item.CMPT_RCBL_AMNT == null) item.CMPT_RCBL_AMNT = 0;
                if (item.CPTL_AMNT == null) item.CPTL_AMNT = 0;
                if (item.GROS_RNTL_AMNT == null) item.GROS_RNTL_AMNT = 0;
                if (item.INRT_ADJT_AMNT == null) item.INRT_ADJT_AMNT = 0;
                if (item.INRT_AMNT == null) item.INRT_AMNT = 0;
                if (item.INRT_SETL_AMNT == null) item.INRT_SETL_AMNT = 0;
                if (item.INSU_ADJT_AMNT == null) item.INSU_ADJT_AMNT = 0;
                if (item.INSU_AMNT == null) item.INSU_AMNT = 0;
                if (item.INSU_SETL_AMNT == null) item.INSU_SETL_AMNT = 0;
                if (item.LUMP_SUM_AMNT == null) item.LUMP_SUM_AMNT = 0;
                if (item.MNTC_ADJT_AMNT == null) item.MNTC_ADJT_AMNT = 0;
                if (item.MNTC_AMNT == null) item.MNTC_AMNT = 0;
                if (item.MNTC_SETL_AMNT == null) item.MNTC_SETL_AMNT = 0;
                if (item.NET_RNTL_AMNT == null) item.NET_RNTL_AMNT = 0;
                if (item.PERD_INRT_AMNT == null) item.PERD_INRT_AMNT = 0;
                if (item.PRCH_TAX_AMNT == null) item.PRCH_TAX_AMNT = 0;
                if (item.PRNC_AJDT_AMNT == null) item.PRNC_AJDT_AMNT = 0;
                //if (item.PRNC_OTSD_AMNT == null) item.PRNC_OTSD_AMNT = 0;
                if (item.PRNC_RNTL_AMNT == null) item.PRNC_RNTL_AMNT = 0;
                if (item.PRNC_SETL_AMNT == null) item.PRNC_SETL_AMNT = 0;
                if (item.REGT_ADJT_AMNT == null) item.REGT_ADJT_AMNT = 0;
                if (item.REGT_AMNT == null) item.REGT_AMNT = 0;
                if (item.REGT_SETL_AMNT == null) item.REGT_SETL_AMNT = 0;
                if (item.SERV_TAX_AMNT == null) item.SERV_TAX_AMNT = 0;
            }
            else if (obj is RepaymentPlanTax)
            {
                var item = (obj as RepaymentPlanTax);
                if (item.CMPT_TAX_RCBL_AMNT == null) item.CMPT_TAX_RCBL_AMNT = 0;
                if (item.TAX_RCBL_AMNT == null) item.TAX_RCBL_AMNT = 0;
            }
            else if (obj is SettlementRepaymentPlanTax)
            {
                var item = (obj as SettlementRepaymentPlanTax);
                if (item.CMPT_TAX_RCBL_AMNT == null) item.CMPT_TAX_RCBL_AMNT = 0;
                if (item.TAX_RCBL_AMNT == null) item.TAX_RCBL_AMNT = 0;
            }
            else if (obj is ReceiptChargeReceivable)
            {
                var item = (obj as ReceiptChargeReceivable);
                if (item.ADJT_AMNT == null) item.ADJT_AMNT = 0;
                if (item.CHRG_AMNT == null) item.CHRG_AMNT = 0;
                if (item.CHRG_WVED_AMNT == null) item.CHRG_WVED_AMNT = 0;
                if (item.SETL_AMNT == null) item.SETL_AMNT = 0;
            }
            else if (obj is SettlementChargeReceivable)
            {
                var item = (obj as SettlementChargeReceivable);
                if (item.ADJT_AMNT == null) item.ADJT_AMNT = 0;
                if (item.CHRG_AMNT == null) item.CHRG_AMNT = 0;
                if (item.CHRG_WVED_AMNT == null) item.CHRG_WVED_AMNT = 0;
                if (item.SETL_AMNT == null) item.SETL_AMNT = 0;
            }
            //else if (obj is ContractChargesTax)
            //{
            //    var item = (obj as ContractChargesTax);                
            //}
            else if (obj is ReceiptComponentRepaymentPlan)
            {
                var item = (obj as ReceiptComponentRepaymentPlan);
                if (item.CMPT_RCBL_AMNT == null) item.CMPT_RCBL_AMNT = 0;
                if (item.GROS_RNTL_AMNT == null) item.GROS_RNTL_AMNT = 0;
                if (item.INRT_ADJT_AMNT == null) item.INRT_ADJT_AMNT = 0;
                if (item.INRT_AMNT == null) item.INRT_AMNT = 0;
                if (item.INRT_SETL_AMNT == null) item.INRT_SETL_AMNT = 0;
                if (item.PRNC_ADJT_AMNT == null) item.PRNC_ADJT_AMNT = 0;
                if (item.PRNC_RNTL_AMNT == null) item.PRNC_RNTL_AMNT = 0;
                if (item.PRNC_SETL_AMNT == null) item.PRNC_SETL_AMNT = 0;
                if (item.RNTL_AMNT == null) item.RNTL_AMNT = 0;
            }
            else if (obj is SettlementComponentRepaymentPlan)
            {
                var item = (obj as SettlementComponentRepaymentPlan);
                if (item.CMPT_RCBL_AMNT == null) item.CMPT_RCBL_AMNT = 0;
                if (item.GROS_RNTL_AMNT == null) item.GROS_RNTL_AMNT = 0;
                if (item.INRT_ADJT_AMNT == null) item.INRT_ADJT_AMNT = 0;
                if (item.INRT_AMNT == null) item.INRT_AMNT = 0;
                if (item.INRT_SETL_AMNT == null) item.INRT_SETL_AMNT = 0;
                if (item.PRNC_ADJT_AMNT == null) item.PRNC_ADJT_AMNT = 0;
                if (item.PRNC_RNTL_AMNT == null) item.PRNC_RNTL_AMNT = 0;
                if (item.PRNC_SETL_AMNT == null) item.PRNC_SETL_AMNT = 0;
                if (item.RNTL_AMNT == null) item.RNTL_AMNT = 0;
            }
            else if (obj is ComponentPaymentPlanTax)
            {
                var item = (obj as ComponentPaymentPlanTax);
                if (item.CMPT_TAX_RCBL_AMNT == null) item.CMPT_TAX_RCBL_AMNT = 0;
            }
            else if (obj is SettlementComponentPaymentPlanTax)
            {
                var item = (obj as SettlementComponentPaymentPlanTax);
                if (item.CMPT_TAX_RCBL_AMNT == null) item.CMPT_TAX_RCBL_AMNT = 0;
            }
            else if (obj is ReceiptChargesPlan)
            {
                var item = (obj as ReceiptChargesPlan);
                if (item.CHRG_INRT_ADJT_AMNT == null) item.CHRG_INRT_ADJT_AMNT = 0;
                if (item.CHRG_INRT_AMNT == null) item.CHRG_INRT_AMNT = 0;
                if (item.CHRG_INRT_SETL_AMNT == null) item.CHRG_INRT_SETL_AMNT = 0;
                if (item.CHRG_PRNC_ADJT_AMNT == null) item.CHRG_PRNC_ADJT_AMNT = 0;
                if (item.CHRG_PRNC_SETL_AMNT == null) item.CHRG_PRNC_SETL_AMNT = 0;
                if (item.CHRG_RCBL_AMNT == null) item.CHRG_RCBL_AMNT = 0;
                if (item.CHRG_RNTL_AMNT == null) item.CHRG_RNTL_AMNT = 0;
            }
            else if (obj is SettlementChargesPlan)
            {
                var item = (obj as SettlementChargesPlan);
                if (item.CHRG_INRT_ADJT_AMNT == null) item.CHRG_INRT_ADJT_AMNT = 0;
                if (item.CHRG_INRT_AMNT == null) item.CHRG_INRT_AMNT = 0;
                if (item.CHRG_INRT_SETL_AMNT == null) item.CHRG_INRT_SETL_AMNT = 0;
                if (item.CHRG_PRNC_ADJT_AMNT == null) item.CHRG_PRNC_ADJT_AMNT = 0;
                if (item.CHRG_PRNC_SETL_AMNT == null) item.CHRG_PRNC_SETL_AMNT = 0;
                if (item.CHRG_RCBL_AMNT == null) item.CHRG_RCBL_AMNT = 0;
                if (item.CHRG_RNTL_AMNT == null) item.CHRG_RNTL_AMNT = 0;
            }
            else if (obj is FinanceChargesPaymentPlanTax)
            {
                var item = (obj as FinanceChargesPaymentPlanTax);
                if (item.TAX_RCBL_AMNT == null) item.TAX_RCBL_AMNT = 0;
            }
            else if (obj is SettlementFinanceChargesPaymentPlanTax)
            {
                var item = (obj as SettlementFinanceChargesPaymentPlanTax);
                if (item.TAX_RCBL_AMNT == null) item.TAX_RCBL_AMNT = 0;
            }
            //else if (obj is ContractAssetMaintenanceReceivable)
            //{
            //    var item = (obj as ContractAssetMaintenanceReceivable);
            //}
            //else if (obj is ContractAssetMaintenanceReceivableTax)
            //{
            //    var item = (obj as ContractAssetMaintenanceReceivableTax);
            //}
            else if (obj is EtContractChargesSettlement)
            {
                var item = (obj as EtContractChargesSettlement);
                if (item.CHRG_SETL_AMNT == null) item.CHRG_SETL_AMNT = 0;
            }
            else if (obj is SettlementEtContractCharges)
            {
                var item = (obj as SettlementEtContractCharges);
                if (item.CHRG_SETL_AMNT == null) item.CHRG_SETL_AMNT = 0;
            }
            else if (obj is EtContractAmountComponentSettlement)
            {
                var item = (obj as EtContractAmountComponentSettlement);
                if (item.CMPT_AMNT == null) item.CMPT_AMNT = 0;
                if (item.CMPT_SETL_AMNT == null) item.CMPT_SETL_AMNT = 0;
                if (item.TAX_EXCL_CMPT_AMNT == null) item.TAX_EXCL_CMPT_AMNT = 0;
            }
            else if (obj is SettlementEtContractAmountComponent)
            {
                var item = (obj as SettlementEtContractAmountComponent);
                if (item.CMPT_AMNT == null) item.CMPT_AMNT = 0;
                if (item.CMPT_SETL_AMNT == null) item.CMPT_SETL_AMNT = 0;
                if (item.TAX_EXCL_CMPT_AMNT == null) item.TAX_EXCL_CMPT_AMNT = 0;
            }
            else if (obj is EtContractRepaymentPlanSettlement)
            {
                var item = (obj as EtContractRepaymentPlanSettlement);
                if (item.GROS_RNTL_AMNT == null) item.GROS_RNTL_AMNT = 0;
                if (item.INRT_ADJT_AMNT == null) item.INRT_ADJT_AMNT = 0;
                if (item.INRT_AMNT == null) item.INRT_AMNT = 0;
                if (item.INRT_SETL_AMNT == null) item.INRT_SETL_AMNT = 0;
                if (item.INSU_AMNT == null) item.INSU_AMNT = 0;
                if (item.INSU_SETL_AMNT == null) item.INSU_SETL_AMNT = 0;
                if (item.MNTC_ADJT_AMNT == null) item.MNTC_ADJT_AMNT = 0;
                if (item.MNTC_AMNT == null) item.MNTC_AMNT = 0;
                if (item.MNTC_SETL_AMNT == null) item.MNTC_SETL_AMNT = 0;
                if (item.NET_RNTL_AMNT == null) item.NET_RNTL_AMNT = 0;
                if (item.OVRD_AMNT == null) item.OVRD_AMNT = 0;
                if (item.OVRD_SETL_AMNT == null) item.OVRD_SETL_AMNT = 0;
                if (item.PRCH_TAX_AMNT == null) item.PRCH_TAX_AMNT = 0;
                if (item.PRNC_RNTL_AMNT == null) item.PRNC_RNTL_AMNT = 0;
                if (item.PRNC_SETL_AMNT == null) item.PRNC_SETL_AMNT = 0;
                if (item.REGT_AMNT == null) item.REGT_AMNT = 0;
                if (item.REGT_SETL_AMNT == null) item.REGT_SETL_AMNT = 0;
                if (item.SERV_TAX_AMNT == null) item.SERV_TAX_AMNT = 0;
            }
            else if (obj is SettlementEtContractPlan)
            {
                var item = (obj as SettlementEtContractPlan);
                if (item.GROS_RNTL_AMNT == null) item.GROS_RNTL_AMNT = 0;
                if (item.INRT_ADJT_AMNT == null) item.INRT_ADJT_AMNT = 0;
                if (item.INRT_AMNT == null) item.INRT_AMNT = 0;
                if (item.INRT_SETL_AMNT == null) item.INRT_SETL_AMNT = 0;
                if (item.INSU_AMNT == null) item.INSU_AMNT = 0;
                if (item.INSU_SETL_AMNT == null) item.INSU_SETL_AMNT = 0;
                if (item.MNTC_ADJT_AMNT == null) item.MNTC_ADJT_AMNT = 0;
                if (item.MNTC_AMNT == null) item.MNTC_AMNT = 0;
                if (item.MNTC_SETL_AMNT == null) item.MNTC_SETL_AMNT = 0;
                if (item.NET_RNTL_AMNT == null) item.NET_RNTL_AMNT = 0;
                if (item.OVRD_AMNT == null) item.OVRD_AMNT = 0;
                if (item.OVRD_SETL_AMNT == null) item.OVRD_SETL_AMNT = 0;
                if (item.PRCH_TAX_AMNT == null) item.PRCH_TAX_AMNT = 0;
                if (item.PRNC_RNTL_AMNT == null) item.PRNC_RNTL_AMNT = 0;
                if (item.PRNC_SETL_AMNT == null) item.PRNC_SETL_AMNT = 0;
                if (item.REGT_AMNT == null) item.REGT_AMNT = 0;
                if (item.REGT_SETL_AMNT == null) item.REGT_SETL_AMNT = 0;
                if (item.SERV_TAX_AMNT == null) item.SERV_TAX_AMNT = 0;
            }
            //else if (obj is EtContractRepaymentPlanTaxSettlement)
            //{
            //    var item = (obj as EtContractRepaymentPlanTaxSettlement);
            //}
            //else if (obj is AssetComponentReceivable)
            //{
            //    var item = (obj as AssetComponentReceivable);
            //}
            else if (obj is RentalOverdue)
            {
                var item = (obj as RentalOverdue);
                if (item.OVRD_ADJT_AMNT == null) item.OVRD_ADJT_AMNT = 0;
                if (item.OVRD_AMNT == null) item.OVRD_AMNT = 0;
                if (item.OVRD_SETL_AMNT == null) item.OVRD_SETL_AMNT = 0;
                if (item.OVRD_WVED_AMNT == null) item.OVRD_WVED_AMNT = 0;
                if (item.RNTL_OTSD_AMNT == null) item.RNTL_OTSD_AMNT = 0;
                if (item.PAID == null) item.PAID = 0;
                if (item.OD_DUE_AMT == null) item.OD_DUE_AMT = 0;
                if (item.OD_RCPT_AMT == null) item.OD_RCPT_AMT = 0;
            }
            else if (obj is SettlementRentalOverdue)
            {
                var item = (obj as SettlementRentalOverdue);
                if (item.OVRD_ADJT_AMNT == null) item.OVRD_ADJT_AMNT = 0;
                if (item.OVRD_AMNT == null) item.OVRD_AMNT = 0;
                if (item.OVRD_SETL_AMNT == null) item.OVRD_SETL_AMNT = 0;
                if (item.OVRD_WVED_AMNT == null) item.OVRD_WVED_AMNT = 0;
                if (item.RNTL_OTSD_AMNT == null) item.RNTL_OTSD_AMNT = 0;
                if (item.PAID == null) item.PAID = 0;
                if (item.OD_DUE_AMT == null) item.OD_DUE_AMT = 0;
                if (item.OD_RCPT_AMT == null) item.OD_RCPT_AMT = 0;
            }
            else if (obj is RentalOverdueTax)
            {
                var item = (obj as RentalOverdueTax);
                if (item.OVRD_TAX_ADJT_AMNT == null) item.OVRD_TAX_ADJT_AMNT = 0;
                if (item.OVRD_TAX_AMNT == null) item.OVRD_TAX_AMNT = 0;
                if (item.OVRD_TAX_SETL_AMNT == null) item.OVRD_TAX_SETL_AMNT = 0;                
            }
            else if (obj is SettlementRentalOverdueTax)
            {
                var item = (obj as SettlementRentalOverdueTax);
                if (item.OVRD_TAX_ADJT_AMNT == null) item.OVRD_TAX_ADJT_AMNT = 0;
                if (item.OVRD_TAX_AMNT == null) item.OVRD_TAX_AMNT = 0;
                if (item.OVRD_TAX_SETL_AMNT == null) item.OVRD_TAX_SETL_AMNT = 0;
            }
            
            //else if (obj is RedemptionExpiryReceivable)
            //{
            //    var item = (obj as RedemptionExpiryReceivable);
            //}
            else if (obj is ArticleClosingShortfallDet)
            {
                var item = (obj as ArticleClosingShortfallDet);
                if (item.SHRT_FALL_BLNC_AMNT == null) item.SHRT_FALL_BLNC_AMNT = 0;
            }
            else if (obj is SettlementArticleClosingShortfallDet)
            {
                var item = (obj as SettlementArticleClosingShortfallDet);
                if (item.SHRT_FALL_BLNC_AMNT == null) item.SHRT_FALL_BLNC_AMNT = 0;
            }
            else if (obj is WOFF_RCVY_OVRD_DET)
            {
                var item = (obj as WOFF_RCVY_OVRD_DET);
                foreach (var taxItem in item.TaxDetail)
                {
                    if (taxItem.OVRD_TAX_SETL_AMNT == null) taxItem.OVRD_TAX_SETL_AMNT = 0;
                    if (taxItem.OVRD_TAX_ADJT_AMNT == null) taxItem.OVRD_TAX_ADJT_AMNT = 0;
                    if (taxItem.OVRD_TAX_AMNT == null) taxItem.OVRD_TAX_AMNT = 0;
                    if (taxItem.OVRD_WVED_AMNT == null) taxItem.OVRD_WVED_AMNT = 0;
                }
            }
            else if (obj is SettlementWOFF_RCVY_OVRD_DET)
            {
                var item = (obj as SettlementWOFF_RCVY_OVRD_DET);
                foreach (var taxItem in item.TaxDetail)
                {
                    if (taxItem.OVRD_TAX_SETL_AMNT == null) taxItem.OVRD_TAX_SETL_AMNT = 0;
                    if (taxItem.OVRD_TAX_ADJT_AMNT == null) taxItem.OVRD_TAX_ADJT_AMNT = 0;
                    if (taxItem.OVRD_TAX_AMNT == null) taxItem.OVRD_TAX_AMNT = 0;
                    if (taxItem.OVRD_WVED_AMNT == null) taxItem.OVRD_WVED_AMNT = 0;
                }
            }
            //else if (obj is WriteOffRcvryChrgDetails)
            //{
            //    var item = (obj as WriteOffRcvryChrgDetails);
            //}
            //else if (obj is WOFF_RCVY_AMNT_CMPT)
            //{
            //    var item = (obj as WOFF_RCVY_AMNT_CMPT);
            //}
            //else if (obj is WriteOffRcvryRpmtPlan)
            //{
            //    var item = (obj as WriteOffRcvryRpmtPlan);
            //}
            //else if (obj is WOFF_RCVY_OVRD_DET)
            //{
            //    var item = (obj as WOFF_RCVY_OVRD_DET);
            //}
        }

        /// <summary>
        /// Assigns the default value.
        /// </summary>
        /// <param name="receipts">The receipts.</param>
        public static void AssignDefaultValue(List<Receipt> receipts)
        {
            foreach (var rcpt in receipts)
            {
                if (rcpt.MISC_AMNT == null) rcpt.MISC_AMNT = 0;
                if (rcpt.RCPT_SETL_AMNT == null) rcpt.RCPT_SETL_AMNT = 0;
                if (rcpt.RFND_AMNT == null) rcpt.RFND_AMNT = 0;
                if (rcpt.UN_ALCT_AMNT == null) rcpt.UN_ALCT_AMNT = 0;
                if (rcpt.WHT_AMNT == null) rcpt.WHT_AMNT = 0;
                if (rcpt.ReceiptDetail != null)
                {
                    foreach (var rcptDetl in rcpt.ReceiptDetail)
                    {
                        if (rcptDetl.RCPT_AMNT == null) rcptDetl.RCPT_AMNT = 0;
                        if (rcptDetl.RCPT_SETL_AMNT == null) rcptDetl.RCPT_SETL_AMNT = 0;
                        if (rcptDetl.UN_ALCT_AMNT == null) rcptDetl.UN_ALCT_AMNT = 0;
                        if (rcptDetl.ReceiptContractAssociation != null)
                        {
                            foreach (var rcptCont in rcptDetl.ReceiptContractAssociation)
                            {
                                if (rcptCont.RCPT_AMNT == null) rcptCont.RCPT_AMNT = 0;
                                if (rcptCont.UN_ALCT_AMNT == null) rcptCont.UN_ALCT_AMNT = 0;
                            }
                        }
                    }
                }
            }
        }

        public static IEnumerable<ReceiptAllocation> AllocationsTobeDeallocated(ReceiptParam param)
        {
            return InitializeIfNull(param.SettlementParam.ReceiptContractAssociation.ReceiptAllocation).Where(p => p.STS_KEY != StatusCode.Cancelled.GetKey() && p.STS_KEY != StatusCode.DeAllocated.GetKey());
        }

        public static IEnumerable<ReceiptAllocation> AllocationsToBeCancelled(ReceiptParam param)
        {
            return InitializeIfNull(param.SettlementParam.ReceiptContractAssociation.ReceiptAllocation).Where(p => p.STS_KEY != StatusCode.Cancelled.GetKey() && p.STS_KEY != StatusCode.DeAllocated.GetKey());
        }

        public static bool IsPeriodicInterest(string component)
        {
            return component == AmountComponents.PeriodicInterest.GetKey();
        }

        public static List<ContractSettlement> CopyContractReceivablesToContractSettlement(List<ContractReceivables> receivables)
        {
            List<ContractSettlement> contracts = new List<ContractSettlement>();
            foreach (var rcbl in receivables)
            {
                ContractSettlement contract = new ContractSettlement();

                Copy(rcbl, contract);
                //contracts.Add(contract);
                if (rcbl.ArticleClosingShortfall != null && rcbl.ArticleClosingShortfall.Count() > 0)
                    foreach (var rcb in rcbl.ArticleClosingShortfall)
                    {
                        SettlementArticleClosingShortfall shrtfll = new SettlementArticleClosingShortfall();
                        Copy(rcb, shrtfll);

                        if (rcb.ArticleClosingShortfallDet != null)
                            foreach (var x in rcb.ArticleClosingShortfallDet)
                            {
                                SettlementArticleClosingShortfallDet det = new SettlementArticleClosingShortfallDet();
                                Copy(x, det);
                                if (shrtfll.SettlementArticleClosingShortfallDet == null) shrtfll.SettlementArticleClosingShortfallDet = new List<SettlementArticleClosingShortfallDet>();
                                shrtfll.SettlementArticleClosingShortfallDet.Add(det);
                            }
                        if (rcb.ArticleClosingShortfallSundryCharges != null)
                            foreach (var x in rcb.ArticleClosingShortfallSundryCharges)
                            {
                                SettlementArticleClosingShortfallSundryCharges det = new SettlementArticleClosingShortfallSundryCharges();
                                Copy(x, det);
                                if (shrtfll.SettlementArticleClosingShortfallSundryCharges == null) shrtfll.SettlementArticleClosingShortfallSundryCharges = new List<SettlementArticleClosingShortfallSundryCharges>();
                                shrtfll.SettlementArticleClosingShortfallSundryCharges.Add(det);
                            }

                        if (contract.SettlementArticleClosingShortfall == null) contract.SettlementArticleClosingShortfall = new List<SettlementArticleClosingShortfall>();
                        contract.SettlementArticleClosingShortfall.Add(shrtfll);
                    }
                else
                {
                    contract.SettlementArticleClosingShortfall = new List<SettlementArticleClosingShortfall>();
                }
                if (rcbl.ArticleComponentTran != null && rcbl.ArticleComponentTran.Count() > 0)
                    foreach (var rcb in rcbl.ArticleComponentTran)
                    {
                        SettlementArticleComponentsMain ex = new SettlementArticleComponentsMain();
                        Copy(rcb, ex);
                        if (rcb.ReceiptArticleComponentsDetail != null)
                            foreach (var x in rcb.ReceiptArticleComponentsDetail)
                            {
                                if (ex.SettlementArticleComponentsDetail == null) ex.SettlementArticleComponentsDetail = new List<ReceiptArticleComponentsDetail>();
                                ex.SettlementArticleComponentsDetail.Add(x);
                            }
                        if (contract.SettlementArticleComponentTran == null) contract.SettlementArticleComponentTran = new List<SettlementArticleComponentsMain>();
                        contract.SettlementArticleComponentTran.Add(ex);
                    }
                else
                {
                    contract.SettlementArticleComponentTran = new List<SettlementArticleComponentsMain>();
                }
                if (rcbl.AsetCmptRcbl != null && rcbl.AsetCmptRcbl.Count() > 0)
                    foreach (var rcb in rcbl.AsetCmptRcbl)
                    {
                        SettlementAssetComponentReceivable ex = new SettlementAssetComponentReceivable();
                        Copy(rcb, ex);
                        if (rcb.AsetComponentReceivableCharge != null)
                            foreach (var x in rcb.AsetComponentReceivableCharge)
                            {
                                SettlementAssetComponentReceivableChrg det = new SettlementAssetComponentReceivableChrg();
                                Copy(x, det);
                                if (ex.SettlementAssetComponentReceivableCharge == null) ex.SettlementAssetComponentReceivableCharge = new List<SettlementAssetComponentReceivableChrg>();
                                ex.SettlementAssetComponentReceivableCharge.Add(det);
                            }
                        if (contract.SettlementAsetCmptRcbl == null) contract.SettlementAsetCmptRcbl = new List<SettlementAssetComponentReceivable>();
                        contract.SettlementAsetCmptRcbl.Add(ex);
                    }
                else
                {
                    contract.SettlementAsetCmptRcbl = new List<SettlementAssetComponentReceivable>();
                }
                if (rcbl.ChargeReceivable != null && rcbl.ChargeReceivable.Count() > 0)
                    foreach (var rcb in rcbl.ChargeReceivable)
                    {
                        SettlementChargeReceivable ex = new SettlementChargeReceivable();
                        Copy(rcb, ex);
                        if (rcb.ReceiptChargesReceivableTax != null)
                            foreach (var x in rcb.ReceiptChargesReceivableTax)
                            {
                                SettlementContractChargesTax det = new SettlementContractChargesTax();
                                Copy(x, det);
                                if (ex.SettlementChargesReceivableTax == null) ex.SettlementChargesReceivableTax = new List<SettlementContractChargesTax>();
                                ex.SettlementChargesReceivableTax.Add(det);
                            }
                        if (contract.ChargeReceivable == null) contract.ChargeReceivable = new List<SettlementChargeReceivable>();
                        contract.ChargeReceivable.Add(ex);
                    }
                else
                {
                    contract.ChargeReceivable = new List<SettlementChargeReceivable>();
                }
                if (rcbl.ComponentRepaymentPlan != null && rcbl.ComponentRepaymentPlan.Count() > 0)
                    foreach (var rcb in rcbl.ComponentRepaymentPlan)
                    {
                        SettlementComponentRepaymentPlan ex = new SettlementComponentRepaymentPlan();
                        Copy(rcb, ex);
                        if (rcb.ReceiptComponentRepaymentPlanTax != null)
                            foreach (var x in rcb.ReceiptComponentRepaymentPlanTax)
                            {
                                SettlementComponentPaymentPlanTax det = new SettlementComponentPaymentPlanTax();
                                Copy(x, det);
                                if (ex.SettlementComponentPlanTax == null) ex.SettlementComponentPlanTax = new List<SettlementComponentPaymentPlanTax>();
                                ex.SettlementComponentPlanTax.Add(det);
                            }
                        if (contract.ComponentRepaymentPlan == null) contract.ComponentRepaymentPlan = new List<SettlementComponentRepaymentPlan>();
                        contract.ComponentRepaymentPlan.Add(ex);
                    }
                else
                {
                    contract.ComponentRepaymentPlan = new List<SettlementComponentRepaymentPlan>();
                }
                //foreach (var rcb in rcbl.ConsolidatedRepaymentPlan)
                //{
                //    if (contract.ConsolidatedRepaymentPlan == null) contract.ConsolidatedRepaymentPlan = new List<ConsolidatedRepaymentPlan>();
                //    contract.ConsolidatedRepaymentPlan.Add(rcb);
                //}
                if (rcbl.EtContractAmountComponentSettlement != null && rcbl.EtContractAmountComponentSettlement.Count() > 0)
                    foreach (var rcb in rcbl.EtContractAmountComponentSettlement)
                    {
                        SettlementEtContractAmountComponent ex = new SettlementEtContractAmountComponent();
                        Copy(rcb, ex);
                        if (contract.SettlementEtContractAmountComponent == null) contract.SettlementEtContractAmountComponent = new List<SettlementEtContractAmountComponent>();
                        contract.SettlementEtContractAmountComponent.Add(ex);
                    }
                else
                {
                    contract.SettlementEtContractAmountComponent = new List<SettlementEtContractAmountComponent>();
                }
                if (rcbl.EtContractCharges != null && rcbl.EtContractCharges.Count() > 0)
                    foreach (var rcb in rcbl.EtContractCharges)
                    {
                        SettlementEtContractCharges ex = new SettlementEtContractCharges();
                        Copy(rcb, ex);
                        if (contract.SettlementEtContractCharges == null) contract.SettlementEtContractCharges = new List<SettlementEtContractCharges>();
                        contract.SettlementEtContractCharges.Add(ex);
                    }
                else
                {
                    contract.SettlementEtContractCharges = new List<SettlementEtContractCharges>();
                }
                if (rcbl.EtContractRepaymentPlanSettlement != null && rcbl.EtContractRepaymentPlanSettlement.Count() > 0)
                    foreach (var rcb in rcbl.EtContractRepaymentPlanSettlement)
                    {
                        SettlementEtContractPlan ex = new SettlementEtContractPlan();
                        Copy(rcb, ex);
                        if (rcb.EtContractRepaymentPlanTaxSettlement != null)
                            foreach (var x in rcb.EtContractRepaymentPlanTaxSettlement)
                            {
                                SettlementEtContractPlanTax det = new SettlementEtContractPlanTax();
                                Copy(x, det);
                                if (ex.SettlementEtContractPlanTax == null) ex.SettlementEtContractPlanTax = new List<SettlementEtContractPlanTax>();
                                ex.SettlementEtContractPlanTax.Add(det);
                            }
                        if (contract.SettlementEtContractRepaymentPlan == null) contract.SettlementEtContractRepaymentPlan = new List<SettlementEtContractPlan>();
                        contract.SettlementEtContractRepaymentPlan.Add(ex);
                    }
                else
                {
                    contract.SettlementEtContractRepaymentPlan = new List<SettlementEtContractPlan>();
                }
                if (rcbl.FinancedCharges != null && rcbl.FinancedCharges.Count() > 0)
                    foreach (var rcb in rcbl.FinancedCharges)
                    {
                        SettlementChargesPlan ex = new SettlementChargesPlan();
                        Copy(rcb, ex);
                        if (rcb.ReceiptChargesPlanTax != null)
                            foreach (var x in rcb.ReceiptChargesPlanTax)
                            {
                                SettlementFinanceChargesPaymentPlanTax det = new SettlementFinanceChargesPaymentPlanTax();
                                Copy(x, det);
                                if (ex.SettlementChargesPlanTax == null) ex.SettlementChargesPlanTax = new List<SettlementFinanceChargesPaymentPlanTax>();
                                ex.SettlementChargesPlanTax.Add(det);
                            }
                        if (contract.FinancedCharges == null) contract.FinancedCharges = new List<SettlementChargesPlan>();
                        contract.FinancedCharges.Add(ex);
                    }
                else
                {
                    contract.FinancedCharges = new List<SettlementChargesPlan>();
                }
                if (rcbl.RentalOverdue != null && rcbl.RentalOverdue.Count() > 0)
                    foreach (var rcb in rcbl.RentalOverdue)
                    {
                        SettlementRentalOverdue ex = new SettlementRentalOverdue();
                        Copy(rcb, ex);
                        if (rcb.OverdueTaxDetails != null)
                            foreach (var x in rcb.OverdueTaxDetails)
                            {
                                SettlementRentalOverdueTax det = new SettlementRentalOverdueTax();
                                Copy(x, det);
                                if (ex.SettlementRentalOverdueTax == null) ex.SettlementRentalOverdueTax = new List<SettlementRentalOverdueTax>();
                                ex.SettlementRentalOverdueTax.Add(det);
                            }
                        if (rcb.DueOverdue != null)
                            foreach (var x in rcb.DueOverdue)
                            {
                                SettlementDueOverdue det = new SettlementDueOverdue();
                                Copy(x, det);
                                if (ex.SettlementDueOverdue == null) ex.SettlementDueOverdue = new List<SettlementDueOverdue>();
                                ex.SettlementDueOverdue.Add(det);
                            }
                        if (rcb.PaidOverdue != null)
                            foreach (var x in rcb.PaidOverdue)
                            {
                                SettlementPaidOverdue det = new SettlementPaidOverdue();
                                Copy(x, det);
                                if (ex.SettlementPaidOverdue == null) ex.SettlementPaidOverdue = new List<SettlementPaidOverdue>();
                                ex.SettlementPaidOverdue.Add(det);
                            }
                        if (rcb.GrossOverdue != null)
                            foreach (var x in rcb.GrossOverdue)
                            {
                                SettlementGrossOverdue det = new SettlementGrossOverdue();
                                Copy(x, det);
                                if (ex.SettlementGrossOverdue == null) ex.SettlementGrossOverdue = new List<SettlementGrossOverdue>();
                                ex.SettlementGrossOverdue.Add(det);
                            }
                        if (rcb.WaivedOverdue != null)
                            foreach (var x in rcb.WaivedOverdue)
                            {
                                SettlementWaivedOverdue det = new SettlementWaivedOverdue();
                                Copy(x, det);
                                if (ex.SettlementWaivedOverdue == null) ex.SettlementWaivedOverdue = new List<SettlementWaivedOverdue>();
                                ex.SettlementWaivedOverdue.Add(det);
                            }
                        if (contract.RentalOverdue == null) contract.RentalOverdue = new List<SettlementRentalOverdue>();
                        contract.RentalOverdue.Add(ex);
                    }
                else
                {
                    contract.RentalOverdue = new List<SettlementRentalOverdue>();
                }
                if (rcbl.RepaymentPlan != null && rcbl.RepaymentPlan.Count() > 0)
                    foreach (var rcb in rcbl.RepaymentPlan)
                    {
                        SettlementRepaymentPlan ex = new SettlementRepaymentPlan();
                        Copy(rcb, ex);
                        //if (rcb.ContractAssetMaintenanceReceivables != null)
                        //    foreach (var x in rcb.ContractAssetMaintenanceReceivables)
                        //    {
                        //        if (ex.ContractAssetMaintenanceReceivables == null) ex.ContractAssetMaintenanceReceivables = new List<ContractAssetMaintenanceReceivable>();
                        //        ex.ContractAssetMaintenanceReceivables.Add(x);
                        //    }
                        if (rcb.ReceiptRepaymentPlanTax != null)
                            foreach (var x in rcb.ReceiptRepaymentPlanTax)
                            {
                                SettlementRepaymentPlanTax det = new SettlementRepaymentPlanTax();
                                Copy(x, det);
                                if (ex.SettlementRepaymentPlanTax == null) ex.SettlementRepaymentPlanTax = new List<SettlementRepaymentPlanTax>();
                                ex.SettlementRepaymentPlanTax.Add(det);
                            }
                        if (contract.RepaymentPlan == null) contract.RepaymentPlan = new List<SettlementRepaymentPlan>();
                        contract.RepaymentPlan.Add(ex);
                    }
                else
                {
                    contract.RepaymentPlan = new List<SettlementRepaymentPlan>();
                }
                if (rcbl.SaleProceedContractReceivable != null && rcbl.SaleProceedContractReceivable.Count() > 0)
                    foreach (var rcb in rcbl.SaleProceedContractReceivable)
                    {
                        if (contract.SaleProceedContractSettlement == null) contract.SaleProceedContractSettlement = new List<SaleProceedReceivables>();
                        contract.SaleProceedContractSettlement.Add(rcb);
                    }
                else
                {
                    contract.SaleProceedContractSettlement = new List<SaleProceedReceivables>();
                }
                if (rcbl.RestructuringReceiptMain != null && rcbl.RestructuringReceiptMain.Count() > 0)
                    foreach (var rcb in rcbl.RestructuringReceiptMain)
                    {
                        if (contract.SettlementRestructuringReceiptMain == null) contract.SettlementRestructuringReceiptMain = new List<RestructuringReceiptMain>();
                        contract.SettlementRestructuringReceiptMain.Add(rcb);
                    }
                else
                {
                    contract.SettlementRestructuringReceiptMain = new List<RestructuringReceiptMain>();
                }
                if (rcbl.WriteOffRcvryReqtDetails != null && rcbl.WriteOffRcvryReqtDetails.Count() > 0)
                    foreach (var rcb in rcbl.WriteOffRcvryReqtDetails)
                    {
                        SettlementWriteOffRcvryReqtDetails ex = new SettlementWriteOffRcvryReqtDetails();
                        Copy(rcb, ex);
                        if (rcb.WOFFAMNTCMPT != null)
                            foreach (var x in rcb.WOFFAMNTCMPT)
                            {
                                SettlementWOFF_RCVY_AMNT_CMPT det = new SettlementWOFF_RCVY_AMNT_CMPT();
                                Copy(x, det);
                                if (ex.SettlementWOFFAMNTCMPT == null) ex.SettlementWOFFAMNTCMPT = new List<SettlementWOFF_RCVY_AMNT_CMPT>();
                                ex.SettlementWOFFAMNTCMPT.Add(det);
                            }
                        if (rcb.WOFFOVRDDET != null)
                            foreach (var x in rcb.WOFFOVRDDET)
                            {
                                SettlementWOFF_RCVY_OVRD_DET det = new SettlementWOFF_RCVY_OVRD_DET();
                                Copy(x, det);
                                if (ex.SettlementWOFFOVRDDET == null) ex.SettlementWOFFOVRDDET = new List<SettlementWOFF_RCVY_OVRD_DET>();
                                ex.SettlementWOFFOVRDDET.Add(det);
                            }
                        //if (rcb.WriteOffRcvryAdjInscPayable != null)
                        //    foreach (var x in rcb.WriteOffRcvryAdjInscPayable)
                        //    {
                        //        SettlementWriteOffRcvryAdjctInscPayable det = new SettlementWriteOffRcvryAdjctInscPayable();
                        //        Copy(x, det);
                        //        if (ex.SettlementWriteOffRcvryAdjInscPayable == null) ex.SettlementWriteOffRcvryAdjInscPayable = new List<SettlementWriteOffRcvryAdjctInscPayable>();
                        //        ex.SettlementWriteOffRcvryAdjInscPayable.Add(det);
                        //    }
                        if (rcb.WriteOffRcvryChrgDetails != null)
                            foreach (var x in rcb.WriteOffRcvryChrgDetails)
                            {
                                SettlementWriteOffRcvryChrgDetails det = new SettlementWriteOffRcvryChrgDetails();
                                Copy(x, det);
                                if (ex.SettlementWriteOffRcvryChrgDetails == null) ex.SettlementWriteOffRcvryChrgDetails = new List<SettlementWriteOffRcvryChrgDetails>();
                                ex.SettlementWriteOffRcvryChrgDetails.Add(det);
                            }
                        if (rcb.WriteOffRcvryRpmtPlan != null)
                            foreach (var x in rcb.WriteOffRcvryRpmtPlan)
                            {
                                SettlementWriteOffRcvryRpmtPlan det = new SettlementWriteOffRcvryRpmtPlan();
                                Copy(x, det);
                                if (ex.SettlementWriteOffRcvryRpmtPlan == null) ex.SettlementWriteOffRcvryRpmtPlan = new List<SettlementWriteOffRcvryRpmtPlan>();
                                ex.SettlementWriteOffRcvryRpmtPlan.Add(det);
                            }
                        //if (rcb.WriteOffRcvryUnAllctRcptDetails != null)
                        //    foreach (var x in rcb.WriteOffRcvryUnAllctRcptDetails)
                        //    {
                        //        SettlementWriteOffRcvryUnAllctRcptDet det = new SettlementWriteOffRcvryUnAllctRcptDet();
                        //        Copy(x, det);
                        //        if (ex.SettlementWriteOffRcvryUnAllctRcptDet == null) ex.SettlementWriteOffRcvryUnAllctRcptDet = new List<SettlementWriteOffRcvryUnAllctRcptDet>();
                        //        ex.SettlementWriteOffRcvryUnAllctRcptDet.Add(det);
                        //    }
                        if (contract.SettlementWriteOffRcvryReqtDetails == null) contract.SettlementWriteOffRcvryReqtDetails = new List<SettlementWriteOffRcvryReqtDetails>();
                        contract.SettlementWriteOffRcvryReqtDetails.Add(ex);
                    }
                else
                {
                    contract.SettlementWriteOffRcvryReqtDetails = new List<SettlementWriteOffRcvryReqtDetails>();
                }
                contracts.Add(contract);
            }
            return contracts;
        }

        public static List<ContractReceivables> CopyContractReceivablesToContractSettlement(List<ContractReceivables> receivable, List<ContractSettlement> settlements)
        {
            foreach (var receivables in receivable)
            {
                var settlement = settlements.FirstOrDefault(p => p.CONT_ID == receivables.CONT_ID);
                Copy(settlement, receivables);
                if (settlement.SettlementArticleClosingShortfall != null)
                    foreach (var rcb in settlement.SettlementArticleClosingShortfall)
                    {
                        Copy(rcb, receivables.ArticleClosingShortfall.First(p => p.SHRT_FALL_WOFF_MAIN_ID == rcb.SHRT_FALL_WOFF_MAIN_ID));
                        if (rcb.SettlementArticleClosingShortfallDet != null)
                            foreach (var x in rcb.SettlementArticleClosingShortfallDet)
                            {
                                Copy(x, receivables.ArticleClosingShortfall.First(p => p.SHRT_FALL_WOFF_MAIN_ID == rcb.SHRT_FALL_WOFF_MAIN_ID).ArticleClosingShortfallDet.First(a => a.SHRT_FALL_WOFF_DET_ID == x.SHRT_FALL_WOFF_DET_ID));
                            }
                        if (rcb.SettlementArticleClosingShortfallSundryCharges != null)
                            foreach (var x in rcb.SettlementArticleClosingShortfallSundryCharges)
                            {
                                Copy(x, receivables.ArticleClosingShortfall.First(p => p.SHRT_FALL_WOFF_MAIN_ID == rcb.SHRT_FALL_WOFF_MAIN_ID).ArticleClosingShortfallSundryCharges.First(a => a.SHRT_FALL_WOFF_CHRG_INFO_ID == x.SHRT_FALL_WOFF_CHRG_INFO_ID));
                            }
                    }
                if (settlement.SettlementArticleComponentTran != null)
                    foreach (var rcb in settlement.SettlementArticleComponentTran)
                    {
                        Copy(rcb, receivables.ArticleComponentTran.First(p => p.CONT_FINC_TRAN_ID == rcb.CONT_FINC_TRAN_ID));
                        if (rcb.SettlementArticleComponentsDetail != null)
                            foreach (var x in rcb.SettlementArticleComponentsDetail)
                            {
                                Copy(x, receivables.ArticleComponentTran.First(p => p.CONT_FINC_TRAN_ID == rcb.CONT_FINC_TRAN_ID).ReceiptArticleComponentsDetail.First(a => a.CONT_FINC_TRAN_RCBL_ID == x.CONT_FINC_TRAN_RCBL_ID));
                            }
                    }
                if (settlement.SettlementAsetCmptRcbl != null)
                    foreach (var rcb in settlement.SettlementAsetCmptRcbl)
                    {
                        Copy(rcb, receivables.AsetCmptRcbl.First(p => p.ASET_CMPT_RCBL_ID == rcb.ASET_CMPT_RCBL_ID));
                        if (rcb.SettlementAssetComponentReceivableCharge != null)
                            foreach (var x in rcb.SettlementAssetComponentReceivableCharge)
                            {
                                Copy(x, receivables.AsetCmptRcbl.First(p => p.ASET_CMPT_RCBL_ID == rcb.ASET_CMPT_RCBL_ID).AsetComponentReceivableCharge.First(a => a.ASET_CMPT_RCBL_CHRG_ID == x.ASET_CMPT_RCBL_CHRG_ID));
                            }
                    }
                if (settlement.ChargeReceivable != null)
                    foreach (var rcb in settlement.ChargeReceivable)
                    {
                        Copy(rcb, receivables.ChargeReceivable.First(p => p.CONT_CHRG_ID == rcb.CONT_CHRG_ID));
                        if (rcb.SettlementChargesReceivableTax != null)
                            foreach (var x in rcb.SettlementChargesReceivableTax)
                            {
                                Copy(x, receivables.ChargeReceivable.First(p => p.CONT_CHRG_ID == rcb.CONT_CHRG_ID).ReceiptChargesReceivableTax.First(a => a.CHRG_TAX_ID == x.CHRG_TAX_ID));
                            }
                    }
                if (settlement.ComponentRepaymentPlan != null)
                    foreach (var rcb in settlement.ComponentRepaymentPlan)
                    {
                        Copy(rcb, receivables.ComponentRepaymentPlan.First(p => p.CONT_CMPT_RPMT_PLAN_ID == rcb.CONT_CMPT_RPMT_PLAN_ID));
                        if (rcb.SettlementComponentPlanTax != null)
                            foreach (var x in rcb.SettlementComponentPlanTax)
                            {
                                Copy(x, receivables.ComponentRepaymentPlan.First(p => p.CONT_CMPT_RPMT_PLAN_ID == rcb.CONT_CMPT_RPMT_PLAN_ID).ReceiptComponentRepaymentPlanTax.First(a => a.CMPT_PLAN_TAX_ID == x.CMPT_PLAN_TAX_ID));
                            }
                    }
                if (settlement.ConsolidatedRepaymentPlan != null)
                    foreach (var rcb in settlement.ConsolidatedRepaymentPlan)
                    {
                        Copy(rcb, receivables.ConsolidatedRepaymentPlan.First(p => p.RPMT_PLAN_ID == rcb.RPMT_PLAN_ID));
                    }
                if (settlement.SettlementEtContractAmountComponent != null)
                    foreach (var rcb in settlement.SettlementEtContractAmountComponent)
                    {
                        Copy(rcb, receivables.EtContractAmountComponentSettlement.First(p => p.ET_QUOT_AMNT_CMPT_ID == rcb.ET_QUOT_AMNT_CMPT_ID));
                    }
                if (settlement.SettlementEtContractCharges != null)
                    foreach (var rcb in settlement.SettlementEtContractCharges)
                    {
                        Copy(rcb, receivables.EtContractCharges.First(p => p.ET_QUOT_CHRG_SETL_DET_ID == rcb.ET_QUOT_CHRG_SETL_DET_ID));
                    }
                if (settlement.SettlementEtContractRepaymentPlan != null)
                    foreach (var rcb in settlement.SettlementEtContractRepaymentPlan)
                    {
                        Copy(rcb, receivables.EtContractRepaymentPlanSettlement.First(p => p.ET_QUOT_RPMT_PLAN_ID == rcb.ET_QUOT_RPMT_PLAN_ID));
                        if (rcb.SettlementEtContractPlanTax != null)
                            foreach (var x in rcb.SettlementEtContractPlanTax)
                            {
                                Copy(x, receivables.EtContractRepaymentPlanSettlement.First(p => p.ET_QUOT_RPMT_PLAN_ID == rcb.ET_QUOT_RPMT_PLAN_ID).EtContractRepaymentPlanTaxSettlement.First(a => a.ET_QUOT_RPMT_TAX_ID == x.ET_QUOT_RPMT_TAX_ID));
                            }
                    }
                if (settlement.FinancedCharges != null)
                    foreach (var rcb in settlement.FinancedCharges)
                    {
                        Copy(rcb, receivables.FinancedCharges.First(p => p.CONT_FINC_CHRG_RPMT_PLAN_ID == rcb.CONT_FINC_CHRG_RPMT_PLAN_ID));
                        if (rcb.SettlementChargesPlanTax != null)
                            foreach (var x in rcb.SettlementChargesPlanTax)
                            {
                                Copy(x, receivables.FinancedCharges.First(p => p.CONT_FINC_CHRG_RPMT_PLAN_ID == rcb.CONT_FINC_CHRG_RPMT_PLAN_ID).ReceiptChargesPlanTax.First(a => a.FINC_CHRG_PLAN_TAX_ID == x.FINC_CHRG_PLAN_TAX_ID));
                            }
                    }
                if (settlement.RentalOverdue != null)
                    foreach (var rcb in settlement.RentalOverdue)
                    {
                        Copy(rcb, receivables.RentalOverdue.First(p => p.RNTL_OVRD_ID == rcb.RNTL_OVRD_ID));
                        if (rcb.SettlementRentalOverdueTax != null)
                            foreach (var x in rcb.SettlementRentalOverdueTax)
                            {
                                Copy(x, receivables.RentalOverdue.First(p => p.RNTL_OVRD_ID == rcb.RNTL_OVRD_ID).OverdueTaxDetails.First(a => a.RNTL_OVRD_TAX_ID == x.RNTL_OVRD_TAX_ID));
                            }
                        if (rcb.SettlementDueOverdue != null)
                            foreach (var x in rcb.SettlementDueOverdue)
                            {
                                Copy(x, receivables.RentalOverdue.First(p => p.RNTL_OVRD_ID == rcb.RNTL_OVRD_ID).DueOverdue.First(a => a.RNTL_ID == x.RNTL_ID));
                            }
                        if (rcb.SettlementPaidOverdue != null)
                            foreach (var x in rcb.SettlementPaidOverdue)
                            {
                                Copy(x, receivables.RentalOverdue.First(p => p.RNTL_OVRD_ID == rcb.RNTL_OVRD_ID).PaidOverdue.First(a => a.RNTL_ID == x.RNTL_ID));
                            }
                        if (rcb.SettlementGrossOverdue != null)
                            foreach (var x in rcb.SettlementGrossOverdue)
                            {
                                Copy(x, receivables.RentalOverdue.First(p => p.RNTL_OVRD_ID == rcb.RNTL_OVRD_ID).GrossOverdue.First(a => a.RNTL_ID == x.RNTL_ID));
                            }
                        if (rcb.SettlementWaivedOverdue != null)
                            foreach (var x in rcb.SettlementWaivedOverdue)
                            {
                                Copy(x, receivables.RentalOverdue.First(p => p.RNTL_OVRD_ID == rcb.RNTL_OVRD_ID).WaivedOverdue.First(a => a.RNTL_ID == x.RNTL_ID));
                            }
                    }
                if (settlement.RepaymentPlan != null)
                    foreach (var rcb in settlement.RepaymentPlan)
                    {
                        Copy(rcb, receivables.RepaymentPlan.First(p => p.RNTL_ID == rcb.RNTL_ID));
                        //foreach (var x in rcb.ContractAssetMaintenanceReceivables)
                        //{
                        //    ex.ContractAssetMaintenanceReceivables.Add(x);
                        //}
                        if (rcb.SettlementRepaymentPlanTax != null)
                            foreach (var x in rcb.SettlementRepaymentPlanTax)
                            {
                                Copy(x, receivables.RepaymentPlan.First(p => p.RNTL_ID == rcb.RNTL_ID).ReceiptRepaymentPlanTax.First(a => a.RPMT_PLAN_TAX_ID == x.RPMT_PLAN_TAX_ID));
                            }
                    }
                if (settlement.RepossessionReceivables != null)
                    foreach (var rcb in settlement.RepossessionReceivables)
                    {
                        Copy(rcb, receivables.RepossessionReceivables.First(p => p.REQT_MAIN_ID == rcb.REQT_MAIN_ID));
                    }
                if (settlement.SettlementRestructuringReceiptMain != null)
                    foreach (var rcb in settlement.SettlementRestructuringReceiptMain)
                    {
                        Copy(rcb, receivables.RestructuringReceiptMain.First(p => p.CONT_ID == rcb.CONT_ID));
                    }
                if (settlement.SettlementWriteOffRcvryReqtDetails != null)
                    foreach (var rcb in settlement.SettlementWriteOffRcvryReqtDetails)
                    {
                        Copy(rcb, receivables.WriteOffRcvryReqtDetails.First(p => p.RCVY_REQT_DET_ID == rcb.RCVY_REQT_DET_ID));
                        if (rcb.SettlementWOFFAMNTCMPT != null)
                            foreach (var x in rcb.SettlementWOFFAMNTCMPT)
                            {
                                Copy(x, receivables.WriteOffRcvryReqtDetails.First(p => p.RCVY_REQT_DET_ID == rcb.RCVY_REQT_DET_ID).WOFFAMNTCMPT.First(a => a.RCVY_REQT_DET_ID == x.RCVY_REQT_DET_ID));
                            }
                        if (rcb.SettlementWOFFOVRDDET != null)
                            foreach (var x in rcb.SettlementWOFFOVRDDET)
                            {
                                Copy(x, receivables.WriteOffRcvryReqtDetails.First(p => p.RCVY_REQT_DET_ID == rcb.RCVY_REQT_DET_ID).WOFFOVRDDET.First(a => a.RCVY_REQT_DET_ID == x.RCVY_REQT_DET_ID));
                            }
                        //if (rcb.SettlementWriteOffRcvryAdjInscPayable != null)
                        //    foreach (var x in rcb.SettlementWriteOffRcvryAdjInscPayable)
                        //    {
                        //        Copy(x, receivables.WriteOffRcvryReqtDetails.First(p => p.RCVY_REQT_DET_ID == rcb.RCVY_REQT_DET_ID).WriteOffRcvryAdjInscPayable.First(a => a.RCVY_REQT_DET_ID == x.RCVY_REQT_DET_ID));
                        //    }
                        if (rcb.SettlementWriteOffRcvryChrgDetails != null)
                            foreach (var x in rcb.SettlementWriteOffRcvryChrgDetails)
                            {
                                Copy(x, receivables.WriteOffRcvryReqtDetails.First(p => p.RCVY_REQT_DET_ID == rcb.RCVY_REQT_DET_ID).WriteOffRcvryChrgDetails.First(a => a.RCVY_REQT_DET_ID == x.RCVY_REQT_DET_ID));
                            }
                        if (rcb.SettlementWriteOffRcvryRpmtPlan != null)
                            foreach (var x in rcb.SettlementWriteOffRcvryRpmtPlan)
                            {
                                Copy(x, receivables.WriteOffRcvryReqtDetails.First(p => p.RCVY_REQT_DET_ID == rcb.RCVY_REQT_DET_ID).WriteOffRcvryRpmtPlan.First(a => a.RCVY_REQT_DET_ID == x.RCVY_REQT_DET_ID));
                            }
                        //if (rcb.SettlementWriteOffRcvryUnAllctRcptDet != null)
                        //    foreach (var x in rcb.SettlementWriteOffRcvryUnAllctRcptDet)
                        //    {
                        //        Copy(x, receivables.WriteOffRcvryReqtDetails.First(p => p.RCVY_REQT_DET_ID == rcb.RCVY_REQT_DET_ID).WriteOffRcvryUnAllctRcptDetails.First(a => a.RCVY_REQT_DET_ID == x.RCVY_REQT_DET_ID));
                        //    }
                    }

            }
            return receivable;
        }

        public static void Copy(object parent, object child)
        {
            var parentProperties = parent.GetType().GetProperties();
            var childProperties = child.GetType().GetProperties();
                foreach (var parentProperty in parentProperties)
                {
                    foreach (var childProperty in childProperties)
                    {
                        if (parentProperty.Name == childProperty.Name && parentProperty.PropertyType == childProperty.PropertyType)
                        {
                            childProperty.SetValue(child, parentProperty.GetValue(parent));
                            break;
                        }
                    }
                }
        }

        public static List<T> InitializeIfNull<T>(List<T> list) where T : BaseModel
        {
            if (list == null)
            {
                list = new List<T>();
            }
            return list;
        }

        private static void UpdateAutoRecieptPaymentMode(Receipt rcpt)
        {
            if (rcpt.SD_ADJT_IND == true || rcpt.AUTO_RCPT_IND == true)
            {
                string paymentSource;
                if (rcpt.SRC != null)
                {
                    if (PaymentSourceForAutoReceipt.TryGetValue(rcpt.SRC, out paymentSource))
                        rcpt.RCPT_PYMT_MODE_NME = paymentSource;
                }
            }
        }        

        #endregion

        #region Fill Param

        /// <summary>
        /// Inititializes the settlement.
        /// </summary>
        /// <param name="batchData">The batch data.</param>
        /// <param name="criteria">The criteria.</param>
        /// <returns></returns>
        public static ReceiptParam InititializeSettlement(ReceiptParam batchData, ReceiptCriteria criteria)
        {
            try
            {
                ReceiptParam taskParam = new ReceiptParam();
                taskParam.IsBulk = true;
                taskParam.ReceiptType = (ReceiptType)Enum.Parse(typeof(ReceiptType), criteria.ReceiptTypeId.ToString());
                taskParam.IsContractActivation = criteria.IsContractActivation;
                taskParam.IsManualReceipt = criteria.IsManualReceipt;
                taskParam.IsPreactivation = criteria.IsPreactivation;
                taskParam.ProcessQueueId = batchData.ProcessQueueId;
                taskParam.ValueDte = batchData.ProcessingDte;
                taskParam.ProcessingDte = batchData.ProcessingDte;
                taskParam.CompanyId = batchData.CompanyId;
                taskParam.BranchId = batchData.BranchId; ;
                taskParam.RequestId = criteria.RequestId;
                taskParam.IsArticleReturn = criteria.IsArticleReturn;
                taskParam.ArticleReturnSource = criteria.ArticleReturnSource;
                taskParam.IsEtFinalReceipt = criteria.IsEtFinalReceipt;
                taskParam.SdAdjustAmount = criteria.SdAdjustAmount;
                taskParam.InsuranceAdjustAmount = criteria.InsuranceAdjustAmount;
                taskParam.ReceiptCriteria = new List<ReceiptCriteria>() { criteria };
                List<int> contractList = GetContractList(taskParam);
                if (contractList != null && batchData != null)
                {
                    if (batchData.SettlementParam.ContractTemplateIds != null)
                    {
                        taskParam.SettlementParam.ContractTemplateIds = batchData.SettlementParam.ContractTemplateIds.FindAll(p => contractList.Contains(p.CONT_ID));
                        // ReSharper disable once ConditionIsAlwaysTrueOrFalse
                        if (batchData.SettlementParam.PriorityTemplates != null && taskParam.SettlementParam.ContractTemplateIds != null)
                        {
                            taskParam.SettlementParam.PriorityTemplates = batchData.SettlementParam.PriorityTemplates.FindAll(p => taskParam.SettlementParam.ContractTemplateIds.Exists(q => q.ATTACHED_TEMPLATE_ID == p.TMPL_SETL_MODL_ATCH_ID));
                        }
                    }
                    if (batchData.SettlementParam.ContractOverPaymentDetail != null)
                    {
                        taskParam.SettlementParam.ContractOverPaymentDetail = batchData.SettlementParam.ContractOverPaymentDetail.FindAll(p => contractList.Contains(p.CONT_ID));
                    }
                    taskParam.ContractIds = contractList;
                }
                //taskParam.ProcessingDte = criteria.BatchProcessCriteria.ProcessingDate;
                taskParam.DepositType = DepositTypes.None;
                return taskParam;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return null;
        }

        public static ReceiptParam FillParam(InterfaceReceipt interfaceReceipt, Context context, int companyId, int branchId, int contId, int businessPartnerId, int currencyId)
        {
            ReceiptParam param = new ReceiptParam();
            param.ValueDte = Convert.ToDateTime(interfaceReceipt.PaymentReceivedDate);
            param.ProcessingDte = Convert.ToDateTime(context.WorkDate);
            param.ReceiptType = ReceiptType.NormalReceipt;
            param.CurrencyId = currencyId;
            if (param.Receipts == null)
                param.Receipts = new List<Receipt>();
            param.Receipts.Add(AutoReceiptManagement.PrepareReceipt(context, businessPartnerId, companyId, branchId, Convert.ToDecimal(interfaceReceipt.AmountReceived), contId, param.ReceiptType, param.ValueDte, interfaceReceipt.ContractId, param.CurrencyId));
            return param;
        }

        public static ReceiptParam FillEftReceiptParam(ReceiptData eftReceipt, Context context, int companyId, int branchId, int contId, int? businessPartnerId, int currencyId, int receiptTypeId, bool isMisc, ApprovedEtQuotes etQuotes = null, RequestReceiptParam restructuringRequest = null)
        {
            ReceiptParam param = new ReceiptParam();
            param.ValueDte = Convert.ToDateTime(eftReceipt.EftDateTime).Date;//skip time
            param.ProcessingDte = Convert.ToDateTime(eftReceipt.EftDateTime).Date;
            param.ReceiptType = Enum.GetValues(typeof(ReceiptType)).Cast<ReceiptType>().FirstOrDefault(p => Convert.ToInt32(p) == receiptTypeId);
            param.CurrencyId = currencyId;
            if (param.Receipts == null)
                param.Receipts = new List<Receipt>();
            if (param.ReceiptType == ReceiptType.EarlyTerminationReceipt)
            {
                if (etQuotes != null)
                    FillEtParam(etQuotes, param);
            }
            else if (param.ReceiptType == ReceiptType.RestructuringReceipt)
            {
                if (restructuringRequest != null)
                    FillRestructuringParam(restructuringRequest, param);
            }
            param.Receipts.Add(AutoReceiptManagement.PrepareReceipt(context, businessPartnerId, companyId, branchId, Convert.ToDecimal(eftReceipt.EftAmount), contId, param.ReceiptType, param.ValueDte, eftReceipt.ContractNo, param.CurrencyId, eftReceipt.PaymentMode));
            if (!string.IsNullOrEmpty(eftReceipt.ReceiptDate))
            {
                param.Receipts.FirstOrDefault().RCPT_DTE = Convert.ToDateTime(eftReceipt.ReceiptDate);
            }
            param.Receipts.FirstOrDefault().RMRK = eftReceipt.Comments;
            param.Receipts.FirstOrDefault().DRWR_NME = eftReceipt.RemitterName;
            if (isMisc)
            {
                param.Receipts.FirstOrDefault().MISC_AMNT = eftReceipt.EftAmount;
                var receiptDetail = param.Receipts.FirstOrDefault()?.ReceiptDetail?.FirstOrDefault();
                param.Receipts.FirstOrDefault().ReceiptDetail?.Remove(receiptDetail);
            }
            else
            {
                if (param.EtQuoteId > 0) param.Receipts.FirstOrDefault().ReceiptDetail.FirstOrDefault().ET_QUOT_ID = param.EtQuoteId;
                if (param.RequestId > 0) param.Receipts.FirstOrDefault().ReceiptDetail.FirstOrDefault().REQT_ID = param.RequestId;
            }
            if (param.Receipts.FirstOrDefault()?.RCPT_CRCY_ID == 0)
                param.Receipts.FirstOrDefault().RCPT_CRCY_ID = null;
            return param;
        }

        private static void FillEtParam(ApprovedEtQuotes etQuotes, ReceiptParam param)
        {
            decimal etQuotationAmount = 0;
            param.EtQuoteId = etQuotes.ET_QUOT_MAIN_ID;
            param.EtCushionAmount = etQuotes.CSHN_AMNT;
            param.RequestId = etQuotes.ET_REQT_MAIN_ID;
            param.SdAdjustAmount = etQuotes.SECR_DPST_AMNT;
            param.Discount = etQuotes.DISCOUNT;
            param.UnallocatedAmount = etQuotes.UN_ALCT_AMNT;
            
            if (Convert.ToDecimal(etQuotes.MNUL_NET_RCBL_AMNT) > 0)
                etQuotationAmount = Convert.ToDecimal(etQuotes.MNUL_NET_RCBL_AMNT);
            else
                etQuotationAmount = Convert.ToDecimal(etQuotes.GROS_RCBL_AMNT);

            if (etQuotes.ET_DCSN_TYPE_KEY == OtpOptions.Return.GetKey())
            {
                param.IsArticleReturn = true;
            }
            else
            {
                param.IsArticleReturn = false;
            }
            param.EtAmount = etQuotationAmount;           
        }

        private static void FillRestructuringParam(RequestReceiptParam restructuringRequest, ReceiptParam param)
        {
            param.SdAdjustAmount = restructuringRequest.SdAjustAmount;
            param.RequestId = restructuringRequest.TaskQueuId;                        
        }


        public static RequestObject<SettlementResponse> FillWorkFlowParam(SettlementResponse settlementResponseObj, Context context, int branchId, int receiptId)
        {
            RequestObject<SettlementResponse> settlementResponse = new RequestObject<SettlementResponse>(context, settlementResponseObj);
            settlementResponse.Object.ResumeWorkflow = true;
            settlementResponse.WorkflowInput = new WorkflowInputParams();
            settlementResponse.WorkflowInput.PostAction = true;
            settlementResponse.WorkflowInput.ScreenId = 2412;
            settlementResponse.WorkflowInput.ScreenAction = "Submit";
            settlementResponse.WorkflowInput.Session = context;
            settlementResponse.WorkflowInput.Entity = settlementResponseObj;
            settlementResponse.WorkflowInput.EntityType = typeof(SettlementResponse).ToString();
            settlementResponse.WorkflowInput.BranchId = branchId;
            settlementResponse.WorkflowInput.ApplicationKey = "CMS";
            settlementResponse.WorkflowInput.Module = ModuleTypeCode.RECEIPT.GetKey();
            settlementResponse.WorkflowInput.ReferenceId = receiptId;
            return settlementResponse;
        }

        /// <summary>
        /// Persists the diary for PEGA Interface.
        /// </summary>
        public static void PersistDiaryForPegaInterafce(Context context,int receiptDetailId, string status, string comments)
        {
            var diaryEntry = new DiaryEntry
            {
                CMNT = comments,
                DIRY_IND = true,
                ENRY_TYPE_KEY = EntryTypes.Automatic.GetKey(),
                REQT_TYPE_KEY = RequestTypeCodes.ReceiptRequest.GetKey(),
                EVNT_DTE_TIME = DateTime.UtcNow,
                REF_MDUL_KEY = ModuleTypeCode.CSI.GetKey(),
                USR_NME = context.UserName,
                CTXT_ID = Convert.ToString(context.ContextId),
                REF_NUMB = Convert.ToString(receiptDetailId),
                STS_KEY = status
            };
            var requestObjectDiary = new RequestObject<DiaryEntry>(context, diaryEntry);
            using (var diaryService = new ProxyClient<IDiaryService>())
            {
                var result = diaryService.ClientInstance.PersistDiaryEntry(requestObjectDiary);
            }
        }

        /// <summary>
        /// Persists event data.
        /// </summary>
        public static void TriggerEvent(Context context, int contId, string requestType,int? Refid3=null,int? processId=null, string refId2 = null)
        {
            EventParm eventParam = new EventParm()
            {
                RequestType = requestType,
                ApplicationKey = null,
                BranchID = 1,
                EventId = 11,
                ContextData = context,
                ModuleKey = ModuleTypeCode.RECEIPT.GetKey(),
                FcId = 1,
                RefId1 = Convert.ToString(contId),
                RefId2 = refId2,
                RefId3 = Refid3 == null? null : Convert.ToString(Refid3),
                RefId4 = processId == null? null : Convert.ToString(processId), 
                PostActionsEnum = new List<EventDispatcherEnum>() { EventDispatcherEnum.AccountingListenerEvent }
            };
            var request = new RequestObject<EventParm>(context, eventParam);
            using (var svc = new ProxyClient<IEventDispatcherLogicService>(true))
            {
                svc.ClientInstance.TriggerEvent(request);
            }
        }

        public static void FillOtpDecision(ReceiptParam param, List<OtpDecisionInfo> OtpDecisions)
        {
            if (HasData(OtpDecisions))
            {
                if (param.OtpDecisions == null) param.OtpDecisions = new List<OtpDecisionInfo>();
                foreach (var item in OtpDecisions)
                {
                    if (!param.OtpDecisions.Exists(p => p.ContractId == item.ContractId))
                    {
                        param.OtpDecisions.Add(item);
                    }
                }
            }
        }
        
        #endregion

        #region Misc. Register

        /// <summary>
        /// Updates the Incom amount.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static bool UpdateIncomAmount(ReceiptParam param)
        {
            try
            {
                if (param != null && param.Receipts.Count > 0)
                {
                    if (param.Receipts.First().MISC_AMNT == null)
                    {
                        param.Receipts.First().MISC_AMNT = 0;
                    }
                    if (param.Receipts.First().INCM_AMNT == null)
                    {
                        param.Receipts.First().INCM_AMNT = 0;
                    }
                    param.Receipts.First().MISC_AMNT -= param.IncomAmount;
                    param.Receipts.First().INCM_AMNT += param.IncomAmount;
                }

                if (param?.Receipts.First().RCPT_AMNT == param?.Receipts.First().INCM_AMNT)
                {
                    if (param != null) param.Receipts.First().STS_KEY = StatusCode.Income.GetKey();
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return false;
            }
        }

        /// <summary>
        /// Updates the refund amount.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static bool UpdateRefundAmount(ReceiptParam param)
        {
            try
            {
                if (param != null && param.Receipts.Count > 0)
                {
                    if (param.Receipts.First().MISC_AMNT == null)
                    {
                        param.Receipts.First().MISC_AMNT = 0;
                    }
                    if (param.Receipts.First().RFND_AMNT == null)
                    {
                        param.Receipts.First().RFND_AMNT = 0;
                    }
                    param.Receipts.First().MISC_AMNT -= param.RefundAmount;
                    param.Receipts.First().RFND_AMNT += param.RefundAmount;
                }
                //update receipt status
                if (param?.Receipts.First().RCPT_AMNT == param?.Receipts.First().RFND_AMNT)
                {
                    if (param != null) param.Receipts.First().STS_KEY = StatusCode.Refunded.GetKey();
                }
                //TODO: add allocation
                return true;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return false;
            }
        }

        /// <summary>
        /// Updates the Loss amount.
        /// </summary>
        /// <param name="param">The parameter.</param>
        /// <returns></returns>
        public static bool UpdateLossAmount(ReceiptParam param)
        {
            try
            {
                if (param != null && param.Receipts.Count > 0)
                {
                    if (param.Receipts.First().MISC_AMNT == null)
                    {
                        param.Receipts.First().MISC_AMNT = 0;
                    }
                    if (param.Receipts.First().LOSS_AMNT == null)
                    {
                        param.Receipts.First().LOSS_AMNT = 0;
                    }
                    param.Receipts.First().MISC_AMNT -= param.LossAmount;
                    param.Receipts.First().LOSS_AMNT += param.LossAmount;
                }
                return true;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return false;
            }
        }

        public static ReceiptMiscDetail FillReceiptMiscDetail(int rcptId, int? contId, string statusCode, decimal? balanceAmt)
        {
            ReceiptMiscDetail receiptMisc = new ReceiptMiscDetail();
            receiptMisc.MISC_AMNT = Convert.ToDecimal(balanceAmt);
            receiptMisc.RCPT_ID = rcptId;
            receiptMisc.STS_KEY = statusCode;
            receiptMisc.CONT_ID = contId;
            return receiptMisc;
        }

        #endregion

        #region Temp / Unused Methods

        /// <summary>
        /// Gets the date.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static DateTime GetDate(DateTime? date)
        {
            return Convert.ToDateTime(date);
        }

        /// <summary>
        /// Converts to int.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static int ConvertToInt(object value)
        {
            //return Convert.ToInt64(value);
            return Convert.ToInt32(value);
        }

        #endregion

        #region Receivables

        public static List<ReceivableDetail> GetContractReceivables(DateTime processing_dte, DateTime value_date, String cont_id, String asset_id)
        {
            var receivables = ReceivableDetail.GetContractReceivables(processing_dte, value_date, cont_id, asset_id);
            if (HasData(receivables))
            {
                foreach (var item in receivables)
                {
                    if (item.DUERECEIVABLES < 0) item.DUERECEIVABLES = 0;
                    if (item.TOTALRECEIVABLES < 0) item.TOTALRECEIVABLES = 0;
                }
            }
            return receivables;
        }

        public static List<TotalReceivableDetail> GetTotalReceivables(int cont_id)
        {
            var receivables = TotalReceivableDetail.ReadTotalReceivableDetail(cont_id);
            if (HasData(receivables))
            {
                foreach (var item in receivables)
                {
                    if (item.TOTALRECEIVABLES < 0) item.TOTALRECEIVABLES = 0;
                }
            }
            return receivables;
        }

        public static bool IsFinalNormalReceipt(ReceiptParam param , Context context)
        {
            bool flag = false;            
            try
            {
                if (HasData(param.SettlementParam.ReceiptContractAssociation.ReceiptAllocation))
                {
                    var rcbl = GetTotalReceivables(Convert.ToInt32(param.SettlementParam.ReceiptContractAssociation.CONT_ID));
                    if (rcbl != null)
                    {
                        #region Handle Rv                                                
                        if (!HasData(param.OtpDecisions)) param.OtpDecisions = ReceiptManagement.ReadOtpDecision(param, context);
                        if (HasData(param.OtpDecisions))
                        {
                            foreach (var otpDecision in param.OtpDecisions)
                            {
                                if (!IsOtpNotApplicableOrPurchase(otpDecision))
                                {
                                    foreach (var receivable in rcbl)
                                    {
                                        ReceivablesHelper.DeductRv(receivable, otpDecision);
                                    }
                                }
                            }
                        }
                        #endregion

                        if (rcbl.Sum(p => p.TOTALRECEIVABLES) - param.SettlementParam.ReceiptContractAssociation.ReceiptAllocation.Sum(p => p.SETL_AMNT) <= 1)
                        {
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return flag;          
        }

        #endregion
    }
}
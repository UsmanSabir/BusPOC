﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Models.DirectDebit;
using CMS.Models.DirectDebit.Custom;
using CMS.Models.Receipting.Custom;

namespace CMS.DirectDebit.Business.Settlement
{
    class DdOverdueSettlement : DirectDebitSettlementBase
    {
       
    }
}

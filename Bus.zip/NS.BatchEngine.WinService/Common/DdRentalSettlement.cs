﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Models.DirectDebit;
using CMS.Models.DirectDebit.Custom;
using CMS.Models.Receipting.Custom;
using CMS.Models.Receipting;
using NFS.Models.BusinessPartner.Custom.Enum;
using CMS.Business.Helper.Utility;
using NS.Resources.Enums.Common;
using NS.Utilities.Enums;
using NS.ServiceModel;
using CMS.ServiceContracts;
using NS.Resources.Enums.Receipt;

namespace CMS.DirectDebit.Business.Settlement
{
    public class DdRentalSettlement : DirectDebitSettlementBase
    {
      
    }
}

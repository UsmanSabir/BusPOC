﻿using NS.BaseModels;
using NS.ORM;
using CMS.ServiceContracts;
using System.Collections.Generic;
using CMS.Models.DirectDebit;
using CMS.Models.DirectDebit.Custom;
using System;
using System.Linq;
using NS.Resources.Enums.Common;
using CMS.Models.Receipting.Custom;
using NFS.Models.AttachedTemplates;
using BatchBootstrapper.Common;
using CMS.Business.Helper.Utility;
using CMS.Models.Receipting;
using CMS.Models.ContractActivation;
using NS.Utilities.Enums;
using NS.ServiceModel;
using NS.Models.IntegrationHub.Custom.Param;
using IHEnums = NS.Models.IntegrationHub.Enums;
using NS.ServiceContracts;
using NS.ExceptionHandling;
using NS.Utilities.Context;
using CMS.DirectDebit.Business.Generation;
using NS.Resources.Enums.DirectDebit;
using CMS.DirectDebit.Business.Settlement;
using CMS.Models.Receipting.Custom.Criteria;
using NFS.Models.BusinessPartner.Custom.Enum;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Linq.Expressions;
using CMS.Models.Custom.Param;
using NFS.ServiceContracts;
using NFS.Models.Custom.Param;
using NFS.Models.BatchProcess.Custom;
using NS.Utilities.Helper;
using NS.Resources.Enums.InvokeType;
using System.Threading.Tasks;
using CMS.Business.Helper.Manage;
using NFS.Models.BatchProcessModel;
using NS.Resources.Enums.BatchProcess;

// ReSharper disable once CheckNamespace
namespace CMS.Business
{
    public class DirectDebitLogic : IDirectDebitService
    {
        string ContractNumber;

        #region Configuration

        public ResponseObject<DdTemplateAttach> ReadDdTemplate(RequestObject<int> requestObject)
        {
            bool isError = false;
            var companyId = requestObject.Object;
            ResponseObject<DdTemplateAttach> response = new ResponseObject<DdTemplateAttach>();
            //get DD template associated with this finance company
            var fpTmplAsocCtx = EntityContextExt<FPTemplateAssociation>.Create();
            var tmplAssoc = fpTmplAsocCtx.Read(s => s.CMPY_ID == companyId && s.TMPL_TYPE_ID == (int)TemplateTypes.DirectDebit, 1);

            //if nothing was found attached this 
            if (tmplAssoc.Entity.Count == 0)
            {
                isError = true;
            }
            var asoc = tmplAssoc.Entity.Find(p => p.TMPL_ATCH_ID > 0);
            if (asoc != null)
            {
                var ddTmplAtchCtx = EntityContextExt<DdTemplateAttach>.Create();
                var ddTmplAtch = ddTmplAtchCtx.Read(s => s.TMPL_DD_ATCH_ID == asoc.TMPL_ATCH_ID);
                if (ddTmplAtch.Entity.Count > 0)
                {
                    return ServiceHelper.SuccessResponse(ddTmplAtch.Entity.FirstOrDefault());
                }
                else
                {
                    isError = true;
                }
            }
            else
            {
                isError = true;
            }
            if (isError)
            {
                response.Message = new MessageInfo();
                response.Message.Type = MessageType.Error;                
                response.Message.CustomMessage = "DD template is not associated with finance company with id {companyId}";
                response.ResultSet = null;
            }
            return response;
        }

        private List<DDHoldConfig> ReadDDHoldConfig(DirectDebitParam ddParam, int contractId)
        {
            var contextDDHold = EntityContextExt.Create<DDHoldConfig>();
            List<DDHoldConfig> ContDDConfig = new List<DDHoldConfig>();
            if (contextDDHold != null)
            {
                contextDDHold.Read(x => x.CONT_ID == contractId); //Cont_Id
                var data = contextDDHold.Entity;
                if (data != null && data.Count > 0)
                {
                    return data;
                }
            }
            return null;
        }

        public ResponseObject<bool> IsDdPendingConfig(RequestObject<int> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
                var contextExt = EntityContextExt.Create<ReadDDMiscConfig>();
                ReadDDMiscConfig DDMiscConfig = new ReadDDMiscConfig();
                if (contextExt != null)
                {
                    contextExt.Read(requestObject.Object);
                    var data = contextExt.Entity;
                    DDMiscConfig = data.FirstOrDefault();
                    response.ResultSet = DDMiscConfig.DD_PEND_IND;
                }
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }
        public ReadDDMiscConfig ReadMiscDDConfig(DirectDebitParam ddParam)
        {
            var contextExt = EntityContextExt.Create<ReadDDMiscConfig>();
            ReadDDMiscConfig DDMiscConfig = new ReadDDMiscConfig();
            if (contextExt != null)
            {
                contextExt.Read(ddParam.FinanceCompanyId);
                var data = contextExt.Entity;
                DDMiscConfig = data.FirstOrDefault();
            }
            return DDMiscConfig;
        }

        #endregion

        #region Batch Processes

        #region Volume

        /// <summary>
        /// This function will get the direct debit volume for batch processor.
        /// </summary>
        /// <param name="requestObject"></param>
        /// <returns>A response object wrapping a tuple whose first element will containt dd generation header, and second element will contain contract id.</returns>
        public ResponseObject<List<int>> GetDirectDebitVolumeForBatchProcess(RequestObject<DirectDebitParam> requestObject)
        {
            var volumeResponse = new List<int>();

            //calculate to/from dates11
            DirectDebitParam ddParam = new DirectDebitParam();
            if (requestObject.Object.IsManual)
            {
                ddParam = requestObject.Object;
            }
            else
            {
                ddParam = CalculateFromToDates(new RequestObject<DirectDebitParam>(requestObject.Context, requestObject.Object)).ResultSet;
            }


            if (ddParam == null)
            {                
               // //commonhelper("DD template is not associated with Finance Company.", requestObject.Context,0, NSLogLevel.Error);
                return ServiceHelper.SuccessResponse(volumeResponse);
            }                

            //first get all contract that require dd generation in this branch/finance company
            var contsToProcess = GetContractsToProcess(ddParam.FinanceCompanyId, ddParam.BranchId, ddParam.EffectiveToDate, ddParam.EffectiveFromDate);

            if (contsToProcess.Count == 0)
            {
                return ServiceHelper.SuccessResponse(volumeResponse);
            }

            //group contract by fc bank (as there will be a separate file for each bank)
            var groups = contsToProcess.GroupBy(s => s.FC_BANK_ID, (key, g) => new { FcBankId = key.GetValueOrDefault(0), Contracts = g.Select(t => t.CONT_ID) });

            //make a DdGenerationMain object and get its id
            int ddGenrMainId = GenerateDdGenrMain(ddParam);

            //go through each fc bank
            foreach (var group in groups)
            {
                //a new Dd header for each bank
                var ddGenHeaderId = GenerateDdHeader(group.Contracts.First(), ddGenrMainId);

                //add contract ids to process (the volume for batch process)
                volumeResponse.AddRange(group.Contracts);
            }

            return ServiceHelper.SuccessResponse(volumeResponse);
        }

        private List<DdGenrContractToProcess> GetContractsToProcess(int companyId, int branchId, DateTime effectiveToDate, DateTime effectiveFromDate)
        {
            List<DdGenrContractToProcess> volume = new List<DdGenrContractToProcess>();
            var pageInfocontext = EntityContextExt<DdVolumePagesInfo>.Create(commandTimeOut: 600);
            var pageInfo = pageInfocontext.Read(companyId, branchId, 10000).Entity;           
            if (pageInfo != null && pageInfo.Count > 0)
            {
                foreach (var page in pageInfo)
                {                    
                    var ddpage = ReadDDGenrContractToProcess(companyId, branchId, effectiveToDate, page.STRT_DD_GENR_ID.Value, page.END_DD_GENR_ID.Value, effectiveFromDate);
                    if (ddpage != null)
                    {
                        volume.AddRange(ddpage);

                    }
                }
            }

            var nonLivePageInfo = DdVolumePagesInfo.ReadPagesInfoForNonLiveContracts(companyId, branchId, 10000);
            if (nonLivePageInfo != null && nonLivePageInfo.Count > 0)
            {
                foreach (var page in nonLivePageInfo)
                {
                    var ddpage = ReadDDGenrNonLiveContractToProcess(companyId, branchId, effectiveToDate, page.STRT_DD_GENR_ID.Value, page.END_DD_GENR_ID.Value, effectiveFromDate);
                    if (ddpage != null)
                    {
                        volume.AddRange(ddpage);

                    }
                }
            }

            return volume;
        }
        private List<DdGenrContractToProcess> ReadDDGenrContractToProcess(int company_id, int branch_id, DateTime value_date, int from_cont, int to_cont, DateTime effectiveFromDate)
        {
            EntityContextExt<DdGenrContractToProcess> c = EntityContextExt.Create<DdGenrContractToProcess>(commandTimeOut: 600);
            c.EnableQueryPlanOptimization();
            c.ReadEntityByKey(new Dictionary<string, object>()
                {
                    {"company_id", company_id},
                    {"branch_id", branch_id},
                    {"value_date", value_date},
                    {"from_cont", from_cont},
                    {"to_cont", to_cont},
                    {"effectiveFromDate", effectiveFromDate},
                }, nameof(ReadDDGenrContractToProcess)
            );
            //if (fillChilds)
            //    c.FillChilds();
            return c.Entity;
        }

        private List<DdGenrContractToProcess> ReadDDGenrNonLiveContractToProcess(int company_id, int branch_id, DateTime value_date, int from_cont, int to_cont, DateTime effectiveFromDate)
        {
            EntityContextExt<DdGenrContractToProcess> c = EntityContextExt.Create<DdGenrContractToProcess>(commandTimeOut: 600);
            c.EnableQueryPlanOptimization();
            c.ReadEntityByKey(new Dictionary<string, object>()
                {
                    {"company_id", company_id},
                    {"branch_id", branch_id},
                    {"value_date", value_date},
                    {"from_cont", from_cont},
                    {"to_cont", to_cont},
                    {"effectiveFromDate", effectiveFromDate},
                }, nameof(ReadDDGenrNonLiveContractToProcess)
            );
            //if (fillChilds)
            //    c.FillChilds();
            return c.Entity;
        }



        /// <summary>
        /// This function will get the direct debit response volume for batch processor.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public ResponseObject<Dictionary<int, List<DdResponseVolume>>> GetDirectDebitResponseVolume(RequestObject<int> requestObject, int batchSize)
        {           
            Dictionary<int, List<DdResponseVolume>> volumeResponse = null;
            try
            {
                var context = EntityContextExt<DdResponseVolume>.Create();

                var result = DdResponseVolume.Read(requestObject.Object);// context.Read(p => p.PRCS_QUEU_ID == requestObject.Object).Entity;

                if (result != null && result.Count > 0)
                {
                    List<DdResponseVolume> volumeList = new List<DdResponseVolume>();
                    List<DdResponseVolume> repeatedContList = new List<DdResponseVolume>();
                    for (int i = 0; i < result.Count; i++)
                    {
                        if (volumeList.Count > 0 && volumeList.Exists(p => p.CONT_NUMB == result[i].CONT_NUMB))
                        {
                            repeatedContList.Add(volumeList.First(p => p.CONT_NUMB == result[i].CONT_NUMB));
                            volumeList.RemoveAll(p => p.CONT_NUMB == result[i].CONT_NUMB);
                            repeatedContList.Add(result[i]);
                        }
                        else
                        {
                            if (repeatedContList.Count > 0 && repeatedContList.Exists(p => p.CONT_NUMB == result[i].CONT_NUMB))
                            {
                                repeatedContList.Add(result[i]);
                            }
                            else
                            {
                                volumeList.Add(result[i]);
                            }
                        }
                    }

                    volumeResponse = new Dictionary<int, List<DdResponseVolume>>();
                    if (volumeList?.Count > 0)
                    {
                        volumeResponse.Add(0, volumeList);
                    }

                    if (repeatedContList?.Count > 0)
                    {
                        var grouped = repeatedContList.GroupBy(s => s.CONT_NUMB, (key, g) => new { SeqNum = key, Items = g.ToList() }).ToList();
                        List<DdResponseVolume> batchList = new List<DdResponseVolume>();
                        for (int i = 0; i < grouped.Count; i++)
                        { 
                            
                            if (grouped[i].Items?.Count > 0)
                            {
                                if (batchList?.Count > 0)
                                {
                                    if ((batchList.Count + grouped[i].Items.Count) <= batchSize)
                                    {
                                        batchList.AddRange(grouped[i].Items);
                                    }
                                    else
                                    {
                                        AddVolumeItems(volumeResponse, batchList);

                                        batchList = new List<DdResponseVolume>();
                                        batchList.AddRange(grouped[i].Items);
                                    }
                                }
                                else
                                {
                                    batchList.AddRange(grouped[i].Items);
                                }
                            }

                            if ((i + 1) == grouped.Count)
                            {
                                if (batchList?.Count > 0)
                                {
                                    AddVolumeItems(volumeResponse, batchList);                                   
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<Dictionary<int, List<DdResponseVolume>>>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }
            return ServiceHelper.SuccessResponse(volumeResponse);
        }

        private void AddVolumeItems(Dictionary<int, List<DdResponseVolume>> volumeResponse, List<DdResponseVolume> batchList)
        {
            if (volumeResponse != null && volumeResponse.Count > 0)
            {
               int key = volumeResponse.Keys.Max();
                volumeResponse.Add((++key), batchList);
            }
            else
            {
                volumeResponse.Add((0), batchList);
            }
        }

        /// <summary>
        /// This function will get the direct debit response volume for batch processor.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public ResponseObject<Dictionary<int, List<DdResponseVolume>>> GetDirectDebitResponseVolumeByRefId(RequestObject<string> requestObject, int batchSize)
        {            
            Dictionary<int, List<DdResponseVolume>> volumeResponse = null;
           
            try
            {
                var context = EntityContextExt<DdResponseVolume>.Create();

                var result = DdResponseVolume.ReadVolumeByRefId(requestObject.Object);

                if (result != null && result.Count > 0)
                {
                    List<DdResponseVolume> volumeList = new List<DdResponseVolume>();
                    List<DdResponseVolume> repeatedContList = new List<DdResponseVolume>();
                    for (int i = 0; i < result.Count; i++)
                    {
                        if (volumeList.Count > 0 && volumeList.Exists(p => p.CONT_NUMB == result[i].CONT_NUMB))
                        {
                            repeatedContList.Add(volumeList.First(p => p.CONT_NUMB == result[i].CONT_NUMB));
                            volumeList.RemoveAll(p => p.CONT_NUMB == result[i].CONT_NUMB);
                            repeatedContList.Add(result[i]);
                        }
                        else
                        {
                            if (repeatedContList.Count > 0 && repeatedContList.Exists(p => p.CONT_NUMB == result[i].CONT_NUMB))
                            {
                                repeatedContList.Add(result[i]);
                            }
                            else
                            {
                                volumeList.Add(result[i]);
                            }                            
                        }
                    }

                    volumeResponse = new Dictionary<int, List<DdResponseVolume>>();
                    if (volumeList?.Count > 0)
                    {
                        volumeResponse.Add(0, volumeList);
                    }
                                       
                    if (repeatedContList?.Count > 0)
                    {
                        var grouped = repeatedContList.GroupBy(s => s.CONT_NUMB, (key, g) => new { SeqNum = key, Items = g.ToList() }).ToList();
                        List<DdResponseVolume> batchList = new List<DdResponseVolume>();
                        for (int i = 0; i < grouped.Count; i++)
                        {
                           
                            if (grouped[i].Items?.Count > 0)
                            {
                                if (batchList?.Count > 0)
                                {
                                    if ((batchList.Count + grouped[i].Items.Count) <= batchSize)
                                    {
                                        batchList.AddRange(grouped[i].Items);
                                    }
                                    else
                                    {
                                        AddVolumeItems(volumeResponse, batchList);

                                        batchList = new List<DdResponseVolume>();
                                        batchList.AddRange(grouped[i].Items);
                                    }
                                }
                                else
                                {                                   
                                    batchList.AddRange(grouped[i].Items);
                                }
                            }

                            if ((i+1) == grouped.Count)
                            {
                                if (batchList?.Count > 0)
                                {
                                    AddVolumeItems(volumeResponse, batchList);
                                }                               
                            }
                        }                       
                    }
                }

            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<Dictionary<int, List<DdResponseVolume>>>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }            
            return ServiceHelper.SuccessResponse(volumeResponse);
        }

        #endregion

        public ResponseObject<bool> PerformManualDdGenrBatchPrcs(RequestObject<DirectDebitParam> requestObject)
        {
            var stsList = new List<string> { "Completed", "CompletedWithError", "Error" };
            var processQueu = EntityContextExt<DayEndBatchProcess>.Create().Read(p => p.PRCS_ID == 2537 && (!stsList.Contains(p.BPEM_STS_KEY))).Entity.ToList();
            if (processQueu != null && processQueu.Count > 0)
            {
                return ServiceHelper.SuccessResponse(false);
            }
            else
            {
                string xmlCriteria = string.Empty;
                requestObject.Object.IsManual = true;
                xmlCriteria = XmlSerializationHelper.SerializeToString(requestObject.Object);

                IBatchProcessControllerService srv = DependencyHelper.GetInstance<IBatchProcessControllerService>("BusinessLogicContainer");
                LogContext.ContextToLog = requestObject.Context;
                RequestObject<BatchProcessRequestParam> request = GetNewBatchProcessRequestParam(2537, 1, xmlCriteria, requestObject.Context?.ContextId.ToString(), requestObject.Context, requestObject.Object.BranchId, requestObject.Context.SubTenantId, requestObject.Object.FinanceCompanyId);
                srv.StartDDAccountingBatchProcess(request);

                return ServiceHelper.SuccessResponse(true);
            }
        }

        public ResponseObject<bool> AlreadyBtchProcessInvoke(RequestObject<List<int>> requestObject)
        {
            if (requestObject != null)
            {
                var stsList = new List<string> { "Completed", "CompletedWithError", "Error" };               
                var processQueu = EntityContextExt<DayEndBatchProcess>.Create().Read(p => requestObject.Object.Contains(p.PRCS_ID) && (!stsList.Contains(p.BPEM_STS_KEY))).Entity.ToList();
                if (processQueu != null && processQueu.Count > 0)
                {
                    return ServiceHelper.SuccessResponse(false);
                }
                else
                {
                    return ServiceHelper.SuccessResponse(true);
                }
            }
            else
            {
                return ServiceHelper.SuccessResponse(false);
            }            
        }

        private void GenerateBatchProcess(int processId, DDSchedularBatch batch, Context contextid, int tenantid)
        {
            BatchProcessCriteria objBatchProcessCriteria = new BatchProcessCriteria();
            string criteria;
            //TODO need to discuss branch id
            objBatchProcessCriteria.BranchId = batch.BRNC_ID ?? 1;

            objBatchProcessCriteria.CompanyId = (int)batch.CMPY_ID;
            objBatchProcessCriteria.SubTenantId = tenantid;
            objBatchProcessCriteria.ProcessingDate = DateTime.UtcNow;
            objBatchProcessCriteria.InvokeType = Convert.ToInt32(InvokeTypes.Scheduler.GetKey());
            //objBatchProcessCriteria.ReferenceId = param.EventLogId;
            criteria = XmlSerializationHelper.SerializeToString(objBatchProcessCriteria);
            //BatchProcessRequestParam request = GetNewBatchProcessRequestParam(processId, 1, criteria, contextid.ToString(), objBatchProcessCriteria.BranchId, objBatchProcessCriteria.CompanyId, objBatchProcessCriteria.SubTenantId, false, Convert.ToInt32(InvokeTypes.Scheduler.GetKey()));
            //batchCollection.Add(request);
            IBatchProcessControllerService srv = DependencyHelper.GetInstance<IBatchProcessControllerService>("BusinessLogicContainer");
            // LogContext.ContextToLog = requestObject.Context;

            RequestObject<BatchProcessRequestParam> request = GetNewBatchProcessRequestParam(processId, 1, criteria, contextid.ToString(), objBatchProcessCriteria.BranchId, objBatchProcessCriteria.CompanyId, objBatchProcessCriteria.SubTenantId, false, Convert.ToInt32(InvokeTypes.Scheduler.GetKey()));
            srv.StartDDAccountingBatchProcess(request);
        }
        private void GenerateBatchProcessGroup(DDSchedularBatch batch, Context context, int tenantid)
        {
            if (string.IsNullOrEmpty(batch.BRNC_CODE) || string.IsNullOrEmpty(batch.FC_CODE))
            {
                //commonhelper("Branch Code or Company Code having null/empty values while invoking DD File Upload batch group against SubTenantID:" + tenantid, context, tenantid, NSLogLevel.Info);
                return;
            }
            InvokeBatchProcessRequestParam invokeBatchProcessRequestParam = new InvokeBatchProcessRequestParam();
            invokeBatchProcessRequestParam.BranchCode = batch.BRNC_CODE;
            invokeBatchProcessRequestParam.CompanyCode = batch.FC_CODE;
            invokeBatchProcessRequestParam.ProcessCode = ProcessGroup.DDFileUpload.GetKey();
            invokeBatchProcessRequestParam.SubTenantId = tenantid;
            invokeBatchProcessRequestParam.InvokeTypeId = Convert.ToInt32(InvokeTypes.Scheduler.GetKey());
            RequestObject<InvokeBatchProcessRequestParam> request = new RequestObject<InvokeBatchProcessRequestParam>(context, invokeBatchProcessRequestParam);
            request.Object.SubTenantId = invokeBatchProcessRequestParam.SubTenantId;
            using (var srv = new ProxyClient<IBatchProcessControllerService>())
            {
                ResponseObject<InvokeBatchProcessResponse> resp = srv.ClientInstance.InvokeBatchProcess(request);
            }
        }
        private RequestObject<BatchProcessRequestParam> GetNewBatchProcessRequestParam(int screenId, int topFetchedRows, string criteria, string contextId, int branchId, int companyId, int subTennatId, bool priorityQueueInd, int? invokeTypeId = null)
        {
            return new RequestObject<BatchProcessRequestParam>(null, new BatchProcessRequestParam
            {
                RowCount = topFetchedRows,
                ScreenId = screenId,
                ProcessId = screenId,
                InsertedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow,
                Criteria = criteria,
                InvokeTypeId = invokeTypeId,
                ContextId = contextId,
                PriorityQueueInd = priorityQueueInd,
                BranchId = branchId,
                CompanyId = companyId,
                SubTennatId = subTennatId


            });
        }

        private static RequestObject<BatchProcessRequestParam> GetNewBatchProcessRequestParam(int screenId, int topFetchedRows, string criteria, string contextId, Context context, int branchId, int subTenentId, int companyId, int? invokeTypeId = null)
        {

            return new RequestObject<BatchProcessRequestParam>(null, new BatchProcessRequestParam
            {
                RowCount = topFetchedRows,
                ScreenId = screenId,
                ProcessId = screenId,
                InsertedDate = new DateTime(2016, 12, 26),
                InsertetedBy = context.UserName,
                UpdatedDate = new DateTime(2016, 12, 26),
                UpdatedBy = context.UserName,
                StartDate = DateTime.UtcNow,
                EndDate = new DateTime(2016, 12, 26),
                Criteria = criteria,
                InvokeTypeId = invokeTypeId,
                ContextId = contextId,
                BranchId = branchId,
                CompanyId = companyId,
                SubTennatId = subTenentId
            });
        }

        public ResponseObject<DirectDebitParam> GetDdParamAgainstProcessQueueId(RequestObject<int> requestObject)
        {
            DirectDebitParam ddParam = new DirectDebitParam();
            var ddMainCtx = new EntityContextExt<DdGenerationMain>();
            var ddMain = ddMainCtx.Read(s => s.PRCS_QUEU_ID == requestObject.Object, 1).Entity.LastOrDefault();

            if (ddMain == null)
            {
                //ddParam.Context = requestObject.Context;
                ddParam.ProcessQueueId = null;
                return ServiceHelper.SuccessResponse(ddParam);
            }
            else
            {
                ddParam = new DirectDebitParam
                {
                    BranchId = ddMain.FC_BRNC_BUSS_PTNR_ID,
                    FinanceCompanyId = ddMain.FC_BUSS_PTNR_ID,
                    CurrentProcessingDate = ddMain.PRCG_DTE,
                    EffectiveFromDate = ddMain.EFCT_FRM_DTE,
                    EffectiveToDate = ddMain.EFCT_TO_DTE,
                    ManualInd = ddMain.MANU_IND,
                    ToDate = ddMain.TO_DTE,
                    FromDate = ddMain.FRM_DTE,
                    ProcessQueueId = ddMain.PRCS_QUEU_ID.GetValueOrDefault(0),
                    DdTemplate = ReadDdTemplate(new RequestObject<int>(requestObject.Context, ddMain.FC_BUSS_PTNR_ID)).ResultSet,
                    Context = requestObject.Context
                };
            }

            return ServiceHelper.SuccessResponse(ddParam);
        }

        public ResponseObject<DirectDebitParam> GetDdParamAgainstCompany(RequestObject<int> requestObject)
        {
            DdTemplateAttach attachedTemplate = null;
            DirectDebitParam ddParam = null;
            try
            {
                attachedTemplate = ReadDdTemplate(new RequestObject<int>(requestObject.Context, requestObject.Object))?.ResultSet;
                ddParam = new DirectDebitParam
                {
                    DdTemplate = attachedTemplate,
                    Context = requestObject.Context
                };
            }
            catch (Exception ex)
            {
                // ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return ServiceHelper.ServiceErrorResponse<DirectDebitParam>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }
            return ServiceHelper.SuccessResponse(ddParam);
        }

        #endregion

        #region File Generation

        public ResponseObject<bool> ExecuteFileGenerationTask(RequestObject<Tuple<DirectDebitParam, int, int>> requestObject, TaskData taskData)
        {
            ContractNumber = "";
            DirectDebitParam param = requestObject.Object.Item1;
            int contId = requestObject.Object.Item2;
            int taskItem = requestObject.Object.Item3;
            ResponseObject<bool> response = new ResponseObject<bool>();
            response.Message = new MessageInfo();
            var  draftStatus = StatusCode.Draft.GetKey();
            List<SettlementResponse> settlementResponse = new List<SettlementResponse>();
            var workingDayType = DaysYearType.FinancialWorkingDays;
            int? receiptId = null;            
            try
            {
                if (taskData != null && taskItem > 0 && taskData.checkPoint > 0)
                {
                    return HandleTaskRetry( taskData, requestObject.Context, response);
                }                

                #region Direct Debit Pending
                if (IsDirectDebitPending(new RequestObject<int>(param.Context, contId)).ResultSet)
                {
                    //commonhelper("Contract Number: " + ContractNumber + ", previuse DD Respoanse already pending. So, system unable to generate further DD file against this contract untill previouse DD response recieved.", param.Context, contId, false, NSLogLevel.Error);
                    //return ServiceHelper.SuccessResponse(false);
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                    return response;

                }
                if (taskData != null) taskData.ContNumb = ContractNumber;
                #endregion

                #region Bank Details

                List<PayerBankDetails> payerBankDetail = GetPayerDirectDebitDetail(contId);
                if (!HasData(payerBankDetail))
                {
                    //commonhelper("No Payer Bank Details Exist against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                    //return ServiceHelper.SuccessResponse(false);
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                    return response;
                }

                var fcBankDetail = payerBankDetail.Find(q => q.ROLE_ID == Convert.ToInt32(BusinessPartnerRole.FinanceCompany.GetKey()));

                if (fcBankDetail == null)
                {
                    //commonhelper("No Finance Company Bank exist for Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                    //return ServiceHelper.SuccessResponse(false);
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                    return response;
                }

                var payerBanks = payerBankDetail.FindAll(p => p.CONT_PYER_IND == true && p.PYER_BP_BANK_ID > 0 && p.BUSS_PTNR_ID > 0);
                if (payerBanks != null && payerBanks.Count > 0)
                {
                    if (payerBanks.Count > 1)
                    {
                        //commonhelper("More than one Payer Bank exists for Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                        response.ResultSet = false;
                        response.Message.Type = MessageType.Error;
                        return response;
                    }
                }

                var payerBank = payerBanks.FirstOrDefault();//payerBankDetail.Find(p => p.CONT_PYER_IND == true && p.PYER_BP_BANK_ID > 0 && p.BUSS_PTNR_ID > 0);
                if (payerBank == null)
                {
                    //commonhelper("There is no valid Payer Bank exist for Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                    //return ServiceHelper.SuccessResponse(false);
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                    return response;
                }

                #endregion

                #region DD Header

                var header = param.DDHeaders.Find(p => p.FcBankId == fcBankDetail.PYER_BP_BANK_ID);

                if (header == null)
                {
                    //commonhelper("No Header exists against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                    //return ServiceHelper.SuccessResponse(false);
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                    return response;
                }
                int headerId = header.HeaderId;

                #endregion

                #region Read Receivables 

                List<DdGenerationDetail> ddGenDetail = new List<DdGenerationDetail>();
                List<DdNormalReceivables> contRpPlan = new List<DdNormalReceivables>();
                if (param.IncludeOdRental == true)
                {
                    contRpPlan = ReceivableHelper.ReadDdNormalReceivables(contId, param);
                }
                else
                {
                    contRpPlan = DdNormalReceivables.DdCurrentReceivables(contId, param.EffectiveFromDate, param.EffectiveToDate);
                }
                #endregion

                #region Handle RV

                if (contRpPlan.Exists(p => p.RNTL_TYPE_KEY == RentalTypes.Residualvalue.GetKey()))
                {
                    EntityContextExt<ContractFPInfo> dbCtx = EntityContextExt<ContractFPInfo>.Create();
                    var fpInfo = dbCtx.Read(s => s.CONT_ID == contId, 1).Entity.FirstOrDefault();
                    if (fpInfo != null)
                    {
                        var FpInfo = new List<Tuple<int, int?, int?>>();
                        FpInfo.Add(new Tuple<int, int?, int?>(contId, fpInfo.FNCL_PROD_GRP_ID, fpInfo.FNCL_PROD_ID));

                        var OtpDecisions = ReceiptManagement.ReadOtpDecision(new ReceiptParam() { CompanyId = param.CompanyId, FpInfo = FpInfo, ContractIds = new List<int>() { contId } }, param.Context);
                        if (OtpDecisions != null && OtpDecisions.Count > 0 && OtpDecisions.Exists(p => p.ContractId == contId))
                        {
                            if (!ReceiptingRepository.IsOtpNotApplicableOrPurchase(OtpDecisions.Find(p => p.ContractId == contId)))
                            {   //applicable and not purchase
                                contRpPlan.RemoveAll(p => p.RNTL_TYPE_KEY == RentalTypes.Residualvalue.GetKey());
                            }
                        }
                    }
                }

                #endregion

                #region Pending DD Generated Records

                List<DdGenerationDetail> contGnrtdDds = new List<DdGenerationDetail>();
                var stsKeyPending = StatusCode.Pending.GetKey();
                if (param.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.ResponseFileUpload)
                {
                    contGnrtdDds = DdGenrProcessor.ReadDdGeneratedDetail(p => p.CONT_ID == contId && p.STS_KEY == stsKeyPending);
                }

                #endregion

                #region Current Rentals

                //var currentRentalsDdGenr = CurrentRentalDdProcessor.ProcessCurrentRental(param, contRpPlan, payerBankDetail.FirstOrDefault(p => p.ROLE_ID == Convert.ToInt32(BusinessPartnerRole.Borrower.GetKey())), headerId, contGnrtdDds);
                var currentRentalsDdGenr = CurrentRentalDdProcessor.ProcessCurrentRental(param, contRpPlan, payerBank, headerId, contGnrtdDds);

                var isCurrentRntlDue = currentRentalsDdGenr.Count > 0;

                //if (isCurrentRntlDue == false)
                //    //commonhelper("No Current Rental is due for Contract ID: " + contId, param.Context, contId, false, NSLogLevel.Info);

                ddGenDetail.AddRange(currentRentalsDdGenr);

                #endregion

                #region  Receivable Config            
                if (param.DdTemplate.DdReceivable?.Count > 0)
                {
                    for (int i = 0; i < param.DdTemplate.DdReceivable.Count; i++)
                    {
                        if (param.DdTemplate.DdReceivable[i].MAX_OD_RNTL_IND && !(param.DdTemplate.DdReceivable[i].OD_RNTL > 0))
                        {
                            ////commonhelper("Max Overdue Indicator checked but Max No of Rentals are not Configured or Zero: " + contId, param.Context, contId, false, NSLogLevel.Info);
                            continue;
                        }

                        int maxNumRntlLmt = -1;
                        if (param.DdTemplate.DdReceivable[i].MAX_OD_RNTL_IND)
                        {
                            maxNumRntlLmt = Convert.ToInt32(param.DdTemplate.DdReceivable[i].OD_RNTL);
                        }

                        if (param.DdTemplate.DdReceivable[i].DD_RECV_ABLE_ID == (int)DdReceivableCodeEnum.OverdueRentals)
                        {

                            if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.DueDate && isCurrentRntlDue)
                            {
                                ddGenDetail.AddRange(OverdueRentalDdProcessor.ProcessOverdueRental(param, contRpPlan, payerBank, headerId, maxNumRntlLmt, contGnrtdDds));
                            }
                            else if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.EveryDay)
                            {
                                ddGenDetail.AddRange(OverdueRentalDdProcessor.ProcessOverdueRental(param, contRpPlan, payerBank, headerId, maxNumRntlLmt, contGnrtdDds));
                            }
                            else if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.DaysPastDue && param.DdTemplate.DdReceivable[i].DdDpd.Count > 0)
                            {
                                ddGenDetail.AddRange(OverdueRentalDdProcessor.ProcessDpdOvrdRental(contRpPlan, payerBank, headerId, maxNumRntlLmt, param, param.DdTemplate.DdReceivable[i].DdDpd, contGnrtdDds));
                            }
                        }
                        else if (param.DdTemplate.DdReceivable[i].DD_RECV_ABLE_ID == (int)DdReceivableCodeEnum.OverdueInterest)
                        {

                            if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.DueDate && isCurrentRntlDue)
                            {
                                ddGenDetail.AddRange(OverdueInterestDdProcessor.ProcessOverdueInterest(param, contRpPlan, payerBank, headerId, maxNumRntlLmt, contGnrtdDds));
                            }
                            else if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.EveryDay)
                            {
                                 ddGenDetail.AddRange(OverdueInterestDdProcessor.ProcessOverdueInterest(param, contRpPlan, payerBank, headerId, maxNumRntlLmt, contGnrtdDds));
                            }
                            else if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.DaysPastDue && param.DdTemplate.DdReceivable[i].DdDpd.Count > 0)
                            {
                                if (contRpPlan != null && contRpPlan.Count > 0)
                                {
                                    ddGenDetail.AddRange(OverdueInterestDdProcessor.ProcessDpdOvrdInterest(contRpPlan[0], payerBank, headerId, maxNumRntlLmt, param, param.DdTemplate.DdReceivable[i].DdDpd, contGnrtdDds));
                                }
                            }
                        }
                        else if (param.DdTemplate.DdReceivable[i].DD_RECV_ABLE_ID == (int)DdReceivableCodeEnum.Charges)
                        {
                            if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.RentalDueDate && isCurrentRntlDue)
                            {
                                ddGenDetail.AddRange(ChargesDdProcessor.ProcessOverdueCharges(payerBank, headerId, param, maxNumRntlLmt, contGnrtdDds));
                            }
                            else if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.ChargeDueDate)
                            {
                                ddGenDetail.AddRange(ChargesDdProcessor.ProcessOverdueCharges(payerBank, headerId, param, maxNumRntlLmt, contGnrtdDds));
                            }
                        }
                    }
                }
                #endregion

                #region Re-Direct Debit        

                if (param.DdTemplate.DD_SEND_DSNR_ID > 0)
                {
                    ddGenDetail.AddRange(ReDirectDebitProcessor.ReDirectDebit(headerId, contGnrtdDds, param, DaysYearType.FinancialWorkingDays, isCurrentRntlDue, contId));
                }
                #endregion                           

                #region Check Subsidy
                if (param.DdTemplate?.DD_SEND_SBDY_ID > 0)
                {
                    ddGenDetail.AddRange(SubsidyDdProcessor.ProcessSubsidy(payerBankDetail, headerId, contGnrtdDds, param, DaysYearType.FinancialWorkingDays));
                }
                #endregion

                #region Check SecurityDeposit

                if (param.DDMiscConfig != null && param.DDMiscConfig.SD_AUTO_DD_IND == true)
                {
                    var stsKey = AmountComponents.SecurityDeposit.GetKey();//new List <string> { "Security Deposit" };
                    //var securityDepositReceivables = ReceivablesHelper.ReadReceivables<SettlementAssetComponentReceivable>(p => p.CONT_ID == contId && components.Contains(p.AMNT_CMPT_TYPE_KEY) && p.CMPT_AMNT > 0);
                    var securityDepositReceivables = ReceivablesHelper.ReadReceivables<SettlementAssetComponentReceivable>(p => p.CONT_ID == contId && p.AMNT_CMPT_TYPE_KEY == stsKey && p.CMPT_AMNT > 0);
                    foreach (var scrtDetail in securityDepositReceivables)
                    {
                        if (contGnrtdDds.Exists(s => s.ASET_CMPT_RCBL_ID == scrtDetail.ASET_CMPT_RCBL_ID))
                        {
                            continue;
                        }
                        var ddScrtyDpst = ProcessSecurityDeposit(payerBank, headerId, param, scrtDetail, contId);
                        if (ddScrtyDpst != null)
                        {
                            ddGenDetail.Add(ddScrtyDpst);
                        }
                    }
                }
                #endregion

                #region UnAllocated Amounts

                if (ddGenDetail.Count != 0 && param.DdTemplate.UN_ALCT_AMNT_IND)
                {
                    var contextUnAllct = EntityContextExt.Create<ReceiptContractAssociation>();
                    var unalctdAmnt = Convert.ToDecimal(contextUnAllct.Read(p => p.CONT_ID == contId && (p.STS_KEY == "Allocated" || p.STS_KEY == "UnAllocated")).Entity.Sum(s => s.UN_ALCT_AMNT));
                    if (unalctdAmnt > 0)
                    {
                        ddGenDetail = UnAllocatedDdProcessor.ProcessUnallocatedAmounts(ddGenDetail, unalctdAmnt);

                        #region Check Recievables Due Date Configuration Again after Un-alloaction

                        if (ddGenDetail.Count > 0)
                        {
                            var isCurrentRental = ddGenDetail.Exists(s => s.AMNT_DUE_DTE >= param.EffectiveFromDate && s.AMNT_DUE_DTE <= param.EffectiveToDate && s.AMNT_CMPT_TYPE_KEY == AmountComponents.Rental.GetKey());
                            if (!isCurrentRental)
                            {
                                for (int i = 0; i < param.DdTemplate.DdReceivable.Count; i++)
                                {
                                    if (param.DdTemplate.DdReceivable[i].DD_RECV_ABLE_ID == (int)DdReceivableCodeEnum.OverdueRentals)
                                    {
                                        if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.DueDate)
                                        {
                                            ddGenDetail.RemoveAll(s => s.AMNT_DUE_DTE < param.EffectiveFromDate && s.AMNT_CMPT_TYPE_KEY == AmountComponents.Rental.GetKey());

                                        }
                                    }
                                    else if (param.DdTemplate.DdReceivable[i].DD_RECV_ABLE_ID == (int)DdReceivableCodeEnum.OverdueInterest)
                                    {
                                        if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.DueDate)
                                        {
                                            ddGenDetail.RemoveAll(s => s.AMNT_CMPT_TYPE_KEY == AmountComponents.Overdue.GetKey());

                                        }
                                    }
                                    else if (param.DdTemplate.DdReceivable[i].DD_RECV_ABLE_ID == (int)DdReceivableCodeEnum.Charges)
                                    {
                                        if (param.DdTemplate.DdReceivable[i].DD_SEND_CLCT_ID == (int)DdSendCollectionCodeEnum.RentalDueDate)
                                        {
                                            ddGenDetail.RemoveAll(s => s.AMNT_CMPT_TYPE_KEY == AmountComponents.Charges.GetKey());

                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region Prepare Receipt Param for Unallocated Amount settlment
                        if (ddGenDetail != null && ddGenDetail.Count > 0)
                        {
                            ProcessUnallocatedReceipts(param, contId, ddGenDetail.Max(p => p.AMNT_DUE_DTE).Value);
                        }
                        #endregion
                    }

                }
                #endregion

                #region Adhoc DD

                var adhocMasterDdGenDet = AdhocDdProcessor.ProcessAdhocDd(contId, param, payerBankDetail, headerId);
                var adhocDdGenDet = adhocMasterDdGenDet?.FindAll(s => s.AMNT_DUE_DTE >= param.EffectiveFromDate && s.AMNT_DUE_DTE <= param.EffectiveToDate);
                if (adhocDdGenDet != null && adhocDdGenDet.Count > 0)
                {
                    ddGenDetail.AddRange(adhocDdGenDet);
                }

                #endregion

                #region DD Hold Config

                var holdPeriods = ReadDDHoldConfig(param, contId);
                if (holdPeriods != null && holdPeriods.Count > 0)
                {
                    foreach (var period in holdPeriods)
                    {
                        if (param?.DdTemplate?.DD_HLDY_ID == (int)DdHolidayCodeEnum.LastWorkingDay)
                        {
                            if (CommonHelper.IsDateLastWorkingDay(period.TO_DTE, workingDayType, param.FinanceCompanyId, param.BranchId))
                            {                                
                                    var nextWorkingDay = CommonHelper.GetNextWorkingDay(period.TO_DTE, workingDayType, param.FinanceCompanyId, param.BranchId);
                                    period.TO_DTE = nextWorkingDay.AddDays(-1);                                
                            }
                        }

                        //if (ddGenDetail != null && ddGenDetail.Count > 0 && ddGenDetail.Exists(p => p.AMNT_DUE_DTE >= period.FRM_DTE && p.AMNT_DUE_DTE <= period.TO_DTE && p.DD_ADHC_CONF_ID == null))
                        if (ddGenDetail != null && ddGenDetail.Count > 0 && param.EffectiveFromDate >= period.FRM_DTE && param.EffectiveToDate <= period.TO_DTE)
                        {
                            ddGenDetail.RemoveAll(p => p.DD_ADHC_CONF_ID == null);
                            //commonhelper("DD hold configured From:" + period.FRM_DTE + ", To:" + period.TO_DTE + " for normal receivables against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                        }

                        if (param.DDMiscConfig.ADHC_DD_IND)
                        {
                            if (ddGenDetail != null && ddGenDetail.Count > 0 && ddGenDetail.Exists(p => p.AMNT_DUE_DTE >= period.FRM_DTE && p.AMNT_DUE_DTE <= period.TO_DTE && p.DD_ADHC_CONF_ID > 0))
                            {
                                ddGenDetail.RemoveAll(p => p.DD_ADHC_CONF_ID > 0);
                                //commonhelper("Hold Adhoc DD checkbox checked at finance company. So, Adhoc receivables did not become part of file against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                            }
                        }
                    }
                }

                #endregion

                if (param?.DDMiscConfig?.ADHC_MNUL_DD_IND == true)
                {
                    var manualAdhocGenDet = adhocDdGenDet?.FindAll(p =>
                                        p.AMNT_CMPT_TYPE_KEY == AmountComponents.NormalReceivables.GetKey() ||
                                        p.AMNT_CMPT_TYPE_KEY == AmountComponents.Rental.GetKey() ||
                                        p.AMNT_CMPT_TYPE_KEY == AmountComponents.Overdue.GetKey() ||
                                        p.AMNT_CMPT_TYPE_KEY == AmountComponents.ChargeReceivable.GetKey() ||
                                        p.AMNT_CMPT_TYPE_KEY == AmountComponentCodes.ManufacturerSubsidy.GetKey() ||
                                        p.AMNT_CMPT_TYPE_KEY == AmountComponentCodes.IntroducerSubsidy.GetKey()
                                    );
                    if (manualAdhocGenDet != null && manualAdhocGenDet.Count > 0)
                    {
                        ddGenDetail = manualAdhocGenDet;
                    }
                }

                if (adhocMasterDdGenDet != null && adhocMasterDdGenDet.Count > 0 && adhocMasterDdGenDet.Exists(p => p.AMNT_CMPT_TYPE_KEY == AmountComponents.ETReceivables.GetKey()))
                {
                    if (param?.DDMiscConfig?.ET_HOLD_NRML_DD_IND == true)
                    {
                        adhocMasterDdGenDet = adhocMasterDdGenDet.FindAll(p => p.AMNT_CMPT_TYPE_KEY == AmountComponents.ETReceivables.GetKey());
                        for (int i = 0; i < adhocMasterDdGenDet.Count; i++)
                        {
                            RequestReceiptParam reqReceiptParam = new RequestReceiptParam();
                            reqReceiptParam.RefId = Convert.ToInt32(adhocMasterDdGenDet[i].ET_QUOT_ID);
                            if (reqReceiptParam.RefId > 0)
                            {
                                var EtQuote = ReceiptManagement.GetApprovedQuote(reqReceiptParam).FirstOrDefault();
                                if (EtQuote != null && EtQuote.IS_VLDY_IND)
                                {   
                                    ddGenDetail?.RemoveAll(p => p.AMNT_CMPT_TYPE_KEY != AmountComponents.ETReceivables.GetKey());
                                    //commonhelper("Remove Normal Receivables because of valid ET Quotation found against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                                }
                                else
                                {
                                    MarkInvalidAdhoc(adhocMasterDdGenDet[i].DD_ADHC_CONF_ID, param.CurrentProcessingDate);

                                    if (ddGenDetail != null && ddGenDetail.Count > 0 && ddGenDetail.Exists(p => p.DD_ADHC_CONF_ID == adhocMasterDdGenDet[i].DD_ADHC_CONF_ID))
                                    {                                        
                                        ddGenDetail?.RemoveAll(p => p.DD_ADHC_CONF_ID == adhocMasterDdGenDet[i].DD_ADHC_CONF_ID);
                                        //commonhelper("Remove ET Adhoc record because of no valid ET Quotation found against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                                    }
                                }
                            }
                            else
                            {
                                MarkInvalidAdhoc(adhocMasterDdGenDet[i].DD_ADHC_CONF_ID, param.CurrentProcessingDate);

                                if (ddGenDetail != null && ddGenDetail.Count > 0 && ddGenDetail.Exists(p => p.DD_ADHC_CONF_ID == adhocMasterDdGenDet[i].DD_ADHC_CONF_ID))
                                {                                    
                                    ddGenDetail?.RemoveAll(p => p.DD_ADHC_CONF_ID == adhocMasterDdGenDet[i].DD_ADHC_CONF_ID);
                                    //commonhelper("Remove ET Adhoc record because of no valid ET Quotation found against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                                }
                            }
                        }
                    }
                }

                if (ddGenDetail != null && ddGenDetail.Count > 0)
                {
                    
                    var normalDD = ddGenDetail.Where(p => (p.AMNT_CMPT_TYPE_KEY == AmountComponents.Rental.GetKey() ||
                    p.AMNT_CMPT_TYPE_KEY == AmountComponents.Overdue.GetKey() ||
                    p.AMNT_CMPT_TYPE_KEY == AmountComponents.Charges.GetKey()) &&
                    Convert.ToInt32(p.DD_ADHC_CONF_ID) == 0).ToList();

                    var otherDD = ddGenDetail.Where(p => !normalDD.Contains(p)).ToList();
                    for (int i = 0; i < 1 + otherDD.Count; i++)
                    {
                        List<DdGenerationDetail> DD = new List<DdGenerationDetail>();
                        if (i == 0)
                        {
                            DD = normalDD;
                        }
                        else
                        {
                            DD = new List<DdGenerationDetail>() { otherDD[i - 1] };
                        }

                        /////////                     

                        List<DdGenerationDetail> fixedList = new List<DdGenerationDetail>();
                        if (DD != null && DD.Count > 0)
                        {
                            decimal maxAmount = 0;
                            if (param?.DDMiscConfig?.DD_TRAN_AMNT > 0) maxAmount = param.DDMiscConfig.DD_TRAN_AMNT;
                            decimal runningSum = 0;
                            int seqNum = 0;
                            foreach (var item in DD)
                            {
                                runningSum += item.AMNT;
                                if (maxAmount > 0 && runningSum > maxAmount)
                                {
                                    fixedList.Add(new DdGenerationDetail { AMNT = maxAmount - fixedList.Where(s => s.RCPT_ID == seqNum).Sum(t => t.AMNT), RCPT_ID = seqNum });
                                    AssignOtherDdGenrValues(item, fixedList.Last());

                                    var remaining = runningSum - maxAmount;
                                    var times = Math.Floor(remaining / maxAmount);
                                    for (int i2 = 0; i2 < times; i2++)
                                    {
                                        seqNum++;
                                        fixedList.Add(new DdGenerationDetail { AMNT = maxAmount, RCPT_ID = seqNum });
                                        AssignOtherDdGenrValues(item, fixedList.Last());
                                    }

                                    if (Decimal.Remainder(remaining, maxAmount) != 0)
                                    {
                                        seqNum++;
                                        fixedList.Add(new DdGenerationDetail { AMNT = remaining % maxAmount, RCPT_ID = seqNum });
                                        AssignOtherDdGenrValues(item, fixedList.Last());
                                        runningSum = decimal.Remainder(remaining, maxAmount);
                                    }
                                    else
                                    {
                                        runningSum = 0;
                                        seqNum++;
                                    }

                                    // runningSum = 0;
                                }
                                else
                                {
                                    fixedList.Add(new DdGenerationDetail { AMNT = item.AMNT, RCPT_ID = seqNum });
                                    AssignOtherDdGenrValues(item, fixedList.Last());
                                    if (maxAmount == runningSum)
                                    {
                                        seqNum++;
                                        runningSum = 0;
                                    }
                                }
                            }
                            /////////


                            #region Settlement

                            if (param.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.FileGeneration)
                            {
                                var grouped = fixedList.GroupBy(s => s.RCPT_ID, (key, g) => new { SeqNum = key, Items = g.ToList() }).ToList();

                                #region Persist

                                if (param.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.FileGeneration)
                                {                                 
                                    Parallel.ForEach(fixedList, p => { p.STS_KEY = draftStatus; p.RCPT_ID = null; });
                                    var ctx1 = EntityContextExt<DdGenerationDetail>.Create(fixedList);
                                    //using (NS.ORM.UoW.IUnitOfWork uow = ctx1.InitiateUnitOfWork())
                                    {
                                        ctx1.Persist();
                                        //uow.Save();
                                    }
                                }
                                #endregion                    
                                for (int j = 0; j < grouped.Count; j++)
                                {
                                   
                                    bool isFinalEt = false;

                                    #region Final ET Check                                    
                                    if (grouped[j].Items[0].AMNT_CMPT_TYPE_KEY == AmountComponents.ETReceivables.GetKey())
                                    {
                                        if (!grouped.Where(p => grouped.IndexOf(p) > j).ToList().Exists(p => p.Items[0].AMNT_CMPT_TYPE_KEY == AmountComponents.ETReceivables.GetKey()))
                                        {
                                            isFinalEt = true;
                                        }
                                    }
                                    #endregion

                                    if (taskData != null)
                                    {
                                        MarkCheckpoint( taskData, 1, param, grouped[j].Items, isFinalEt);
                                    }                                  

                                    var result = PerformSettlement(taskData, grouped[j].Items, param, isFinalEt);
                                    if (taskData?.checkPoint == 1)
                                    {
                                        MarkCheckpoint( taskData, 2, taskData.ddParam, taskData.ddGenDetail, taskData.isFinalEt);
                                    }
                                    settlementResponse.Add(result.Item1);
                                    receiptId = result.Item2;
                                    //requestObject.Context.WorkDate = param.CurrentProcessingDate;
                                    //InvokePostSettlementWorkflow(requestObject.Context, settlementResponse, param.BranchId, receiptId);
                                }
                            }

                            #endregion

                            #region Persist

                            if (fixedList.Exists(p => p.STS_KEY == StatusCode.Pending.GetKey()))
                            {
                                response.ResultSet = true;
                                response.Message.Type = MessageType.Success;
                                var ctx = EntityContextExt<DdGenerationDetail>.Create(fixedList);
                                ctx.Persist();
                            }

                            #endregion

                            //#region Invoke Workflow
                            ////requestObject.Context.WorkDate = param.CurrentProcessingDate;
                            ////InvokePostSettlementWorkflow(requestObject.Context, settlementResponse, param.BranchId, receiptId);

                            //#endregion
                        }                       
                    }

                    if (!ddGenDetail.Exists(p => p.STS_KEY == StatusCode.Pending.GetKey()))
                    {
                        //commonhelper("Receipt didn't settle against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                        response.ResultSet = false;
                        response.Message.Type = MessageType.Error;
                    }                   

                    #region Invoke Workflow                        
                    foreach (var item in settlementResponse)
                    {
                        InvokePostSettlementWorkflow(requestObject.Context, item, param.BranchId, receiptId);
                    }
                    #endregion
                    
                }
                else
                {
                    //commonhelper("No Receivable found against Contract Number: " + ContractNumber, param.Context, contId, false, NSLogLevel.Error);
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                    return response;
                }
            }
            catch (Exception ex)
            {               
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }          
            
            return response;            
        }

        private void  AssignOtherDdGenrValues(DdGenerationDetail source, DdGenerationDetail target)
        {
            target.DD_GENR_DET_ID = source.DD_GENR_DET_ID;
            target.DD_GENR_HEDR_ID = source.DD_GENR_HEDR_ID;
            target.RE_SEND_IND = source.RE_SEND_IND;
            target.DD_RE_SEND_REF_ID = source.DD_RE_SEND_REF_ID;
            target.BUSS_PTNR_ID = source.BUSS_PTNR_ID;
            target.PYER_BP_BANK_ID = source.PYER_BP_BANK_ID;
            target.ASET_CMPT_RCBL_ID = source.ASET_CMPT_RCBL_ID;
            target.CONT_ID = source.CONT_ID;
            target.AMNT_CMPT_TYPE_KEY = source.AMNT_CMPT_TYPE_KEY;
            //target.AMNT = source.AMNT;
            target.AMNT_DUE_DTE = source.AMNT_DUE_DTE;
            //target.RCPT_ID = source.RCPT_ID;
            target.RNTL_ID = source.RNTL_ID;
            target.RPMT_PLAN_ID = source.RPMT_PLAN_ID;
            target.CHRG_ID = source.CHRG_ID;
            target.CHRG_RCBL_TYPE_ID = source.CHRG_RCBL_TYPE_ID;
            target.RNTL_OVRD_ID = source.RNTL_OVRD_ID;
            target.STS_KEY = source.STS_KEY;
            target.FILE_ROW_NUMB = source.FILE_ROW_NUMB;
            target.FILE_NME = source.FILE_NME;
            target.INSR_BY = source.INSR_BY;
            target.UPDT_BY = source.UPDT_BY;
            target.INSR_DTE = source.INSR_DTE;
            target.UPDT_DTE = source.UPDT_DTE;
            target.DD_ADHC_CONF_ID = source.DD_ADHC_CONF_ID;
            target.ASET_ID = source.ASET_ID;
            target.DD_RSPN_DET_ID = source.DD_RSPN_DET_ID;
            target.RCPT_TYPE_ID = source.RCPT_TYPE_ID;
            target.ET_QUOT_ID = source.ET_QUOT_ID;
            target.REQT_ID = source.REQT_ID;
        }

        // File Generation For Manual DD Receipting
        private bool ProcessManualReceiptingContracts(IEnumerable<int> contractIds, int ddGenrHeaderId, DirectDebitParam ddParam)
        {
            List<DdGenerationDetail> ddGenrDetail = new List<DdGenerationDetail>();
            
            foreach (var contractId in contractIds)
            {                
                if (IsDirectDebitPending(new RequestObject<int>(ddParam.Context, contractId)).ResultSet)
                {
                    //commonhelper("Contract Id: " + contractId + ", previuse DD Respoanse already pending. So, system unable to generate further DD file against this contract untill previouse DD response recieved.", ddParam.Context, contractId, false, NSLogLevel.Info);
                    continue;
                }
                
                List<PayerBankDetails> payerBankDetail = GetPayerDirectDebitDetail(contractId);

                if (payerBankDetail.Count == 0)
                {
                    //commonhelper("No Payer Bank Details Exist against Contract ID: " + contractId, ddParam.Context, contractId, false, NSLogLevel.Info);
                    continue;
                }

                if (ddParam.ComponentsReceivables != null && ddParam.ComponentsReceivables.Count > 0)
                {
                    var ddDetail = ManualComponentDdProcessor.ProcessSelectedComponents(contractId, ddParam, payerBankDetail, ddGenrHeaderId);
                    if (ddDetail != null && ddDetail.Count > 0)
                    {
                        if (ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.FileGeneration)
                        {
                            Parallel.ForEach(ddDetail, p => p.STS_KEY = StatusCode.Draft.GetKey());
                            var ctx = EntityContextExt<DdGenerationDetail>.Create(ddDetail);
                            ctx.Persist();
                            PerformSettlement(null, ddDetail, ddParam);
                        }
                                                
                        ddGenrDetail.AddRange(ddDetail);
                    }
                    else
                    {
                        //commonhelper("Contract Id: " + contractId + ", No recievable found against this contract between selected Effective Dates.", ddParam.Context, contractId, false, NSLogLevel.Info);
                    }
                }                                
            }

            if (ddGenrDetail != null && ddGenrDetail.Count > 0)
            {
                var ctx = EntityContextExt<DdGenerationDetail>.Create(ddGenrDetail);
                ctx.Persist();
                return true;
            }
            return false;
        }
        
        #endregion

        #region File Upload    

        public ResponseObject<bool> ProcessDdResponseTask(RequestObject<Tuple<int, DirectDebitParam, string>> requestObject)
        {
            int ddRspnId = requestObject.Object.Item1;
            DirectDebitParam ddParam = requestObject.Object.Item2;
            string refId = requestObject.Object.Item3;
            ResponseObject<bool> response = new ResponseObject<bool>();
            response.Message = new MessageInfo();
            int processQueueId = Convert.ToInt32(ddParam.ProcessQueueId);
            var failureKey = StatusCode.Failure.GetKey();
            var failureKeyLower = failureKey.ToLower();
            var recptReqt = RequestTypeCodes.ReceiptRequest.GetKey();
            var successKey = StatusCode.Success.GetKey();
            var scsLower = successKey.ToLower();
            var honored = StatusCode.Honored.GetKey();
            var dishonored = StatusCode.Dishonored.GetKey();
            try
            {
                if (ddParam == null || (ddParam != null && ddParam.DdTemplate == null))
                    throw new Exception($"Direct Debit Template is not Configured for Finance Company");                              

                #region Validate (Collection and Response) & Log Details
                 
                var ddGenerationObjects = DdGenerationDetail.ReadDdDetailByResponseId(ddRspnId);                
                    
                if (ValidateLogErrorDet(ddGenerationObjects, requestObject.Context, ddRspnId, ddParam) == false)
                {
                    response.ResultSet = false;
                    response.Message.Type = MessageType.Error;
                    return response;
                }
                #endregion                

                if (ddGenerationObjects != null && ddGenerationObjects.Count > 0)
                {

                    if (ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.FileGeneration)
                    {
                        List<DdSelectHelper> ddReceipts = new List<DdSelectHelper>();
                        for (int i = 0; i < ddGenerationObjects.Count; i++)
                        {
                            if (ddReceipts.Count == 0)
                            {
                                ddReceipts.Add(new DdSelectHelper
                                {
                                    RCPT_ID = ddGenerationObjects[i].RCPT_ID,
                                    STS_KEY = ddGenerationObjects[i].STS_KEY,
                                    DD_RSPN_DET_ID = Convert.ToInt32(ddGenerationObjects[i].DD_RSPN_DET_ID)
                                });
                            }
                            else
                            {
                                if (ddReceipts.Find(p=>p.RCPT_ID == ddGenerationObjects[i].RCPT_ID) == null)
                                {
                                    ddReceipts.Add(new DdSelectHelper
                                    {
                                        RCPT_ID = ddGenerationObjects[i].RCPT_ID,
                                        STS_KEY = ddGenerationObjects[i].STS_KEY,
                                        DD_RSPN_DET_ID = Convert.ToInt32(ddGenerationObjects[i].DD_RSPN_DET_ID)
                                    });
                                }
                            }
                        }

                        ddReceipts = ddReceipts?.OrderByDescending(p => p.RCPT_ID).ToList();
                        foreach (var detailItem in ddReceipts)
                                {
                                // Perform Receipt Cancellation against Failed records
                                if (ddGenerationObjects[0].RSPN_STS_KEY.ToLower() == failureKeyLower) //(detailItem.STS_KEY.ToLower() == StatusCode.Failure.GetKey().ToLower())
                                    {
                                        //Cancel Receipt
                                      if (Convert.ToInt32(detailItem.RCPT_ID) > 0)
                                    {
                                       bool rcptCancelled = CancelReceipt(requestObject.Context, Convert.ToInt32(detailItem.RCPT_ID), detailItem.DD_RSPN_DET_ID, ddParam);
                                                                        if (rcptCancelled)
                                    {
                                        detailItem.STS_KEY = failureKey;
                                    }
                                    else
                                    {
                                        response.ResultSet = false;
                                        response.Message.Type = MessageType.Error;
                                        return response;
                                            }
                                        }
                                    }
                                    if (ddGenerationObjects[0].RSPN_STS_KEY.ToLower() == scsLower)
                                        {
                                        // to trigger event on DD file upload for success records
                                        ReceiptingRepository.TriggerEvent(requestObject.Context, Convert.ToInt32(detailItem.RCPT_ID), recptReqt, null, processQueueId, ddGenerationObjects[0].CONT_ID.ToString());
                                        detailItem.STS_KEY = successKey;
                                         }
                                     }
                                ddReceipts.ForEach(ddRcpt =>
                                    {
                                    foreach (var ddGen in ddGenerationObjects)
                                    {
                                    if (ddRcpt.RCPT_ID == ddGen.RCPT_ID)
                                        {
                                          ddGen.STS_KEY = ddRcpt.STS_KEY;
                                          if (ddGen.DD_ADHC_CONF_ID > 0)
                                            {
                                                var stsKey = honored;
                                                if (ddGen.STS_KEY == failureKey)
                                            {
                                                stsKey = dishonored;
                                            }
                                    DbController controller = DbController.Create();
                                    string sql = "BEGIN TRANSACTION; UPDATE CONT_DD_ADHC_CONF SET DD_STS_KEY = @DdStatusKey, ADHC_DD_SENT_DTE = @AdhcDdSentDate WHERE DD_ADHC_CONF_ID = @DdAdhcConfId;COMMIT TRANSACTION;";
                                    controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "DdStatusKey", stsKey }, { "DdAdhcConfId", ddGen.DD_ADHC_CONF_ID }, { "AdhcDdSentDate", ddParam.CurrentProcessingDate } });
                                }
                            }

                                        }
                                        });

                var contextPersist = EntityContextExt<DdGenerationDetail>.Create(ddGenerationObjects);
                contextPersist.Persist();
                                }
                if (ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.ResponseFileUpload && ddGenerationObjects != null && ddGenerationObjects.Count > 0)
                    {
                      if (ddGenerationObjects[0].RSPN_STS_KEY.ToLower() == scsLower)
                        {
                            PerformSettlement(null, ddGenerationObjects, ddParam);
                            var contextPersist = EntityContextExt<DdGenerationDetail>.Create(ddGenerationObjects.Where(p => p.STS_KEY.ToLower() == scsLower).ToList());
                            contextPersist.Persist();
                        }
                        if (ddGenerationObjects[0].RSPN_STS_KEY.ToLower() == failureKeyLower)
                            {
                            for (int i = 0; i < ddGenerationObjects.Count; i++)
                                {
                                    ddGenerationObjects[i].STS_KEY = failureKey;
                                    if (ddGenerationObjects[i].DD_ADHC_CONF_ID > 0)
                                    {
                                        DbController controller = DbController.Create();
                                        var stsKey = dishonored;
                                        string sql = "BEGIN TRANSACTION; UPDATE CONT_DD_ADHC_CONF SET DD_STS_KEY = @DdStatusKey, ADHC_DD_SENT_DTE = @AdhcDdSentDate WHERE DD_ADHC_CONF_ID = @DdAdhcConfId;COMMIT TRANSACTION;";
                                        controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "DdStatusKey", stsKey }, { "DdAdhcConfId", ddGenerationObjects[i].DD_ADHC_CONF_ID }, { "AdhcDdSentDate", ddParam.CurrentProcessingDate } });
                                    }
                        }
                            var contextPersist = EntityContextExt<DdGenerationDetail>.Create(ddGenerationObjects);
                            contextPersist.Persist();
                        }
                        
                    }
                    // to trigger event on DD file upload
                    //ReceiptingRepository.TriggerEvent(requestObject.Context, ddGenerationObjects[0].CONT_ID, RequestTypeCodes.DirectDebitRequest.GetKey());

                }              
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            response.ResultSet = true;
            response.Message.Type = MessageType.Error;
            return response;
        }
        public ResponseObject<DdResponseFileParam> ReadDdFileNamesToUpload(RequestObject<DirectDebitParam> ddParam)
        {
            DdResponseFileParam response = new DdResponseFileParam();
            try
            {  
                DdTemplateAttach ddTemplate = null;
                if (ddParam?.Object?.FinanceCompanyId > 0)
                    ddTemplate = ReadDdTemplate(new RequestObject<int>(ddParam.Context, ddParam.Object.FinanceCompanyId)).ResultSet;

                var msgFlow = ddTemplate.DdFileConfig.SingleOrDefault(s => s.DD_FILE_TYPE_ID == (int)DdFileTypeEnum.FileResponse && s.BP_BANK_ID == ddParam.Object.BPBankId);

                if (msgFlow == null)
                    return null;

                response.MesgFlowId = Convert.ToInt32(msgFlow.MESG_FLOW_ID);
                IIntegrationHubService srv = ChannelFactory.CreateChannel<IIntegrationHubService>();
                var result = srv.ReadMessageFlow(new RequestObject<int>(ddParam.Context, Convert.ToInt32(msgFlow.MESG_FLOW_ID)));
                ChannelFactory.CloseChannel(srv);
                if (result?.ResultSet?.MessageFlowParameters != null)
                {
                    string files = null;
                
                    var fileGenerationPath = (ddParam.Context.SubTenantId == 2) ? result?.ResultSet?.MessageFlowParameters.SingleOrDefault(p => p.NME == "FilePath_LC") : result?.ResultSet?.MessageFlowParameters.SingleOrDefault(p => p.NME == "FilePath");

                    if (fileGenerationPath != null)
                    {
                        string path = fileGenerationPath.DFLT_VAL;
                        if (!string.IsNullOrEmpty(path))
                        {                       
                            var mesgFlowParam = new MessageFlowExecParam
                            {                                
                                MesgFlowName = "GetDdFiles",
                                Params = new Dictionary<string, object>()
                                {
                                   { "Path", path}
                                },
                                InvokeType = IHEnums.InvokeTypeCodeEnum.Event
                            };

                            IIntegrationHubService srv1 = ChannelFactory.CreateChannel<IIntegrationHubService>();
                            var filesResult = mesgFlowParam.ExecuteMessageFlow(ddParam.Context, srv1);
                            ChannelFactory.CloseChannel(srv1);
                        
                            if (filesResult.ResultSet.ExecutionStatus == IHEnums.MessageFlowExecutionStatusCodeEnum.Success)
                            {
                                files = filesResult.ResultSet.Params["FileNames"].ToString();
                            }

                        }
                           // files = Directory.GetFiles(path);

                        if (!String.IsNullOrWhiteSpace(files))
                        {
                            //response.FilesData = new List<DDFilesData>();
                            //for (int i = 0; i < files.Length; i++)
                            //{
                            //    string fileName = Path.GetFileName(files[i]);
                            //    response.FilesData.Add(new DDFilesData { File_Name = fileName });
                            //}
                            //#region Filtering the files that are already processed
                            //var fNames = new List<string>();
                            //foreach (var item in response.FilesData)
                            //{
                            //    fNames.Add(item.File_Name);
                            //}

                            //string fileNames = string.Join<string>(",", fNames);
                            RequestObject<string> request = new RequestObject<string>(ddParam.Context, files);
                            var lstFilesToProcess = ReadDdResponseFilesToProcess(request).ResultSet.Select(p => p.FILE_NAME).ToList();
                            response.FilesData = new List<DDFilesData>();
                            foreach (var item in lstFilesToProcess)
                            {
                                response.FilesData.Add(new DDFilesData { File_Name = item });
                            }                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return null;
            }
            return ServiceHelper.SuccessResponse(response);
        }

        public ResponseObject<DdResponseFileParam> ReadClientDdFileNamesToUpload(RequestObject<DirectDebitParam> ddParam, List<DDFilesData> ddFiles)
        {
            DdResponseFileParam response = new DdResponseFileParam();

            DdTemplateAttach ddTemplate = null;
            if (ddParam?.Object?.FinanceCompanyId > 0)
                ddTemplate = ReadDdTemplate(new RequestObject<int>(ddParam.Context, ddParam.Object.FinanceCompanyId)).ResultSet;

            var msgFlow = ddTemplate.DdFileConfig.SingleOrDefault(s => s.DD_FILE_TYPE_ID == (int)DdFileTypeEnum.FileResponse && s.BP_BANK_ID == ddParam.Object.BPBankId);

            if (msgFlow == null)
                return null;

            response.MesgFlowId = Convert.ToInt32(msgFlow.MESG_FLOW_ID);

            string fileNames = null;
            foreach (var item in ddFiles)
            {
                if (item.File_Name != null && item.File_Name != "")
                {
                    fileNames += item.File_Name + ',';
                }
            }

            if (fileNames != null)
            {
                fileNames.TrimEnd(',', ' ');
                RequestObject<string> request = new RequestObject<string>(ddParam.Context, fileNames);
                var lstFilesToProcess = ReadDdResponseFilesToProcess(request).ResultSet.Select(p => p.FILE_NAME).ToList();
                response.FilesData = new List<DDFilesData>();
                foreach (var item in lstFilesToProcess)
                {
                    if (item != "")
                    {
                        foreach (var file in ddFiles)
                        {
                            if (item == file.File_Name)
                            {
                                response.FilesData.Add(new DDFilesData { File_Name = file.File_Name, File_Text = file.File_Text });
                            }
                        }
                    }
                }
            }

            return ServiceHelper.SuccessResponse(response);
        }

        public ResponseObject<bool> UploadCheckedResponseFiles(RequestObject<DdResponseFileParam> requestObject)
        {
            int mesgflowId = requestObject.Object.MesgFlowId;
            var mesgFlowParam = new MessageFlowExecParam
            {
                MesgFlowId = mesgflowId,
                Params = new Dictionary<string, object>()
                {
                   { "InputEntity", requestObject.Object}
                },
                InvokeType = IHEnums.InvokeTypeCodeEnum.Event
            };

            IIntegrationHubService srv = ChannelFactory.CreateChannel<IIntegrationHubService>();
            var response = mesgFlowParam.ExecuteMessageFlow(requestObject.Context, srv);
            ChannelFactory.CloseChannel(srv);
            //response.ResultSet.Params.Values.
            if (response.ResultSet.ExecutionStatus == IHEnums.MessageFlowExecutionStatusCodeEnum.Success)
            {
                return ServiceHelper.SuccessResponse(true);
            }

            return ServiceHelper.SuccessResponse(false);
        }

        public ResponseObject<List<DdResponseFilesToProcess>> ReadDdResponseFilesToProcess(RequestObject<string> requestObject)
        {
            return ServiceHelper.SuccessResponse(DdResponseFilesToProcess.Read(requestObject.Object.ToString()).ToList());
        }
        
        #endregion

        #region Adhoc DD

        public ResponseObject<List<ContractAdhocDdConfig>> PersistContractAdhocDdConfig(RequestObject<List<ContractAdhocDdConfig>> requestObject)
        {                       
            var ctx = EntityContextExt.Create(requestObject.Object);
            ctx.Persist();
            return ServiceHelper.SuccessResponse(ctx.Entity);
        }

        public ResponseObject<List<ContractAdhocDdConfig>> ModifyAdhocDdStatus(RequestObject<AdhocDirectDebitParam> requestObject)
        {
            var ctx = EntityContextExt.Create<ContractAdhocDdConfig>();
            ctx.Read(x => x.ADHC_TYPE_ID == requestObject.Object.AdhocTypeId && x.CONT_ID == requestObject.Object.ContractId
            && x.DD_STS_KEY == requestObject.Object.DdStatusKey);
            var list = ctx.Entity;
            foreach (var item in list)
            {
                item.DD_STS_KEY = requestObject.Object.ModifiedDdStatus;
            }
            var ctxPersist = EntityContextExt.Create(list);
            ctxPersist.Persist();
            return ServiceHelper.SuccessResponse(ctxPersist.Entity);

        }

        public ResponseObject<bool> AdhocDdStatusChange(RequestObject<DdTransactionTypeParam> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool> { ResultSet = false };
           
            return response;
        }

        #endregion

        #region Manual DD Receipting

        /// <summary>
        /// Performs DD generation for a fc + branch.
        /// </summary>
        /// <param name="requestObject"></param>
        /// <returns></returns>
        public ResponseObject<bool> PerformDdGeneration(RequestObject<DirectDebitParam> requestObject)
        {
            var ddParam = requestObject.Object;
            List<DdGenrContractToProcess> contsToProcess = null;
            ddParam.Context = requestObject.Context;

            if (ddParam.DdTemplate == null)
            {
                ddParam.DdTemplate = ReadDdTemplate(new RequestObject<int>(requestObject.Context, ddParam.FinanceCompanyId)).ResultSet;
            }
            
            if (requestObject.Object.ComponentsReceivables != null && requestObject.Object.ComponentsReceivables.Count > 0)
            {                
                contsToProcess = GetContractsToProcess(requestObject.Object.ComponentsReceivables);
            }
            
            if (contsToProcess != null && contsToProcess.Count == 0)
            {
                //commonhelper("No Contract found to process.", ddParam.Context, 0, false, NSLogLevel.Info);
                return ServiceHelper.SuccessResponse(false);
            }
            
            var groups = contsToProcess.GroupBy(s => s.FC_BANK_ID, (key, g) => new { FcBankId = key.GetValueOrDefault(0), Contracts = g.Select(t => t.CONT_ID) });                        
            int ddGenrMainId = GenerateDdGenrMain(ddParam);
            ddParam.DDMiscConfig = ReadMiscDDConfig(ddParam);
            
            foreach (var group in groups)
            {               
                var ddGenHeaderId = GenerateDdHeader(group.Contracts.First(), ddGenrMainId);                
                var procResult = ProcessManualReceiptingContracts(group.Contracts, ddGenHeaderId, ddParam);                
                if (procResult)
                {
                    var mesgFlowId = ddParam.DdTemplate.DdFileConfig.Where(s => s.DD_FILE_TYPE_ID == (int)DdFileTypeEnum.FileGeneration && s.BP_BANK_ID == group.FcBankId).FirstOrDefault()?.MESG_FLOW_ID;
                    if (mesgFlowId != null)
                    {
                        InvokeMessageFlow(mesgFlowId.Value, ddGenrMainId, ddGenHeaderId, ddParam);
                    }
                }
            }

            return ServiceHelper.SuccessResponse(true);
        }

        private List<DdGenrContractToProcess> GetContractsToProcess(List<ManualDDReceipting> componentsReceivables)
        {
            List<DdGenrContractToProcess> contractsToProcess = new List<DdGenrContractToProcess>();
            foreach (var item in componentsReceivables)
            {
                DdGenrContractToProcess info = new DdGenrContractToProcess();
                info.CONT_ID = item.CONT_ID;
                info.FC_BANK_ID = item.FC_BANK_ID;
                contractsToProcess.Add(info);
            }

            return contractsToProcess;
        }

        #endregion

        #region Security Deposit

        private static DdGenerationDetail ProcessSecurityDeposit(PayerBankDetails payerDdGenrDetail, int ddGenrHeaderId, DirectDebitParam ddParam, SettlementAssetComponentReceivable Scrty_Dpst_Detail, int Cont_Id)
        {
            var dueAmount = ReceivablesHelper.GetCurrentReceivableInclChrg(Scrty_Dpst_Detail);
            //Convert.ToDecimal(Scrty_Dpst_Detail.CMPT_AMNT) - (Convert.ToDecimal(Scrty_Dpst_Detail.SETL_AMNT) + Convert.ToDecimal(Scrty_Dpst_Detail.ADJT_AMNT));
            if (dueAmount > 0)
            {
                DdGenerationDetail ddGenDet = new DdGenerationDetail();
                ddGenDet.State = EntityState.NewModified;
                ddGenDet.STS_KEY = StatusCode.Pending.GetKey();
                ddGenDet.BUSS_PTNR_ID = payerDdGenrDetail.BUSS_PTNR_ID.GetValueOrDefault();
                ddGenDet.PYER_BP_BANK_ID = payerDdGenrDetail.PYER_BP_BANK_ID.GetValueOrDefault();
                ddGenDet.CONT_ID = Cont_Id;
                ddGenDet.AMNT = dueAmount;
                ddGenDet.AMNT_DUE_DTE = Scrty_Dpst_Detail.DUE_DTE;
                ddGenDet.ASET_CMPT_RCBL_ID = Scrty_Dpst_Detail.ASET_CMPT_RCBL_ID;
                ddGenDet.AMNT_CMPT_TYPE_KEY = AmountComponents.SecurityDeposit.GetKey();
                ddGenDet.DD_GENR_HEDR_ID = ddGenrHeaderId;
                //commonhelper("Security Deposit is added for processing. Contract ID:" + payerDdGenrDetail.CONT_ID, ddParam.Context, Convert.ToInt32(payerDdGenrDetail.CONT_ID), false, NSLogLevel.Info);
                return ddGenDet;

            }
            return null;
        }

        private decimal CalculateSecurityDeposit(int Cont_Id)
        {
            SecurityDepositParam ScrDpst = new SecurityDepositParam();
            try
            {
                ReceiptParam param = new ReceiptParam();
                List<int> contractIds = new List<int>();
                contractIds.Add(Cont_Id);
                param.ContractIds = contractIds;
                ScrDpst = ReceiptManagement.ReadSecurityDepositByContractId(param);
                return ScrDpst.NetRemainingAmount;

            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.CommunicationPolicy);
            }
            return ScrDpst.NetRemainingAmount;
        }

        #endregion

        #region Settlement
        
        private Tuple<SettlementResponse,int?> PerformSettlement(TaskData taskData, List<DdGenerationDetail> ddGenDetail, DirectDebitParam ddParam, bool isFinalEt = false)
        {
            ReceiptParam receiptParam = new ReceiptParam() { Receipts = new List<Receipt>() };
            List<Receipt> receipts = new List<Receipt>();
            DirectDebitSettlementBase settlementObject = null;
            SettlementResponse SettlementResponse = null;
            int? receiptId = null;
            try
            {
                receiptParam.ProcessQueueId = Convert.ToInt32(ddParam.ProcessQueueId);
                receiptParam.IsEtFinalReceipt = isFinalEt;

                if (ddGenDetail != null)
                {
                    List<DdGenerationDetail> normalReceiptDdGenrDets = null;
                    #region For Settlement Method "Configured Settlement Priority Template"
                    if (ddParam.DdTemplate != null && ddParam.DdTemplate.DD_SETL_MTHD_ID == Convert.ToInt32(DdSettlementMethodCodeEnum.AccordingToConfiguredSettlementPriority.GetId()))
                    {
                        //CommonHelper.Log("Settlement According To Configured Settlement Priority", ddParam.Context, 0, false, NSLogLevel.Info);
                        //selecting DD detail for Normal receivables in case Settlement Method "Configured Settlement Priority
                        normalReceiptDdGenrDets = ddGenDetail.Where(s => (s.AMNT_CMPT_TYPE_KEY == AmountComponents.Rental.GetKey() || s.AMNT_CMPT_TYPE_KEY == AmountComponents.Overdue.GetKey() || s.AMNT_CMPT_TYPE_KEY == AmountComponents.Charges.GetKey()) && Convert.ToInt32(s.DD_ADHC_CONF_ID) == 0).ToList();
                        if (normalReceiptDdGenrDets != null && normalReceiptDdGenrDets.Count > 0)
                        {
                            AmountComponents amountComponent = AmountComponents.NormalReceivables;
                            settlementObject = DirectDebitSettlementFactory.GetSettlementType(amountComponent);
                            if (settlementObject != null)
                            {
                                receiptParam = settlementObject.PrepareDirectDebitReceipt(normalReceiptDdGenrDets, ddParam, receiptParam);
                            }
                        }

                        var nonNormalReceiptDdGenrDets = ddGenDetail.Where(p => !normalReceiptDdGenrDets.Contains(p));
                        foreach (var ddGen in nonNormalReceiptDdGenrDets)
                        {
                            var enumValue = NS.Utilities.Enums.EnumExtensions.GetEnumValueFromKey<AmountComponents>(ddGen.AMNT_CMPT_TYPE_KEY).ToString();
                            AmountComponents amountComponent = (AmountComponents)Enum.Parse(typeof(AmountComponents), enumValue);

                            settlementObject = DirectDebitSettlementFactory.GetSettlementType(amountComponent);
                            if (settlementObject != null)
                            {
                                var rcptParam = settlementObject.PrepareDirectDebitReceipt(new List<DdGenerationDetail>() { ddGen }, ddParam, receiptParam);
                                if (rcptParam != null)
                                {
                                    receiptParam = rcptParam;
                                }
                                else
                                {
                                    receiptParam = null;
                                }

                            }
                        }
                        if (receiptParam != null && receiptParam.Receipts != null && receiptParam.Receipts.Count > 0)
                        {
                            var response = settlementObject.SettleDirectDebit(ddParam.Context, receiptParam);
                            receipts = response.Item1;
                            receiptId = response.Item1?.FirstOrDefault()?.RCPT_ID;
                            SettlementResponse = response.Item2;
                        }

                    }
                    #endregion

                    #region For Settlement Method "Component for Which DD is Sent"

                    else if (ddParam.DdTemplate != null && ddParam.DdTemplate.DD_SETL_MTHD_ID == Convert.ToInt32(DdSettlementMethodCodeEnum.ComponentForWhichDdIsSent.GetId()))
                    {
                       // CommonHelper.Log("Settlement According To Component For Which Dd Is Sent", ddParam.Context, 0, false, NSLogLevel.Info);
                        foreach (var ddGen in ddGenDetail)
                        {
                            var key = ddGen.AMNT_CMPT_TYPE_KEY;
                            if (ddGen.AMNT_CMPT_TYPE_KEY == AmountComponents.DownPayment.GetKey())
                            {
                                key = AmountComponents.DownPayment.ToString();
                            }
                            else if (ddGen.AMNT_CMPT_TYPE_KEY == AmountComponents.SecurityDeposit.GetKey())
                            {
                                key = AmountComponents.SecurityDeposit.ToString();
                            }
                            AmountComponents amountComponent = (AmountComponents)Enum.Parse(typeof(AmountComponents), key);

                            settlementObject = DirectDebitSettlementFactory.GetSettlementType(amountComponent);
                            if (settlementObject != null)
                            {
                                receiptParam = settlementObject.PrepareDirectDebitReceipt(new List<DdGenerationDetail>() { ddGen }, ddParam, receiptParam);
                            }
                        }
                        if (receiptParam != null)
                        {
                            var response = settlementObject.SettleDirectDebit(ddParam.Context, receiptParam);
                            receipts = response.Item1;
                            receiptId = receiptId = response.Item1?.FirstOrDefault()?.RCPT_ID;
                            SettlementResponse = response.Item2;
                        }
                    }
                    #endregion

                    MapReceiptWithDd(ddGenDetail, receipts, ddParam);

                }
            }
            catch
            {
                if (receiptParam.Receipts.FirstOrDefault().STS_KEY != StatusCode.Draft.GetKey())
                {
                    MapReceiptWithDd(ddGenDetail, receiptParam.Receipts, ddParam);
                    if (taskData?.ddGenDetail?.Count > 0)
                    {
                        MarkCheckpoint(taskData, 2, taskData.ddParam, taskData.ddGenDetail, taskData.isFinalEt);
                    }
                }
                throw;
            }
            return new Tuple<SettlementResponse, int?>(SettlementResponse, receiptId);
        }

        private void MapReceiptWithDd(List<DdGenerationDetail> ddGenDetail, List<Receipt> receipts, DirectDebitParam ddParam)
        {

            if (receipts != null && receipts.Count > 0)
            {
                for (int i = 0; i < receipts.Count; i++)
                {

                    var lstDdGenrIds = receipts[i].DD_GENR_DET_ID.Split(',').ToList();

                    if (lstDdGenrIds != null && lstDdGenrIds.Count > 0)
                    {
                        for (int k = 0; k < lstDdGenrIds.Count; k++)
                        {
                            if (ddGenDetail != null && ddGenDetail.Count > 0)
                            {
                                for (int j = 0; j < ddGenDetail.Count; j++)
                                {
                                    if (ddGenDetail[j].DD_GENR_DET_ID == Convert.ToInt32(lstDdGenrIds[k]))
                                    {
                                        ddGenDetail[j].RCPT_ID = receipts[i].RCPT_ID;
                                        var stsKey = StatusCode.SentForCollection.GetKey();
                                        if (ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.ResponseFileUpload && receipts[i].STS_KEY != StatusCode.Draft.GetKey())
                                        {
                                            stsKey = StatusCode.Honored.GetKey();
                                            ddGenDetail[j].STS_KEY = StatusCode.Success.GetKey();
                                        }
                                        if (ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.FileGeneration)
                                        {
                                            if (receipts[i].STS_KEY != StatusCode.Draft.GetKey())
                                            {
                                                ddGenDetail[j].STS_KEY = StatusCode.Pending.GetKey();
                                            }
                                            else
                                            {
                                                ddGenDetail[j].STS_KEY = StatusCode.Draft.GetKey();
                                            }
                                        }
                                                                                
                                        if (ddGenDetail[j].DD_ADHC_CONF_ID > 0 && receipts[i].STS_KEY != StatusCode.Draft.GetKey())
                                        {
                                            DbController controller = DbController.Create();
                                            string sql = "BEGIN TRANSACTION; UPDATE CONT_DD_ADHC_CONF SET DD_STS_KEY = @DdStatusKey, ADHC_DD_SENT_DTE = @AdhcDdSentDate WHERE DD_ADHC_CONF_ID = @DdAdhcConfId;COMMIT TRANSACTION;";
                                            controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "DdStatusKey", stsKey }, { "DdAdhcConfId", ddGenDetail[j].DD_ADHC_CONF_ID }, { "AdhcDdSentDate", ddParam.CurrentProcessingDate } });
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (ddGenDetail != null && ddGenDetail.Count > 0)
                        {
                            for (int j = 0; j < ddGenDetail.Count; j++)
                            {
                                if (ddGenDetail[j].DD_GENR_DET_ID == Convert.ToInt32(receipts[i].DD_GENR_DET_ID))
                                {
                                    ddGenDetail[j].RCPT_ID = receipts[i].RCPT_ID;
                                    var stsKey = StatusCode.SentForCollection.GetKey();
                                    if (ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.ResponseFileUpload && receipts[i].STS_KEY != StatusCode.Draft.GetKey())
                                    {
                                        stsKey = StatusCode.Honored.GetKey();
                                        ddGenDetail[j].STS_KEY = StatusCode.Success.GetKey();
                                    }
                                    if (ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.FileGeneration )
                                    {
                                        if (receipts[i].STS_KEY != StatusCode.Draft.GetKey())
                                        {
                                            ddGenDetail[j].STS_KEY = StatusCode.Pending.GetKey();
                                        }
                                        else
                                        {
                                            ddGenDetail[j].STS_KEY = StatusCode.Draft.GetKey();
                                        }

                                    }  
                                    if (ddGenDetail[j].DD_ADHC_CONF_ID > 0 && receipts[i].STS_KEY != StatusCode.Draft.GetKey())
                                    {
                                        DbController controller = DbController.Create();
                                        string sql = "BEGIN TRANSACTION; UPDATE CONT_DD_ADHC_CONF SET DD_STS_KEY = @DdStatusKey, ADHC_DD_SENT_DTE = @AdhcDdSentDate WHERE DD_ADHC_CONF_ID = @DdAdhcConfId;COMMIT TRANSACTION;";
                                        controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "DdStatusKey", stsKey }, { "DdAdhcConfId", ddGenDetail[j].DD_ADHC_CONF_ID }, { "AdhcDdSentDate", ddParam.CurrentProcessingDate } });
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private SettlementResponse ProcessUnallocatedReceipts(DirectDebitParam ddParam, int contractId, DateTime valueDate)
        {
            ReceiptParam receiptParam = new ReceiptParam();
            receiptParam.ValueDte = valueDate;
            receiptParam.ProcessingDte = ddParam.CurrentProcessingDate;
            receiptParam.CompanyId = ddParam.FinanceCompanyId;
            receiptParam.BranchId = ddParam.BranchId;
            receiptParam.ContractIds = new List<int>() { contractId };
            receiptParam.ReceiptType = ReceiptType.NormalReceipt;

            //Fill Fp info
            var contractContext = EntityContextExt.Create<ContractFPInfo>();
            contractContext.Read(p => p.CONT_ID == contractId);
            if (ReceiptingRepository.HasData(contractContext.Entity))
            {
                receiptParam.FpInfo = new List<Tuple<int, int?, int?>>() { new Tuple<int, int?, int?>(Convert.ToInt32(contractId), contractContext.Entity[0].FNCL_PROD_GRP_ID, contractContext.Entity[0].FNCL_PROD_ID) };
            }

            receiptParam.DepositType = NS.Resources.Enums.Receipt.DepositTypes.ParkSeparate;
            RequestObject<ReceiptParam> requestObject = new RequestObject<ReceiptParam>(ddParam.Context, receiptParam);
            var processReceiptResponse = new CMS.Business.ReceiptingLogic().ProcessReceipt(requestObject);

            if (processReceiptResponse.ResultSet != null && processReceiptResponse.Message.Type == MessageType.Success)
            {
                try
                {
                    if (processReceiptResponse != null)
                    {
                        processReceiptResponse.ResultSet.ResumeWorkflow = true;
                        //RequestObject<SettlementResponse> settlementResponse = new RequestObject<SettlementResponse>(context, processReceiptResponse);
                        WorkflowInputParams workflowInput = new WorkflowInputParams();
                        workflowInput.PostAction = true;
                        workflowInput.ScreenId = 2537;
                        workflowInput.ScreenAction = "Save";
                        workflowInput.Session = requestObject.Context;
                        workflowInput.Entity = processReceiptResponse.ResultSet;
                        workflowInput.EntityType = typeof(SettlementResponse).ToString();
                        workflowInput.BranchId = requestObject.Object.BranchId;
                        workflowInput.ApplicationKey = "CMS";
                        workflowInput.Module = ModuleTypeCode.RECEIPT.GetKey();
                        workflowInput.ReferenceId = 0;
                        //Invoke Workflow for Post settlement activities
                        RequestObject<WorkflowInputParams> reqObj = new RequestObject<WorkflowInputParams>(ddParam.Context, workflowInput);
                        //var workflowSrv = ChannelFactory.CreateChannel<IWorkflowEngineService>(true);
                        //workflowSrv.InvokeHumanWorkflow(reqObj);
                        //ChannelFactory.CloseChannel(workflowSrv);
                        using (var workflowSrv = new ProxyClient<IWorkflowEngineService>(true))
                        {
                            workflowSrv.ClientInstance.InvokeHumanWorkflow(reqObj);
                        }
                        //commonhelper("Settle through Park Separately Receipts.", ddParam.Context, 0, false, NSLogLevel.Info);
                    }
                }
                catch (Exception ex)
                {
                    //add log only message; exception should not be thrown 
                    ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy, ddParam.Context);
                }                
            }

            return null;
        }

        #endregion

        #region Reversal

        private static bool CancelReceipt(Context ctx, int receiptId, int DD_RSPN_DET_ID, DirectDebitParam ddParam)
        {
            if (receiptId > 0)
            {
                ReceiptingLogic rcptlogic = new ReceiptingLogic();
                ReceiptParam param = new ReceiptParam();
                param.LogInstallmentSettlement = ddParam.LogInstallmentSettlement;
                param.LogTransactionDetail = ddParam.LogTransactionDetail;
                param.ReceiptCriteria = new List<ReceiptCriteria>() { new ReceiptCriteria() { ReceiptId = Convert.ToInt32(receiptId) } };
                param.ProcessingDte = ddParam.CurrentProcessingDate;
                param.ProcessQueueId = Convert.ToInt32(ddParam.ProcessQueueId);
                param.DdResponseId = DD_RSPN_DET_ID;
                param.TaskMaxRetry = ddParam.TaskMaxRetry;
                param.TaskRetryCount = ddParam.TaskRetryCount;
                RequestObject<ReceiptParam> reqtObject = new RequestObject<ReceiptParam>(ctx, param);
                return rcptlogic.CancelReceiptByReceiptId(reqtObject).ResultSet;
            }
            return false;
        }

        #endregion

        #region Integration Hub

        public ResponseObject<bool> InvokeMessageFlowsForProcessQueueId(RequestObject<DirectDebitParam> requestObject)
        {
            DirectDebitParam ddParam = requestObject.Object;

            //read information against this process id
            var ddGenrHeaders = GetDdGenrHeaderByProcessQueueId(ddParam.ProcessQueueId);

            foreach (var header in ddGenrHeaders)
            {
                var mesgFlowId = ddParam.DdTemplate.DdFileConfig.Where(s => s.DD_FILE_TYPE_ID == (int)DdFileTypeEnum.FileGeneration && s.BP_BANK_ID == header.FC_BP_BANK_ID).FirstOrDefault()?.MESG_FLOW_ID;
                if (mesgFlowId != null)
                {
                    InvokeMessageFlow(mesgFlowId.Value, header.DD_GENR_MAIN_ID, header.DD_GENR_HEDR_ID, ddParam);
                }
            }

            return ServiceHelper.SuccessResponse(true);
        }   

        private void InvokeMessageFlow(int mesgFlowId, int ddGenrMainId, int ddGenHeaderId, DirectDebitParam ddParam)
        {
            int PageLimit = 20000;            
            using (var obj = new ProxyClient<IIntegrationHubService>())
            {
                RequestObject<int> requestObj = new RequestObject<int>(ddParam.Context, mesgFlowId);
                var result = obj.ClientInstance.ReadMessageFlowParameters(requestObj);
                if (result.ResultSet != null && result.ResultSet.Count > 0)
                {
                    var IHFileLineLimit = result.ResultSet.FirstOrDefault(p => p.NME == "MaxLinesPerFile");
                    if (IHFileLineLimit != null)
                    {                        
                        if (!String.IsNullOrWhiteSpace(IHFileLineLimit.DFLT_VAL))
                        { 
                            var fileLimit = Convert.ToInt32(IHFileLineLimit.DFLT_VAL);                                                    
                            if (fileLimit > PageLimit)
                            {
                                PageLimit = Convert.ToInt32(IHFileLineLimit.DFLT_VAL);
                            }
                            else
                            {
                                if (fileLimit > 0)
                                {
                                    PageLimit = (PageLimit / fileLimit) * fileLimit;
                                }                                
                            }
                        }   
                    }                                      
                }
            }                      

            var pageInfocontext = EntityContextExt<DdMessageflowPagesInfo>.Create(commandTimeOut: 600);
            var pageInfo = pageInfocontext.Read(PageLimit, ddGenHeaderId).Entity;
            if (pageInfo != null && pageInfo.Count > 0)
            {
                foreach (var page in pageInfo)
                {
                    var mesgFlowParam = new MessageFlowExecParam
                    {
                        MesgFlowId = mesgFlowId,
                        Params = new Dictionary<string, object>()
                        {
                            { "BranchId", ddParam.BranchId},
                            { "CompanyId", ddParam.FinanceCompanyId },
                            { "DdGenrHeaderId", ddGenHeaderId },
                            { "ddGenDetlIdFrom", page.STRT_DD_GENR_ID },
                            { "ddGenDetlIdTo", page.END_DD_GENR_ID },
                            { "CurrentProcessingDate", ddParam.CurrentProcessingDate.ToString("s") }                           
                        },
                        InvokeType = IHEnums.InvokeTypeCodeEnum.Event
                    };
                    IIntegrationHubService srv = ChannelFactory.CreateChannel<IIntegrationHubService>();
                    //mesgFlowParam.InvokeMessageFlow(ddParam.Context, srv);
                    var result = mesgFlowParam.ExecuteMessageFlow(ddParam.Context, srv);
                    ChannelFactory.CloseChannel(srv);
                }
            }
        }

        #endregion

        #region Helper Methods
        public ResponseObject<DateTime> AddBusinessDay(RequestObject<Tuple<DateTime,int,int>> requestObj)
        {
            ResponseObject<DateTime> response = new ResponseObject<DateTime>();
            response.Message = new MessageInfo();
            response.Message.Type = MessageType.Success;
            response.ResultSet = CommonHelper.AddBusinessDays(requestObj.Object.Item1, 1, DaysYearType.FinancialWorkingDays, requestObj.Object.Item2, requestObj.Object.Item3); 
            return response;            
        }
        public ResponseObject<DirectDebitParam> CalculateFromToDates(RequestObject<DirectDebitParam> requestObj)
        {
            DirectDebitParam ddParam = requestObj.Object;

            var workingDayType = DaysYearType.FinancialWorkingDays; // DD will always on Financucial working day

            var lastDd = DdGenerationMain.GetLastGeneratedDd(ddParam.FinanceCompanyId, ddParam.BranchId, ddParam.CurrentProcessingDate);
            var ddTemplate = ddParam.DdTemplate;

            if (ddTemplate == null)
            {
                var result = ReadDdTemplate(new RequestObject<int>(requestObj.Context, ddParam.FinanceCompanyId));
                if (result.ResultSet != null)
                {
                    ddTemplate = result.ResultSet;
                }
                else
                {
                    ResponseObject<DirectDebitParam> response = new ResponseObject<DirectDebitParam>();
                    response.Message = result.Message;
                    response.ResultSet = null;
                    return response;
                }
            }

            //Calculating from and to dates

            //To date will always be current processing date
            ddParam.ToDate = ddParam.CurrentProcessingDate;

            if (lastDd.Count == 0)
            {
                //in case dd running first time on this fc+branch from date will be current processing date
                ddParam.FromDate = ddParam.CurrentProcessingDate;
            }
            else
            {
                ddParam.LastDdDate = lastDd.Single().PRCG_DTE;

                if (CommonHelper.IsDateFirstWorkingDay(ddParam.CurrentProcessingDate, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId) && //is current processing date first day right after holiday? 
                    CommonHelper.IsDateLastWorkingDay(ddParam.LastDdDate, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId))//was last dd done on the last working date? 
                {
                    ddParam.FromDate = ddParam.CurrentProcessingDate;
                }
                else
                {
                    ddParam.FromDate = CommonHelper.AddBusinessDays(ddParam.LastDdDate, 1, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId);
                }

                //if ((ddParam.FromDate - ddParam.LastDdDate).Days > 0)//TODO: how to figure out if dd was missed?
                //{
                //    ddParam.FromDate = ddParam.LastDdDate;
                //}
            }

            if (ddParam.ToDate < ddParam.FromDate)
            {
                ddParam.ToDate = ddParam.FromDate;
            }
            //Calculating Effective To/From dates

            //if dd is to be send x-number of days before due date
            if (ddTemplate.DD_SEND_ID == (int)DdSendCodeEnum.DaysBeforeDueDate && Convert.ToInt32(ddTemplate.RNTL_SEND_DD_DAYS) > 0)
            {
                //step 1: calculate effective from date by adding working days to fromdate calculated above
                ddParam.EffectiveFromDate = CommonHelper.AddBusinessDays(ddParam.FromDate, Convert.ToInt32(ddTemplate.RNTL_SEND_DD_DAYS), workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId);

                //step 2: examine date calculated in step 1 
                var isFirstWorkingDay = CommonHelper.IsDateFirstWorkingDay(ddParam.EffectiveFromDate, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId);

                if (isFirstWorkingDay)//is it first working day after holiday?
                {
                    var lastWorkingDay = CommonHelper.GetLastWorkingDay(ddParam.EffectiveFromDate, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId);
                    ddParam.EffectiveFromDate = lastWorkingDay.AddDays(1);//to to the last holiday date
                }

                ddParam.EffectiveToDate = CommonHelper.AddBusinessDays(ddParam.ToDate, (int)ddTemplate.RNTL_SEND_DD_DAYS, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId);
                
            }
            else if (ddTemplate.DD_SEND_ID == (int)DdSendCodeEnum.DueDate)
            {
                ddParam.EffectiveFromDate = ddParam.FromDate;
                if (CommonHelper.IsDateFirstWorkingDay(ddParam.FromDate, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId))
                {
                    if (ddTemplate.DD_HLDY_ID == (int)DdHolidayCodeEnum.NextWorkingDay)
                    {
                        var lastWorkingDay = CommonHelper.GetLastWorkingDay(ddParam.EffectiveFromDate, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId);
                        ddParam.EffectiveFromDate = lastWorkingDay.AddDays(1);
                    }
                }

                ddParam.EffectiveToDate = ddParam.ToDate;
                if (CommonHelper.IsDateLastWorkingDay(ddParam.ToDate, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId))
                {
                    if (ddTemplate.DD_HLDY_ID == (int)DdHolidayCodeEnum.LastWorkingDay)
                    {
                        var nextWorkingDay = CommonHelper.GetNextWorkingDay(ddParam.ToDate, workingDayType, ddParam.FinanceCompanyId, ddParam.BranchId);
                        ddParam.EffectiveToDate = nextWorkingDay.AddDays(-1);
                    }
                }

            }

            if (ddParam.EffectiveToDate < ddParam.EffectiveFromDate)
            {
                ddParam.EffectiveToDate = ddParam.EffectiveFromDate;
            }

            return ServiceHelper.SuccessResponse(ddParam);
        }

        private string PrepareDiaryComment(DdResponseDetail responseDetail)
        {
            string Comment = string.Empty;
            DateTime ddCollectionDate = Convert.ToDateTime(responseDetail.DD_RSPN_DTE);
            string customerBank = ""; // TODO
            string customerBranch = "";// TODO
            string customerAccountNo = responseDetail.PYER_ACCT_NUMB;
            decimal DDAmount = responseDetail.AMNT;
            DateTime disHonorDate = Convert.ToDateTime(responseDetail.DD_RSPN_DTE);
            string ReasonCode = responseDetail.DD_RESN_CODE;

            Comment = "DD Record Failed.";
            Comment += "Collection Date: " + ddCollectionDate.ToString();
            Comment += "Customer Bank: " + customerBank;
            Comment += "Customer Branch: " + customerBranch;
            Comment += "Customer Account No: " + customerAccountNo;
            Comment += "DD Amount: " + DDAmount;
            Comment += "DD disHonor Date: " + disHonorDate.ToString();
            Comment += "Failuer Reason Code: " + ReasonCode;

            return Comment;
        }

        private List<PayerBankDetails> GetPayerDirectDebitDetail(int contractId)
        {
            List<PayerBankDetails> payerBankDetails = new List<PayerBankDetails>();
            EntityContextExt<PayerBankDetails> dbCtx = EntityContextExt<PayerBankDetails>.Create();
            dbCtx.Read(s => s.CONT_ID == contractId && s.ACT_IND == true);
            if (dbCtx != null && dbCtx.Entity != null)
            {
                payerBankDetails = dbCtx.Entity;
            }

            return payerBankDetails;
        }
        
        private List<DdGenerationHeader> GetDdGenrHeaderByProcessQueueId(int? processQueueId)
        {
            var ddGenrHedr = DdGenerationHeader.GetHeaderByProcessQueueId(processQueueId.Value);

            if (ddGenrHedr.Count == 0)
            {
                throw new Exception($"Unable to find DD_GENR_HEDR against process queue id {processQueueId}");
            }

            return ddGenrHedr;
        }

        /// <summary>
        /// Makes and persists a DdGenerationHeader.
        /// </summary>
        /// <param name="contractId">Contract id agains which </param>
        /// <param name="ddGenrMainId"></param>
        /// <returns></returns>
        /// <summary>       
        private int GenerateDdHeader(int contractId, int ddGenrMainId)
        {
            EntityContextExt<ContractDDConfiguration> dbCtx = EntityContextExt<ContractDDConfiguration>.Create();
            var ContDdConf = dbCtx.Read(s => s.CONT_ID == contractId && s.BP_ROLE_ID == 41 && s.ACT_IND == true).Entity.FirstOrDefault();

            DdGenerationHeader ddGenrDet = new DdGenerationHeader();
            ddGenrDet.DD_GENR_MAIN_ID = ddGenrMainId;
            ddGenrDet.BUSS_PTNR_ID = Convert.ToInt32(ContDdConf.BUSS_PTNR_ID);            
            ddGenrDet.FC_BP_BANK_ID = Convert.ToInt32(ContDdConf.BP_BANK_ID);

            if (ddGenrDet == null)
            {
                throw new Exception($"Could not get DD_GENR_HEDR for contract {contractId}. Check CONT_DD_CONF for this contract.");
            }

            var ctx = EntityContextExt<DdGenerationHeader>.Create(new List<DdGenerationHeader> { ddGenrDet });
            ctx.Persist();

            return ctx.Entity.First().DD_GENR_HEDR_ID;
        }

        /// <summary>
        /// Creates a DdGenerationMain object based on ddParams passed to it and returns it's id.
        /// </summary>
        /// <param name="ddParam">DirectDebitParam object with from/to dates and processing date.</param>
        /// <returns>id of the Dd generation object.</returns>
        public int GenerateDdGenrMain(DirectDebitParam ddParam)
        {
            DdGenerationMain ddGenrMain = new DdGenerationMain();
            ddGenrMain.FC_BRNC_BUSS_PTNR_ID = ddParam.BranchId;
            ddGenrMain.FC_BUSS_PTNR_ID = ddParam.FinanceCompanyId;
            ddGenrMain.FRM_DTE = ddParam.FromDate;
            ddGenrMain.TO_DTE = ddParam.ToDate;
            ddGenrMain.PRCG_DTE = ddParam.CurrentProcessingDate;
            ddGenrMain.EFCT_FRM_DTE = ddParam.EffectiveFromDate;
            ddGenrMain.EFCT_TO_DTE = ddParam.EffectiveToDate;
            ddGenrMain.MANU_IND = ddParam.ManualInd;
            ddGenrMain.PRCS_QUEU_ID = ddParam.ProcessQueueId;
            ddGenrMain.FILE_CNT = 0;
            var ctx = EntityContextExt<DdGenerationMain>.Create(new List<DdGenerationMain> { ddGenrMain });
            ctx.Persist();
            return ctx.Entity.Single().DD_GENR_MAIN_ID;
        }

        private bool HasData<T>(ICollection<T> collection)
        {
            return collection != null && collection.Count > 0;
        }        

        #endregion

        #region Public Methods

        public ResponseObject<DdHeaderForFile> ReadDdGenerationHeader(RequestObject<DirectDebitParam> requestObject)
        {
            var header = EntityContextExt<DdHeaderForFile>.Create().ReadFromSp("NFS_DD_GENR_HEDR_S", new Dictionary<string, object> { { "p_DD_HEDR_ID", requestObject.Object.HeaderId } }).Entity.FirstOrDefault();
            if (header != null)
            {
                Dictionary<string, object> keys = new Dictionary<string, object>();
                keys.Add("p_ddGenDetlIdFrom", requestObject.Object.ddGenDetlIdFrom);
                keys.Add("p_ddGenDetlIdTo", requestObject.Object.ddGenDetlIdTo);
                keys.Add("p_ddGenHedrId", requestObject.Object.HeaderId);
                header.DdDetailForFile = EntityContextExt<DdDetailForFile>.Create().ReadFromSp("NFS_DD_GENR_DET_S", keys).Entity;
            }

            return ServiceHelper.SuccessResponse(header);
        }

        public ResponseObject<int> ReadNextFileNumber(RequestObject<DdGenrMainParam> requestObject)
        {
            if (requestObject.Object != null)
            {
                DbController controller = DbController.Create();
                string sql = "BEGIN TRANSACTION; SELECT SUM(FILE_CNT) AS FilesCount from DD_GENR_MAIN AS dd WHERE CONVERT(date, dd.PRCG_DTE) = CONVERT(date, @PrcgDate); UPDATE DD_GENR_MAIN SET DD_GENR_MAIN.FILE_CNT += 1 WHERE DD_GENR_MAIN.DD_GENR_MAIN_ID = @DdGenrMainId;COMMIT TRANSACTION;";
                var result = controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "PrcgDate", requestObject.Object.PRCG_DTE }, { "DdGenrMainId", requestObject.Object.DD_GENR_MAIN_ID } });

                return ServiceHelper.SuccessResponse(result.Count > 0 && !string.IsNullOrEmpty(result[0]) ? Convert.ToInt32(result[0]) : -1);
            }
            return ServiceHelper.SuccessResponse(-1);
        }

        public ResponseObject<bool> PerformDdGenrToFileMapping(RequestObject<List<DdGenrDetToFileMapParam>> requestObject)
        {
            try
            {
                var stsKey = StatusCode.Success.GetKey();
                var adhcStsKey = StatusCode.Honored.GetKey();
                var isDdSuccessMark = false;               
                List<DdGenrDetToFileMapWithSts> toUpdateWithStatus = new List<DdGenrDetToFileMapWithSts>();
                List<DdAdhcMapSts> toUpdateAdhocStatus = new List<DdAdhcMapSts>();

                List<DdGenrDetToFileMap> toUpdate = new List<DdGenrDetToFileMap>();

                foreach (var row in requestObject.Object)
                {
                    if (row.IsDdSuccessMark != null && row.IsDdSuccessMark == true)
                    {
                        isDdSuccessMark = true;
                        foreach (var ddGenId in row.DdGenrDetIds)
                        {
                            toUpdateWithStatus.Add(new DdGenrDetToFileMapWithSts { DD_GENR_DET_ID = ddGenId, FILE_NME = row.FileName, FILE_ROW_NUMB = row.RowNumber, State = EntityState.DataModified, STS_KEY = stsKey });
                        }
                        foreach (var ddAdhcId in row.DdAdhcIds)
                        {
                            if (ddAdhcId > 0)
                            {
                                if (!toUpdateAdhocStatus.Exists(p => p.DD_ADHC_CONF_ID == ddAdhcId))
                                {
                                    toUpdateAdhocStatus.Add(new DdAdhcMapSts { DD_ADHC_CONF_ID = ddAdhcId, DD_STS_KEY = adhcStsKey, State = EntityState.DataModified });
                                }                                
                            }                            
                        }
                    }
                    else
                    {
                        foreach (var ddGenId in row.DdGenrDetIds)
                        {
                            toUpdate.Add(new DdGenrDetToFileMap { DD_GENR_DET_ID = ddGenId, FILE_NME = row.FileName, FILE_ROW_NUMB = row.RowNumber, State = EntityState.DataModified });
                        }
                    }
                    ////commonhelper("DD File Name: "+row.FileName, requestObject.Context, 0, false, NSLogLevel.Info);
                }

                if (isDdSuccessMark)
                {
                    EntityContextExt<DdGenrDetToFileMapWithSts> detToFileMapCtx = new EntityContextExt<DdGenrDetToFileMapWithSts>(toUpdateWithStatus);
                    detToFileMapCtx.Persist();
                    if (toUpdateAdhocStatus != null && toUpdateAdhocStatus.Count > 0)
                    {
                        EntityContextExt<DdAdhcMapSts> adhcCtx = new EntityContextExt<DdAdhcMapSts>(toUpdateAdhocStatus);
                        adhcCtx.Persist();
                    }
                }
                else
                {
                    EntityContextExt<DdGenrDetToFileMap> detToFileMapCtx = new EntityContextExt<DdGenrDetToFileMap>(toUpdate);
                    detToFileMapCtx.Persist();
                }                         
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }           

            return ServiceHelper.SuccessResponse(true);
        }

        public ResponseObject<bool> PersistDdResponseDetail(RequestObject<List<DdResponseDetail>> requestObject)
        {           
            if (requestObject.Object != null && requestObject.Object.Count > 0)
            {
                //if (requestObject.Object.Exists(p => p.STS_KEY == "" || p.STS_KEY == null || p.STS_KEY == String.Empty))
                //{
                    for (int i = 0; i < requestObject.Object.Count; i++)
                    {
                        if (requestObject.Object[i].DD_RESN_CODE == "0000")
                        {
                            requestObject.Object[i].STS_KEY = StatusCode.Success.GetKey();
                        }
                        else
                        {
                            requestObject.Object[i].STS_KEY = StatusCode.Failure.GetKey();
                        }
                    }
               // }

                var ctx = EntityContextExt<DdResponseDetail>.Create(requestObject.Object);
                ctx.Persist();
            }
            return ServiceHelper.SuccessResponse(true);
        }

        public ResponseObject<bool> PersistSADdResponseDetail(RequestObject<List<DdResponseDetail>> requestObject)
        {
            try
            {
                for (int i = 0; i < requestObject.Object.Count; i++)
                {
                    requestObject.Object[i].CONT_NUMB = requestObject.Object[i].CONT_NUMB.PadLeft(16, '0');
                }

                var ctx = EntityContextExt<DdResponseDetail>.Create(requestObject.Object);
                ctx.Persist();
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                return ServiceHelper.SuccessResponse(false);
            }

            return ServiceHelper.SuccessResponse(true);
        }

        /// <summary>
        ///  Reads DD Send For Collection
        /// </summary>
        /// <param name="requestObject"></param>
        /// <returns></returns>
        public ResponseObject<List<DdSendForCollection>> ReadDdSendForCollection(RequestObject<bool> requestObject)
        {
            ResponseObject<List<DdSendForCollection>> response = new ResponseObject<List<DdSendForCollection>>
            {
                Message = new MessageInfo()
            };
            try
            {
                var readcontext = EntityContextExt.Create<DdSendForCollection>();
                var localdata = readcontext.Read();
                if (localdata != null)
                {
                    response.ResultSet = localdata.Entity;
                    response.Message.Type = MessageType.Success;
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.CommunicationPolicy);
            }
            return response;
        }

        public ResponseObject<List<DDFileDetails>> GetDDFileDetails(RequestObject<string> requestObject)
        {
            List<DDFileDetails> response = new List<DDFileDetails>();
            try
            {
                //int process_queue_id = requestObject.Object;

                var context = EntityContextExt<DDFileDetails>.Create(commandTimeOut: 600);
                var result = context.Read(requestObject.Object).Entity;
                if (result != null && result.Count > 0)
                {
                    response = result;
                }
            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<List<DDFileDetails>>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }
            return ServiceHelper.SuccessResponse(response);
        }

        public ResponseObject<List<MandateFileVolume>> ReadMandateFileVolume(RequestObject<MandateFileParam> requestObject)
        {
            List<MandateFileVolume> response = new List<MandateFileVolume>();
            try
            {
                var context = EntityContextExt<MandateFileVolume>.Create();
                var result = context.Read(requestObject.Object.PREV_MANDATE_GENR_DATE, requestObject.Object.FinanceCompanyId);
                if (result != null && result.Entity != null && result.Entity.Count > 0)
                {
                    response = result.Entity;
                }
            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<List<MandateFileVolume>>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }
            return ServiceHelper.SuccessResponse(response);
        }

        public ResponseObject<List<ManualDDReceipting>> GetContractReceievables(RequestObject<DirectDebitParam> requestObject)
        {
            List<ManualDDReceipting> response = new List<ManualDDReceipting>();
            try
            {
                var context = EntityContextExt<ManualDDReceipting>.Create();
                var result = context.Read(requestObject.Object.amntComponentKey, requestObject.Object.FinanceCompanyId).Entity;
                if (result != null && result.Count > 0)
                {
                    response = result;
                }
            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<List<ManualDDReceipting>>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }
            return ServiceHelper.SuccessResponse(response);
        }

        public ResponseObject<MandateFileNameInfo> ReadMandateFileNameInfo(RequestObject<int> requestObject)
        {
            MandateFileNameInfo response = new MandateFileNameInfo();
            try
            {
                int companyId = requestObject.Object;
                var context = EntityContextExt<MandateFileNameInfo>.Create();
                var result = context.Read(companyId);
                if (result != null && result.Entity != null && result.Entity.Count > 0)
                {
                    response = result.Entity.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<MandateFileNameInfo>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }
            return ServiceHelper.SuccessResponse(response);
        }

        public static void SetLogRequestEvent(DirectDebitParam param)
        {
            var requests = LogRequestEvent();
            param.LogInstallmentSettlement = requests.Exists(p => p == RequestTypeCodes.InstallmentSettlement.GetKey());
            param.LogTransactionDetail = requests.Exists(p => p == RequestTypeCodes.TransactionDetail.GetKey());
        }

        private static List<string> LogRequestEvent()
        {
            var reqtTyp1 = RequestTypeCodes.TransactionDetail.GetKey();
            var reqtTyp2 = RequestTypeCodes.InstallmentSettlement.GetKey();
            DbController controller = DbController.Create();
            string sql = @"SELECT REQT_TYPE_KEY FROM CNF_REQT_TYPE_CODE WHERE REQT_TYPE_KEY = @ReqtType1 UNION ALL 
                SELECT REQT_TYPE_KEY FROM CNF_REQT_TYPE_CODE WHERE REQT_TYPE_KEY = @ReqtType2";
            return controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "ReqtType1", reqtTyp1 }, { "ReqtType2", reqtTyp2 } }).ToList();
        }

        #endregion

        #region Validations

        /// <summary>
        /// Check either adhoc DD exists with  or not
        /// </summary>
        /// <param name="requestObject"></param>
        /// <returns>true if exists false else case</returns>
        public ResponseObject<bool> IsAdhocDdExists(RequestObject<WriteOffParam> requestParam)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
                Int32 contractId = requestParam.Object.ContractId;
                var context = EntityContextExt<ContractAdhocDdConfig>.Create();


                context.Read(r => r.CONT_ID == contractId && r.ADHC_TYPE_ID == 10);
                var filteredRequests = context.Entity.Where(x => requestParam.Object.RequestStatuss.Any(y => y == x.DD_STS_KEY));
                if (filteredRequests != null && filteredRequests.Count() > 0)
                    response.ResultSet = true;
                return response;
            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<bool>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }
        }

        public ResponseObject<bool> IsDirectDebitPending(RequestObject<int> requestObject)
        {
            bool IsDirectDebitPending = false;
            try
            {
                Int32 contractId = requestObject.Object;
                var context = EntityContextExt<DirectDebitPending>.Create();

                var result = context.Read(contractId).Entity;

                if (result != null && result.Count > 0)
                {
                    if (result[0].DD_PEND_COUNT > 0 && result[0].DD_PEND_IND == true)
                        IsDirectDebitPending = true;
                    ContractNumber = result[0].CONT_NUMB;
                }

            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<bool>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }

            return ServiceHelper.SuccessResponse(IsDirectDebitPending);
        }      

        private bool ValidateLogErrorDet(List<DdGenerationDetail> ddDetToPrcs, Context ctx, int ddRspnId, DirectDebitParam ddParam)
        {

            #region map response task with DD Genration Detail            

            if (ddDetToPrcs != null && ddDetToPrcs.Count > 0)
            {
                for (int i = 0; i < ddDetToPrcs.Count; i++)
                {
                    ddDetToPrcs[i].DD_RSPN_DET_ID = ddRspnId;
                }

                var ctx1 = EntityContextExt<DdGenerationDetail>.Create(ddDetToPrcs);
                ctx1.Persist();

                // validate Contract Number

                // get response contract id
                DbController controller1 = DbController.Create();
                string sql1 = "";
                if (ddParam.DDMiscConfig.CTRY_ID ==  Convert.ToInt32(CountryCodes.SA.GetKey()))
                {
                    sql1 = "SELECT TOP 1 CONT_ID From cont WHERE @rspnContNumb LIKE '%'+cont.CONT_NUMB;";
                }
                else
                {
                    sql1 = "SELECT TOP 1 CONT_ID From cont WHERE cont.CONT_NUMB = @rspnContNumb;";
                }
                
                var rspnContId = controller1.GetCustomList<string>(sql1, new NS.Utilities.SerializableDictionary<string, object>() { { "rspnContNumb", ddDetToPrcs[0].CONT_NUMB } });
                if (rspnContId != null && rspnContId.Count > 0 && !String.IsNullOrEmpty(rspnContId[0]))
                {
                    ddDetToPrcs[0].RSPN_CONT_ID = Convert.ToInt32(rspnContId[0]);
                    if (ddDetToPrcs[0].CONT_ID != ddDetToPrcs[0].RSPN_CONT_ID)
                    {
                        //commonhelper("Contract Number: " + ddDetToPrcs[0].CONT_NUMB + "is not according to DD generation. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                        return false;
                    }
                }
                else
                {
                    //commonhelper("Contract Number: " + ddDetToPrcs[0].CONT_NUMB + "is not according to DD generation. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                    return false;
                }

                // validate Amount
                if (ddDetToPrcs.Sum(p=>p.AMNT) != ddDetToPrcs[0].RSPN_AMNT)
                {
                    //commonhelper("Response Amount for contract: " + ddDetToPrcs[0].CONT_NUMB + "is not according to DD generation. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                    return false;
                }
              
                #region Bank Details Validation                
                
                var ctx2 = EntityContextExt<PayerBankDetail>.Create();
                var responseObjectBp = ctx2.Read(ddDetToPrcs[0].CONT_ID).Entity.FirstOrDefault();

                if (responseObjectBp != null)
                {
                    if (!String.IsNullOrEmpty(responseObjectBp.ACCT_NME))
                    {
                        if (String.IsNullOrEmpty(ddDetToPrcs[0].PYER_ACCT_NME))
                        {
                            //commonhelper("File contains null value against pyer account name. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                            return false;
                        }
                        if (responseObjectBp.ACCT_NME.Trim().Length == ddDetToPrcs[0].PYER_ACCT_NME.Trim().Length)
                        {
                            if (responseObjectBp.ACCT_NME.Trim() != ddDetToPrcs[0].PYER_ACCT_NME.Trim())
                            {
                                //commonhelper("Payer Account Name: " + ddDetToPrcs[0].PYER_ACCT_NME + "is not according to DD generation. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                                return false;
                            }
                        }
                        else if(responseObjectBp.ACCT_NME.Trim().Length > ddDetToPrcs[0].PYER_ACCT_NME.Trim().Length)
                        {
                            var pyerNameFile = ddDetToPrcs[0].PYER_ACCT_NME.Trim();
                            var pyerNameLength = pyerNameFile.Length;
                            var pyerNameActual = responseObjectBp.ACCT_NME.Trim().Substring(0, (pyerNameLength));
                            if (pyerNameActual != pyerNameFile)
                            {
                                //commonhelper("Payer Account Name: " + ddDetToPrcs[0].PYER_ACCT_NME + "is not according to DD generation. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                                return false;
                            }
                        }
                        else
                        {
                            //commonhelper("Payer Account Name: " + ddDetToPrcs[0].PYER_ACCT_NME + "is not according to DD generation. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                            return false;
                        }
                        
                    }

                    if (!String.IsNullOrEmpty(responseObjectBp.ACCT_NUMB))
                    {
                        if (String.IsNullOrEmpty(ddDetToPrcs[0].PYER_ACCT_NUMB))
                        {
                            //commonhelper("File contains null value against pyer account number. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                            return false;
                        }
                        var requestAcctNo = responseObjectBp.ACCT_NUMB.PadLeft(ddDetToPrcs[0].PYER_ACCT_NUMB.Length, '0');

                        if (requestAcctNo != ddDetToPrcs[0].PYER_ACCT_NUMB)
                        {
                            //commonhelper("Account Number: " + ddDetToPrcs[0].PYER_ACCT_NUMB + "is not according to DD generation. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                            return false;
                        }
                    }

                }
                else
                {
                    //TODO: log for null response
                }
                #endregion

                // validate Reason Code

                if (!(ddDetToPrcs[0].DD_RESN_CODE.Length == 4 || ddDetToPrcs[0].DD_RESN_CODE.Length == 2))
                {
                    //commonhelper("Reason Code is invalid. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                    return false;
                }
                // validate contract status
                if (ddDetToPrcs[0].RSPN_STS_KEY.ToLower() == StatusCode.Failure.GetKey().ToLower() && ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.FileGeneration)
                {
                    DbController controller = DbController.Create();
                    string sql = "SELECT STS_KEY FROM CONT WHERE CONT_ID = @contId;";
                    var contStatus = controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "contId", ddDetToPrcs[0].CONT_ID } });
                    if (!String.IsNullOrEmpty(contStatus[0]))
                    {
                        if (contStatus[0] == StatusCode.FlatCancelled.GetKey())
                        {
                            //commonhelper("Contract is Flat Cancelled.So, system unable to cancel its receipt. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                            return false;
                        }
                    }                    
                }
                if (ddDetToPrcs[0].RSPN_STS_KEY.ToLower() == StatusCode.Success.GetKey().ToLower() && ddParam.DdTemplate.DD_SETL_TIME_ID == (int)DdSettlementTimeCodeEnum.ResponseFileUpload)
                {
                    DbController controller = DbController.Create();
                    string sql = "SELECT STS_KEY FROM CONT WHERE CONT_ID = @contId;";
                    var contStatus = controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "contId", ddDetToPrcs[0].CONT_ID } });
                    if (!String.IsNullOrEmpty(contStatus[0]))
                    {
                        if (contStatus[0] == StatusCode.FlatCancelled.GetKey())
                        {
                            //commonhelper("Contract is Flat Cancelled.So, system unable to settle its receipt. Row No." + ddDetToPrcs[0].RESP_FILE_ROW_NUMB, ctx, ddRspnId, false, NSLogLevel.Error);
                            return false;
                        }
                    }
                }
            }
            else
            {

                var ddResponseDet = EntityContextExt<DdResponseDetail>.Create().Read(p => p.DD_RSPN_DET_ID == ddRspnId).Entity.FirstOrDefault();
                //commonhelper("File name (" + ddResponseDet?.SEND_FILE_NME + ") or its row number (" + ddResponseDet?.FILE_ROW_NUMB + ") is not according to DD generation.", ctx, ddRspnId, false, NSLogLevel.Error);
                return false;
            }
            #endregion

            return true;
        }
        #endregion

        #region Schedular

        public ResponseObject<bool> GenerateDirectDebitSchedulerBatch(RequestObject<DirectDebitSchedulerParam> requestObject)
        {
            ResponseObject<bool> response = new ResponseObject<bool>();
            try
            {
               // List<BatchProcessRequestParam> batchProcessRequestParamList = new List<BatchProcessRequestParam>();
                int subtanatid = requestObject.Object.SubTenantId;
                var context = EntityContextExt<DDSchedularBatch>.Create();
                var result = context.Read(subtanatid);
                if (result != null && result.Entity != null && result.Entity.Count > 0)
                {
                    foreach (var entity in result.Entity)
                    {
                        if (entity.DD_UTIL_ID == Convert.ToInt32(DirectDebitUtilityCodeEnum.Both))
                        {
                            GenerateBatchProcess(2537, entity, requestObject.Context, subtanatid);
                            // for DD File Upload
                            //GenerateBatchProcess(2938, entity, requestObject.Context, subtanatid, batchProcessRequestParamList);
                            GenerateBatchProcessGroup(entity, requestObject.Context, subtanatid);                            
                        }
                        else if (entity.DD_UTIL_ID == Convert.ToInt32(DirectDebitUtilityCodeEnum.DDGeneration))
                        {
                            GenerateBatchProcess(2537, entity, requestObject.Context, subtanatid);
                        }

                        else if (entity.DD_UTIL_ID == Convert.ToInt32(DirectDebitUtilityCodeEnum.DDReturnfileupload))
                        {
                            // for DD File Upload
                            //GenerateBatchProcess(2938, entity, requestObject.Context, subtanatid, batchProcessRequestParamList);
                            GenerateBatchProcessGroup(entity, requestObject.Context, subtanatid);
                        }
                    }
                    //IBatchProcessControllerService srv = ChannelFactory.CreateChannel<IBatchProcessControllerService>();
                    //RequestObject<List<BatchProcessRequestParam>> requestList = new RequestObject<List<BatchProcessRequestParam>>(requestObject.Context, batchProcessRequestParamList);
                    //response = srv.StartBatchProcessList(requestList);
                    //ChannelFactory.CloseChannel(srv);
                }
            }
            catch (Exception ex)
            {
                return ServiceHelper.ServiceErrorResponse<bool>(ExceptionHandlingPolicy.BusinessPolicy, ex);
            }
            return ServiceHelper.SuccessResponse(response.ResultSet);
        }

        #endregion

        #region Invoke Workflow
        private static void InvokePostSettlementWorkflow(Context context, SettlementResponse processReceiptResponse, int branchId, int? receiptId)
        {
            try
            {
                if (processReceiptResponse != null)
                {
                    processReceiptResponse.ResumeWorkflow = true;                    
                    WorkflowInputParams workflowInput = new WorkflowInputParams();
                    workflowInput.PostAction = true;
                    workflowInput.ScreenId = 2537;
                    workflowInput.ScreenAction = "Save";
                    workflowInput.Session = context;
                    workflowInput.Entity = processReceiptResponse;
                    workflowInput.EntityType = typeof(SettlementResponse).ToString();
                    workflowInput.BranchId = branchId;
                    workflowInput.ApplicationKey = "CMS";
                    workflowInput.Module = ModuleTypeCode.RECEIPT.GetKey();
                    workflowInput.ReferenceId = Convert.ToInt32(receiptId);                    
                    RequestObject<WorkflowInputParams> reqObj = new RequestObject<WorkflowInputParams>(context, workflowInput);                    
                    using (var workflowSrv = new ProxyClient<IWorkflowEngineService>(true))
                    {
                        workflowSrv.ClientInstance.InvokeHumanWorkflow(reqObj);
                    }
                }
            }
            catch(Exception ex)
            {                
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy, context);
            }
        }

        public ResponseObject<IList<DirectDebitErrorLog>> GetDDErrorLogReportData(RequestObject<DirectDebitErrorLog> requestObject)
        {
            var response = new ResponseObject<IList<DirectDebitErrorLog>> { Message = new MessageInfo() };
            try
            {
                using (var contextExtDDDetailInfo = EntityContextExt.Create<DirectDebitErrorLog>())
                {
                    contextExtDDDetailInfo.Read(requestObject.Object.FromDate, requestObject.Object.ToDate);
                    if (contextExtDDDetailInfo.Entity != null)
                    {
                        response.ResultSet = contextExtDDDetailInfo.Entity;
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                response.Message.Type = MessageType.Error;
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }

        #endregion


        #region Retry check points
        private void MarkCheckpoint( TaskData taskData, int checkpoint, DirectDebitParam ddParam = null, List<DdGenerationDetail> ddDetail = null, bool isFinalEt = false)
        {
            if (taskData != null)
            {
                FillTaskData(taskData, ddParam, ddDetail, isFinalEt);
                taskData.checkPoint = checkpoint;
                //save
                //taskItem.RESN_ID = checkpoint;
                //var taskItemContext1 = EntityContextExt.Create(new[] { taskItem });
                //taskItemContext1.Persist();
            }
        }

        private void FillTaskData(TaskData taskData, DirectDebitParam ddParam = null, List<DdGenerationDetail> ddDetail = null, bool isFinalEt = false)
        {
            if (taskData != null)
            {
                taskData.ddParam = new DirectDebitParam();
                taskData.ddParam = ddParam;

                taskData.ddGenDetail = new List<DdGenerationDetail>();
                taskData.ddGenDetail = ddDetail;
                taskData.isFinalEt = isFinalEt;
            }                   
        }

        private ResponseObject<bool> HandleTaskRetry( TaskData taskData, Context requestContext, ResponseObject<bool> response)
        {
            if (taskData != null && taskData.ddGenDetail != null && taskData.ddGenDetail.Count > 0)
            {
                ContractNumber = taskData.ContNumb;
                if (taskData.checkPoint == 1)
                {                    
                    PerformSettlement( taskData, taskData.ddGenDetail, taskData.ddParam, taskData.isFinalEt);
                    if (taskData.ddGenDetail.Exists(p => p.STS_KEY == StatusCode.Pending.GetKey()))
                    {
                        var ctx = EntityContextExt<DdGenerationDetail>.Create(taskData.ddGenDetail);
                        ctx.Persist();
                    }
                }
                if (taskData.checkPoint == 2)
                {
                    if (taskData.ddGenDetail.Exists(p => p.STS_KEY == StatusCode.Pending.GetKey()))
                    {
                        var ctx = EntityContextExt<DdGenerationDetail>.Create(taskData.ddGenDetail);
                        ctx.Persist();
                    }
                }
            } 
            response.ResultSet = true;
            response.Message.Type = MessageType.Success;
            return response;
        }

        private void MarkInvalidAdhoc(int? DD_ADHC_CONF_ID, DateTime CurrentProcessingDate)
        {
            var stsKey = StatusCode.Invalid.GetKey();
            DbController controller = DbController.Create();
            string sql = "BEGIN TRANSACTION; UPDATE CONT_DD_ADHC_CONF SET DD_STS_KEY = @DdStatusKey, ADHC_DD_SENT_DTE = @AdhcDdSentDate WHERE DD_ADHC_CONF_ID = @DdAdhcConfId;COMMIT TRANSACTION;";
            controller.GetCustomList<string>(sql, new NS.Utilities.SerializableDictionary<string, object>() { { "DdStatusKey", stsKey }, { "DdAdhcConfId", DD_ADHC_CONF_ID }, { "AdhcDdSentDate", CurrentProcessingDate } });
        }
        #endregion
    }
}

public class DdSelectHelper
{
    public int? RCPT_ID { get; set; }

    public int DD_RSPN_DET_ID { get; set; }
    public string STS_KEY { get; set; }
}

public class TaskData
{   
    public string ContNumb { get; set; }

    public int checkPoint { get; set; }

    public bool isFinalEt { get; set; } = false;
    
    public DirectDebitParam ddParam { get; set; }

    public List<DdGenerationDetail> ddGenDetail { get; set; }
        
}

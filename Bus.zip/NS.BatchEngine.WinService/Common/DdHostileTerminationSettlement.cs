﻿using CMS.Models.DirectDebit;
using CMS.Models.DirectDebit.Custom;
using CMS.Models.Receipting.Custom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.DirectDebit.Business.Settlement
{
    class DdHostileTerminationSettlement : DirectDebitSettlementBase
    {
        public override ReceiptParam PrepareDirectDebitReceipt(List<DdGenerationDetail> ddGenDetails, DirectDebitParam ddParam, ReceiptParam receiptParam)
        {
         
                return new ReceiptParam();
        }
    }
}

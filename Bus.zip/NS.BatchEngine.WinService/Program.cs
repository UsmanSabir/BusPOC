﻿using BatchEngine.Core;
using BatchEngine.Core.BatchEngineCore;
using BatchEngine.Core.JobScheduler;
using NFS.Models.BusinessPartner;
using NS.Configurations.Models;
using NS.ORM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NS.BatchEngine.WinService
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ready");

            var configManager = NS.Configurations.Manager.ConfigurationManager.GetInstance();
            //NS.Configurations.Manager.ConfigurationManager.GetInstance().InitializeConfigAndServices();
            configManager.InitializeConfigAndServices(new BpemSettings());
            //var redisConnection = "10.39.100.27";// "localhost";// "172.31.15.19";
            var redisConnection = "172.31.15.19";

            //var serializer = Bootstrap.GetSerializer();          
            //IProcessDataStorage storage=new RedisProcessStorage(NodeSettings.Instance.Name, redisConnection, serializer);

            //IPubSubFactory factory= new RedisPubSubFactory(redisConnection);
            //IDistributedMutexFactory mutexFactory=new DistributedMutexFactory(redisConnection);

            var nodeId = System.Configuration.ConfigurationManager.AppSettings["NodeId"] ?? "Raheel";
            //  NS.Configurations.Models.BpemSettings

            var container = Bootstrap.Initialize(NS.Configurations.Models.BpemSettings.SubtenantId, nodeId, null, NS.Configurations.Models.BpemSettings.DependProcessComp, 0);

            var scheduler = container.Resolve<IJobScheduler>();
            BatchEngineService service = container.Resolve<BatchEngineService>(); // new BatchEngineService(new StatePersistenceService(), new EntityFactory());
            try
            {
                //IConnectionStringSetting settings;
                //var r = LogContext.ContextToLog;
                //Console.WriteLine(r?.SubTenantId);

                //if (DependencyHelper.TryGetInstance(out settings, string.Empty, "BusinessDatabase"))
                //{
                //    var connectionString = settings.GetConnectionStringBySubtenant(1);
                //    string s = settings.ConnectionString;
                //    var providerName = settings?.ProviderName;
                //}
                var tenant = GetTenantPartitionEntity(2);
                service.Start();
                var vir = new List<int>();
                var jc = new List<JobCriteria>();
                vir.Add(4);
                vir.Add(1);
                jc.Add(new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = tenant.PRCG_DTE.Value, ReferenceId = 1, SubTenantId = 1 });
                //1492665
                //service.SubmitSingleProcess<TestDDProcess>(new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 }, false);
                //scheduler.CreateJob(vir, jc, "Raheel");
                // scheduler.CreateJob(2800, new List<JobCriteria>() { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = tenant.PRCG_DTE.Value, ReferenceId = 1, SubTenantId = 1, Tag = "" } }, "Raheelm2");
                //scheduler.CreateJob(2800, new List<int>() { 1, 4 }, new List<JobCriteria>() { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = tenant.PRCG_DTE.Value, ReferenceId = 1, SubTenantId = 1, Tag = "" } }, "Raheel");
                string tag = "<?xml version=\"1.0\"?><DirectDebitParam xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">  <SubTenantId>0</SubTenantId>  <BranchId>1492665</BranchId>  <CompanyId>0</CompanyId>  <ProcessingDate xsi:nil=\"true\" />  <SubmittedProcessingDate xsi:nil=\"true\" />  <ReferenceId>0</ReferenceId>  <InvokeType>0</InvokeType>  <TaskRetryCount>0</TaskRetryCount>  <TaskMaxRetry>0</TaskMaxRetry>  <AMNT_PER_TRANS>0</AMNT_PER_TRANS>  <FinanceCompanyId>1</FinanceCompanyId>  <FromDate>2019-01-18T18:04:42.787</FromDate>  <ToDate>2029-12-28T00:00:00</ToDate>  <EffectiveFromDate>2019-01-18T18:04:42.787</EffectiveFromDate>  <EffectiveToDate>2029-12-28T00:00:00</EffectiveToDate>  <LastDdDate>0001-01-01T00:00:00</LastDdDate>  <CurrentProcessingDate>2029-12-28T00:00:00</CurrentProcessingDate>  <ProcessQueueId xsi:nil=\"true\" />  <ManualInd>false</ManualInd>  <HeaderId>0</HeaderId>  <Take>0</Take>  <Skip>0</Skip>  <BPBankId>0</BPBankId>  <ComponentsReceivables />  <IsManual>true</IsManual>  <ddGenDetlIdTo>0</ddGenDetlIdTo>  <ddGenDetlIdFrom>0</ddGenDetlIdFrom>  <DDHeaders />  <IncludeOdRental xsi:nil=\"true\" />  <LogInstallmentSettlement>true</LogInstallmentSettlement>  <LogTransactionDetail>true</LogTransactionDetail></DirectDebitParam>";
                //scheduler.CreateJob(2,new List<JobCriteria>() { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } }, "raheelm2");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine("Done");
            Console.ReadLine();
            service.Stop();

            Console.WriteLine("Stopped <enter> to exit");
            Console.ReadLine();

        }

        public static TenantPartitionEntity GetTenantPartitionEntity(int partId)
        {
            var contextExt = EntityContextExt.Create<TenantPartitionEntity>();

            return contextExt.Read(x => x.PART_ID == partId)?.Entity?.FirstOrDefault();
        }
    }
}

﻿using System;
using BusImpl.Logs;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using NS.Utilities.Context;

namespace BusImpl.Listeners
{
    public class LogContextTaskListener:ITaskListener
    {
        private readonly ILogger _logger;

        public LogContextTaskListener(ILoggerFactory logger)
        {
            _logger = logger.CreateLogger();
        }

        public void BeforeExecute(ITaskContext taskContext)
        {
            var contextToLog = ContextHost.GetCurrentContext().Copy((int) taskContext.State.Id);
            contextToLog.ProcessQueueId = (int) taskContext.State.ProcessId;//backward compatibility
            contextToLog.ProcessId = taskContext.ProcessExecutionContext.Configuration.ProcessId;
            contextToLog.TaskId = (int) taskContext.State.Id;
            //contextToLog.Status
            //contextToLog.TaskStatus
            ContextHost.SetAppContext(contextToLog);
            //LogContext.ContextToLog = contextToLog; 
        }

        public void AfterExecute(ITaskContext taskContext)
        {
            
        }

        public string Name { get; } = nameof(LogContextTaskListener);
    }

    public class LogContextProcessListener : ProcessSubscriberBase //IProcessSubscriber
    {
        private readonly ILogger _logger;

        public LogContextProcessListener(ILoggerFactory logger)
        {
            _logger = logger.CreateLogger();
        }

       
        //public string Name { get; } = nameof(LogContextTaskListener);
        public override int ProcessKey { get; } = 0;
        public override bool CanExecute(IProcessExecutionContext context)
        {
            //todo: check if can execute i.e. is month-end or day-end
            if (context.Configuration.IsMonthEnd)
            {
                
            }

            return true;
        }


        public override void BeforeVolumeGenerating(IProcessExecutionContext context)
        {
            var contextToLog = ContextHost.NodeContext.Copy((int)context.ProcessState.Id);
            contextToLog.ProcessQueueId = (int)context.ProcessState.Id;//backward compatibility
            contextToLog.ProcessId = context.Configuration.ProcessId;
            contextToLog.TaskId = 0;
            //contextToLog.Status
            //contextToLog.TaskStatus
            ContextHost.SetAppContext(contextToLog);
        }

        public override void ProcessStarting(IProcessExecutionContext context)
        {
            var contextToLog = ContextHost.NodeContext.Copy((int)context.ProcessState.Id);
            contextToLog.ProcessQueueId = (int)context.ProcessState.Id;//backward compatibility
            contextToLog.ProcessId = context.Configuration.ProcessId;
            contextToLog.TaskId = 0;
            //contextToLog.Status
            //contextToLog.TaskStatus
            ContextHost.SetAppContext(contextToLog);
        }
    }
}
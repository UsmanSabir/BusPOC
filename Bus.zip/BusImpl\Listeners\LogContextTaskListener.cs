﻿using System;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using NS.Utilities.Context;

namespace BusImpl.Listeners
{
    public class LogContextTaskListener:ITaskListener
    {
        private readonly ILogger _logger;

        public LogContextTaskListener(ILoggerFactory logger)
        {
            _logger = logger.CreateLogger();
        }

        public void BeforeExecute(ITaskContext taskContext)
        {
            //new Context()
            //{
            //    ApplicationCode = "BPEM",
            //    ContextId = Guid.NewGuid(),
            //    SessionId = 12,
            //    SessionCode = "14",
            //    LoginId = "BPEM", //Environment.UserName,
            //    MachineIp = "127.0.0.1",
            //    UserName = "BPEM", //Environment.UserName,
            //    SubTenantId = 1,
            //    ReferenceId = 1,

            //    //CustomParameters = new NS.Utilities.SerializableDictionary<string, object>()
            //    //{
            //    //    { "ServerIP", ConfigurationManager.AppSettings["ApplicationServer"]}
            //    //},
            //}
            LogContext.ContextToLog = new Context
            {
                ContextId = taskContext.ProcessExecutionContext.ProcessState.CorrelationId,
                SubTenantId = taskContext.ProcessExecutionContext.Criteria.SubTenantId,
                ApplicationCode = "BPEM",
                SessionId = 12,
                SessionCode = "14",
                LoginId = "BPEM", //Environment.UserName,
                MachineIp = "127.0.0.1",
                UserName = "BPEM", //Environment.UserName,
                ReferenceId = 1,
                //todo
            };
        }

        public void AfterExecute(ITaskContext taskContext)
        {
            
        }

        public string Name { get; } = nameof(LogContextTaskListener);
    }

    public class LogContextProcessListener : ProcessSubscriberBase //IProcessSubscriber
    {
        private readonly ILogger _logger;

        public LogContextProcessListener(ILoggerFactory logger)
        {
            _logger = logger.CreateLogger();
        }

       
        //public string Name { get; } = nameof(LogContextTaskListener);
        public override int ProcessKey { get; } = 0;
        public override bool CanExecute(IProcessExecutionContext context)
        {
            //todo: check if can execute i.e. is month-end or day-end
            if (context.Configuration.IsMonthEnd)
            {
                
            }

            return true;
        }


        public override void BeforeVolumeGenerating(IProcessExecutionContext context)
        {
            LogContext.ContextToLog = new Context
            {
                ContextId = context.ProcessState.CorrelationId,
                SubTenantId = context.Criteria.SubTenantId,
                ApplicationCode = "BPEM",
                SessionId = 12,
                SessionCode = "14",
                LoginId = "BPEM", //Environment.UserName,
                MachineIp = "127.0.0.1",
                UserName = "BPEM", //Environment.UserName,
                ReferenceId = 1,
                //todo
            };
        }

        public override void ProcessStarting(IProcessExecutionContext context)
        {
            LogContext.ContextToLog = new Context
            {
                ContextId = context.ProcessState.CorrelationId,
                SubTenantId = context.Criteria.SubTenantId,
                ApplicationCode = "BPEM",
                SessionId = 12,
                SessionCode = "14",
                LoginId = "BPEM", //Environment.UserName,
                MachineIp = "127.0.0.1",
                UserName = "BPEM", //Environment.UserName,
                ReferenceId = 1,
                //todo
            };
        }
    }
}
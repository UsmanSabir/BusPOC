﻿using BatchEngine.Core;

namespace NS.BatchEngine.PubSub
{
    public class EmptyPublisher:IDistributedMessagePublisher
    {
        public void Dispose()
        {
            
        }

        public void PublishMessage(string message, string type)
        {
            
        }

        public void PublishMessage<T>(T message)
        {
            
        }
    }
}
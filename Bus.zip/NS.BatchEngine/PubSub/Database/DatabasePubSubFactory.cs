﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using NS.BatchEngine.Empty;
using NS.BatchEngine.PubSub.Udp;

namespace NS.BatchEngine.PubSub.Database
{
    public class DatabasePubSubFactory: IPubSubFactory
    {
        readonly object _lock=new object();
        //private UdpPortSubscriber _portSubscriber;
        protected const string PubChannel = "BPEMChannel";
        readonly List<VirtualSubscriber> _activeSubscribers = new List<VirtualSubscriber>();
        private readonly IFrameworkLogger _systemLogger;
        private DatabaseListener _dbListener;
        public DatabasePubSubFactory(IBatchLoggerFactory logger)
        {
            _systemLogger = logger.GetSystemLogger();
            //_portSubscriber=new UdpPortSubscriber(_ip, port, _systemLogger, OnMessageReceived);
            _dbListener=new DatabaseListener(_systemLogger, OnMessageReceived);
        }

        private void OnMessageReceived(string channel, string type, string message)
        {
            IEnumerable<VirtualSubscriber> subscribers;
            lock (_lock)
            {
                subscribers = _activeSubscribers.Where(ch=>ch.Channel==channel).ToList();
            }
            foreach (var subscriber in subscribers)
            {
                subscriber.OnMessageReceived(type, message);
            }
        }

        public IDistributedMessagePublisher GetPublisher(CancellationToken token, ILogger logger, string channelName = null)
        {
            if (nameof(IWatchDogMessage).Equals(channelName))
            {
                return new DatabasePublisher(channelName, logger);
            }
            else
            {
                return new EmptyPub();
            }
            
        }

        public IDistributedMessageSubscriber GetSubscriber(CancellationToken token, ILogger logger, string channelName = null)
        {
            var ch = channelName ?? PubChannel;

            
            VirtualSubscriber virtualSubscriber = new VirtualSubscriber((s) =>
            {
                lock (_lock)
                {
                    _activeSubscribers.Remove(s);
                    _systemLogger.Trace("DB PubSub channel {channel} removed", s.Channel);
                    if (_activeSubscribers.Count == 0)
                    {
                        _dbListener.Dispose();
                        _dbListener = null;
                        _systemLogger.Info("DB PubSub listener closed due to empty subscribers");
                    }
                }
            }, ch);

            lock (_lock)
            {
                _activeSubscribers.Add(virtualSubscriber);
                
                if (_dbListener == null)
                {
                    _dbListener=new DatabaseListener(_systemLogger, OnMessageReceived);
                    _dbListener.Start(token);//todo
                }
            }
            
            return virtualSubscriber;
        }
    }
}
﻿using System;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Helper;
using BatchEngine.Models.Entities;
using NS.BatchEngine.Redis;
using NS.ORM;

namespace NS.BatchEngine.PubSub.Database
{
    public class DatabasePublisher:IDistributedMessagePublisher
    {
        private readonly RedisSerializer _serializer;
        protected const string PubChannel = "BPEMChannel";
        private readonly string _customChannel;
        private readonly ILogger _logger;

        public DatabasePublisher(string channel, ILogger logger)
        {
            _customChannel = channel;
            _logger = logger;
            _serializer = new RedisSerializer();
        }
        public void Dispose()
        {
            
        }

        public void PublishMessage(string message, string type)
        {
            Robustness.Instance.SafeCall(() =>
            {
                var ext = EntityContextExt.Create<BatchEngineCommand>();
                var command = ext.CreateNew();
                command.CHANNEL = _customChannel;
                command.COMMAND = message;
                command.TYPE = type;
                command.PUBLISHEDBYNODE = NodeSettings.Instance.Name;
                command.PUBLISHEDTIME = DateTime.UtcNow;
                ext.Persist();
            }, _logger);
        }

        public void PublishMessage<T>(T message)
        {
            var json = _serializer.SerializeToString(message);
            var type = message.GetType().Name;
            PublishMessage(json, type);
        }
    }
}
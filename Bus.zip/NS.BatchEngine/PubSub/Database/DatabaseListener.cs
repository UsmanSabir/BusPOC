﻿using System;
using System.Configuration;
using System.Linq;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Helper;
using BatchEngine.Models.Entities;
using NS.ORM;

namespace NS.BatchEngine.PubSub.Database
{
    public class DatabaseListener:RepeatingProcess
    {
        DateTime _lastSync=new DateTime(1901,1,1);

        private readonly Action<string, string, string> _onMessageReceived;
        private readonly string _connectionString;

        public DatabaseListener(ILogger logger, Action<string, string, string> onMessageReceived, string connectionString) : base("DbCommandListener", logger)
        {
            _onMessageReceived = onMessageReceived;
            _connectionString = connectionString;

            var interval = ConfigurationManager.AppSettings["DbCommandPollIntervalSecs"] ?? "5";
            int pollInterval = 5; //sec
            if (!string.IsNullOrWhiteSpace(interval))
            {
                int.TryParse(interval, out pollInterval);
            }

            if (pollInterval <= 0 || pollInterval > 999)
                pollInterval = 5;

            base.Interval= TimeSpan.FromSeconds(pollInterval);
        }

        internal override void PerformIteration()
        {
            CheckPendingCommands();
        }

        void CheckPendingCommands()
        {
            EntityContextExt<BatchEngineCommand> ext;
            if (string.IsNullOrWhiteSpace(_connectionString))
                ext = EntityContextExt.Create<BatchEngineCommand>();
            else
                ext = EntityContextExt.Create<BatchEngineCommand>(_connectionString);

            ext.Read(r => r.ISHANDLEDBYMASTER == false); //r.PUBLISHEDTIME >= _lastSync && 
            if (ext.Entity.Count > 0)
            {
                foreach (var command in ext.Entity.OrderBy(r => r.PUBLISHEDTIME))
                {
                    Robustness.Instance.SafeCall(() =>
                    {
                        _onMessageReceived?.Invoke(command.CHANNEL, command.TYPE, command.COMMAND);
                        command.ISHANDLEDBYMASTER = true;
                        command.HANDLERNODEID = NodeSettings.Instance.Name;
                    }, Logger);
                }

                Robustness.Instance.SafeCall(() =>
                {
                    ext.Persist();
                }, Logger);
                
            }

            _lastSync=DateTime.UtcNow;
            

            //var command = ext.CreateNew();
            //command.CHANNEL = _customChannel;
            //command.COMMAND = message;
            //command.TYPE = type;
            //command.PUBLISHEDBYNODE = NodeSettings.Instance.Name;
            //command.PUBLISHEDTIME = DateTime.UtcNow;
        }


    }
}
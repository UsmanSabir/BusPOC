﻿using System;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.JobScheduler;
using BatchEngine.Core.Serializers;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using NS.BaseModels;
using NS.ORM;

namespace NS.BatchEngine
{
    internal abstract class JobSchedulerBase
    {
        private readonly IBatchEngineQueueService _batchEngineQueueService;
        private readonly ISerializer _ser;
        protected internal IFrameworkLogger SystemLogger;

        protected JobSchedulerBase(ISerializersFactory factory, IBatchLoggerFactory loggerFactory, 
            IBatchEngineQueueService batchEngineQueueService)
        {
            _batchEngineQueueService = batchEngineQueueService;
            SystemLogger = loggerFactory.GetSystemLogger();
            
            //_ser = SerializersFactory.Instance.GetSerializer<List<JobCriteria>>();
            //JsonSerializer serializer=new JsonSerializer();
            _ser = factory.GetSerializer(typeof(JobCriteria));
        }

        public long CreateProcessJob(int processId, List<JobCriteria> criteria, string submittedBy, bool hasPriority = false,
            bool isResubmission = false)
        {
            return CreateJob(new List<int>() {processId}, criteria, submittedBy, hasPriority, isResubmission);
        }

        public long CreateJob(int groupId, List<JobCriteria> criteria, string submittedBy, bool hasPriority, bool isResubmission)
        {
            BatchGroupState group=new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(@group)
            {
                GroupKey = groupId,
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsFinished = false,
                IsResubmission = isResubmission,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual,
                HasPriority = hasPriority
            };

            var ext = EntityContextExt.Create(new[] {@group});
            ext.Persist();

            Publish(groupEntity.Id);

            return @group.ID;
        }

        public long CreateJob(int groupId, List<int> processIds, List<JobCriteria> criteria, string submittedBy, bool hasPriority = false,
            bool isResubmission = false)
        {
            BatchGroupState group = new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(@group)
            {
                GroupKey = groupId,
                Payload = _ser.SerializeToString(processIds),
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsResubmission = isResubmission,
                IsFinished = false,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual,
                HasPriority = hasPriority
            };

            var ext = EntityContextExt.Create(new[] { @group });
            ext.Persist();

            Publish(groupEntity.Id);

            return groupEntity.Id;
        }

        public long CreateJob(List<int> processIds, List<JobCriteria> criteria, string submittedBy, bool hasPriority, bool isResubmission)
        {
            BatchGroupState group = new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(@group)
            {
                Payload = _ser.SerializeToString(processIds),
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsResubmission = isResubmission,
                IsFinished = false,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual,
                HasPriority = hasPriority
            };
            
            var ext = EntityContextExt.Create(new[] { @group });
            ext.Persist();

            Publish(groupEntity.Id);

            return groupEntity.Id;
        }

        public long CreateQueueJob(List<int> processIds, List<JobCriteria> criteria, string queueName, string submittedBy, bool hasPriority, bool isResubmission = false)
        {
            if (processIds==null || processIds.Count==0)
                throw new ArgumentNullException(nameof(processIds));

            if (string.IsNullOrWhiteSpace(queueName))
                throw new ArgumentNullException(nameof(queueName));

            BatchGroupState group = new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(@group)
            {
                Payload = _ser.SerializeToString(processIds),
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsResubmission = isResubmission,
                IsFinished = false,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual,
                QueueName = queueName,
                HasPriority = hasPriority
            };

            using (var unitOfWorkManager = new DataQueueManager())
            {
                //unitOfWorkManager.QueuePersist(new List<BatchGroupState>{ group });
                unitOfWorkManager.QueueCommand(uow =>
                {
                    var ext = EntityContextExt.Create(new[] { @group }).UsingUnitOfWork(uow);
                    ext.Persist();

                    var queueSeq = _batchEngineQueueService.GetProcessSeqNoForQueue(queueName, @group.ID, new TransactionWrapper(uow));
                    @group.QUEUESEQ = queueSeq;
                    @group.State = EntityState.DataModified; //trigger update command
                    ext.Persist();
                });

                unitOfWorkManager.Commit();
            }

            //var ext = EntityContextExt.Create(new[] { group });
            //using (var unitOfWork = ext.InitiateUnitOfWork())
            //{
            //    ext.Persist();

            //    var queueSeq = _batchEngineQueueService.GetProcessSeqNoForQueue(queueName,@group.ID, new TransactionWrapper(unitOfWork));
            //    group.QUEUESEQ = queueSeq;
            //    ext.Persist();

            //    unitOfWork.Save();
            //}
            

            Publish(groupEntity.Id);

            return groupEntity.Id;
        }

        protected abstract void Publish(long groupId);

        
    }
}
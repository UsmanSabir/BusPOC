﻿using System;
using System.Threading;
using BatchEngine.Core;
using BatchEngine.Core.JobScheduler;
using BatchEngine.Core.Serializers;

namespace NS.BatchEngine
{
    internal class JobScheduler: JobSchedulerBase, IJobScheduler
    {
        private readonly IDistributedMessagePublisher _publisher;

        public JobScheduler(ISerializersFactory factory, IPubSubFactory pubSubFactory, IBatchLoggerFactory loggerFactory, 
            IBatchEngineQueueService batchEngineQueueService) : base(factory, loggerFactory, batchEngineQueueService)
        {
            _publisher = pubSubFactory.GetPublisher(CancellationToken.None, SystemLogger, nameof(IWatchDogMessage));
        }

        protected override void Publish(long groupId)
        {
            try
            {
                _publisher.PublishMessage(new ProcessGroupAddedMessage { GroupId = groupId }); 
                //_publisher.PublishMessage(new ProcessGroupAddedMessage { GroupId = groupId }); GroupMessage
            }
            catch (Exception e)
            {
                SystemLogger.Error("Failed to publish ProcessGroupAddedMessage for groupId {groupId} having error {error}", groupId, e);
            }
        }

        
    }
}
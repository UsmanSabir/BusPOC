﻿namespace NS.BatchEngine
{
    public class Class1
    {
    }
}

﻿using BatchEngine.Core;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Subscribers;

namespace NS.BatchEngine.Listeners
{
    public class GroupCompleteListener:IGroupSubscriber
    {
        public int GroupKey { get; } = 0;

        public void OnGroupStarting(IGroupStartContext context)
        {
            
        }

        public void OnGroupSubmitted(IGroupStartContext context)
        {
            
        }

        public void OnGroupComplete(IGroupCompleteContext context)
        {
            //if (context.IsResubmitted)
            //    throw new InvalidOperationException("Process already submitted");

            //context.Resubmit(context.Criteria, "Rollover");
        }
    }
}
﻿using BatchEngine.Core.Process;

namespace NS.BatchEngine.Listeners
{
    public class MSMQWatchdogMessageHandler:IMasterSlaveObserver
    {
        private bool _isMaster = false;

        public void OnMaster()
        {
            _isMaster = true;
        }

        public void OnSlave()
        {
            _isMaster = false;
        }

        void OnMessageArrived()
        {
            if (_isMaster)
            {

            }
        }
    }
}
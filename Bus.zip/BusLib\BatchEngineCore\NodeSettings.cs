﻿using System.Configuration;
using System.Threading;

namespace BusLib.BatchEngineCore
{
    public class NodeSettings
    {
        private static NodeSettings _instance;

        public NodeSettings()
        {
            LockKey = "BatchEngine"; // + System.Diagnostics.Process.GetCurrentProcess().Id
        }

        public static NodeSettings Instance => _instance ?? (_instance = new NodeSettings()); //todo

        public string Name { get; private set; } = ConfigurationManager.AppSettings["NodeId"]?? "Node"; //todo
        public int Throttling { get; private set; } = 0;
        public string LockKey { get; private set; }
    }
}
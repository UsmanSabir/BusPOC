﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using BusLib.BatchEngineCore.Groups;
using BusLib.Core;
using BusLib.Helper;
using BusLib.Infrastructure;
using BusLib.JobSchedular;
using BusLib.Serializers;

namespace BusLib.BatchEngineCore
{
    class ProcessExecutionContext: SafeDisposable,  IProcessExecutionContextWithVolume
    {
        private readonly IProcessDataStorage _storage;
        private readonly IResolver _resolver;
        readonly ConcurrentDictionary<string,object> _tempData=new ConcurrentDictionary<string, object>();
        readonly ConcurrentDictionary<string, IDisposable> _tempResources = new ConcurrentDictionary<string, IDisposable>();
        private bool _hasVolume = false;

        public ProcessExecutionContext(ILogger logger, IReadWritableProcessState processState,
            IProcessConfiguration configuration, IProcessDataStorage storage,
            IReadWritableGroupEntity groupDetailsGroupEntity, IResolver resolver)
        {
            Logger = logger;
            //ProcessState = processState;
            WritableProcessState = processState;
            Configuration = configuration;
            _storage = storage;
            _resolver = resolver;
            GroupEntity = groupDetailsGroupEntity;
            Criteria =
                SerializersFactory.Instance.DefaultSerializer.DeserializeFromString<JobCriteria>(processState.Criteria);
        }

        public IReadWritableProcessState WritableProcessState
        {
            get;
            private set;
        }

        public ILogger Logger { get; }
        public IDashboardService DashboardService { get; }
        public IProcessState ProcessState => WritableProcessState;
        public DateTime ProcessingDate => ProcessState.ProcessingDate;
        public JobCriteria Criteria { get; }

        //private IProcessConfiguration _configuration;
        public IProcessConfiguration Configuration
        {
            get;// { return _configuration ?? (_configuration = GetProcessConfiguration()); }
        }

        internal bool HasVolume
        {
            get { return _hasVolume || ProcessState.HasVolume; }
        }

        public IReadWritableGroupEntity GroupEntity { get; }

        public bool AddUpdateProcessData<T>(string key, T value)
        {
            _storage.AddOrUpdateProcessData(ProcessState.Id, key, value, TimeSpan.FromMinutes(Configuration.ProcessTimeoutMins??360)); //6 hours
            return true;
        }

        public T GetProcessData<T>(string key)
        {
            return _storage.GetProcessData<T>(ProcessState.Id, key);
        }

        public object GetProcessData(string key)
        {
            return _storage.GetProcessData<object>(ProcessState.Id, key);
        }

        public bool SetTempData(string key, object value)
        {
            _tempData.AddOrUpdate(key, value, (s, o) => value);
            return true;
        }

        public T GetTempData<T>(string key)
        {
            if (_tempData.TryGetValue(key, out object value))
            {
                return (T)value;
            }

            return default;
        }

        public T GetSetTempData<T>(string key, Func<T> valueFactory)
        {
            T res = (T) _tempData.GetOrAdd(key, k => valueFactory());
            return res;
        }

        public object GetTempData(string key)
        {
            return GetTempData<object>(key);
        }

        public void SetVolumeGenerated()
        {
            _hasVolume = true;
        }

        public bool SetResource(string key, IDisposable value)
        {
            _tempResources.AddOrUpdate(key, value, (s, o) => value);
            return true;
        }

        public T GetResource<T>(string key)
        {
            if (_tempResources.TryGetValue(key, out IDisposable value))
            {
                return (T)value;
            }

            return default;
        }

        public T GetSetResource<T>(string key, Func<T> valueFactory) where T:IDisposable
        {
            T res = (T)_tempResources.GetOrAdd(key, k => valueFactory());
            return res;
        }



        internal void UpdateProcessEntity(IReadWritableProcessState state)
        {
            WritableProcessState = state;
        }

        protected override void Dispose(bool disposing)
        {
            CleanResources();

            base.Dispose(disposing);
        }

        public void CleanResources()
        {
            foreach (var value in _tempResources.Values)
            {
                Robustness.Instance.SafeCall(() => { value?.Dispose(); });
            }
            _tempResources.Clear();
        }
    }

    class ProcessFinalizerContext:IProcessFinalizedContext
    {
        private readonly IJobScheduler _scheduler;
        private readonly IStateManager _stateManager;
        private IGroupEntity _groupEntity;

        public ProcessFinalizerContext(IProcessExecutionContext executionContext, IJobScheduler scheduler, IStateManager stateManager)
        {
            ExecutionContext = executionContext;
            _scheduler = scheduler;
            _stateManager = stateManager;
            
            Logger = executionContext?.Logger;
        }

        public ILogger Logger { get; }
        public IProcessExecutionContext ExecutionContext { get; }

        public void Resubmit(List<JobCriteria> criteria, string reason)
        {
            var payload = GroupEntity.Payload;
            if (string.IsNullOrWhiteSpace(payload))
            {
                //group submission
                _scheduler.CreateJob(GroupEntity.GroupKey, criteria, "BPEM", GroupEntity.HasPriority, true);
            }
            else
            {
                var serializer = SerializersFactory.Instance.DefaultSerializer;
                var processKeys = serializer.DeserializeFromString<List<int>>(payload);
                _scheduler.CreateJob(processKeys, criteria, "BPEM", GroupEntity.HasPriority, true);
            }

            IsResubmitted = true;

            //throw new System.NotImplementedException();
        }

        public bool IsResubmitted { get; private set; } = false;

        protected internal IGroupEntity GroupEntity
        {
            get
            {
                return _groupEntity?? (_groupEntity = _stateManager.GetGroupEntity(ExecutionContext.ProcessState.GroupId));
            }
        }
    }
}
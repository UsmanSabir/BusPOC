﻿/****** Object:  Database [TestDB]    Script Date: 1/24/2019 7:14:03 PM ******/
--CREATE DATABASE [TestDB]
-- CONTAINMENT = NONE
-- ON  PRIMARY 
--( NAME = N'TestDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestDB.mdf' , SIZE = 71680KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
-- LOG ON 
--( NAME = N'TestDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\TestDB_log.ldf' , SIZE = 1341696KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
--GO
--ALTER DATABASE [TestDB] SET COMPATIBILITY_LEVEL = 120
--GO
--IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
--begin
--EXEC [TestDB].[dbo].[sp_fulltext_database] @action = 'enable'
--end
--GO
--ALTER DATABASE [TestDB] SET ANSI_NULL_DEFAULT OFF 
--GO
--ALTER DATABASE [TestDB] SET ANSI_NULLS OFF 
--GO
--ALTER DATABASE [TestDB] SET ANSI_PADDING OFF 
--GO
--ALTER DATABASE [TestDB] SET ANSI_WARNINGS OFF 
--GO
--ALTER DATABASE [TestDB] SET ARITHABORT OFF 
--GO
--ALTER DATABASE [TestDB] SET AUTO_CLOSE OFF 
--GO
--ALTER DATABASE [TestDB] SET AUTO_SHRINK OFF 
--GO
--ALTER DATABASE [TestDB] SET AUTO_UPDATE_STATISTICS ON 
--GO
--ALTER DATABASE [TestDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
--GO
--ALTER DATABASE [TestDB] SET CURSOR_DEFAULT  GLOBAL 
--GO
--ALTER DATABASE [TestDB] SET CONCAT_NULL_YIELDS_NULL OFF 
--GO
--ALTER DATABASE [TestDB] SET NUMERIC_ROUNDABORT OFF 
--GO
--ALTER DATABASE [TestDB] SET QUOTED_IDENTIFIER OFF 
--GO
--ALTER DATABASE [TestDB] SET RECURSIVE_TRIGGERS OFF 
--GO
--ALTER DATABASE [TestDB] SET  DISABLE_BROKER 
--GO
--ALTER DATABASE [TestDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
--GO
--ALTER DATABASE [TestDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
--GO
--ALTER DATABASE [TestDB] SET TRUSTWORTHY OFF 
--GO
--ALTER DATABASE [TestDB] SET ALLOW_SNAPSHOT_ISOLATION ON 
--GO
--ALTER DATABASE [TestDB] SET PARAMETERIZATION SIMPLE 
--GO
--ALTER DATABASE [TestDB] SET READ_COMMITTED_SNAPSHOT ON 
--GO
--ALTER DATABASE [TestDB] SET HONOR_BROKER_PRIORITY OFF 
--GO
--ALTER DATABASE [TestDB] SET RECOVERY FULL 
--GO
--ALTER DATABASE [TestDB] SET  MULTI_USER 
--GO
--ALTER DATABASE [TestDB] SET PAGE_VERIFY CHECKSUM  
--GO
--ALTER DATABASE [TestDB] SET DB_CHAINING OFF 
--GO
--ALTER DATABASE [TestDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
--GO
--ALTER DATABASE [TestDB] SET TARGET_RECOVERY_TIME = 0 SECONDS 
--GO
--ALTER DATABASE [TestDB] SET DELAYED_DURABILITY = DISABLED 
--GO
--EXEC sys.sp_db_vardecimal_storage_format N'TestDB', N'ON'
--GO
/****** Object:  Table [BatchGroupState]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [BatchGroupState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[GroupKey] [int] NOT NULL,
	[SubmittedBy] [varchar](250) NOT NULL,
	[IsManual] [bit] NOT NULL,
	[IsResubmission] [bit] NOT NULL,
	[Criteria] [varchar](250) NOT NULL,
	[IsFinished] [bit] NOT NULL,
	[IsStopped] [bit] NOT NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[Payload] [varchar](max) NULL,
	[IsGenerated] [bit] NOT NULL,
	[QueueName] [varchar](50) NULL,
	[QueueSeq] [int] NULL,
	[HasPriority] [bit] NOT NULL,
 CONSTRAINT [PK_BatchGroupState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [BatchProcessConfig]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [BatchProcessConfig](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProcessId] [int] NOT NULL,
	[ProcessKey] [int] NOT NULL,
	[BatchSize] [int] NOT NULL,
	[ProcessTimeoutMins] [int] NULL,
	[TaskTimeout] [int] NULL,
	[ProcessRetries] [int] NULL,
	[TaskRetries] [int] NULL,
	[RetryDelayMilli] [int] NULL,
	[MaxVolumeRetries] [int] NOT NULL CONSTRAINT [DF_BatchProcessConfig_MaxVolumeRetries]  DEFAULT ((3)),
	[QueueSize] [int] NULL,
	[ErrorThreshold] [int] NULL,
	[DAYS_YEAR_TYPE_KEY] [varchar](25) NULL,
	[ACT_IND] [bit] NOT NULL CONSTRAINT [DF_BatchProcessConfig_ACT_IND]  DEFAULT ((1)),
	[ROLL_OVER_EXEC_IND] [bit] NOT NULL CONSTRAINT [DF_BatchProcessConfig_ROLL_OVER_EXEC_IND]  DEFAULT ((1)),
	[IsMonthEnd] [bit] NOT NULL CONSTRAINT [DF_BatchProcessConfig_IsMonthEnd]  DEFAULT ((0)),
 CONSTRAINT [PK_BatchProcessConfig] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [BatchProcessGroupDetail]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [BatchProcessGroupDetail](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[GroupKey] [int] NOT NULL,
	[ProcessId] [int] NOT NULL,
	[ParentProcessId] [int] NULL,
	[DependentProcessIds] [varchar](500) NULL,
	[ACT_IND] [bit] NOT NULL CONSTRAINT [DF_BatchProcessGroupDetail_ACT_IND]  DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [BatchProcessGroupMaster]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [BatchProcessGroupMaster](
	[GroupKey] [int] IDENTITY(1,1) NOT NULL,
	[NME] [varchar](100) NULL,
	[insr_by] [varchar](20) NULL,
	[insr_DTE] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[GroupKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [BatchProcessState]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [BatchProcessState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CorrelationId] [uniqueidentifier] NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[RetryCount] [int] NOT NULL,
	[CompanyId] [int] NOT NULL,
	[BranchId] [int] NOT NULL,
	[ProcessingDate] [datetime] NOT NULL,
	[ProcessId] [int] NOT NULL,
	[IsVolumeGenerated] [bit] NOT NULL,
	[HasVolume] [bit] NOT NULL,
	[ParentId] [bigint] NULL,
	[DependentProcessIds] [varchar](500) NULL,
	[GroupId] [bigint] NOT NULL,
	[IsFinished] [bit] NOT NULL,
	[IsStopped] [bit] NOT NULL,
	[Criteria] [nvarchar](4000) NOT NULL,
	[StartTime] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[SubTenantId] [int] NOT NULL,
	[CompleteTime] [datetime] NULL,
	[GenerationCompleteTime] [datetime] NULL,
	[ResultStatus] [varchar](50) NOT NULL,
	[GroupSeqId] [int] NOT NULL,
	[GroupStopper] [bit] NULL,
	[QueueName] [varchar](50) NULL,
	[QueueSeq] [int] NULL,
	[HasPriority] [bit] NOT NULL,
 CONSTRAINT [PK_BatchProcessState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [BatchQueue]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [BatchQueue](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[QueueName] [varchar](50) NOT NULL,
	[QueueSeq] [int] NOT NULL,
	[RefId] [bigint] NOT NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchQueue_IsFinished]  DEFAULT ((0)),
 CONSTRAINT [PK_BatchQueue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [BatchTaskState]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
CREATE TABLE [BatchTaskState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[Payload] [varchar](500) NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[FailedCount] [int] NOT NULL,
	[DeferredCount] [int] NOT NULL,
	[NodeKey] [varchar](250) NULL,
	[IsFinished] [bit] NOT NULL,
	[IsStopped] [bit] NOT NULL,
	[StartedOn] [datetime] NULL,
	[CompletedOn] [datetime] NULL,
	[HasPriority] [bit] NOT NULL,
 CONSTRAINT [PK_BatchTaskState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [BatchTaskValue]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [BatchTaskValue](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TaskId] [bigint] NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[StateKey] [varchar](250) NOT NULL,
	[StateValue] [varchar](500) NULL,
 CONSTRAINT [PK_BatchTaskValue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [QUEUE]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [QUEUE](
	[QUEUEID] [int] IDENTITY(1,1) NOT NULL,
	[SOMEACTION] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[QUEUEID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [Student]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Student](
	[Id] [int] NULL,
	[FirstName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [StudentSubject]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [StudentSubject](
	[Id] [int] NULL,
	[SubjectId] [int] NULL,
	[StudentId] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [subject]    Script Date: 1/24/2019 7:14:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [subject](
	[Id] [int] NULL,
	[SubjectName] [nvarchar](50) NULL
) ON [PRIMARY]

GO
SET IDENTITY_INSERT [BatchProcessConfig] ON 

GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (1, 1, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, 5, NULL, 1, 1, 0)
GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (2, 2, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (3, 3, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (4, 4, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (5, 5, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (6, 6, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (7, 7, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (8, 8, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (9, 9, 5301, 10, 500, 3, 3, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
SET IDENTITY_INSERT [BatchProcessConfig] OFF
GO
SET IDENTITY_INSERT [BatchProcessGroupDetail] ON 

GO
INSERT [BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND]) VALUES (1, 2, 1, NULL, NULL, 1)
GO
INSERT [BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND]) VALUES (2, 2, 2, 1, NULL, 1)
GO
INSERT [BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND]) VALUES (3, 2, 3, 2, NULL, 1)
GO
INSERT [BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND]) VALUES (5, 2, 4, 3, NULL, 1)
GO
INSERT [BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND]) VALUES (6, 2, 5, 1, N'2', 1)
GO
INSERT [BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND]) VALUES (7, 2, 6, 5, NULL, 1)
GO
INSERT [BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND]) VALUES (8, 2, 7, 4, NULL, 1)
GO
INSERT [BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND]) VALUES (9, 2, 9, 7, NULL, 0)
GO
SET IDENTITY_INSERT [BatchProcessGroupDetail] OFF
GO
SET IDENTITY_INSERT [BatchProcessGroupMaster] ON 

GO
INSERT [BatchProcessGroupMaster] ([GroupKey], [NME], [insr_by], [insr_DTE]) VALUES (2, N'DayEnd', N'Usman', CAST(N'2019-01-08 00:00:00.000' AS DateTime))
GO
SET IDENTITY_INSERT [BatchProcessGroupMaster] OFF
GO
SET IDENTITY_INSERT [BatchQueue] ON 

GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (1, N'Fin', 1, 1, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (2, N'Fin', 2, 2, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (3, N'Fin', 3, 3, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (4, N'Fin', 4, 4, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (5, N'Fin', 5, 5, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (6, N'Fin', 6, 6, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (7, N'Fin', 7, 7, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (8, N'Fin', 8, 8, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (9, N'Fin', 9, 2, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (10, N'Fin', 10, 3, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (11, N'Fin', 11, 2, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (12, N'Fin', 12, 3, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (13, N'Fin', 13, 7, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (14, N'Fin', 14, 8, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (15, N'NonFin', 1, 11, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (16, N'Fin', 15, 2, 1)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (17, N'Fin', 16, 3, 0)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (18, N'NonFin', 2, 6, 0)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (19, N'Fin', 17, 2, 0)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (20, N'Fin', 18, 3, 0)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (21, N'NonFin', 3, 6, 0)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (22, N'Fin', 19, 8, 0)
GO
INSERT [BatchQueue] ([Id], [QueueName], [QueueSeq], [RefId], [IsFinished]) VALUES (23, N'Fin', 20, 9, 0)
GO
SET IDENTITY_INSERT [BatchQueue] OFF
GO
SET IDENTITY_INSERT [QUEUE] ON 

GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (1, N'some action 1')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (2, N'some action 1+1')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (3, N'some action 3')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (4, N'some action 4')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (5, N'some action 5')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (6, N'some action 6')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (7, N'some action 7')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (8, N'some action 8')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (9, N'some action 9')
GO
INSERT [QUEUE] ([QUEUEID], [SOMEACTION]) VALUES (10, N'some action 10')
GO
SET IDENTITY_INSERT [QUEUE] OFF
GO
INSERT [Student] ([Id], [FirstName], [LastName]) VALUES (4, N'farhan', N'Kamran')
GO
INSERT [Student] ([Id], [FirstName], [LastName]) VALUES (4, N'Farooq', N'kashif')
GO
INSERT [Student] ([Id], [FirstName], [LastName]) VALUES (1, N'junaid', N'shah')
GO
INSERT [Student] ([Id], [FirstName], [LastName]) VALUES (2, N'Ahmad', N'Ali')
GO
INSERT [Student] ([Id], [FirstName], [LastName]) VALUES (3, N'Hamza', N'Hassan')
GO
INSERT [StudentSubject] ([Id], [SubjectId], [StudentId]) VALUES (1, 1, 1)
GO
INSERT [StudentSubject] ([Id], [SubjectId], [StudentId]) VALUES (2, 2, 1)
GO
INSERT [StudentSubject] ([Id], [SubjectId], [StudentId]) VALUES (3, 1, 2)
GO
INSERT [StudentSubject] ([Id], [SubjectId], [StudentId]) VALUES (4, 2, 3)
GO
INSERT [subject] ([Id], [SubjectName]) VALUES (1, N'Computer')
GO
INSERT [subject] ([Id], [SubjectName]) VALUES (2, N'Physics')
GO
INSERT [subject] ([Id], [SubjectName]) VALUES (3, N'Math')
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IDX_BATCHTASKVALUE_TID_SKEY]    Script Date: 1/24/2019 7:14:03 PM ******/
CREATE NONCLUSTERED INDEX [IDX_BATCHTASKVALUE_TID_SKEY] ON [BatchTaskValue]
(
	[TaskId] ASC,
	[StateKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsManual]  DEFAULT ((1)) FOR [IsManual]
GO
ALTER TABLE [BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsResubmission]  DEFAULT ((0)) FOR [IsResubmission]
GO
ALTER TABLE [BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsFinished]  DEFAULT ((0)) FOR [IsFinished]
GO
ALTER TABLE [BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsStopped]  DEFAULT ((0)) FOR [IsStopped]
GO
ALTER TABLE [BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsGenerated]  DEFAULT ((0)) FOR [IsGenerated]
GO
ALTER TABLE [BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_HasPriority]  DEFAULT ((0)) FOR [HasPriority]
GO
ALTER TABLE [BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_RetryCount]  DEFAULT ((0)) FOR [RetryCount]
GO
ALTER TABLE [BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_IsVolumeGenerated]  DEFAULT ((0)) FOR [IsVolumeGenerated]
GO
ALTER TABLE [BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_HasVolume]  DEFAULT ((0)) FOR [HasVolume]
GO
ALTER TABLE [BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_IsFinished]  DEFAULT ((0)) FOR [IsFinished]
GO
ALTER TABLE [BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_IsStopped]  DEFAULT ((0)) FOR [IsStopped]
GO
ALTER TABLE [BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_ResultStatus]  DEFAULT ('Pending') FOR [ResultStatus]
GO
ALTER TABLE [BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_HasPriority]  DEFAULT ((0)) FOR [HasPriority]
GO
ALTER TABLE [BatchTaskState] ADD  CONSTRAINT [DF_BatchTask_FailedCount]  DEFAULT ((0)) FOR [FailedCount]
GO
ALTER TABLE [BatchTaskState] ADD  CONSTRAINT [DF_BatchTask_DeferredCount]  DEFAULT ((0)) FOR [DeferredCount]
GO
ALTER TABLE [BatchTaskState] ADD  CONSTRAINT [DF_BatchTask_IsFinished]  DEFAULT ((0)) FOR [IsFinished]
GO
ALTER TABLE [BatchTaskState] ADD  CONSTRAINT [DF_BatchTaskState_IsStopped]  DEFAULT ((0)) FOR [IsStopped]
GO
ALTER TABLE [BatchTaskState] ADD  CONSTRAINT [DF_BatchTaskState_HasPriority]  DEFAULT ((0)) FOR [HasPriority]
GO
ALTER TABLE [BatchProcessGroupDetail]  WITH CHECK ADD  CONSTRAINT [FK_ProcessGroups] FOREIGN KEY([GroupKey])
REFERENCES [BatchProcessGroupMaster] ([GroupKey])
GO
ALTER TABLE [BatchProcessGroupDetail] CHECK CONSTRAINT [FK_ProcessGroups]
GO
ALTER DATABASE [TestDB] SET  READ_WRITE 
GO


CREATE INDEX IDX_BatchTaskState_NodeKey_IsFinished ON BatchTaskState(NodeKey,IsFinished) INCLUDE (Id) ;
go

--ALTER DATABASE TestDb2 SET ALLOW_SNAPSHOT_ISOLATION ON  

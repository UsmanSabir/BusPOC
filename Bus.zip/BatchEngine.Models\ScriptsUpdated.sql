﻿
/****** Object:  Table [dbo].[BatchGroupState]    Script Date: 12/31/2018 5:59:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchGroupState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[GroupKey] [int] NOT NULL,
	[SubmittedBy] [varchar](250) NOT NULL,
	[IsManual] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsManual]  DEFAULT ((1)),
	[IsResubmission] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsResubmission]  DEFAULT ((0)),
	[Criteria] [varchar](250) NOT NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsStopped]  DEFAULT ((0)),
	[CurrentState] [varchar](50) NOT NULL,
	[Payload] [varchar](max) NULL,
	[IsGenerated] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsGenerated]  DEFAULT ((0)),
 CONSTRAINT [PK_BatchGroupState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessConfig]    Script Date: 12/31/2018 5:59:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BatchProcessConfig](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProcessKey] [int] NOT NULL,
	[BatchSize] [int] NOT NULL,
	[ProcessTimeoutMins] [int] NULL,
	[TaskTimeout] [int] NULL,
	[ProcessRetries] [int] NULL,
	[TaskRetries] [int] NULL,
	[RetryDelayMilli] [int] NULL,
	[MaxVolumeRetries] [int] NOT NULL CONSTRAINT [DF_BatchProcessConfig_MaxVolumeRetries]  DEFAULT ((3)),
	[QueueSize] [int] NULL,
 CONSTRAINT [PK_BatchProcessConfig] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[BatchProcessState]    Script Date: 12/31/2018 5:59:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[BatchProcessState](
	[Id] [BIGINT] IDENTITY(1,1) NOT NULL,
	[CorrelationId] [UNIQUEIDENTIFIER] NOT NULL,
	[UpdatedOn] [DATETIME] NULL,
	[RetryCount] [INT] NOT NULL,
	[CompanyId] [INT] NOT NULL,
	[BranchId] [INT] NOT NULL,
	[ProcessingDate] [DATETIME] NOT NULL,
	[ProcessKey] [INT] NOT NULL,
	[IsVolumeGenerated] [BIT] NOT NULL,
	[ParentId] [BIGINT] NULL,
	[GroupId] [BIGINT] NOT NULL,
	[IsFinished] [BIT] NOT NULL,
	[IsStopped] [BIT] NOT NULL,
	[Criteria] [NVARCHAR](500) NOT NULL,
	[StartTime] [DATETIME] NULL,
	[CurrentState] [VARCHAR](50) NOT NULL,
	[SubTenantId] [INT] NOT NULL,
	[CompleteTime] [DATETIME] NULL,
	[GenerationCompleteTime] [DATETIME] NULL,
	[ResultStatus] [VARCHAR](50) NOT NULL,
	[GroupSeqId] [INT] NOT NULL,
 CONSTRAINT [PK_BatchProcessState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchTaskState]    Script Date: 12/31/2018 5:59:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
CREATE TABLE [dbo].[BatchTaskState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[Payload] [varchar](500) NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[FailedCount] [int] NOT NULL CONSTRAINT [DF_BatchTask_FailedCount]  DEFAULT ((0)),
	[DeferredCount] [int] NOT NULL CONSTRAINT [DF_BatchTask_DeferredCount]  DEFAULT ((0)),
	[NodeKey] [varchar](250) NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchTask_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchTaskState_IsStopped]  DEFAULT ((0)),
	[StartedOn] [datetime] NULL,
	[CompletedOn] [datetime] NULL,
 CONSTRAINT [PK_BatchTaskState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchTaskValue]    Script Date: 12/31/2018 5:59:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchTaskValue](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TaskId] [bigint] NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[StateKey] [varchar](250) NOT NULL,
	[StateValue] [varchar](500) NULL,
 CONSTRAINT [PK_BatchTaskValue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

--/////=== updates

CREATE TABLE BatchProcessGroupMaster
(
	GroupKey INT PRIMARY KEY IDENTITY(1,1),
	NME VARCHAR(100),
	insr_by VARCHAR(20),
	insr_DTE DATETIME NOT NULL
)
GO

CREATE TABLE BatchProcessGroupDetail
(
	Id INT PRIMARY KEY IDENTITY(1,1),
	GroupKey INT NOT NULL,
	ProcessKey INT NOT NULL,
	CONSTRAINT FK_ProcessGroups FOREIGN KEY (GroupKey) REFERENCES BatchProcessGroupMaster(GroupKey),
	--CONSTRAINT FK_ProcessConf_2	FOREIGN KEY	(ProcessKey) REFERENCES BatchProcessConfig(ProcessKey)
)
GO

ALTER TABLE BatchProcessConfig
ADD PrntPrcsId INT 

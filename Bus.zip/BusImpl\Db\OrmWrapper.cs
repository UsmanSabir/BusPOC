﻿using BusLib;
using BusLib.Infrastructure;

namespace BusImpl.Db
{
    internal static class OrmWrapper
    {
        public static void WrapOrmActions(Bus bus)
        {
            //NS.ORM.GlobalConfig.Configurations.ConnectionOpeningActon = () =>
            //{
            //    bus.HandleDbCommand(new DbAction(DbActions.Opening));
            //};

            //NS.ORM.GlobalConfig.Configurations.CommandExecutedAction = () =>
            //{
            //    bus.HandleDbCommand(new DbAction(DbActions.Executed));
            //};


            //NS.ORM.GlobalConfig.Configurations.CommandExecutingAction= () =>
            //{
            //    bus.HandleDbCommand(new DbAction(DbActions.Executing));
            //};

            //NS.ORM.GlobalConfig.Configurations.ConnectionClosedActon = () =>
            //{
            //    bus.HandleDbCommand(new DbAction(DbActions.Closed));
            //};

            //NS.ORM.GlobalConfig.Configurations.ConnectionOpenedActon = () =>
            //{
            //    bus.HandleDbCommand(new DbAction(DbActions.Opened));
            //};

            //NS.ORM.GlobalConfig.Configurations.ErrorAction = (e) =>
            //{
            //    //bus.HandleDbCommand(new DbAction(DbActions.Error));
            //};

            NS.ORM.GlobalConfig.Configurations.DbCallWrapper= (action) =>
            {
                bus.HandleDbCommand(new DbAction(DbActions.Persist, action));
            };


            NS.ORM.GlobalConfig.Configurations.DbTransactionWrapper = (action) =>
            {
                bus.HandleDbCommand(new DbAction(DbActions.Transaction, action));
            };
            

        }
    }
}
﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading;
using BusImpl.Redis;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using BusLib.Helper;
using StackExchange.Redis;

namespace BusImpl.PubSubImpl.Udp
{
    public class UdpSubscriber: IDistributedMessageSubscriber
    {
        private UdpClient _udpClient;
        private string _ip;
        private int _port;
        private Thread _receiveThread;
        private bool _stop = false;
        readonly ConcurrentBag<KeyValuePair<string, Action<string>>> _subscriptions = new ConcurrentBag<KeyValuePair<string, Action<string>>>();
        private readonly ILogger _logger;
        private readonly RedisSerializer _serializer;
        protected const string PubChannel = "BPEMChannel";
        private readonly string _customChannel;

        public UdpSubscriber(string ip, int port, string channel, ILogger logger)
        {
            _port = port;
            _logger = logger;
            _ip = ip;
            _serializer = new RedisSerializer();
            _customChannel = channel ?? PubChannel;
        }


        public void Dispose()
        {
            _stop = true;
            Robustness.Instance.SafeCall(() => { _udpClient?.Dispose(); });
            _receiveThread?.Interrupt();
        }

        public UdpClient StartIfNot()
        {
            if (_udpClient == null)
            {
                _stop = false;
                _udpClient = new UdpClient();
                _udpClient.ExclusiveAddressUse = false;
                IPEndPoint localEp = new IPEndPoint(IPAddress.Any, _port);
                _udpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                _udpClient.ExclusiveAddressUse = false;

                _udpClient.JoinMulticastGroup(IPAddress.Parse(_ip), 50);
                _udpClient.Client.Bind(localEp);
                _udpClient.MulticastLoopback = true;
                
                _receiveThread = new Thread(Receive);
                _receiveThread.Start();
            }

            return _udpClient;
        }

        public void Receive()
        {
            while (!_stop)
            {
                Robustness.Instance.SafeCall(() =>
                {
                    var ipEndPoint = new IPEndPoint(IPAddress.Any, _port);

                    //var result = _udpClient.BeginReceive()
                    var data = _udpClient.Receive(ref ipEndPoint);

                    var message = Encoding.UTF8.GetString(data);

                    OnMessageReceived(message, ipEndPoint.Address.ToString());
                    // Raise the AfterReceive event
                    Console.WriteLine(message);
                }, _logger);
            }
        }

        private void OnMessageReceived(string message, string endPoint)
        {
            _logger.Trace("UDP Pubsub message received from endPoint '{endPoint}' and {message}", endPoint, message);
            //var channel = ch.ToString();
            //string message = val;
            var msgParts = message.Split(new[] { "::" }, StringSplitOptions.None);
            if (msgParts.Length < 6)
            {
                _logger.Warn("UDP Invalid pubsub message from endPoint {endPoint}, Dropping. {message}", endPoint, message);
                return;
            }
            var channel = msgParts[0];
            if (!channel.Equals(_customChannel))
            {
                _logger.Info("UDP pubsub channel {channel} received message from channel {messageChannel}, Dropping", _customChannel, channel);
                return;
            }
            var nodeName = msgParts[1];
            var type = msgParts[2];
            //3 and 4 reserved
            var packet = msgParts[5];

            _logger.Trace($"UDP PubSub packet received from node {nodeName}, on channel {channel} message, {message}");
            //var isWatchDogMsg = type == nameof(IWatchDogMessage);
            foreach (var pair in _subscriptions)
            {
                if (type == pair.Key)
                {
                    Robustness.Instance.SafeCall(() =>
                    {
                        pair.Value.BeginInvoke(packet, null, null);
                    });
                }
            }
        }

        public void Subscribe(string message, Action<string> action)
        {
            var cl = StartIfNot(); //just to initialize
            _subscriptions.Add(new KeyValuePair<string, Action<string>>(message, action)); //todo, do we need to store weak reference
        }

        public void Subscribe<T>(Action<T> action)
        {
            if (action == null)
                return;

            void ActString(string s)
            {
                var item = _serializer.DeserializeFromString<T>(s);

                //WeakAction w=new WeakAction(action);//todo, do we need to store weak reference
                action(item);
            }

            var typeName = typeof(T).Name;

            Subscribe(typeName, ActString);

            //var cl = GetClient(); //just to initialize
            //_subscriptions.Add(new KeyValuePair<string, Action<string>>(typeName, ActString)); //todo, do we need to store weak reference
        }
    }
}
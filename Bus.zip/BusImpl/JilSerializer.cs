﻿using BusLib.Core;
using Jil;

namespace BusImpl
{
    public class JilSerializer: ISerializer
    {
        public string SerializeToString<T>(T item)
        {
            var serialize = JSON.Serialize(item);
            return serialize;
        }

        public T DeserializeFromString<T>(string data)
        {
            var item = JSON.Deserialize<T>(data);
            return item;
        }
    }
}
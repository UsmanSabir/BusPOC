﻿using System;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Groups;
using BusLib.Core;
using NS.ORM;
using NS.ORM.UoW;
using NS.Utilities;
using ProcessConfiguration = BatchEngine.Models.Entities.ProcessConfiguration;

namespace BusImpl
{
    public class StatePersistenceService: IStatePersistenceService
    {
        public IEnumerable<IReadWritableGroupEntity> GetAllIncomplete()
        {
            var contextExt = EntityContextExt.Create<BatchGroupState>();
            contextExt.Read(r => r.ISFINISHED == false && r.ISSTOPPED== false);
            
            return contextExt.Entity.Select(s=>new BatchGroupStateWrapper(s));
            
        }

        public IReadWritableGroupEntity GetGroupEntity(long groupId)
        {
            var contextExt = EntityContextExt.Create<BatchGroupState>();
            contextExt.Read(r => r.ISFINISHED == false && r.ISSTOPPED == false);

            return contextExt.Entity.Select(s => new BatchGroupStateWrapper(s)).FirstOrDefault();
        }

        public List<KeyValuePair<string, string>> GetTaskStates(long taskId, long processId)
        {
            var contextExt = EntityContextExt.Create<BatchTaskValues>();
            contextExt.Read(r => r.PROCESSID==processId && r.TASKID==taskId);

            return contextExt.Entity.Select(s => new KeyValuePair<string,string>(s.STATEKEY, s.STATEVALUE)).ToList();
        }

        public IEnumerable<int> GetConfiguredGroupProcessKeys(long groupEntityId)
        {
            //todo read from group-process mapping
            throw new NotImplementedException();

            //var contextExt = EntityContextExt.Create<BatchProcessState>();
            //contextExt.Read(r => r.GROUPID == groupEntityId);

            //return contextExt.Entity.Select(s => new ProcessStateWrapper(s));
        }

        public IEnumerable<IReadWritableProcessState> GetSubmittedGroupProcesses(long groupEntityId)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.GROUPID == groupEntityId);

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s));
        }

        

        public IEnumerable<ITaskState> GetIncompleteTasksForProcess(long processId)
        {
            var contextExt = EntityContextExt.Create<BatchTaskState>();
            contextExt.Read(r => r.PROCESSID == processId && (r.ISFINISHED==false && r.ISSTOPPED==false));

            return contextExt.Entity.Select(s => new BatchTaskWrapper(s));
        }

        public long CountFailedTasksForProcess<T>(long processId)
        {
            using (var dbController = DbController.Create())
            {
                var count = dbController.Count(Constant.SQLCountFailedTasks, new SerializableDictionary<string,object>(){{ "pid", processId } });
                return count;
            }
        }

        public long CountPendingTasksForProcess(long processId)
        {
            using (var dbController = DbController.Create())
            {
                var count = dbController.Count(Constant.SQLCountPendingTasks, new SerializableDictionary<string, object>() { { "pid", processId } });
                return count;
            }
        }

        public IReadWritableProcessState GetAndStartProcessById(long processId)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.ID == processId);
            var state = contextExt.Entity.FirstOrDefault();
            if (state != null && state.STARTTIME==null)
            {
                state.STARTTIME = DateTime.UtcNow;
                contextExt.Persist();
            }
            
            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public IReadWritableProcessState GetProcessById(long processId)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.ID == processId);
            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public IReadWritableProcessState GetProcessByKey(int processKey)
        {
            //todo read from group-process mapping
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.ID == processKey); //todo read from process config

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public void AddGroupProcess(List<IReadWritableProcessState> groupProcesses)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>(groupProcesses.Cast<ProcessStateWrapper>().Select(s=>s.State).ToList());
            contextExt.Persist();
        }

        public void SaveGroup(IReadWritableGroupEntity @group)
        {
            BatchGroupStateWrapper groupStateWrapper= (BatchGroupStateWrapper)group;
            var contextExt = EntityContextExt.Create<BatchGroupState>(new List<BatchGroupState>() { groupStateWrapper._state });
            contextExt.Persist();
        }

        public IReadWritableGroupEntity CreateGroupEntity(IReadWritableGroupEntity entity)
        {
            var state = ((BatchGroupStateWrapper)entity)._state;
            var contextExt = EntityContextExt.Create<BatchGroupState>(new []{ state });
            contextExt.Persist();
            return entity;
        }

        

        public IProcessConfiguration GetProcessConfiguration(int key)
        {
            var ext = EntityContextExt.Create<ProcessConfiguration>();
            ext.Read(c => c.PROCESSKEY == key);
            return ext.Entity.Select(s => new ProcessConfigurationWrapper(s)).FirstOrDefault();
        }

        public void SaveProcess(IProcessState process)
        {
            ProcessStateWrapper processStateWrapper = (ProcessStateWrapper) process;
            var contextExt = EntityContextExt.Create<BatchProcessState>( new List<BatchProcessState>(){processStateWrapper.State});
            contextExt.Persist();
        }

        public void SaveTaskStates(long taskId, long processId, List<KeyValuePair<string, string>> states)
        {
            using (var dbController = DbController.Create())
            {
                using (
                    var uow = dbController.UsingUnitOfWork())
                {
                    foreach (var pair in states)
                    {
                        var count = dbController.ExecuteNonQuery(Constant.SQLUpdateTaskState, taskId, pair.Key, pair.Value);
                        if (count == 0)
                        {
                            //insert
                            var contextExt = EntityContextExt.Create<BatchTaskValues>().UsingUnitOfWork(uow);
                            var entity = contextExt.CreateNew();
                            entity.PROCESSID = processId;
                            entity.TASKID = taskId;
                            entity.STATEKEY = pair.Key;
                            entity.STATEVALUE = pair.Value;
                            contextExt.Persist();
                        }
                    }

                    uow.Save();
                }
            }
            


            //var contextExt = EntityContextExt.Create<BatchTaskValues>();
            //contextExt.Read(r => r.PROCESSID == processId && r.TASKID == taskId);

            //return contextExt.Entity.Select(s => new KeyValuePair<string, string>(s.STATEKEY, s.STATEVALUE)).ToList();
        }

        public void SaveTaskState(long taskId, long processId, string key, string val)
        {
            SaveTaskStates(taskId, processId, new List<KeyValuePair<string, string>>(){new KeyValuePair<string, string>(key, val)});
        }

        public void UpdateTask(ITaskState task, ITransaction runningTransaction)
        {
            var taskWrapper = (BatchTaskWrapper) task;
            var cxt = EntityContextExt.Create<BatchTaskState>(new List<BatchTaskState> {taskWrapper.State});
            if (runningTransaction != null)
            {
                if (runningTransaction.TransactionObject is IUnitOfWork uow)
                {
                    cxt=cxt.UsingUnitOfWork(uow);
                }
            }

            cxt.Persist();
        }

        public int MarkProcessForRetry(IReadWritableProcessState process)
        {
            process.RetryCount = process.RetryCount + 1;

            ProcessStateWrapper wrapper = (ProcessStateWrapper) process;
            var ext = EntityContextExt.Create<BatchProcessState>(new List<BatchProcessState>(){wrapper.State});
            using (var uow = ext.InitiateUnitOfWork())
            {
                using (var controller=DbController.Create(uow))
                {
                    var effectedRows = controller.ExecuteNonQuery(Constant.SQLRetryFailedTasks, process.Id);
                    
                    ext.Persist();
                    uow.Save();

                    return effectedRows;
                }
            }
        }
    }
}
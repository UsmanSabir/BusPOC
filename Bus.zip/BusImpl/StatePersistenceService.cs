﻿using System;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Groups;
using BusLib.Core;
using NS.ORM;
using NS.Utilities;
using ProcessConfiguration = BatchEngine.Models.Entities.ProcessConfiguration;

namespace BusImpl
{
    public class StatePersistenceService: IStatePersistenceService
    {
        public IEnumerable<IGroupEntity> GetAllIncomplete()
        {
            var contextExt = EntityContextExt.Create<BatchGroupState>();
            contextExt.Read(r => r.ISFINISHED == false && r.ISSTOPPED== false);
            
            return contextExt.Entity.Select(s=>new BatchGroupStateWrapper(s));
            
        }

        public List<KeyValuePair<string, string>> GetTaskStates(long taskId, long processId)
        {
            var contextExt = EntityContextExt.Create<BatchTaskValues>();
            contextExt.Read(r => r.PROCESSID==processId && r.TASKID==taskId);

            return contextExt.Entity.Select(s => new KeyValuePair<string,string>(s.STATEKEY, s.STATEVALUE)).ToList();
        }

        public IEnumerable<int> GetConfiguredGroupProcessKeys(long groupEntityId)
        {
            //todo read from group-process mapping
            throw new NotImplementedException();

            //var contextExt = EntityContextExt.Create<BatchProcessState>();
            //contextExt.Read(r => r.GROUPID == groupEntityId);

            //return contextExt.Entity.Select(s => new ProcessStateWrapper(s));
        }

        public IEnumerable<IReadWritableProcessState> GetSubmittedGroupProcesses(long groupEntityId)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.GROUPID == groupEntityId);

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s));
        }


        public IEnumerable<ITaskState> GetIncompleteTasksForProcess(long processId)
        {
            var contextExt = EntityContextExt.Create<BatchTaskState>();
            contextExt.Read(r => r.PROCESSID == processId && (r.ISFINISHED==false && r.ISSTOPPED==false));

            return contextExt.Entity.Select(s => new BatchTaskWrapper(s));
        }

        public long CountFailedTasksForProcess<T>(long processId)
        {
            using (var dbController = DbController.Create())
            {
                var count = dbController.Count(Constant.SQLCountFailedTasks, new SerializableDictionary<string,object>(){{ "pid", processId } });
                return count;
            }
        }

        public long CountPendingTasksForProcess(long processId)
        {
            using (var dbController = DbController.Create())
            {
                var count = dbController.Count(Constant.SQLCountPendingTasks, new SerializableDictionary<string, object>() { { "pid", processId } });
                return count;
            }
        }

        public IReadWritableProcessState GetProcessById(long processId)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.ID == processId);

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public IReadWritableProcessState GetProcessByKey(int processKey)
        {
            //todo read from group-process mapping
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.ID == processKey); //todo read from process config

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public void AddGroupProcess(List<IReadWritableProcessState> groupProcesses)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>(groupProcesses.Cast<ProcessStateWrapper>().Select(s=>s.State).ToList());
            contextExt.Persist();
        }

        public IGroupEntity CreateGroupEntity(IReadWriteableGroupEntity entity)
        {
            var state = ((BatchGroupStateWrapper)entity)._state;
            var contextExt = EntityContextExt.Create<BatchGroupState>(new []{ state });
            contextExt.Persist();
            return entity;
        }

        public IProcessConfiguration GetProcessConfiguration(int key)
        {
            var ext = EntityContextExt.Create<ProcessConfiguration>();
            ext.Read(c => c.PROCESSKEY == key);
            return ext.Entity.Select(s => new ProcessConfigurationWrapper(s)).FirstOrDefault();
        }
    }
}
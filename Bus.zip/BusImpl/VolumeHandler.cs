﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Volume;
using BusLib.Serializers;
using NS.ORM;
using NS.ORM.UoW;
using NS.Utilities.Helper;

namespace BusImpl
{
    public class VolumeHandler: IVolumeHandler
    {
        private readonly ISerializersFactory _serializersFactory;

        public VolumeHandler()
        {
            _serializersFactory = SerializersFactory.Instance;
        }

        public void Handle<T>(IEnumerable<T> volume, IProcessExecutionContext processContext)
        {
            var serializer = _serializersFactory.GetSerializer<T>();
            int currentCount = 0;
            int batchSize = 100;

            var ext = EntityContextExt<BatchTaskState>.Create();
            using (var unitOfWork = ext.InitiateUnitOfWork(IsolationLevel.Snapshot)) //todo check isolation level with db team, is it enabled by default
            {
                foreach (var v in volume)
                {
                    var payLoad = serializer.SerializeToString(v);
                    var state = ext.CreateNew();

                    state.PAYLOAD = payLoad;
                    state.PROCESSID = processContext.ProcessState.Id;
                    state.CURRENTSTATE = ResultStatus.Empty.Name;

                    currentCount++;
                    if (currentCount >= batchSize)
                    {
                        ext.Persist();
                        currentCount = 0;
                        ext.Entity.Clear();//remove persisted items
                    }
                }
                ext.Persist();
                unitOfWork.Save();
            }
        }

        public IReadWritableTaskState GetNextTaskWithTransaction(out ITransaction transaction)
        {
            IUnitOfWork unitOfWork = null;
            transaction = null;

            try
            {
                var ext = EntityContextExt<BatchTaskState>.Create();
                unitOfWork = ext.InitiateUnitOfWork();

                ext.ReadWithSql(Constant.SQLReadDataQueue, DateTime.UtcNow);
                if (ext.Entity?.Count > 0)
                {
                    transaction= new TransactionWrapper(unitOfWork); //todo what if db connection lost
                    return new BatchTaskWrapper(ext.Entity.First());
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                unitOfWork?.Dispose();
                throw;
            }
        }
    }
}
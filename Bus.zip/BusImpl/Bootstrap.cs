﻿using BusLib.Serializers;

namespace BusImpl
{
    public class Bootstrap
    {
        public static void Initilize()
        {
            SerializersFactory.Instance.DefaultSerializer = new JilSerializer();
        }
    }
}
﻿using BusLib.Core;
using BusLib.Serializers;

namespace BusImpl
{
    public class Bootstrap
    {
        public static void Initialize()
        {
            SerializersFactory.Instance.DefaultSerializer = new JilSerializer();
        }

        public static ISerializer GetSerializer()
        {
            return SerializersFactory.Instance.DefaultSerializer;
        }
    }
}
﻿using BusImpl.Db;
using BusImpl.Redis;
using BusLib;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using BusLib.Infrastructure;
using BusLib.ProcessLocks;
using BusLib.Serializers;

namespace BusImpl
{
    public class Bootstrap
    {
        public static void Initialize(string redisConnection = "10.39.100.27")
        {
            SerializersFactory.Instance.DefaultSerializer = new JsonSerializer();
            OrmWrapper.WrapOrmActions();

            //todo
            //var redisConnection = "10.39.100.27";// "localhost";// "172.31.15.19";
            //var redisConnection = "172.31.15.19";

            var serializer = SerializersFactory.Instance.DefaultSerializer;

            IProcessDataStorage storage = new RedisProcessStorage(NodeSettings.Instance.Name, redisConnection, serializer);

            IPubSubFactory factory = new RedisPubSubFactory(redisConnection);
            IDistributedMutexFactory mutexFactory = new DistributedMutexFactory(redisConnection);

            Bus.EntityFactory = new EntityFactory();
            Bus.StateManager = new StatePersistenceService();
            Bus.VolumeHandler = new VolumeHandler();
            Bus.Storage = storage;
            Bus.PubSubFactory = factory;
            Bus.DistributedMutexFactory = mutexFactory;
        }
        
    }
}
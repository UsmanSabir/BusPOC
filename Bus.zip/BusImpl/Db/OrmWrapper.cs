﻿using BusLib;
using BusLib.Infrastructure;

namespace BusImpl.Db
{
    internal static class OrmWrapper
    {
        public static void WrapOrmActions()
        {
            NS.ORM.GlobalConfig.Configurations.ConnectionOpeningActon = () =>
            {
                Bus.Instance.HandleDbCommand(new DbAction(DbActions.Opening));
            };

            NS.ORM.GlobalConfig.Configurations.CommandExecutedAction = () =>
            {
                Bus.Instance.HandleDbCommand(new DbAction(DbActions.Executed));
            };


            NS.ORM.GlobalConfig.Configurations.CommandExecutingAction= () =>
            {
                Bus.Instance.HandleDbCommand(new DbAction(DbActions.Executing));
            };

            NS.ORM.GlobalConfig.Configurations.ConnectionClosedActon = () =>
            {
                Bus.Instance.HandleDbCommand(new DbAction(DbActions.Closed));
            };

            NS.ORM.GlobalConfig.Configurations.ConnectionOpenedActon = () =>
            {
                Bus.Instance.HandleDbCommand(new DbAction(DbActions.Opened));
            };

            NS.ORM.GlobalConfig.Configurations.ErrorAction = (e) =>
            {
                //Bus.Instance.HandleDbCommand(new DbAction(DbActions.Error));
            };

            NS.ORM.GlobalConfig.Configurations.DbCallWrapper= (action) =>
            {
                Bus.Instance.HandleDbCommand(new DbAction(DbActions.Persist, action));
            };


            NS.ORM.GlobalConfig.Configurations.DbTransactionWrapper = (action) =>
            {
                Bus.Instance.HandleDbCommand(new DbAction(DbActions.Transaction, action));
            };
            

        }
    }
}
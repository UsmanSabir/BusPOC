﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Helper;
using StackExchange.Redis;

namespace BusImpl.Redis
{
    abstract class RedisPubSubClient: SafeDisposable
    {
        private readonly string _connection;
        private readonly CancellationToken _token;
        //private StackExchangeRedisCacheClient _redis;
        private ConnectionMultiplexer _redis;
        private readonly RedisSerializer _serializer;
        protected const string PubChannel = "BPEMChannel";

        //private static Lazy<ConfigurationOptions> configOptions = new Lazy<ConfigurationOptions>(() =>
        //{
        //    var configOptions = new ConfigurationOptions();
        //    configOptions.EndPoints.Add("10.26.130.170:6379");
        //    configOptions.ClientName = "MyAppRedisConn";
        //    configOptions.ConnectTimeout = 100000;
        //    configOptions.SyncTimeout = 100000;
        //    configOptions.AbortOnConnectFail = true;
        //    return configOptions;
        //});

        //private static Lazy<ConnectionMultiplexer> LazyRedisconn = new Lazy<ConnectionMultiplexer>(() => ConnectionMultiplexer.Connect(configOptions.Value));



        protected RedisPubSubClient(string connection, CancellationToken token)
        {
            _connection = connection;
            _token = token;
            this._serializer = new RedisSerializer();

            CreateClient();
        }

        private void CreateClient()
        {
            _redis = ConnectionMultiplexer.Connect(_connection); //StackExchangeRedisCacheClient(_serializer, _connection);
            OnClientCreated(_redis);
        }

        protected abstract void OnClientCreated(ConnectionMultiplexer redis);

        protected IDatabase GetClient()
        {
            try
            {
                _redis.GetDatabase().StringGet("Ping");
            }
            catch (Exception e)
            {
                _redis?.Dispose();
                _redis = null;

                Robustness.Instance.ExecuteUntilTrue(() =>
                {
                    CreateClient();
                }, _token);
                //while (_redis==null)
                //{
                //    try
                //    {
                //        CreateClient();
                //    }
                //    catch (Exception exception)
                //    {
                //        //todo log
                //        Thread.Sleep(500);
                //        _redis = null;
                //    }
                //}
            }
            return _redis.GetDatabase();
        }

        protected override void Dispose(bool disposing)
        {
            _redis?.Dispose();
            base.Dispose(disposing);
        }
    }

    internal class RedisPublisher:RedisPubSubClient, IDistributedMessagePublisher
    {
        public RedisPublisher(string connection, CancellationToken token) : base(connection, token)
        {

        }

        protected override void OnClientCreated(ConnectionMultiplexer redis)
        {
            
        }

        public void PublishMessage(string message)
        {
            var count = GetClient().Publish(PubChannel, message);
            Console.WriteLine(count);
        }
        
    }

    class RedisSubscriber : RedisPubSubClient, IDistributedMessageSubscriber
    {
        ConcurrentBag<KeyValuePair<string, Action<string>>> _subscriptions = new ConcurrentBag<KeyValuePair<string, Action<string>>>();

        public RedisSubscriber(string connection, CancellationToken token):base(connection, token)
        {
            
        }

        protected override void OnClientCreated(ConnectionMultiplexer redis)
        {
            ISubscriber sub = redis.GetSubscriber();
            sub.Subscribe(PubChannel, OnMessageReceived);
            //foreach (var pair in _subscriptions)
            //{
            //    sub.Subscribe(pair.Key, pair.Value);
            //}
        }

        private void OnMessageReceived(RedisChannel ch, RedisValue val)
        {
            var channel = ch.ToString();
            foreach (var pair in _subscriptions)
            {
                if (channel == pair.Key)
                {
                    Robustness.Instance.SafeCall(()=> pair.Value(val));
                }
            }
        }

        public void Subscribe(string message, Action<string> action)
        {
            var cl = GetClient(); //just to initialize
            _subscriptions.Add(new KeyValuePair<string, Action<string>>(message, action)); //todo, do we need to store weak reference
        }

        protected override void Dispose(bool disposing)
        {
            _subscriptions = null;
            base.Dispose(disposing);
        }
    }
}
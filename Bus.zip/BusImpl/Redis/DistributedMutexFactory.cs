﻿using System;
using System.Threading;
using System.Threading.Tasks;
using BusLib.ProcessLocks;

namespace BusImpl.Redis
{
    public class DistributedMutexFactory: IDistributedMutexFactory
    {
        private readonly string _connection;

        public DistributedMutexFactory(string connection)
        {
            _connection = connection;
        }

        public DistributedMutex CreateDistributedMutex(string key,
            Func<CancellationToken, Task> taskToRunWhenLockAcquired, Action secondaryAction)
        {
            return new RedisDistributedLock(_connection, key, taskToRunWhenLockAcquired, secondaryAction);
        }
    }
}
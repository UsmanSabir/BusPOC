﻿using System;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Groups;

namespace BusImpl
{
    public class EntityFactory: IEntityFactory
    {
        
        public IReadWriteableGroupEntity CreateGroupEntity()
        {
            BatchGroupStateWrapper wrapper=new BatchGroupStateWrapper(new BatchGroupState());
            return wrapper;
        }

        public IReadWritableProcessState CreateProcessEntity()
        {
            var wrapper = new ProcessStateWrapper(new BatchProcessState());
            wrapper.Status= CompletionStatus.Pending;
            return wrapper;
        }
    }
}
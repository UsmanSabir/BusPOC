﻿using BusLib.BatchEngineCore;

namespace BusImpl
{
    public class Constant
    {
        public const string SQLCountFailedTasks =
            "SELECT COUNT(1) FROM BatchTaskState WHERE CurrentState = 'Error' AND ProcessId=@pid";

        public const string SQLCountPendingTasks =
            @"SELECT COUNT(1) FROM BatchTaskState WITH(READPAST) WHERE (CurrentState='' OR CurrentState IS NULL) AND IsFinished = 0 AND IsStopped = 0 AND  ProcessId=@pid";


        //public const string SQLReadDataQueue =
        //    @"SELECT TOP(1) * FROM BatchTaskState WITH(UPDLOCK, READPAST) WHERE IsFinished=0 AND IsStopped=0  ORDER BY ProcessId, DeferredCount";

        public static readonly string SQLReadDataQueue = string.Format(
            @"UPDATE BatchTaskState SET NodeKey='{0}', StartedOn = @0
OUTPUT Inserted.*
FROM (SELECT TOP 1 id FROM dbo.BatchTaskState WITH (NOLOCK) WHERE IsFinished = 0 AND IsStopped=0 AND NodeKey IS NULL ORDER  BY ProcessId, DeferredCount,Id) t
WHERE BatchTaskState.id = t.Id", NodeSettings.Instance.Name); //todo optimize with CTE


        public const string SQLUpdateTaskState =
            @"UPDATE dbo.BatchTaskValue
	SET StateValue = @2
WHERE TaskId = @0 AND StateKey=@1;";

    }
}
﻿namespace BusLib.BatchEngineCore.Volume.Adapters
{
    public interface IBatchVolumeAdapter<T>:IVolumeAdapter<T,T[]>
    {
        
    }
}
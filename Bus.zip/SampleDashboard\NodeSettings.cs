﻿namespace BusImpl.Redis
{
    internal class NodeSettings
    {
        private static NodeSettings _instance;
        public static NodeSettings Instance => _instance ?? (_instance = new NodeSettings());
        public string Name { get; set; } = "Dashboard";
    }
}
﻿using System;
using System.Threading;
using System.Threading.Tasks;
using BusLib.BatchEngineCore;
using BusLib.Core;
using BusLib.ProcessLocks;

namespace BusImpl.Sql
{
    public class SqlLockFactory: IDistributedMutexFactory
    {
        private readonly IContextSwitchHandler _contextSwitchHandler;

        public SqlLockFactory(IContextSwitchHandler contextSwitchHandler)
        {
            this._contextSwitchHandler = contextSwitchHandler;
        }

        public DistributedMutex CreateDistributedMutex(string key, Func<CancellationToken, Task> taskToRunWhenLockAcquired, Action secondaryAction,
            IFrameworkLogger logger)
        {
            return new SqlDistributedLock(key, taskToRunWhenLockAcquired, secondaryAction, logger, _contextSwitchHandler);
        }
    }
}
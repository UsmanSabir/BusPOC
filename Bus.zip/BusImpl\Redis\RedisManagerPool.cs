﻿namespace BusImpl.Redis
{
    public class RedisManagerPool
    {
        
    }
}

/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchTaskValue
	public partial class BatchTaskValues : BaseModel
	{
		
				private Int64 _id;
				private Int64 _taskid;
				private Int64 _processid;
				private String _statekey;
				private String _statevalue;
		
		//public BatchTaskValues BatchTaskValues { get { return this; } } //Self reference property

		
		public Int64 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Int64 TASKID
		{
			get { return _taskid; }
			set
			{
				CheckSetProperty(ref _taskid, value);
			}
		}

		
		public Int64 PROCESSID
		{
			get { return _processid; }
			set
			{
				CheckSetProperty(ref _processid, value);
			}
		}

		
		public String STATEKEY
		{
			get { return _statekey; }
			set
			{
				CheckSetProperty(ref _statekey, value);
			}
		}

		
		public String STATEVALUE
		{
			get { return _statevalue; }
			set
			{
				CheckSetProperty(ref _statevalue, value);
			}
		}

		

		
	}

		public class BatchTaskValuesValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "TASKID", "PROCESSID", "STATEKEY", "STATEVALUE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		      ["STATEKEY"] = 250
		  , ["STATEVALUE"] = 500
		 
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
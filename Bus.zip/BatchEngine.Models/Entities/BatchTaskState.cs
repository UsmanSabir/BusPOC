
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchTaskState
	public partial class BatchTaskState : BaseModel
	{
		
				private Int64 _id;
				private Int64 _processid;
				private String _payload;
				private DateTime? _updatedon;
				private String _currentstate;
				private Int32 _failedcount;
				private Int32 _deferredcount;
				private String _nodekey;
				private Boolean _isfinished;
				private Boolean _isstopped;
		
		//public BatchTaskState BatchTaskState { get { return this; } } //Self reference property

		
		public Int64 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Int64 PROCESSID
		{
			get { return _processid; }
			set
			{
				CheckSetProperty(ref _processid, value);
			}
		}

		
		public String PAYLOAD
		{
			get { return _payload; }
			set
			{
				CheckSetProperty(ref _payload, value);
			}
		}

		
		public DateTime? UPDATEDON
		{
			get { return _updatedon; }
			set
			{
				CheckSetProperty(ref _updatedon, value);
			}
		}

		
		public String CURRENTSTATE
		{
			get { return _currentstate; }
			set
			{
				CheckSetProperty(ref _currentstate, value);
			}
		}

		
		public Int32 FAILEDCOUNT
		{
			get { return _failedcount; }
			set
			{
				CheckSetProperty(ref _failedcount, value);
			}
		}

		
		public Int32 DEFERREDCOUNT
		{
			get { return _deferredcount; }
			set
			{
				CheckSetProperty(ref _deferredcount, value);
			}
		}

		
		public String NODEKEY
		{
			get { return _nodekey; }
			set
			{
				CheckSetProperty(ref _nodekey, value);
			}
		}

		
		public Boolean ISFINISHED
		{
			get { return _isfinished; }
			set
			{
				CheckSetProperty(ref _isfinished, value);
			}
		}

		
		public Boolean ISSTOPPED
		{
			get { return _isstopped; }
			set
			{
				CheckSetProperty(ref _isstopped, value);
			}
		}

		

		
	}

		public class BatchTaskStateValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "PROCESSID", "PAYLOAD", "CURRENTSTATE", "FAILEDCOUNT", "DEFERREDCOUNT", "ISFINISHED", "ISSTOPPED"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		     ["PAYLOAD"] = 500
		   , ["CURRENTSTATE"] = 50
		    , ["NODEKEY"] = 250
		   
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace

/* This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
using NS.ORM;


namespace BatchEngine.Models.Entities
{

	///BatchGroupState
	public partial class BatchGroupState 

	{

	public static List<BatchGroupState> Read(
		int? depth=null
	)
	{
		
		return Read(null, depth);
		
	}

	public static List<BatchGroupState> Read(Dictionary<string, object> parameters, int? depth = null)
        {
            EntityContextExt<BatchGroupState> c = EntityContextExt.Create<BatchGroupState>();
            c.Read(parameters, depth);
            return c.Entity;
        }


		

				
				

		public static void Persist(IList<BatchGroupState> entity)
    {
        EntityContextExt<BatchGroupState> c = EntityContextExt.Create(entity);
        c.Persist();
    }
		
	

	}
	

#pragma warning restore CS1591

}
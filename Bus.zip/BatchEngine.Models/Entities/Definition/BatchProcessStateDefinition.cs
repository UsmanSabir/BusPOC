 
 
 
 

/*  This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
	Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
using NS.Utilities;
using NS.ORM.Definitions;
using NS.ORM.Definitions.Classes;

using BatchEngine.Models.Entities;


namespace BatchEngine.Models.Entities.Definition
{
	public class BatchProcessStateDefinition : BaseDefination
	{

	
 

		//constructor ctor
		public BatchProcessStateDefinition(): base()
        {
			DefinitionVersion = 3;

			ParameterNames = new List<string>()
		    {
					    };
					 
		 
		  //==========Start secondarySqlColl=============


		  
		  //=========End secondarySqlColl=============

			//store type relation (i.e. join and where clause)



			// ===== Ver 2 ======

			//better performance with "OrdinalIgnoreCase" in string key comparison. ref http://stackoverflow.com/a/7145953 
			AggregateChildsV2 = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
			{
					};


			ChildRelations = new Dictionary<string, Tuple<RelationDetails, Func<BatchProcessState, IList<object>>, Action<List<BatchProcessState>, List<BaseModel>>>>()			
			{
			};


		} //end ctor
		
		internal Dictionary<string, Tuple<RelationDetails, Func<BatchProcessState, IList<object>>, Action<List<BatchProcessState>, List<BaseModel>>>> ChildRelations { get; set; }

		public override bool HasIdentity { get; protected set; } = true;
		
		public override string IdentityColumn { get; protected set; } = "ID";        
        
		public override string RootName => string.Empty;//TODO

        public override bool HasChilds { get; } = false ;

        public override string SelectQuery { get; protected set; } = @"SELECT Id , CorrelationId , UpdatedOn , RetryCount , CompanyId , BranchId , ProcessingDate , ProcessKey , IsVolumeGenerated , ParentId , GroupId , IsFinished , IsStopped , Criteria , StartTime , CurrentState , SubTenantId , CompleteTime , GenerationCompleteTime , ResultStatus  FROM BatchProcessState  ";

        public override bool Updatable { get; protected set; } = true;
        
		public override string UpdateTableName { get; protected set; } = @"BatchProcessState";
	
		public override string CountQuery { get; protected set; } = @"SELECT COUNT(*) FROM    BatchProcessState  {0}";

		public override string OrderBy { get; set; } = @"" ;

		public override string Where { get; protected set; } = @""; 

		public override string GroupBy { get; set; } = @""; 

		public override string Having { get; set; } =  @"";

		public override HashSet<string> NStringsColl { get; protected set; } = new HashSet<string>(){"CRITERIA"};
				
		public override void IdInjector<T>(T item, int id)
        {

		
		var t = item as BatchProcessState;
            if (t != null)
            {
				t.ID = id;     


       
			}
		
            
        }

		public override void UpdateChildIds<T>(T item)
        {

		
		var t = item as BatchProcessState;
            if (t != null)
            {
				var id = t.ID;

       
			}
		
            
        }

		
		
public override IEnumerable<string> GetInsertIgnoreList<T>(T entity)
        {
            //Nested Iterators
            //nameof(entity.State)
            foreach (var i in base.GetInsertIgnoreList(entity)) yield return i;

            //example usage
            
             
						yield return nameof(BatchProcessState.ID);
			
						
        }

		public override IEnumerable<string> GetClrMapping()
        {
		           
						yield return nameof(BatchProcessState.CORRELATIONID);
						yield return nameof(BatchProcessState.UPDATEDON);
						yield return nameof(BatchProcessState.RETRYCOUNT);
						yield return nameof(BatchProcessState.COMPANYID);
						yield return nameof(BatchProcessState.BRANCHID);
						yield return nameof(BatchProcessState.PROCESSINGDATE);
						yield return nameof(BatchProcessState.PROCESSKEY);
						yield return nameof(BatchProcessState.ISVOLUMEGENERATED);
						yield return nameof(BatchProcessState.PARENTID);
						yield return nameof(BatchProcessState.GROUPID);
						yield return nameof(BatchProcessState.ISFINISHED);
						yield return nameof(BatchProcessState.ISSTOPPED);
						yield return nameof(BatchProcessState.CRITERIA);
						yield return nameof(BatchProcessState.STARTTIME);
						yield return nameof(BatchProcessState.CURRENTSTATE);
						yield return nameof(BatchProcessState.SUBTENANTID);
						yield return nameof(BatchProcessState.COMPLETETIME);
						yield return nameof(BatchProcessState.GENERATIONCOMPLETETIME);
						yield return nameof(BatchProcessState.RESULTSTATUS);
			
			
        }

		public override SerializableDictionary<string,object> GetIds(BaseModel model)
	    {
	        var t = model as BatchProcessState;
	        if (t != null)
	        {

	            var lst = new SerializableDictionary<string,object>();

								lst.Add(nameof(t.ID), t.ID); 
						
	            
	            
	            return lst;
	        }

	        return base.GetIds(model);
	    }

		 public override Tuple<string, IList<object>> GetChildSqlWithParamsV2(BaseModel parent, Type entityChild,
            string propertyName, string aggregateName, Action<List<BaseModel>> postAction = null)
         {
            var target = parent as BatchProcessState;
            if (target == null)
                throw new ArgumentNullException(nameof(parent));


            var type = entityChild;//.GetType();
            var def = type.ToDefination();
            Tuple<RelationDetails, Func<BatchProcessState, IList<object>>, Action<List<BatchProcessState>, List<BaseModel>>> relationTuple=null;
			
            string sql = string.Empty;
            IList<object> ids = null;
            

            string aggrName = aggregateName;
            if (string.IsNullOrWhiteSpace(aggrName))
            {
                relationTuple = ChildRelations.Values.FirstOrDefault(f => f.Item1.ChildType == type && f.Item1.PropertyName.Equals(propertyName));//?.Item1.AggregateName;
            }

            if (relationTuple!=null || ChildRelations.TryGetValue(propertyName + aggrName, out relationTuple))
            {
                DbBatch batch = new DbBatch();
                int i = 0;
                var rel = relationTuple.Item1;

                //HACK: entityId is fixed(empty string)
                var s = def.GetSelectBatchV2(rel.AggregateName, batch,
                    rel.Join,
                                        string.Format(rel.CustomWhere, string.Join(" and ", GetUpdateWhereV2().Select(p => (string.IsNullOrEmpty(rel.Join) ? string.Empty :/*in case of join, append table name with each column name in where clause*/ UpdateTableName + ".") + p + "= @" + i++).ToArray()))
                        //, postAction
                        //, list => { ChildProcessor<Product>(parent, list);}
                        , 1, 1, null, null
                        );


                sql = batch.GetQueries().FirstOrDefault().Key;
                ids = relationTuple.Item2(target);
            }

            

            return Tuple.Create(sql, ids);
        }


		private List<BaseModel> ProcessResult(IModelReader reader, DbBatch batch, EntityHost<BatchProcessState> entityHost, Action<List<BaseModel>> postResultAction)
        {
            var ret = reader.GetWithDefination<BatchProcessState>(this);
            entityHost?.SetHostedItems(ret);

            ProcessChildBatches(batch, ret);

            var r = new List<BaseModel>(ret);
            postResultAction?.Invoke(r); //r);

            return r;
        }
		public override void ProcessChildBatches<T>(DbBatch batch, List<T> ret)
        {
            if (ret.Count > 0)
            {
                foreach (var childBatch in batch.Successor)
                {
                    childBatch.ProcessInitilizer(ret, childs => { ChildProcessor(ret, childs); });
                }
            }
        }
		public override void ChildProcessor<T>(List<T> parentItems, List<BaseModel> childs)
        {
            var items = parentItems.Cast<BatchProcessState>().ToList();
            var itemsCount = items.Count;
            if (itemsCount==0)
            {
                return;
            }

            if (childs.Count > 0)
            {
                
					    }
        }
		public override void CustomMapper<T>(T item, IDbReader row)
        {
            var target = item as BatchProcessState;
            if (target == null) return;

								target.ID = row.GetInt64("ID");

			
								target.CORRELATIONID = row.GetGuid("CORRELATIONID");

			
								target.UPDATEDON = (DateTime?) row.GetValue("UPDATEDON");
	
			
								target.RETRYCOUNT = row.GetInt32("RETRYCOUNT");

			
								target.COMPANYID = row.GetInt32("COMPANYID");

			
								target.BRANCHID = row.GetInt32("BRANCHID");

			
								target.PROCESSINGDATE = row.GetDateTime("PROCESSINGDATE");

			
								target.PROCESSKEY = row.GetInt32("PROCESSKEY");

			
								target.ISVOLUMEGENERATED = row.GetBoolean("ISVOLUMEGENERATED");

			
								target.PARENTID = (Int64?) row.GetValue("PARENTID");
	
			
								target.GROUPID = row.GetInt64("GROUPID");

			
								target.ISFINISHED = row.GetBoolean("ISFINISHED");

			
								target.ISSTOPPED = row.GetBoolean("ISSTOPPED");

			
								target.CRITERIA = row.GetString("CRITERIA");

			
								target.STARTTIME = (DateTime?) row.GetValue("STARTTIME");
	
			
								target.CURRENTSTATE = row.GetString("CURRENTSTATE");

			
								target.SUBTENANTID = row.GetInt32("SUBTENANTID");

			
								target.COMPLETETIME = (DateTime?) row.GetValue("COMPLETETIME");
	
			
								target.GENERATIONCOMPLETETIME = (DateTime?) row.GetValue("GENERATIONCOMPLETETIME");
	
			
								target.RESULTSTATUS = row.GetString("RESULTSTATUS");

			
			
		}

		public override IEnumerable<string> GetUpdateWhere<T>(T entity)
        {
            var target = entity as BatchProcessState;
            if (target == null)
                throw new ArgumentNullException(nameof(entity) + " is null.");
									yield return nameof(target.ID); 
						
            
        }

		public IEnumerable<string> GetUpdateWhereV2()
        {
								yield return nameof(BatchProcessState.ID); 
			            
        }

		public override IEnumerable<IEnumerable<BaseModel>> GetChildsColl(IEnumerable<BaseModel> items)
        {
            var target = items as IEnumerable<BatchProcessState>;
	    foreach (var child in base.GetChildsColl(items))
            {
                yield return child;
            }
        }

		public override IEnumerable<BaseModel> GetChilds(BaseModel item)
        {
            var target = item as BatchProcessState;
	    foreach (var baseModel in base.GetChilds(item))
            {
                yield return baseModel;
            }
        }

		public override IEnumerable<BaseModel> AcceptChildCollections(BaseModel item) 
        {
		var target = item as BatchProcessState;
	    foreach (var baseModel in base.GetChilds(item))
            {
                yield return baseModel;
            }

            
            
        }
						
		public override DbBatch GetSelectBatchV2(string aggregateId, DbBatch batch, string strJoin, string strWhere, int? depth, int level, Action<List<BaseModel>> postAction, Func<Type, string, string, string, bool> shouldAppendChild)
        {
            if (depth.HasValue && depth.Value < level)
                return batch;          

            if (batch == null)
                batch = new DbBatch();

            //var sql = string.Format(SelectQuery, column, vals);
            var sbQuery = new StringBuilder();
            sbQuery.Append(" " + SelectQuery);

            if(!string.IsNullOrEmpty(strJoin))
            {
                sbQuery.AppendLine(strJoin);
            }
            var whereClause = strWhere;
            bool customWhere = true;
            if(string.IsNullOrEmpty(whereClause))
            {
                whereClause = Where;//string.IsNullOrWhiteSpace(Where)?" 1=1 ":Where;
                customWhere = false;
            }

			if (whereClause.Trim().Equals("1=1"))
                whereClause = string.Empty;
            else if (!string.IsNullOrWhiteSpace(whereClause))
                sbQuery.Append(" WHERE " + whereClause);

			if (!string.IsNullOrEmpty(GroupBy))
            {
                sbQuery.Append(" Group BY " + GroupBy);
            }
			if (!string.IsNullOrEmpty(Having))
            {
                sbQuery.Append(" HAVING " + Having);
            }
            if (!string.IsNullOrEmpty(OrderBy))
            {
                sbQuery.Append(" ORDER BY " + OrderBy);
            }

            var entityHost = new EntityHost<BatchProcessState>();
            
            batch.AddQuery(sbQuery.ToString(), (reader, dbBatch) => ProcessResult(reader, dbBatch, entityHost, postAction));
            sbQuery.Clear();
            
            //TODO: for childs, either use 1-direct column that exist in child table, 2-use sub query with in syntax, 3-use join if relation have multiple columns
            //if  customWhere==true, if subquery with "in" supported then use relation column in sub-query else use joins
            //if customWhere==false, if child table have same column then use/pass it for where clause, else sub-query with "in" if supported or use joins

            var nextLevel = level + 1;

            if (depth.HasValue && depth.Value < nextLevel)
                return batch;
                

		    List<string> entityChilds;
            if (AggregateChildsV2.TryGetValue(aggregateId, out entityChilds))
            {
                foreach (var entityChild in entityChilds)
                {
					Tuple<RelationDetails, Func<BatchProcessState, IList<object>>, Action<List<BatchProcessState>, List<BaseModel>>> relationTuple;

                    if (ChildRelations.TryGetValue(entityChild, out relationTuple))
                    {	
						var rel = relationTuple.Item1;					
						bool appendInd = shouldAppendChild?.Invoke(relationTuple.Item1.ChildType, nameof(BatchProcessState), aggregateId, rel.PropertyName) ?? true;						
                        if(appendInd)
                        {
							var def = rel.ChildType.ToDefination();						
							string @where = string.Empty;
                            var @join = string.Empty;

                            if (!rel.UseParentWhere) //in-case UseParentWhere==true then use entity's "where" clause defined with parameter name matching parent parameter name. so keep it empty string, child will append its 'where'
                            {
                                if (!string.IsNullOrWhiteSpace(strJoin))
                                {
                                    if (string.IsNullOrWhiteSpace(rel.Join))
                                    {
                                        //single column join
                                        @join = rel.ConditionalJoin + strJoin;
                                    }
                                    else
                                    {
                                        //multi column join
                                        @join = rel.Join + strJoin;
                                    }

                                    @where = whereClause;
                                }
                                else
                                {
                                    if (string.IsNullOrWhiteSpace(rel.Join))
                                    {
                                        //no joins
                                        if (customWhere)
                                            @where = string.Format(rel.CustomWhere, string.IsNullOrWhiteSpace(whereClause) ? "1=1" : whereClause);
                                        else
                                            @where = rel.Where;
                                    }
                                    else
                                    {
                                        //join just started
                                        @join = rel.Join;
                                        @where = whereClause;
                                    }

                                    
                                }

         //                       if (string.IsNullOrWhiteSpace(rel.Join))
         //                       {
         //                           if (customWhere)
         //                               @where = string.Format(rel.CustomWhere, string.IsNullOrWhiteSpace(whereClause) ? "1=1" : whereClause);
         //                           else
         //                               @where = rel.Where;
         //                       }
         //                       else
         //                       {
         //                           //have join with parent                                    
									//@where = whereClause; // in this case, this child relation already has join with its parent, so we can use parent's where clause to optimize query


         //                           //else if (customWhere) // orm has passed a custom "where" clause
         //                           //    @where = whereClause; // in this case, this child relation already has join with its parent, so we can use parent's where clause to optimize query
         //                           //else
         //                           //    @where = rel.Where; //we are in join here, can we use entity's own where clause here?
         //                       }
                            }

                            var s = def.GetSelectBatchV2(aggregateId, batch, @join,
                                    @where
                                    , depth, nextLevel, list => relationTuple.Item3(entityHost.Items, list),
                                    shouldAppendChild);
						}
                    }
                }            
	        }
			            
            //var baseSqls = base.GetSelectBatchV2(aggregateId, batch, strJoin, strWhere, depth, level, postAction, shouldAppendChild);
            return batch;
        }

		public override DbBatch FillChilds(IEnumerable<BaseModel> items, string aggregateId, DbBatch batch, int? depth, int level, Func<Type, string, string, string, bool> shouldAppendChild)
        {
		 if (depth.HasValue && depth.Value < level)
                return batch;

            if (batch == null)
                batch = new DbBatch();

            string whereClause = string.Empty;

            StringBuilder sb=new StringBuilder();

			var cast = items.Cast<BatchProcessState>().ToList();

						var p1 = cast.Select(r=> r.ID).ToList();
			string pName1 = nameof(BatchProcessState.ID);
						sb.Append($"{pName1} in(@{pName1}) ");
				
				batch.AddParam(pName1, p1);				
			
			whereClause = sb.ToString();

			bool customWhere = true;
            
            var nextLevel = level + 1;

            if (depth.HasValue && depth.Value < nextLevel)
                return batch;

            List<string> entityChilds;
			if (AggregateChildsV2.TryGetValue(aggregateId, out entityChilds))
            {
                foreach (var entityChild in entityChilds)
                {
					Tuple<RelationDetails, Func<BatchProcessState, IList<object>>, Action<List<BatchProcessState>, List<BaseModel>>> relationTuple;

                    if (ChildRelations.TryGetValue(entityChild, out relationTuple))
                    {	
						var rel = relationTuple.Item1;					
						bool appendInd = shouldAppendChild?.Invoke(relationTuple.Item1.ChildType, nameof(BatchProcessState), aggregateId, rel.PropertyName) ?? true;						
                        if(appendInd)
                        {
							
							var def = rel.ChildType.ToDefination();
							
							var s = def.GetSelectBatchV2(aggregateId, batch, rel.Join,
							customWhere ? string.Format(rel.CustomWhere, string.IsNullOrWhiteSpace(whereClause) ? "1=1" : whereClause) : rel.Where
							, depth, nextLevel, list =>  relationTuple.Item3(cast, list) , shouldAppendChild);							
						}
                    }
                }            
	        }
			return batch;

		}

		/// <summary>
        /// Checks if entity exists in specified entity graph.
        /// </summary>
        /// <param name="entityId">The entity graph key to search.</param>
        /// <param name="type">The entity type to search.</param>
        /// <returns>True, if entity found in specifed entity graph.</returns>
        /// <remarks>
        /// <para>[US] 19/08/2016  1.0 Method created.</para>
        /// </remarks>
        public override bool HaveType(string entityId, Type type)
        {
            //return false;

            if (AggregateChildsV2 == null || AggregateChildsV2.ContainsKey(entityId) == false)
            {
                return false;
            }

            var types = AggregateChildsV2[entityId];


            var haveType =
                ChildRelations.Where(t => types.Any(ty => ty.Equals(t.Key))).Any(a => a.Value.Item1.ChildType == type);
            return haveType;
            
        }


	}//end class

#pragma warning restore

}//end ns
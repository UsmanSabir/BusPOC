﻿using System;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;

namespace BatchEngine.Models.BusStateWrapper
{
    public class ProcessStateWrapper: IReadWriteableProcessState
    {
        internal readonly BatchProcessState State;

        public ProcessStateWrapper(BatchProcessState state)
        {
            State = state;
        }

        public long Id => State.ID;
        Guid IWritableProcessState.CorrelationId
        {
            set { State.CORRELATIONID = value; }
        }

        DateTime? IWritableProcessState.UpdatedOn
        {
            set => State.UPDATEDON = value;
        }

        ProcessStatus IWritableProcessState.Status { set => State.CURRENTSTATE = value.Name; }
        int IWritableProcessState.RetryCount
        {
            set { State.RETRYCOUNT = value; }
        }
        int IWritableProcessState.CompanyId
        {
            set { State.COMPANYID = value; }
        }
        int IWritableProcessState.BranchId
        {
            set { State.BRANCHID = value; }
        }

        int IWritableProcessState.SubTenantId
        {
            set
            {
                throw new NotImplementedException();
            }
        } //todo

        DateTime IWritableProcessState.ProcessingDate
        {
            set { State.PROCESSINGDATE = value; }
        }
        int IWritableProcessState.ProcessKey
        {
            set { State.PROCESSKEY = value; }
        }
        bool IWritableProcessState.IsVolumeGenerated
        {
            set { State.ISVOLUMEGENERATED = value; }
        }

        long? IWritableProcessState.ParentId
        {
            set { State.PARENTID = value; }
        }

        long IWritableProcessState.GroupId
        {
            set { State.GROUPID = (int) value; }//todo
        }
        bool IWritableProcessState.IsFinished
        {
            set { State.ISFINISHED = value; }
        }
        bool IWritableProcessState.IsStopped
        {
            set { State.ISSTOPPED = value; }
        }
        string IWritableProcessState.Criteria
        {
            set { State.CRITERIA = value; }
        }
        DateTime? IWritableProcessState.StartTime
        {
            set { State.STARTTIME = value; }
        }

        long IWritableProcessState.Id
        {
            set { State.ID = value; }
        }

        public Guid CorrelationId => State.CORRELATIONID;

        public DateTime? UpdatedOn => State.UPDATEDON;

        public ProcessStatus Status => ProcessStatus.FromName(State.CURRENTSTATE);

        public int RetryCount => State.RETRYCOUNT;

        public int CompanyId => State.COMPANYID;

        public int BranchId => State.BRANCHID;

        public int SubTenantId => throw new NotImplementedException();

        public DateTime ProcessingDate => State.PROCESSINGDATE;

        public int ProcessKey => State.PROCESSKEY;

        public bool IsVolumeGenerated => State.ISVOLUMEGENERATED;

        public long? ParentId => State.PARENTID;

        public int GroupId => State.GROUPID;

        public bool IsFinished => State.ISFINISHED;

        public bool IsStopped => State.ISSTOPPED;

        public string Criteria => State.CRITERIA;

        public DateTime? StartTime => State.STARTTIME;
    }
}
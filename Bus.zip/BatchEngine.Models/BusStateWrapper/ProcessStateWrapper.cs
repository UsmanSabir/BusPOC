﻿using System;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;

namespace BatchEngine.Models.BusStateWrapper
{
    public class ProcessStateWrapper: IReadWritableProcessState
    {
        internal readonly BatchProcessState State;

        public ProcessStateWrapper(BatchProcessState state)
        {
            State = state;
        }

        public long Id
        {
            get => State.ID;
            set => State.ID = value;
        }

        public Guid CorrelationId
        {
            get => State.CORRELATIONID;
            set => State.CORRELATIONID=value;
        }

        public DateTime? UpdatedOn
        {
            get => State.UPDATEDON;
            set => State.UPDATEDON=value;
        }

        public ProcessStatus Status
        {
            get => ProcessStatus.FromName(State.CURRENTSTATE);
            set => State.CURRENTSTATE= value.Name;
        }

        public int RetryCount
        {
            get => State.RETRYCOUNT;
            set => State.RETRYCOUNT=value;
        }

        public int CompanyId
        {
            get => State.COMPANYID;
            set => State.COMPANYID=value;
        }

        public int BranchId
        {
            get => State.BRANCHID;
            set => State.BRANCHID=value;
        }

        public int SubTenantId
        {
            get => State.SUBTENANTID;
            set => State.SUBTENANTID=value;
        }

        public DateTime ProcessingDate
        {
            get => State.PROCESSINGDATE;
            set => State.PROCESSINGDATE=value;
        }

        public int ProcessKey
        {
            get => State.PROCESSKEY;
            set => State.PROCESSKEY=value;
        }

        public bool IsVolumeGenerated
        {
            get => State.ISVOLUMEGENERATED;
            set => State.ISVOLUMEGENERATED=value;
        }

        public long? ParentId
        {
            get => State.PARENTID;
            set => State.PARENTID=value;
        }

        public long GroupId
        {
            get => State.GROUPID;
            set => State.GROUPID = value;
        }


        public bool IsFinished
        {
            get => State.ISFINISHED;
            set => State.ISFINISHED=value;
        }

        public bool IsStopped
        {
            get => State.ISSTOPPED;
            set => State.ISSTOPPED=value;
        }

        public string Criteria
        {
            get => State.CRITERIA;
            set => State.CRITERIA=value;
        }

        public DateTime? StartTime
        {
            get => State.STARTTIME;
            set => State.STARTTIME=value;
        }
    }
}
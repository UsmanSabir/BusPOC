
/* This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore.Groups;

namespace BatchEngine.Models.BusStateWrapper
{

	///BatchGroupState
	public class BatchGroupStateWrapper : IGroupEntity
	{
	    public BatchGroupState _state;

	    public BatchGroupStateWrapper(BatchGroupState state)
	    {
	        _state = state;
	    }

	    public bool IsFinished
	    {
	        get { return _state.ISFINISHED; }
	    }
	    public bool IsStopped
	    {
	        get { return _state.ISSTOPPED; }
	    }
	    public long Id
	    {
	        get { return _state.ID; }
	    }
	    public int GroupKey
	    {
	        get { return _state.GROUPKEY; }
	    }
	    public bool IsManual
	    {
	        get { return _state.ISMANUAL; }
	    }

	    public bool IsResubmission
	    {
	        get { return _state.ISRESUBMISSION; }
	    }

	    public string SubmittedBy
	    {
	        get { return _state.SUBMITTEDBY; }
	    }
	    public string Criteria
	    {
	        get { return _state.CRITERIA; }
	    }
	}
	

#pragma warning restore CS1591

}
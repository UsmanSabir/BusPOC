﻿using System;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;

namespace BatchEngine.Models.BusStateWrapper
{
    public class BatchTaskWrapper:ITaskState
    {
        internal readonly BatchTaskState State;

        public BatchTaskWrapper(BatchTaskState state)
        {
            State = state;
        }

        public bool IsFinished => State.ISFINISHED;

        public bool IsStopped => State.ISSTOPPED;

        public long Id => State.ID;

        public long ProcessId => State.PROCESSID;

        public string Payload => State.PAYLOAD;

        public DateTime? UpdatedOn => State.UPDATEDON;

        public ResultStatus Status => ResultStatus.FromName(State.CURRENTSTATE);

        public string CurrentState => State.CURRENTSTATE;

        public int FailedCount => State.FAILEDCOUNT;

        public int DeferredCount => State.DEFERREDCOUNT;

        public string NodeKey => State.NODEKEY;
    }
}
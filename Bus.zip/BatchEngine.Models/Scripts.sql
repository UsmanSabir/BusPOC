﻿CREATE TABLE [BatchGroupState](
	[Id] [BIGINT] IDENTITY(1,1) NOT NULL,
	[GroupKey] [INT] NOT NULL,
	[SubmittedBy] [VARCHAR](250) NOT NULL,
	[IsManual] [BIT] NOT NULL,
	[IsResubmission] [BIT] NOT NULL,
	[Criteria] [VARCHAR](250) NOT NULL,
	[IsFinished] [BIT] NOT NULL,
	[IsStopped] [BIT] NOT NULL,
 CONSTRAINT [PK_BatchGroupState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
) 
) 

GO


ALTER TABLE [dbo].[BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsManual]  DEFAULT ((1)) FOR [IsManual]
GO

ALTER TABLE [dbo].[BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsResubmission]  DEFAULT ((0)) FOR [IsResubmission]
GO

ALTER TABLE [dbo].[BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsFinished]  DEFAULT ((0)) FOR [IsFinished]
GO

ALTER TABLE [dbo].[BatchGroupState] ADD  CONSTRAINT [DF_BatchGroupState_IsStopped]  DEFAULT ((0)) FOR [IsStopped]
GO


CREATE TABLE [BatchProcessState](
	[Id] [BIGINT] IDENTITY(1,1) NOT NULL,
	[CorrelationId] [UNIQUEIDENTIFIER] NOT NULL,
	[UpdatedOn] [DATETIME] NULL,
	[RetryCount] [INT] NOT NULL,
	[CompanyId] [INT] NOT NULL,
	[BranchId] [INT] NOT NULL,
	[ProcessingDate] [DATETIME] NOT NULL,
	[ProcessKey] [INT] NOT NULL,
	[IsVolumeGenerated] [BIT] NOT NULL,
	[ParentId] [BIGINT] NULL,
	[GroupId] [INT] NOT NULL,
	[IsFinished] [BIT] NOT NULL,
	[IsStopped] [BIT] NOT NULL,
	[Criteria] [NVARCHAR](500) NOT NULL,
	[StartTime] [DATETIME] NULL,
	[CurrentState] [VARCHAR](50) NOT NULL,
 CONSTRAINT [PK_BatchProcessState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)
)

GO

CREATE TABLE [BatchTaskState](
	[Id] [BIGINT] IDENTITY(1,1) NOT NULL,
	[ProcessId] [BIGINT] NOT NULL,
	[Payload] [VARCHAR](500) NOT NULL,
	[UpdatedOn] [DATETIME] NULL,
	[CurrentState] [VARCHAR](50) NOT NULL,
	[FailedCount] [INT] NOT NULL,
	[DeferredCount] [INT] NOT NULL,
	[NodeKey] [VARCHAR](250) NULL,
	[IsFinished] [BIT] NOT NULL,
 CONSTRAINT [PK_BatchTaskState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)
)

GO

CREATE TABLE [dbo].[BatchTaskValue](
	[Id] [BIGINT] IDENTITY(1,1) NOT NULL,
	[TaskId] [BIGINT] NOT NULL,
	[ProcessId] [BIGINT] NOT NULL,
	[StateKey] [VARCHAR](250) NOT NULL,
	[StateValue] [VARCHAR](500) NOT NULL,
 CONSTRAINT [PK_BatchTaskValue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)
)

GO

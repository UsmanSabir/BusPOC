﻿
CREATE TABLE [dbo].[BatchGroupState](
	[Id] [BIGINT] IDENTITY(1,1) NOT NULL,
	[GroupKey] [INT] NOT NULL,
	[SubmittedBy] [VARCHAR](250) NOT NULL,
	[IsManual] [BIT] NOT NULL CONSTRAINT [DF_BatchGroupState_IsManual]  DEFAULT ((1)),
	[IsResubmission] [BIT] NOT NULL CONSTRAINT [DF_BatchGroupState_IsResubmission]  DEFAULT ((0)),
	[Criteria] [VARCHAR](250) NOT NULL,
	[IsFinished] [BIT] NOT NULL CONSTRAINT [DF_BatchGroupState_IsFinished]  DEFAULT ((0)),
	[IsStopped] [BIT] NOT NULL CONSTRAINT [DF_BatchGroupState_IsStopped]  DEFAULT ((0)),
	[CurrentState] [VARCHAR](50) NOT NULL,
 CONSTRAINT [PK_BatchGroupState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO


CREATE TABLE [dbo].[BatchProcessConfig](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProcessKey] [int] NOT NULL,
	[BatchSize] [int] NOT NULL,
	[ProcessTimeoutMins] [int] NULL,
	[TaskTimeout] [int] NULL,
	[ProcessRetries] [int] NULL,
	[TaskRetries] [int] NULL,
	[RetryDelayMilli] [int] NULL,
	[MaxVolumeRetries] [int] NOT NULL CONSTRAINT [DF_BatchProcessConfig_MaxVolumeRetries]  DEFAULT ((3)),
	[QueueSize] [int] NULL,
 CONSTRAINT [PK_BatchProcessConfig] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO



CREATE TABLE [dbo].[BatchProcessState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CorrelationId] [uniqueidentifier] NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[RetryCount] [int] NOT NULL CONSTRAINT [DF_BatchProcessState_RetryCount]  DEFAULT ((0)),
	[CompanyId] [int] NOT NULL,
	[BranchId] [int] NOT NULL,
	[ProcessingDate] [datetime] NOT NULL,
	[ProcessKey] [int] NOT NULL,
	[IsVolumeGenerated] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsVolumeGenerated]  DEFAULT ((0)),
	[ParentId] [bigint] NULL,
	[GroupId] [bigint] NOT NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsStopped]  DEFAULT ((0)),
	[Criteria] [nvarchar](500) NOT NULL,
	[StartTime] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[SubTenantId] [int] NOT NULL,
	[CompleteTime] [DATETIME] NULL,
	[GenerationCompleteTime] [DATETIME] NULL,
	[ResultStatus] [VARCHAR](50) NOT NULL,
 CONSTRAINT [PK_BatchProcessState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO


ALTER TABLE [dbo].[BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_RetryCount]  DEFAULT ((0)) FOR [RetryCount]
GO

ALTER TABLE [dbo].[BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_IsVolumeGenerated]  DEFAULT ((0)) FOR [IsVolumeGenerated]
GO

ALTER TABLE [dbo].[BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_IsFinished]  DEFAULT ((0)) FOR [IsFinished]
GO

ALTER TABLE [dbo].[BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_IsStopped]  DEFAULT ((0)) FOR [IsStopped]
GO

ALTER TABLE [dbo].[BatchProcessState] ADD  CONSTRAINT [DF_BatchProcessState_ResultStatus]  DEFAULT ('Pending') FOR [ResultStatus]
GO




CREATE TABLE [dbo].[BatchTaskState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[Payload] [varchar](500) NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[FailedCount] [int] NOT NULL CONSTRAINT [DF_BatchTask_FailedCount]  DEFAULT ((0)),
	[DeferredCount] [int] NOT NULL CONSTRAINT [DF_BatchTask_DeferredCount]  DEFAULT ((0)),
	[NodeKey] [varchar](250) NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchTask_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchTaskState_IsStopped]  DEFAULT ((0)),
	[StartedOn] [datetime] NULL,
	[CompletedOn] [datetime] NULL,
 CONSTRAINT [PK_BatchTaskState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO



CREATE TABLE [dbo].[BatchTaskValue](
	[Id] [BIGINT] IDENTITY(1,1) NOT NULL,
	[TaskId] [BIGINT] NOT NULL,
	[ProcessId] [BIGINT] NOT NULL,
	[StateKey] [VARCHAR](250) NOT NULL,
	[StateValue] [VARCHAR](500) NOT NULL,
 CONSTRAINT [PK_BatchTaskValue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO




--=====================

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Groups;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using BusLib.JobSchedular;
using BusLib.JobScheduler;
using BusLib.Serializers;
using NS.BaseModels;
using NS.ORM;

namespace BusImpl
{
    internal class JobScheduler:IJobScheduler
    {
        private readonly IBatchEngineQueueService _batchEngineQueueService;
        private readonly IDistributedMessagePublisher _publisher;
        private readonly ISerializer _ser;
        protected internal readonly IFrameworkLogger SystemLogger;

        public JobScheduler(ISerializersFactory factory, IPubSubFactory pubSubFactory, IBatchLoggerFactory loggerFactory, 
            IBatchEngineQueueService batchEngineQueueService)
        {
            _batchEngineQueueService = batchEngineQueueService;
            SystemLogger = loggerFactory.GetSystemLogger();
            _publisher = pubSubFactory.GetPublisher(CancellationToken.None, SystemLogger, nameof(IWatchDogMessage));
            //_ser = SerializersFactory.Instance.GetSerializer<List<JobCriteria>>();
            //JsonSerializer serializer=new JsonSerializer();
            _ser = factory.GetSerializer(typeof(JobCriteria));
        }

        public long CreateProcessJob(int processId, List<JobCriteria> criteria, string submittedBy, bool hasPriority = false,
            bool isResubmission = false)
        {
            return CreateJob(new List<int>() {processId}, criteria, submittedBy, hasPriority, isResubmission);
        }

        public long CreateJob(int groupId, List<JobCriteria> criteria, string submittedBy, bool hasPriority, bool isResubmission)
        {
            BatchGroupState group=new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(group)
            {
                GroupKey = groupId,
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsFinished = false,
                IsResubmission = isResubmission,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual,
                HasPriority = hasPriority
            };

            var ext = EntityContextExt.Create(new[] {group});
            ext.Persist();

            Publish(groupEntity.Id);

            return group.ID;
        }

        public long CreateJob(List<int> processIds, List<JobCriteria> criteria, string submittedBy, bool hasPriority, bool isResubmission)
        {
            BatchGroupState group = new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(group)
            {
                Payload = _ser.SerializeToString(processIds),
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsResubmission = isResubmission,
                IsFinished = false,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual,
                HasPriority = hasPriority
            };
            
            var ext = EntityContextExt.Create(new[] { group });
            ext.Persist();

            Publish(groupEntity.Id);

            return groupEntity.Id;
        }

        public long CreateQueueJob(List<int> processIds, List<JobCriteria> criteria, string queueName, string submittedBy, bool hasPriority, bool isResubmission = false)
        {
            if (processIds==null || processIds.Count==0)
                throw new ArgumentNullException(nameof(processIds));

            if (string.IsNullOrWhiteSpace(queueName))
                throw new ArgumentNullException(nameof(queueName));

            BatchGroupState group = new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(group)
            {
                Payload = _ser.SerializeToString(processIds),
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsResubmission = isResubmission,
                IsFinished = false,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual,
                QueueName = queueName,
                HasPriority = hasPriority
            };

            using (var unitOfWorkManager = new UnitOfWorkManager())
            {
                //unitOfWorkManager.QueuePersist(new List<BatchGroupState>{ group });
                unitOfWorkManager.QueueCommand(uow =>
                {
                    var ext = EntityContextExt.Create(new[] { group }).UsingUnitOfWork(uow);
                    ext.Persist();

                    var queueSeq = _batchEngineQueueService.GetProcessSeqNoForQueue(queueName, @group.ID, new TransactionWrapper(uow));
                    group.QUEUESEQ = queueSeq;
                    group.State = EntityState.DataModified; //trigger update command
                    ext.Persist();
                });

                unitOfWorkManager.Commit();
            }

            //var ext = EntityContextExt.Create(new[] { group });
            //using (var unitOfWork = ext.InitiateUnitOfWork())
            //{
            //    ext.Persist();

            //    var queueSeq = _batchEngineQueueService.GetProcessSeqNoForQueue(queueName,@group.ID, new TransactionWrapper(unitOfWork));
            //    group.QUEUESEQ = queueSeq;
            //    ext.Persist();

            //    unitOfWork.Save();
            //}
            

            Publish(groupEntity.Id);

            return groupEntity.Id;
        }

        void Publish(long groupId)
        {
            try
            {
                _publisher.PublishMessage(new ProcessGroupAddedMessage { GroupId = groupId }); 
                //_publisher.PublishMessage(new ProcessGroupAddedMessage { GroupId = groupId }); GroupMessage
            }
            catch (Exception e)
            {
                SystemLogger.Error("Failed to publish ProcessGroupAddedMessage for groupId {groupId} having error {error}", groupId, e);
            }
        }
    }
}
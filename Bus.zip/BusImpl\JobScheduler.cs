﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Groups;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using BusLib.JobSchedular;
using BusLib.Serializers;
using NS.ORM;

namespace BusImpl
{
    internal class JobScheduler:IJobScheduler
    {
        private readonly IDistributedMessagePublisher _publisher;
        private readonly ISerializer _ser;
        protected internal readonly IFrameworkLogger SystemLogger;

        public JobScheduler(ISerializersFactory factory, IPubSubFactory pubSubFactory, IBatchLoggerFactory loggerFactory)
        {
            SystemLogger = loggerFactory.GetSystemLogger();
            _publisher = pubSubFactory.GetPublisher(CancellationToken.None, SystemLogger, nameof(IWatchDogMessage));
            //_ser = SerializersFactory.Instance.GetSerializer<List<JobCriteria>>();
            //JsonSerializer serializer=new JsonSerializer();
            _ser = factory.GetSerializer(typeof(JobCriteria));
        }

        public long CreateJob(int groupKey, List<JobCriteria> criteria, string submittedBy, bool isResubmission)
        {
            BatchGroupState group=new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(group)
            {
                GroupKey = groupKey,
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsFinished = false,
                IsResubmission = isResubmission,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual
            };

            var ext = EntityContextExt.Create(new[] {group});
            ext.Persist();

            Publish(groupEntity.Id);

            return group.ID;
        }

        public long CreateJob(List<int> processKeys, List<JobCriteria> criteria, string submittedBy, bool isResubmission)
        {
            BatchGroupState group = new BatchGroupState();
            BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(group)
            {
                Payload = _ser.SerializeToString(processKeys),
                Criteria = _ser.SerializeToString(criteria),
                IsGenerated = false,
                IsStopped = false,
                IsResubmission = isResubmission,
                IsFinished = false,
                SubmittedBy = submittedBy,
                State = CompletionStatus.Pending.Name,
                IsManual = isResubmission || criteria.First().IsManual
            };
            
            var ext = EntityContextExt.Create(new[] { group });
            ext.Persist();

            Publish(groupEntity.Id);

            return groupEntity.Id;
        }

        void Publish(long groupId)
        {
            try
            {
                _publisher.PublishMessage(new ProcessGroupAddedMessage { GroupId = groupId }); 
                //_publisher.PublishMessage(new ProcessGroupAddedMessage { GroupId = groupId }); GroupMessage
            }
            catch (Exception e)
            {
                SystemLogger.Error("Failed to publish ProcessGroupAddedMessage for groupId {groupId} having error {error}", groupId, e);
            }
        }
    }
}
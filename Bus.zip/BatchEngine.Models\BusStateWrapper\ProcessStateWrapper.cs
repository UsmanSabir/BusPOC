﻿using System;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;

namespace BatchEngine.Models.BusStateWrapper
{
    public class ProcessStateWrapper: IReadWritableProcessState
    {
        internal readonly BatchProcessState State;

        public ProcessStateWrapper(BatchProcessState state)
        {
            State = state;
        }

        public long Id
        {
            get => State.ID;
            set => State.ID = value;
        }

        public Guid CorrelationId
        {
            get => State.CORRELATIONID;
            set => State.CORRELATIONID=value;
        }

        public DateTime? UpdatedOn
        {
            get => State.UPDATEDON;
            set => State.UPDATEDON=value;
        }

        public CompletionStatus Status
        {
            get => CompletionStatus.FromName(State.CURRENTSTATE);
            set => State.CURRENTSTATE= value.Name;
        }

        public int RetryCount
        {
            get => State.RETRYCOUNT;
            set => State.RETRYCOUNT=value;
        }

        public int CompanyId
        {
            get => State.COMPANYID;
            set => State.COMPANYID=value;
        }

        public int BranchId
        {
            get => State.BRANCHID;
            set => State.BRANCHID=value;
        }

        public int SubTenantId
        {
            get => State.SUBTENANTID;
            set => State.SUBTENANTID=value;
        }

        public DateTime ProcessingDate
        {
            get => State.PROCESSINGDATE;
            set => State.PROCESSINGDATE=value;
        }

        public int ProcessId
        {
            get => State.PROCESSID;
            set => State.PROCESSID=value;
        }

        public bool IsVolumeGenerated
        {
            get => State.ISVOLUMEGENERATED;
            set => State.ISVOLUMEGENERATED=value;
        }

        public long? ParentId
        {
            get => State.PARENTID;
            set => State.PARENTID=value;
        }

        public long GroupId
        {
            get => State.GROUPID;
            set => State.GROUPID = value;
        }


        public bool IsFinished
        {
            get => State.ISFINISHED;
            set => State.ISFINISHED=value;
        }

        public bool IsStopped
        {
            get => State.ISSTOPPED;
            set => State.ISSTOPPED=value;
        }

        public string Criteria
        {
            get => State.CRITERIA;
            set => State.CRITERIA=value;
        }

        public DateTime? StartTime
        {
            get => State.STARTTIME;
            set => State.STARTTIME=value;
        }

        public DateTime? CompleteTime
        {
            get => State.COMPLETETIME;
            set => State.COMPLETETIME=value;
        }

        public DateTime? GenerationCompleteTime
        {
            get => State.GENERATIONCOMPLETETIME;
            set => State.GENERATIONCOMPLETETIME=value;
        }

        public ResultStatus Result
        {
            get => ResultStatus.FromName(State.RESULTSTATUS);
            set => State.RESULTSTATUS=value.Name;
        }

        public int GroupSeqId
        {
            get => State.GROUPSEQID;
            set => State.GROUPSEQID = value;
        }

        public bool HasVolume
        {
            get => State.HASVOLUME;
            set => State.HASVOLUME = value;
        }

        public bool? GroupStopper
        {
            get => State.GROUPSTOPPER;
            set => State.GROUPSTOPPER = value;
        }

        public string DependentIds
        {
            get => State.DEPENDENTPROCESSIDS;
            set => State.DEPENDENTPROCESSIDS = value;
        }

        private List<long> _dependentIdsList = null;
        public List<long> DependentIdsList
        {
            get
            {
                if (_dependentIdsList == null)
                {
                    _dependentIdsList = new List<long>();
                    foreach (var s in DependentIds.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries))
                    {
                        if (long.TryParse(s, out long id))
                        {
                            _dependentIdsList.Add(id);
                        }
                    }
                }

                return _dependentIdsList;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusImpl.Db;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Exceptions;
using BusLib.BatchEngineCore.Groups;
using BusLib.Core;
using BusLib.Helper;
using BusLib.JobScheduler;
using NS.BaseModels;
using NS.ORM;
using NS.ORM.UoW;
using NS.Utilities;
using ProcessConfiguration = BatchEngine.Models.Entities.ProcessConfiguration;

namespace BusImpl
{
    public class StatePersistenceService: IStatePersistenceService
    {
        private readonly IBatchEngineQueueService _queueService;

        public StatePersistenceService(IBatchEngineQueueService queueService)
        {
            _queueService = queueService;
        }

        EntityContextExt<T> GetEntityContext<T>(IList<T> entities = null) where T : BaseModel, new()
        {
            return OrmFactory.GetEntityContext(entities);
        }

        private DbController GetDbController(IUnitOfWork uow = null)
        {
            return OrmFactory.GetDbController(uow);
        }

        public IEnumerable<IReadWritableGroupEntity> GetAllIncomplete()
        {
            var contextExt = GetEntityContext<BatchGroupState>();
            contextExt.Read(r => r.ISFINISHED == false && r.ISSTOPPED== false);
            
            return contextExt.Entity.Select(s=>new BatchGroupStateWrapper(s));
            
        }

        //public IEnumerable<IReadWritableGroupEntity> GetAllIncomplete()
        //{
        //    var contextExt = GetEntityContext<BatchGroupState>();
        //    contextExt.Read(r => r.ISFINISHED == false && r.ISSTOPPED == false && r.ISGENERATED == false);

        //    return contextExt.Entity.Select(s => new BatchGroupStateWrapper(s));

        //}


        public IReadWritableGroupEntity GetGroupEntity(long groupId)
        {
            var contextExt = GetEntityContext<BatchGroupState>();
            contextExt.Read(r => r.ID== groupId);

            return contextExt.Entity.Select(s => new BatchGroupStateWrapper(s)).FirstOrDefault();
        }

        public List<KeyValuePair<string, string>> GetTaskStates(long taskId, long processId)
        {
            var contextExt = GetEntityContext<BatchTaskValues>();
            contextExt.Read(r => r.PROCESSID==processId && r.TASKID==taskId);

            return contextExt.Entity.Select(s => new KeyValuePair<string,string>(s.STATEKEY, s.STATEVALUE)).ToList();
        }

        public IEnumerable<int> GetConfiguredGroupProcessKeys(long groupEntityId)
        {
            //var ext = GetEntityContext<BatchProcessGroupDetail>();
            ////todo read from group-process mapping
            //ext.Read(r => r.GROUPKEY == groupEntityId && r.ACT_IND);

            //return ext.Entity.Select(r => r.PROCESSID);
            //return BatchProcessGroupDetail.GetActiveGroupProcess(groupEntityId).Select(r => r.PROCESSID);
            return GetActiveGroupProcess(groupEntityId).Select(r => r.PROCESSID); 
        }

        List<BatchProcessGroupDetail> GetActiveGroupProcess(
            Int64 groupKey)
        {
            EntityContextExt<BatchProcessGroupDetail> c = GetEntityContext<BatchProcessGroupDetail>();
            c.ReadEntityByKey(new Dictionary<string, object>()
                {
                    { "groupKey" , groupKey },
                }, nameof(GetActiveGroupProcess)
            );
            //if (fillChilds)
            //    c.FillChilds();
            return c.Entity;
        }

        public IEnumerable<IReadWritableProcessState> GetSubmittedGroupProcesses(long groupEntityId)
        {
            var contextExt = GetEntityContext<BatchProcessState>();
            contextExt.Read(r => r.GROUPID == groupEntityId);

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s));
        }

        

        public IEnumerable<ITaskState> GetIncompleteTasksForProcess(long processId)
        {
            var contextExt = GetEntityContext<BatchTaskState>();
            contextExt.Read(r => r.PROCESSID == processId && (r.ISFINISHED==false && r.ISSTOPPED==false));
            
            return contextExt.Entity.Select(s => new BatchTaskWrapper(s));
        }

        public long GetIncompleteTasksCountForProcess(long processId)
        {
            using (var controller = DbController.Create())
            {
                var count = controller.Count<BatchTaskState>($"{nameof(BatchTaskState.PROCESSID)} = @pid AND {nameof(BatchTaskState.ISFINISHED)}=0 AND {nameof(BatchTaskState.ISSTOPPED)}=0", 
                    new Dictionary<string, object> {{"pid", processId}}); //todo optimize orm usage with builder
                return count;
            }

            //var contextExt = GetEntityContext<BatchTaskState>();
            //contextExt.FillChilds()
            //contextExt.Read(r => r.PROCESSID == processId && (r.ISFINISHED == false && r.ISSTOPPED == false));

            //return contextExt.Entity.Select(s => new BatchTaskWrapper(s));
        }

        public long CountFailedTasksForProcess<T>(long processId)
        {
            using (var dbController = GetDbController())
            {
                var count = dbController.Count(Constant.SQLCountFailedTasks, new SerializableDictionary<string,object>(){{ "pid", processId } });
                return count;
            }
        }

        
        public long CountPendingTasksForProcess(long processId)
        {
            using (var dbController = GetDbController())
            {
                var count = dbController.Count(Constant.SQLCountPendingTasks, new SerializableDictionary<string, object>() { { "pid", processId } });
                return count;
            }
        }

        public IReadWritableProcessState GetAndStartProcessById(long processId)
        {
            var contextExt = GetEntityContext<BatchProcessState>();
            contextExt.Read(r => r.ID == processId && r.ISSTOPPED==false);
            var state = contextExt.Entity.FirstOrDefault();
            if (state != null && state.STARTTIME==null)
            {
                state.STARTTIME = DateTime.UtcNow;

                if (state.CURRENTSTATE == CompletionStatus.Pending.Name)
                    state.CURRENTSTATE = CompletionStatus.Generating.Name;

                contextExt.Persist();
            }
            
            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public IReadWritableProcessState GetProcessById(long processId)
        {
            var contextExt = GetEntityContext<BatchProcessState>();
            contextExt.Read(r => r.ID == processId);
            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public IReadWritableProcessState GetProcessByKey(int processKey)
        {
            //todo read from group-process mapping
            var contextExt = GetEntityContext<BatchProcessState>();
            contextExt.Read(r => r.ID == processKey); //todo read from process config

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public void AddGroupProcess(List<IReadWritableProcessState> groupProcesses, IGroupEntity groupEntity)
        {
            var hierarchy = BuildHierarchy(groupProcesses.Select(s=>s.ProcessId).ToList());
            var groupSeqs = groupProcesses.Select(s => s.GroupSeqId).Distinct().ToList();
            var processes = groupProcesses.Cast<ProcessStateWrapper>().Select(s => s.State).ToList();
            var contextExt = GetEntityContext<BatchProcessState>(processes);
            using (var work = contextExt.InitiateUnitOfWork())
            {
                //contextExt.IdInjector

                BatchGroupStateWrapper groupWrp = (BatchGroupStateWrapper)groupEntity;
                var ext = GetEntityContext(new []{ groupWrp._state}).UsingUnitOfWork(work);
                groupWrp.IsGenerated = true;

                ext.Persist();
                contextExt.Persist();

                #region Hierarchy

                try
                {

                    foreach (var process in processes)
                    {
                        process.State = EntityState.NotModified;
                    }

                    foreach (var processDependency in hierarchy) //.Where(p=>p.PRNTPRCSID.HasValue && p.PRNTPRCSID.Value!=0))
                    {
                        if(processDependency.hierarchy.PARENTPROCESSID==null)
                            continue;

                        var processId = processDependency.hierarchy.PROCESSID;
                        var parentProcessId = processDependency.hierarchy.PARENTPROCESSID.Value;

                        foreach (var groupSeq in groupSeqs)
                        {
                            //a process id must exist in each groupSeqId. GroupSeqId is a collection of group processes per "Criteria"
                            var childProcess = processes.FirstOrDefault(c => c.PROCESSID == processId && c.GROUPSEQID == groupSeq);
                            var parentProcess = processes.FirstOrDefault(p => p.PROCESSID == parentProcessId && p.GROUPSEQID == groupSeq);

                            if (childProcess == null)
                            {
                                throw new FrameworkException($"Child Process id '{processId}' not found in group");
                            }
                            if (parentProcess == null)
                            {
                                throw new FrameworkException($"Parent Process id '{parentProcessId}' not found in group");
                            }

                            childProcess.PARENTID = parentProcess.ID;
                            if (processDependency.dependents != null && processDependency.dependents.Count>0)
                            {
                                //get dependent process Ids and keep ids who's process not found. "not found ids" will be executed at last
                                var dependentIds = processDependency.dependents.Select(did=> (processes.FirstOrDefault(c => c.PROCESSID == did && c.GROUPSEQID == groupSeq)?.ID) ?? did);
                                childProcess.DEPENDENTPROCESSIDS = string.Join(",", dependentIds);
                            }
                            
                            childProcess.State = EntityState.DataModified;
                        }
                    }

                    contextExt.Persist();//persist hierarchy

                    work.Save();

                }
                catch (Exception)
                {
                    //restore state for retry
                    foreach (var wrapper in processes)
                    {
                        wrapper.State = EntityState.NewModified;
                    }

                    throw;
                }

                #endregion

            }
            
        }

        List<(ProcessHierarchy hierarchy, List<int> dependents)> BuildHierarchy(List<int> processIds) //(int key, int parent) 
        {
            var ext = GetEntityContext<ProcessHierarchy>();
            //ext.Read(r => processKeys.Contains(r.PROCESSKEY));
            ext.Read();

            //var inActive = ext.Entity.Where(r => r.ACT_IND == false).Select(r=>r.PROCESSID).ToList();
            ////remove in-active process
            //processIds.RemoveAll(i => inActive.Contains(i));

            return CheckHierarchy(ext.Entity, processIds);

            //return ext.Entity; //.Select(s=>new {s.PROCESSKEY, s.PRNTPRCSID})
        }

        private List<(ProcessHierarchy hierarchy, List<int> dependents)> CheckHierarchy(List<ProcessHierarchy> hirDefinition, List<int> processIds)
        {
            //var rootNodes = hirDefinition.Where(s=>s.PRNTPRCSID==null).ToList();
            //var nestedNodes = hirDefinition.Where(r => r.PRNTPRCSID.HasValue && r.PRNTPRCSID.Value > 0).ToList();

            List<(ProcessHierarchy hierarchy, List<int> dependents)> res=new List<(ProcessHierarchy hierarchy, List<int> dependents)>();

            var result = hirDefinition
                .Where(r => processIds.Exists(s => s == r.PROCESSID))
                .Select(s =>
                {
                    var hir = new ProcessHierarchy
                    {
                        ID = s.ID,
                        ACT_IND = s.ACT_IND,
                        DEPENDENTPROCESSIDS = s.DEPENDENTPROCESSIDS,
                        GROUPKEY = s.GROUPKEY,
                        PARENTPROCESSID = s.PARENTPROCESSID,
                        PROCESSID = s.PROCESSID
                    };

                    List<int> depIds = null;
                    if (!string.IsNullOrWhiteSpace(s.DEPENDENTPROCESSIDS))
                    {
                        var dependents = s.DEPENDENTPROCESSIDS.Split(new[] { "" }, StringSplitOptions.RemoveEmptyEntries);
                        depIds = new List<int>();
                        foreach (var dependent in dependents)
                        {
                            if (int.TryParse(dependent, out int depId))
                            {
                                depIds.Add(depId);
                            }
                        }
                    }
                    res.Add((hir, depIds));
                    return hir;

                }).ToList();


            foreach (var pair in res)
            {
                var key = pair.Item1;

                if(key.PARENTPROCESSID==null)
                    continue;

                var parentNodeId = key.PARENTPROCESSID.Value;
                if (parentNodeId == key.PROCESSID)
                {
                    throw new FrameworkException($"A process cannot be parent of itself. Process Id '{key.PROCESSID}' has same parent '{parentNodeId}' configured");
                }
                //var node = hirDefinition.First(r => r.PROCESSKEY == key);

                if (result.Exists(r => r.PROCESSID == parentNodeId))
                {
                    //success
                }
                else
                {
                    int? parentId = FindParent(parentNodeId, hirDefinition, result);
                    key.PARENTPROCESSID = parentId;

                    foreach (var (hierarchy, dependents) in res)
                    {
                        if (dependents != null && dependents.Contains(parentNodeId))
                        {
                            dependents.Remove(parentNodeId);
                            if (parentId.HasValue && !dependents.Contains(parentId.Value))
                            {
                                dependents.Add(parentId.Value);
                            }
                        }
                    }

                }
            }

            return res;
        }

        private int? FindParent(int parentId, List<ProcessHierarchy> extEntity, List<ProcessHierarchy> result)
        {
            var parentNode = result.FirstOrDefault(r=>r.PROCESSID == parentId);
            if (parentNode != null)
            {
                return parentNode.PROCESSID;
            }
            else
            {
                var processConfig = extEntity.First(r=>r.PROCESSID==parentId);
                if (processConfig.PARENTPROCESSID.HasValue && processConfig.PARENTPROCESSID.Value > 0)
                    return FindParent(processConfig.PARENTPROCESSID.Value, extEntity, result);
                else
                {
                    return null;// become root
                }
            }
        }

        public void SaveGroup(IReadWritableGroupEntity @group)
        {
            BatchGroupStateWrapper groupStateWrapper= (BatchGroupStateWrapper)group;
            var contextExt = GetEntityContext<BatchGroupState>(new List<BatchGroupState>() { groupStateWrapper._state });
            if (contextExt.Entity.Any(r => r.State == EntityState.NewModified || r.State == EntityState.New))
            {
#if DEBUG
                //if (Debugger.IsAttached)
                {
                    Debugger.Break();
                }
#endif
            }
            contextExt.Persist();
        }

        public IReadWritableGroupEntity CreateGroupEntity(IReadWritableGroupEntity entity)
        {
            var state = ((BatchGroupStateWrapper)entity)._state;
            var contextExt = GetEntityContext<BatchGroupState>(new []{ state });
            contextExt.Persist();
            return entity;
        }

        

        public IProcessConfiguration GetProcessConfiguration(int processId)
        {
            var ext = GetEntityContext<ProcessConfiguration>();
            ext.Read(c => c.PROCESSID == processId);
            return ext.Entity.Select(s => new ProcessConfigurationWrapper(s)).FirstOrDefault();
        }

        public void SaveProcess(IProcessState process)
        {
            ProcessStateWrapper processStateWrapper = (ProcessStateWrapper) process;
            var contextExt = GetEntityContext<BatchProcessState>( new List<BatchProcessState>(){processStateWrapper.State});
            using (var unitOfWork = contextExt.InitiateUnitOfWork())
            {
                if (process.Status == CompletionStatus.Finished && process.QueueSeq.HasValue)
                {
                    _queueService.MarkQueueSeqFinish(process.QueueName, process.QueueSeq.Value,
                        new TransactionWrapper(unitOfWork));

                    //var controller = GetDbController(unitOfWork);
                    //var rowsEffected = controller.ExecuteNonQuery(Constant.SQLMarkQueueFinished, process.QueueName, process.QueueSeq.Value);
                }
                contextExt.Persist();

                unitOfWork.Save();
            }
            
        }

        public void SaveTaskStates(long taskId, long processId, List<KeyValuePair<string, string>> states)
        {
            using (var dbController = GetDbController())
            {
                using (
                    var uow = dbController.UsingUnitOfWork())
                {
                    foreach (var pair in states)
                    {
                        var count = dbController.ExecuteNonQuery(Constant.SQLUpdateTaskState, taskId, pair.Key, pair.Value);
                        if (count == 0)
                        {
                            //insert
                            var contextExt = GetEntityContext<BatchTaskValues>().UsingUnitOfWork(uow);
                            var entity = contextExt.CreateNew();
                            entity.PROCESSID = processId;
                            entity.TASKID = taskId;
                            entity.STATEKEY = pair.Key;
                            entity.STATEVALUE = pair.Value;
                            contextExt.Persist();
                        }
                    }

                    uow.Save();
                }
            }
            


            //var contextExt = GetEntityContext<BatchTaskValues>();
            //contextExt.Read(r => r.PROCESSID == processId && r.TASKID == taskId);

            //return contextExt.Entity.Select(s => new KeyValuePair<string, string>(s.STATEKEY, s.STATEVALUE)).ToList();
        }

        public void SaveTaskState(long taskId, long processId, string key, string val)
        {
            SaveTaskStates(taskId, processId, new List<KeyValuePair<string, string>>(){new KeyValuePair<string, string>(key, val)});
        }

        public void UpdateTask(ITaskState task, ITransaction runningTransaction, bool commit)
        {
            try
            {
                var taskWrapper = (BatchTaskWrapper) task;
                var cxt = GetEntityContext<BatchTaskState>(new List<BatchTaskState> {taskWrapper.State});
                if (runningTransaction != null)
                {
                    if (runningTransaction.TransactionObject is IUnitOfWork uow)
                    {
                        cxt = cxt.UsingUnitOfWork(uow);
                    }
                    else
                    {
                        if (Debugger.IsAttached)
                        {
                            Debugger.Break(); //todo task update without transaction
                        }
                    }
                }

                if (runningTransaction==null || !runningTransaction.IsOpen())
                {
                    throw new FrameworkException(
                        $"Failed to commit Task transaction against taskId {task.Id}. Transaction closed");
                }

                cxt.Persist();

                if (commit)
                {
                    try
                    {
                        runningTransaction?.Commit();
                    }
                    catch (Exception e)
                    {
                        throw new FrameworkException($"Failed to commit Task transaction against taskId {task.Id}",
                            e); //stop
                        //Robustness.Instance.SafeCall(()=>runningTransaction?.Dispose());
                    }
                }
            }
            //catch (InvalidOperationException e) when(e.Message.Contains("This SQLTransaction has completed"))
            //{ }
            catch (FrameworkException)
            {
                throw;
            }
            catch (Exception e) when (
                (e.Message.Contains("This SqlTransaction has completed")) ||
                (e.Message.Contains("The connection is broken and recovery is not possible"))
            //|| (e is SqlException se && se.Errors.Count >0 && se.Errors[0].Number==232) //A transport-level error has occurred when sending the request to the server. (provider: Shared Memory Provider, error: 0 - The pipe is being closed.)
            )
            {
                throw new FrameworkException($"Task transaction closed against taskId {task.Id}", e); //stop
            }
            catch (Exception e)
            {

                throw; // new FrameworkException($"Error updating task taskId {task.Id}", e);//stop
            }
        }

        public bool IsTaskActive(ITaskState task, ITransaction runningTransaction)
        {
            try
            {
                //var taskWrapper = (BatchTaskWrapper)task;
                //var cxt = GetEntityContext<BatchTaskState>(new List<BatchTaskState> { taskWrapper.State });
                if (runningTransaction != null)
                {
                    if (runningTransaction.TransactionObject is IUnitOfWork uow)
                    {
                        var dbController = GetDbController(uow);
                        //var customItem = dbController.GetCustomList<string>(Constant.SQLPing);
                        var customItem = dbController.ExecuteSql(Constant.SQLPing, null);
                        return true;
                    }
                }

                return false;
            }
            catch (Exception e) when (
                (e.Message.Contains("This SqlTransaction has completed")) ||
                (e.Message.Contains("The connection is broken and recovery is not possible"))
            //|| (e is SqlException se && se.Errors.Count >0 && se.Errors[0].Number==232) //A transport-level error has occurred when sending the request to the server. (provider: Shared Memory Provider, error: 0 - The pipe is being closed.)
            )
            {
                //throw new FrameworkException($"Task transaction closed against taskId {task.Id}", e); //stop
                return false;
            }
            catch (Exception e)
            {
                //retry
                throw; // new FrameworkException($"Error updating task taskId {task.Id}", e);//stop
            }
        }

        public int MarkProcessForRetry(IReadWritableProcessState process)
        {
            process.RetryCount = process.RetryCount + 1;

            ProcessStateWrapper wrapper = (ProcessStateWrapper) process;
            var ext = GetEntityContext<BatchProcessState>(new List<BatchProcessState>(){wrapper.State});
            using (var uow = ext.InitiateUnitOfWork())
            {
                using (var controller=GetDbController(uow))
                {
                    var effectedRows = controller.ExecuteNonQuery(Constant.SQLRetryFailedTasks, process.Id);
                    
                    ext.Persist();
                    uow.Save();

                    return effectedRows;
                }
            }
        }

        public void MarkGroupStopped(IGroupEntity @group)
        {
            var contextExt = GetEntityContext<BatchGroupState>();
            //contextExt.Read(g => g.ID == group.Id);

            using (var uow = contextExt.InitiateUnitOfWork())
            {
                contextExt.Read(g => g.ID == group.Id);

                var dbController = GetDbController(uow);
                var updateTime = DateTime.UtcNow;


                var groupState = contextExt.Entity.First();
                groupState.ISSTOPPED = true;
                groupState.CURRENTSTATE = CompletionStatus.Stopped.Name;
                
                contextExt.Persist();

                var ext = GetEntityContext<BatchProcessState>().UsingUnitOfWork(uow);
                ext.Read(r => r.GROUPID == group.Id && r.ISFINISHED == false);

                foreach (var processState in ext.Entity)
                {
                    processState.ISSTOPPED = true;
                    if (processState.CURRENTSTATE == CompletionStatus.Generating.Name)
                        processState.STARTTIME = null;

                    processState.CURRENTSTATE = CompletionStatus.Stopped.Name;
                    processState.UPDATEDON = processState.COMPLETETIME = updateTime;

                    dbController.ExecuteNonQuery(Constant.SQLStopProcessTaskState, processState.ID, updateTime,
                        CompletionStatus.Stopped.Name, NodeSettings.Instance.Name, CompletionStatus.Pending.Name);
                }
                ext.Persist();

                uow.Save();
            }
        }

        public bool IsHealthy()
        {
            try
            {
                using (var controller = GetDbController())
                {
                    var res = controller.ExecuteSql(Constant.SQLPing, null);
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public IEnumerable<IReadWritableProcessState> GetIncompleteProcesses()
        {
            //ProcessStateWrapper wrapper = (ProcessStateWrapper)process;
            var ext = GetEntityContext<BatchProcessState>();
            ext.Read(p => p.ISFINISHED == false && p.ISSTOPPED == false);
            return ext.Entity.Select(e => new ProcessStateWrapper(e));
        }

        public void ResumeGroup(long groupId)
        {
            using (var dbController = GetDbController())
            {
                using (var uow = dbController.UsingUnitOfWork())
                {
                    var groupUpdated = dbController.ExecuteNonQuery(Constant.SQLResumeGroup, groupId);
                    if (groupUpdated > 0)
                    {
                        var resumedProcesses = dbController.ExecuteNonQuery(Constant.SQLResumeGroupProcesses, groupId);

                        var stopperProcessIds = dbController.GetCustomList<long>(Constant.SQLResumeUpdateGetGroupStopper, groupId);

                        
                        var tasksResumed = dbController.ExecuteNonQuery(Constant.SQLResumeGroupTask, groupId);

                        if (stopperProcessIds.Count>0) //.HasValue && stopperProcessId.Value > 0)
                        {
                            foreach (var stopperProcessId in stopperProcessIds)
                            {
                                var tasksReset = dbController.ExecuteNonQuery(Constant.SQLResumeResetStopperErroredTasks, stopperProcessId); //stopperProcessId.Value
                            }
                        }

                        uow.Save();
                    }
                }
            }
        }
    }
}
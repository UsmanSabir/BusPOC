﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Exceptions;
using BusLib.BatchEngineCore.Groups;
using BusLib.Core;
using BusLib.Helper;
using NS.BaseModels;
using NS.ORM;
using NS.ORM.UoW;
using NS.Utilities;
using ProcessConfiguration = BatchEngine.Models.Entities.ProcessConfiguration;

namespace BusImpl
{
    public class StatePersistenceService: IStatePersistenceService
    {
        public IEnumerable<IReadWritableGroupEntity> GetAllIncomplete()
        {
            var contextExt = EntityContextExt.Create<BatchGroupState>();
            contextExt.Read(r => r.ISFINISHED == false && r.ISSTOPPED== false);
            
            return contextExt.Entity.Select(s=>new BatchGroupStateWrapper(s));
            
        }

        //public IEnumerable<IReadWritableGroupEntity> GetAllIncomplete()
        //{
        //    var contextExt = EntityContextExt.Create<BatchGroupState>();
        //    contextExt.Read(r => r.ISFINISHED == false && r.ISSTOPPED == false && r.ISGENERATED == false);

        //    return contextExt.Entity.Select(s => new BatchGroupStateWrapper(s));

        //}


        public IReadWritableGroupEntity GetGroupEntity(long groupId)
        {
            var contextExt = EntityContextExt.Create<BatchGroupState>();
            contextExt.Read(r => r.ID== groupId);

            return contextExt.Entity.Select(s => new BatchGroupStateWrapper(s)).FirstOrDefault();
        }

        public List<KeyValuePair<string, string>> GetTaskStates(long taskId, long processId)
        {
            var contextExt = EntityContextExt.Create<BatchTaskValues>();
            contextExt.Read(r => r.PROCESSID==processId && r.TASKID==taskId);

            return contextExt.Entity.Select(s => new KeyValuePair<string,string>(s.STATEKEY, s.STATEVALUE)).ToList();
        }

        public IEnumerable<int> GetConfiguredGroupProcessKeys(long groupEntityId)
        {
            var ext = EntityContextExt.Create<BatchProcessGroupDetail>();
            //todo read from group-process mapping
            ext.Read(r => r.GROUPKEY == groupEntityId);

            return ext.Entity.Select(r => r.PROCESSID);
        }

        public IEnumerable<IReadWritableProcessState> GetSubmittedGroupProcesses(long groupEntityId)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.GROUPID == groupEntityId);

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s));
        }

        

        public IEnumerable<ITaskState> GetIncompleteTasksForProcess(long processId)
        {
            var contextExt = EntityContextExt.Create<BatchTaskState>();
            contextExt.Read(r => r.PROCESSID == processId && (r.ISFINISHED==false && r.ISSTOPPED==false));
            
            return contextExt.Entity.Select(s => new BatchTaskWrapper(s));
        }

        public long GetIncompleteTasksCountForProcess(long processId)
        {
            using (var controller = DbController.Create())
            {
                var count = controller.Count<BatchTaskState>($"{nameof(BatchTaskState.PROCESSID)} = @pid AND {nameof(BatchTaskState.ISFINISHED)}=0 AND {nameof(BatchTaskState.ISSTOPPED)}=0", 
                    new Dictionary<string, object> {{"pid", processId}}); //todo optimize orm usage with builder
                return count;
            }

            //var contextExt = EntityContextExt.Create<BatchTaskState>();
            //contextExt.FillChilds()
            //contextExt.Read(r => r.PROCESSID == processId && (r.ISFINISHED == false && r.ISSTOPPED == false));

            //return contextExt.Entity.Select(s => new BatchTaskWrapper(s));
        }

        public long CountFailedTasksForProcess<T>(long processId)
        {
            using (var dbController = DbController.Create())
            {
                var count = dbController.Count(Constant.SQLCountFailedTasks, new SerializableDictionary<string,object>(){{ "pid", processId } });
                return count;
            }
        }

        public long CountPendingTasksForProcess(long processId)
        {
            using (var dbController = DbController.Create())
            {
                var count = dbController.Count(Constant.SQLCountPendingTasks, new SerializableDictionary<string, object>() { { "pid", processId } });
                return count;
            }
        }

        public IReadWritableProcessState GetAndStartProcessById(long processId)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.ID == processId);
            var state = contextExt.Entity.FirstOrDefault();
            if (state != null && state.STARTTIME==null)
            {
                state.STARTTIME = DateTime.UtcNow;
                contextExt.Persist();
            }
            
            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public IReadWritableProcessState GetProcessById(long processId)
        {
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.ID == processId);
            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public IReadWritableProcessState GetProcessByKey(int processKey)
        {
            //todo read from group-process mapping
            var contextExt = EntityContextExt.Create<BatchProcessState>();
            contextExt.Read(r => r.ID == processKey); //todo read from process config

            return contextExt.Entity.Select(s => new ProcessStateWrapper(s)).FirstOrDefault();
        }

        public void AddGroupProcess(List<IReadWritableProcessState> groupProcesses, IGroupEntity groupEntity)
        {
            var hierarchy = BuildHierarchy(groupProcesses.Select(s=>s.ProcessId).ToList());
            var groupSeqs = groupProcesses.Select(s => s.GroupSeqId).Distinct().ToList();
            var wrappers = groupProcesses.Cast<ProcessStateWrapper>().Select(s => s.State).ToList();
            var contextExt = EntityContextExt.Create<BatchProcessState>(wrappers);
            using (var work = contextExt.InitiateUnitOfWork())
            {
                //contextExt.IdInjector

                BatchGroupStateWrapper groupWrp = (BatchGroupStateWrapper)groupEntity;
                var ext = EntityContextExt.Create(new []{ groupWrp._state});
                groupWrp.IsGenerated = true;

                ext.Persist();
                contextExt.Persist();

                #region Hierarchy

                try
                {

                    foreach (var wrapper in wrappers)
                    {
                        wrapper.State = EntityState.NotModified;
                    }

                    foreach (var prcsDependency in hierarchy)//.Where(p=>p.PRNTPRCSID.HasValue && p.PRNTPRCSID.Value!=0))
                    {
                        if(prcsDependency.PRNTPRCSID==null)
                            continue;

                        var processId = prcsDependency.PROCESSID;
                        var parentProcessId = prcsDependency.PRNTPRCSID.Value;

                        foreach (var groupSeq in groupSeqs)
                        {
                            //a process id must exist in each groupSeqId. GroupSeqId is a collection of group processes per "Criteria"
                            var childProcess = wrappers.FirstOrDefault(c => c.PROCESSID == processId && c.GROUPSEQID == groupSeq);
                            var parentProcess = wrappers.FirstOrDefault(p => p.PROCESSID == parentProcessId && p.GROUPSEQID == groupSeq);

                            if (childProcess == null)
                            {
                                throw new FrameworkException($"Child Process id '{processId}' not found in group");
                            }
                            if (parentProcess == null)
                            {
                                throw new FrameworkException($"Parent Process id '{parentProcessId}' not found in group");
                            }

                            childProcess.PARENTID = parentProcess.ID;
                            childProcess.State = EntityState.DataModified;
                        }
                    }

                    contextExt.Persist();//persist hierarchy

                    work.Save();

                }
                catch (Exception)
                {
                    //restore state for retry
                    foreach (var wrapper in wrappers)
                    {
                        wrapper.State = EntityState.NewModified;
                    }

                    throw;
                }

                #endregion

            }
            
        }

        List<ProcessHierarchy> BuildHierarchy(List<int> processIds) //(int key, int parent) 
        {
            var ext = EntityContextExt.Create<ProcessHierarchy>();
            //ext.Read(r => processKeys.Contains(r.PROCESSKEY));
            ext.Read();

            return CheckHierarchy(ext.Entity, processIds);

            //return ext.Entity; //.Select(s=>new {s.PROCESSKEY, s.PRNTPRCSID})
        }

        private List<ProcessHierarchy> CheckHierarchy(List<ProcessHierarchy> extEntity, List<int> processIds)
        {
            //var rootNodes = extEntity.Where(s=>s.PRNTPRCSID==null).ToList();
            //var nestedNodes = extEntity.Where(r => r.PRNTPRCSID.HasValue && r.PRNTPRCSID.Value > 0).ToList();
            List<ProcessHierarchy> result = extEntity.Where(r => processIds.Exists(s => s == r.PROCESSID))
                .Select(s => new ProcessHierarchy
                {
                    ID = s.ID,
                    PRNTPRCSID = s.PRNTPRCSID,
                    PROCESSID = s.PROCESSID,
                }).ToList();


            foreach (var key in result)
            {
                if(key.PRNTPRCSID==null)
                    continue;

                var parentNodeId = key.PRNTPRCSID.Value;
                if (parentNodeId == key.PROCESSID)
                {
                    throw new FrameworkException($"A process cannot be parent of itself. Process Id '{key.PROCESSID}' has same parent '{parentNodeId}' configured");
                }
                //var node = extEntity.First(r => r.PROCESSKEY == key);
                if (result.Exists(r => r.PROCESSID == parentNodeId))
                {
                    //success
                }
                else
                {
                    int? parentId = FindParent(parentNodeId, extEntity, result);
                    key.PRNTPRCSID = parentId;
                }
            }

            return result;
        }

        private int? FindParent(int parentId, List<ProcessHierarchy> extEntity, List<ProcessHierarchy> result)
        {
            var parentNode = result.FirstOrDefault(r=>r.PROCESSID == parentId);
            if (parentNode != null)
            {
                return parentNode.PROCESSID;
            }
            else
            {
                var processConfig = extEntity.First(r=>r.PROCESSID==parentId);
                if (processConfig.PRNTPRCSID.HasValue && processConfig.PRNTPRCSID.Value>0)
                    return FindParent(processConfig.PRNTPRCSID.Value, extEntity, result);
                else
                {
                    return null;// become root
                }
            }
        }

        public void SaveGroup(IReadWritableGroupEntity @group)
        {
            BatchGroupStateWrapper groupStateWrapper= (BatchGroupStateWrapper)group;
            var contextExt = EntityContextExt.Create<BatchGroupState>(new List<BatchGroupState>() { groupStateWrapper._state });
            if (contextExt.Entity.Any(r => r.State == EntityState.NewModified || r.State == EntityState.New))
            {
#if DEBUG
                //if (Debugger.IsAttached)
                {
                    Debugger.Break();
                }
#endif
            }
            contextExt.Persist();
        }

        public IReadWritableGroupEntity CreateGroupEntity(IReadWritableGroupEntity entity)
        {
            var state = ((BatchGroupStateWrapper)entity)._state;
            var contextExt = EntityContextExt.Create<BatchGroupState>(new []{ state });
            contextExt.Persist();
            return entity;
        }

        

        public IProcessConfiguration GetProcessConfiguration(int key)
        {
            var ext = EntityContextExt.Create<ProcessConfiguration>();
            ext.Read(c => c.PROCESSID == key);
            return ext.Entity.Select(s => new ProcessConfigurationWrapper(s)).FirstOrDefault();
        }

        public void SaveProcess(IProcessState process)
        {
            ProcessStateWrapper processStateWrapper = (ProcessStateWrapper) process;
            var contextExt = EntityContextExt.Create<BatchProcessState>( new List<BatchProcessState>(){processStateWrapper.State});
            contextExt.Persist();
        }

        public void SaveTaskStates(long taskId, long processId, List<KeyValuePair<string, string>> states)
        {
            using (var dbController = DbController.Create())
            {
                using (
                    var uow = dbController.UsingUnitOfWork())
                {
                    foreach (var pair in states)
                    {
                        var count = dbController.ExecuteNonQuery(Constant.SQLUpdateTaskState, taskId, pair.Key, pair.Value);
                        if (count == 0)
                        {
                            //insert
                            var contextExt = EntityContextExt.Create<BatchTaskValues>().UsingUnitOfWork(uow);
                            var entity = contextExt.CreateNew();
                            entity.PROCESSID = processId;
                            entity.TASKID = taskId;
                            entity.STATEKEY = pair.Key;
                            entity.STATEVALUE = pair.Value;
                            contextExt.Persist();
                        }
                    }

                    uow.Save();
                }
            }
            


            //var contextExt = EntityContextExt.Create<BatchTaskValues>();
            //contextExt.Read(r => r.PROCESSID == processId && r.TASKID == taskId);

            //return contextExt.Entity.Select(s => new KeyValuePair<string, string>(s.STATEKEY, s.STATEVALUE)).ToList();
        }

        public void SaveTaskState(long taskId, long processId, string key, string val)
        {
            SaveTaskStates(taskId, processId, new List<KeyValuePair<string, string>>(){new KeyValuePair<string, string>(key, val)});
        }

        public void UpdateTask(ITaskState task, ITransaction runningTransaction, bool commit)
        {
            try
            {
                var taskWrapper = (BatchTaskWrapper) task;
                var cxt = EntityContextExt.Create<BatchTaskState>(new List<BatchTaskState> {taskWrapper.State});
                if (runningTransaction != null)
                {
                    if (runningTransaction.TransactionObject is IUnitOfWork uow)
                    {
                        cxt = cxt.UsingUnitOfWork(uow);
                    }
                    else
                    {
                        if (Debugger.IsAttached)
                        {
                            Debugger.Break(); //todo task update without transaction
                        }
                    }
                }

                if (runningTransaction==null || !runningTransaction.IsOpen())
                {
                    throw new FrameworkException(
                        $"Failed to commit Task transaction against taskId {task.Id}. Transaction closed");
                }

                cxt.Persist();

                if (commit)
                {
                    try
                    {
                        runningTransaction?.Commit();
                    }
                    catch (Exception e)
                    {
                        throw new FrameworkException($"Failed to commit Task transaction against taskId {task.Id}",
                            e); //stop
                        //Robustness.Instance.SafeCall(()=>runningTransaction?.Dispose());
                    }
                }
            }
            //catch (InvalidOperationException e) when(e.Message.Contains("This SQLTransaction has completed"))
            //{ }
            catch (FrameworkException)
            {
                throw;
            }
            catch (Exception e) when (
                (e.Message.Contains("This SqlTransaction has completed")) ||
                (e.Message.Contains("The connection is broken and recovery is not possible"))
            //|| (e is SqlException se && se.Errors.Count >0 && se.Errors[0].Number==232) //A transport-level error has occurred when sending the request to the server. (provider: Shared Memory Provider, error: 0 - The pipe is being closed.)
            )
            {
                throw new FrameworkException($"Task transaction closed against taskId {task.Id}", e); //stop
            }
            catch (Exception e)
            {

                throw; // new FrameworkException($"Error updating task taskId {task.Id}", e);//stop
            }
        }

        public int MarkProcessForRetry(IReadWritableProcessState process)
        {
            process.RetryCount = process.RetryCount + 1;

            ProcessStateWrapper wrapper = (ProcessStateWrapper) process;
            var ext = EntityContextExt.Create<BatchProcessState>(new List<BatchProcessState>(){wrapper.State});
            using (var uow = ext.InitiateUnitOfWork())
            {
                using (var controller=DbController.Create(uow))
                {
                    var effectedRows = controller.ExecuteNonQuery(Constant.SQLRetryFailedTasks, process.Id);
                    
                    ext.Persist();
                    uow.Save();

                    return effectedRows;
                }
            }
        }

        public void MarkGroupStopped(IGroupEntity @group)
        {
            var contextExt = EntityContextExt.Create<BatchGroupState>();
            contextExt.Read(g => g.ID == group.Id);

            using (var uow = contextExt.InitiateUnitOfWork())
            {
                var dbController = DbController.Create();
                var updateTime = DateTime.UtcNow;


                var groupState = contextExt.Entity.First();
                groupState.ISSTOPPED = true;
                groupState.CURRENTSTATE = CompletionStatus.Stopped.Name;
                
                contextExt.Persist();

                var ext = EntityContextExt.Create<BatchProcessState>().UsingUnitOfWork(uow);
                ext.Read(r => r.GROUPID == group.Id && r.ISFINISHED == false);

                foreach (var processState in ext.Entity)
                {
                    processState.ISSTOPPED = true;
                    processState.CURRENTSTATE = CompletionStatus.Stopped.Name;
                    processState.UPDATEDON = processState.COMPLETETIME = updateTime;

                    dbController.ExecuteNonQuery(Constant.SQLStopProcessTaskState, processState.ID, updateTime,
                        CompletionStatus.Stopped.Name, NodeSettings.Instance.Name, CompletionStatus.Pending.Name);
                }
                ext.Persist();

                uow.Save();
            }
        }

        public bool IsHealthy()
        {
            try
            {
                using (var controller = DbController.Create())
                {
                    var res = controller.ExecuteSql(Constant.SQLPing, null);
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public IEnumerable<IReadWritableProcessState> GetIncompleteProcesses()
        {
            //ProcessStateWrapper wrapper = (ProcessStateWrapper)process;
            var ext = EntityContextExt.Create<BatchProcessState>();
            ext.Read(p => p.ISFINISHED == false && p.ISSTOPPED == false);
            return ext.Entity.Select(e => new ProcessStateWrapper(e));
        }
    }
}
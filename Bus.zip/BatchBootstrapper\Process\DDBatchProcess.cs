﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BusLib.BatchEngineCore;

namespace BatchBootstrapper.Process
{
    public class DDBatchProcess:StatefulProcess<int>
    {
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            return Enumerable.Empty<int>();
        }

        public override int ProcessKey { get; } = 5301;

        public override void InitializeStates()
        {
            DefineState("Receipt", DoReceipt);
            DefineState("Settlment", DoSettlment);
            DefineState("Step3", DoSomething);
        }
        
        private void DoReceipt(int id, ITaskContext context)
        {
            //todo: call to logic class method 1
        }

        private void DoSettlment(int id, ITaskContext context)
        {
            //todo: call to logic class method 2
        }

        private void DoSomething(int id, ITaskContext context)
        {
            //todo: call to logic class method 3
        }


    }
}
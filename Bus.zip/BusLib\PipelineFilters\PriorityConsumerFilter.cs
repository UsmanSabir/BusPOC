﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using BusLib.Core;

namespace BusLib.PipelineFilters
{
    public class PriorityConsumerFilter<T>: FeatureCommandHandlerBase<T> where T : IMessage
    {
        readonly BlockingCollection<T> _priorityCollection=new BlockingCollection<T>(new ConcurrentQueue<T>());
        readonly BlockingCollection<T> _collection = new BlockingCollection<T>(new ConcurrentQueue<T>());
        private readonly CancellationToken _token;
        private readonly ILogger _logger;
        private readonly string _name;
        private readonly Task _task;
        private readonly CancellationTokenSource _linkedTokenSource;
        private readonly Func<T, bool> _priorityClassifier;

        public PriorityConsumerFilter(CancellationToken token, ILogger logger, string name, Func<T, bool> priorityClassifier)
        {
            _priorityClassifier = priorityClassifier ?? throw new ArgumentNullException(nameof(priorityClassifier));
            _token = token;
            _logger = logger;
            _name = name??string.Empty;

            _linkedTokenSource = CancellationTokenSource.CreateLinkedTokenSource(token);

            _task = Task.Run(()=>Consume(), _linkedTokenSource.Token);
        }

        void Consume()
        {
            try
            {
                while (!_token.IsCancellationRequested)
                {
                    int collIndex = BlockingCollection<T>.TakeFromAny(new[] {_priorityCollection, _collection}, out T t, _token);
                    //collIndex ==0 priority index
                    //var t = _collection.Take(_token);
                    Handler?.Handle(t);
                }
            }
            catch (OperationCanceledException e)
            {
                _logger.Warn($"Consumer {_name} cancelled while taking");
            }
        }

        public override void FeatureDecoratorHandler(T message)
        {
            try
            {
                bool isPriorityPacket = _priorityClassifier(message);
                if (isPriorityPacket)
                {
                    _priorityCollection.Add(message, _token);
                }
                else
                {
                    _collection.Add(message, _token);
                }
            }
            catch (OperationCanceledException)
            {
                _logger.Warn($"Consumer {_name} add cancelled");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if(_linkedTokenSource.IsCancellationRequested)
                _linkedTokenSource.Cancel();

            try
            {
                _task?.Wait();
            }
            catch (Exception e)
            {
                _logger.Trace($"Consumer {_name} got exception while stopping.{e.Message}");
            }

            base.Dispose(disposing);
        }
    }
}
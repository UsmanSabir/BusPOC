﻿using BusLib.BatchEngineCore.Volume;
using BusLib.Core;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using BusLib.BatchEngineCore.Exceptions;
using BusLib.BatchEngineCore.Saga;
using BusLib.Helper;

namespace BusLib.BatchEngineCore
{
    public interface IBaseProcess
    {
        int ProcessKey { get; }

        Type VolumeDataType { get; }

        void HandleVolume(IVolumeHandler handler, IProcessExecutionContext processContext);
    }

    public interface IBaseProcess<out T> : IBaseProcess
    {
        IEnumerable<T> GetVolume(IProcessExecutionContext processContext);

        //void LinkProcess<T1, T2>(IBaseProcess<T1, T2> process) where T2 : ITask;
    }

    internal interface IBaseProcessWithExecutor<out T, out TU> : IBaseProcess<T> where TU : ITask
    {
     
    }

    public interface IHasSupportingData
    {
        void InitializeSupportingData(IProcessExecutionContext context);
    }

    public abstract class BaseProcess <T>: IBaseProcess<T>  //where TU : ITask
    {
        public abstract IEnumerable<T> GetVolume(IProcessExecutionContext processContext);
        public abstract int ProcessKey { get; }

        public Type VolumeDataType { get; } = typeof(T);
        //public Type TaskActorType { get; } = typeof(TU);

        protected bool CanRegenerateVolume { get; set; } = false;

        public virtual void ProcessStarting(IProcessExecutionContext processContext)
        {

        }

        public virtual void ProcessCompleted(IProcessExecutionContext processContext)
        {

        }

        public virtual void ProcessFailed(IProcessExecutionContext processContext)
        {

        }

        public virtual void ProcessFinalizer(IProcessExecutionContext processContext)
        {

        }

        void IBaseProcess.HandleVolume(IVolumeHandler handler, IProcessExecutionContext processContext)
        {
            var volumeGenerated = processContext.ProcessState.IsVolumeGenerated;
            if (!volumeGenerated || CanRegenerateVolume)
            {
                handler.Handle(GetVolume(processContext), processContext); //volume visitor
            }            

        }

        public ISerializer Serializer { get; protected set; }
    }

    public abstract class BaseTaskProcess<T> : BaseProcess<T>
    {
        //public abstract void Execute(T item, ITaskContext context);
        
        public abstract override int ProcessKey { get; }

        
        
    }

    public abstract class StatelessProcess<T> : BaseTaskProcess<T> //, ITask<T>
    {

    }

    public abstract class StatefulProcess<T> : BaseTaskProcess<T>, ITaskSaga<T>
    {
        private readonly ConcurrentDictionary<string, Action<T, ITaskContext>> _sagaStateDictionary =
            new ConcurrentDictionary<string, Action<T, ITaskContext>>();

        
        public abstract void InitializeStates();

        protected void DefineState(string name, Action<T, ITaskContext> action)
        {
            _sagaStateDictionary.AddOrUpdate(name, action, (s, a) => action);
        }


        protected internal virtual string GetNextState(ITaskContext context)
        {
            if (!string.IsNullOrWhiteSpace(context.NextState) && context.State.CurrentState != context.NextState)
                return context.NextState;

            var nextState = _sagaStateDictionary.Keys.SkipWhile(s => s != context.State.CurrentState).ElementAtOrDefault(1);
            return nextState;
        }

        public virtual void Started(T item, ITaskContext context)
        {

        }

        public virtual void Completed(T item, ITaskContext context)
        {

        }

        //public void Execute(T item, ITaskContext context)
        //{
        //    Started(item, context);
        //}

        void ITask.Handle(ITaskContext taskContext, ISerializer serializer)
        {
            var item = serializer.DeserializeFromString<T>(taskContext.State.Payload);
            var state = taskContext.State.CurrentState;

            Action<T, ITaskContext> action = null;

            _sagaStateDictionary.TryGetValue(state, out action);

            if (action == null) //string.IsNullOrWhiteSpace(state) && 
            {
                action = this.Started; // (item, taskContext);
            }

            do
            {
                taskContext.Logger.Trace($"Excution started with state '{state}'");

                action(item, taskContext);

                taskContext.Logger.Trace($"Excution finished with state '{state}'");

                state = GetNextState(taskContext);

                if (string.IsNullOrWhiteSpace(state) || state == taskContext.State.CurrentState)
                {
                    taskContext.MarkTaskStatus(TaskCompletionStatus.Finished, ResultStatus.Success, Constants.ReasonCompleted);
                    return;
                }

                if (!_sagaStateDictionary.TryGetValue(state, out var nextAction) || nextAction == null)
                {
                    string errMsg = $"Saga state '{state}' not found";
                    taskContext.Logger.Error(errMsg);
                    throw new SagaStateException(errMsg);
                }

                if (ReferenceEquals(action, nextAction)) //string.IsNullOrWhiteSpace(state) && 
                {
                    string errMsg = $"Saga state '{state}' re-entering to previous state";
                    taskContext.Logger.Error(errMsg);
                    throw new SagaStateException(errMsg);
                }
                action = nextAction;

            } while (taskContext.IsFinished());



        }

        void ITask<T, ITaskContext>.Execute(T item, ITaskContext context)
        {
            Started(item, context);
        }

        
    }


}
﻿using System;

namespace BusLib.BatchEngineCore.PubSub
{
    public interface IDistributedMessagePublisher:IDisposable
    {
        void PublishMessage(string message);
    }

    public interface IDistributedMessageSubscriber:IDisposable
    {
        void Subscribe(string message, Action<string> action);

        //void Shutdown();
    }

}
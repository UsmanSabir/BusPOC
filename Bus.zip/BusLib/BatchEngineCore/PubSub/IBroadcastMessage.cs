﻿using BusLib.BatchEngineCore.Groups;

namespace BusLib.BatchEngineCore.PubSub
{
    public interface IBroadcastMessage:IMessage
    {
        
    }

    internal interface IProcessGroupRemovedMessage : IBroadcastMessage
    {
        SubmittedGroup Group { get; }
    }

    public interface IWatchDogMessage : IBroadcastMessage
    {

    }

    public interface IProcessInputIdleWatchDogMessage : IWatchDogMessage
    {
        long GroupId { get; }
        long ProcessId { get; }

        int ProcessKey { get; }
    }

    class ProcessGroupRemovedMessage: IProcessGroupRemovedMessage
    {
        public ProcessGroupRemovedMessage(SubmittedGroup @group)
        {
            Group = @group;
        }

        public SubmittedGroup Group { get; }
    }

    internal class ProcessInputIdleWatchDogMessage : IProcessInputIdleWatchDogMessage
    {
        public ProcessInputIdleWatchDogMessage(long groupId, long processId, int processKey)
        {
            GroupId = groupId;
            ProcessId = processId;
            ProcessKey = processKey;
        }

        public long GroupId { get; }
        public long ProcessId { get; }
        public int ProcessKey { get; }
    }

}
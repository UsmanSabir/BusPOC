﻿using BusLib.BatchEngineCore.Groups;
using BusLib.Core.Events;

namespace BusLib.BatchEngineCore.PubSub
{
    public interface IBroadcastMessage:IMessage, ITinyMessage
    {
        
    }

    internal interface IProcessGroupRemovedMessage : IBroadcastMessage
    {
        SubmittedGroup Group { get; }
    }

    public interface IWatchDogMessage : IBroadcastMessage
    {

    }

    public interface IProcessInputIdleWatchDogMessage : IWatchDogMessage
    {
        long GroupId { get; }
        long ProcessId { get; }

        int ProcessKey { get; }
    }

    class ProcessGroupRemovedMessage: IProcessGroupRemovedMessage
    {
        public ProcessGroupRemovedMessage(SubmittedGroup @group, object sender)
        {
            Group = @group;
            Sender = sender;
        }

        public SubmittedGroup Group { get; }
        public object Sender { get; }
    }

    internal class ProcessInputIdleWatchDogMessage : IProcessInputIdleWatchDogMessage
    {
        public ProcessInputIdleWatchDogMessage(long groupId, long processId, int processKey, object sender)
        {
            GroupId = groupId;
            ProcessId = processId;
            ProcessKey = processKey;
            Sender = sender;
        }

        public long GroupId { get; }
        public long ProcessId { get; }
        public int ProcessKey { get; }
        public object Sender { get; }
    }

}
﻿using System;
using System.Threading;
using BusLib.BatchEngineCore.Groups;
using BusLib.Core;
using BusLib.Helper;
using BusLib.Serializers;

namespace BusLib.BatchEngineCore.PubSub
{
    internal class DashboardService:RepeatingProcess
    {
        private readonly IPubSubFactory _pubSubFactory;
        //private readonly CancellationToken _cancellationToken;
        private IDistributedMessageSubscriber _subscriber;
        private IDistributedMessagePublisher _publisher;
        //private ISerializer _serializer;

        private const string dashboardChannel = "Dashboard";
        private const string statusRequest = "status";


        public DashboardService(IPubSubFactory pubSubFactory, ILogger logger):base(nameof(DashboardService), logger)
        {
            _pubSubFactory = pubSubFactory;
        }

        internal override void OnStart()
        {
            base.OnStart();

            _publisher = _pubSubFactory.GetPublisher(Interrupter.Token, Logger, dashboardChannel);

            _subscriber = _pubSubFactory.GetSubscriber(Interrupter.Token, Logger, dashboardChannel);
            

            _subscriber.Subscribe(statusRequest, OnStatusRequest);
        }

        private void OnStatusRequest(string req)
        {
            //todo compile status
            //todo memory/ram/db/disk heal check

            HealthMessage healthMessage=new HealthMessage()
            {
                Id = Guid.NewGuid(),
                Time = DateTime.UtcNow,
                NodeKey = NodeSettings.Instance.Name,
                Sender = NodeSettings.Instance.Name,
                NodeThrottling = NodeSettings.Instance.Throttling
            };

            Bus.Instance.EventAggregator.Broadcast(healthMessage);

            PublishMessage(healthMessage);
        }

        void PublishMessage<T>(T message) where T: IBroadcastMessage
        {
            Robustness.Instance.SafeCall(() => { _publisher.PublishMessage(message); }, Logger, "Failed to publish dashboard message with error {0}");
        }

        internal override void PerformIteration()
        {
            PublishMessage(new PingHealthMessage
            {
                IsWorking = true,
                NodeKey = NodeSettings.Instance.Name,
                Sender = NodeSettings.Instance.Name
            });
        }
    }
}
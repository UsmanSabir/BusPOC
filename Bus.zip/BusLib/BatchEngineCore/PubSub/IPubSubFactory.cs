﻿using System.Threading;

namespace BusLib.BatchEngineCore.PubSub
{
    public interface IPubSubFactory
    {
        IDistributedMessagePublisher GetPublisher(CancellationToken token);

        IDistributedMessageSubscriber GetSubscriber(CancellationToken token);
    }
}
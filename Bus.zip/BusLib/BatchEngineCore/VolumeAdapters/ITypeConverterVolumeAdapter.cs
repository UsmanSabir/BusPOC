﻿namespace BusLib.BatchEngineCore.VolumeAdapters
{
    public interface ITypeConverterVolumeAdapter<out T, in TU>:IVolumeAdapter<T,TU>
    {
        
    }
}
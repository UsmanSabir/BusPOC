﻿namespace BusLib.BatchEngineCore.VolumeAdapters
{
    public interface IBatchVolumeAdapter<T>:IVolumeAdapter<T,T[]>
    {
        
    }
}
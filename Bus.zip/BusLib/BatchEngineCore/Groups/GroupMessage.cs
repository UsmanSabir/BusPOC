﻿using System.Collections.Generic;

namespace BusLib.BatchEngineCore.Groups
{
    internal class GroupMessage:IMessage
    {
        public GroupMessage(GroupActions action, IReadWritableGroupEntity entity, List<ProcessExecutionCriteria> criteria, string message=null)
        {
            Action = action;
            Group = entity;
            Criteria = criteria;
            Message = message;
        }

        public GroupMessage(GroupActions action, IReadWritableGroupEntity entity, List<ProcessExecutionCriteria> criteria, List<int> processKeys)
        {
            Action = action;
            Group = entity;
            Criteria = criteria;
            ProcessKeys = processKeys;
            IsProcessSubmission = true;
        }

        public List<int> ProcessKeys
        {
            get;
            private set;
        }

        public bool IsProcessSubmission { get; internal set; } = false;


        public GroupActions Action { get; }

        public IReadWritableGroupEntity Group { get; }

        public string Message { get;  }

        public List<ProcessExecutionCriteria> Criteria { get; }

    }

    

}

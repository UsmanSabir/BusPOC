﻿namespace BusLib.BatchEngineCore.Volume.Adapters
{
    public interface ITypeConverterVolumeAdapter<out T, in TU>:IVolumeAdapter<T,TU>
    {
        
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace BusLib.BatchEngineCore.Process
{
    public interface IProcessRepository
    {
        IReadOnlyCollection<IBaseProcess> GetRegisteredProcesses();
    }


    internal class ProcessRepository : IProcessRepository
    {
        List<IBaseProcess> _registeredProcesses = new List<IBaseProcess>();


        public ProcessRepository()
        {
            //todo scan through ioc
            //todo verify process configurations on registration

            Scan();
        }

        void Scan()
        {
            var loadedAssemblies = AppDomain.CurrentDomain.GetAssemblies().ToList();
            var loadedPaths = loadedAssemblies.Select(a =>
            {
                try
                {
                    return a.Location;
                }
                catch (Exception)
                {
                    return null;
                }
            }).Where(a => !string.IsNullOrEmpty(a)).ToArray();

            var referencedPaths =
                Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory, "*.dll"); //*.Definitions.dll
            var toLoad =
                referencedPaths.Where(r => !loadedPaths.Contains(r, StringComparer.InvariantCultureIgnoreCase))
                    .ToList();
            toLoad.ForEach(
                path =>
                {
                    try
                    {
                        loadedAssemblies.Add(AppDomain.CurrentDomain.Load(AssemblyName.GetAssemblyName(path)));
                    }
                    catch (Exception)
                    {
                        // ignored
                    }
                });


            var asmbs = AppDomain.CurrentDomain.GetAssemblies();
            var baseType = typeof(IBaseProcess);

            var processes = asmbs.SelectMany(s =>
            {
                try
                {
                    return s.GetTypes();
                }
                catch (ReflectionTypeLoadException ex)
                {
                    return ex.Types.Where(x => x != null);
                }
                catch (Exception)
                {
                    // ignored
                }

                return new Type[] { };

            }).Where(a =>
                a != null && a.IsPublic && a.IsAbstract == false && a.IsClass && baseType.IsAssignableFrom(a));

            foreach (var process in processes)
            {
                var p = (IBaseProcess) Activator.CreateInstance(process);
                _registeredProcesses.Add(p);
            }

        }

        public IReadOnlyCollection<IBaseProcess> GetRegisteredProcesses()
        {
            return _registeredProcesses.AsReadOnly();
        }
    }

}
﻿using System.Text;
using BusLib.BatchEngineCore.Groups;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using BusLib.Helper;
using BusLib.Serializers;

namespace BusLib.BatchEngineCore.WatchDog
{
    internal class PubSubWatchDog :SafeDisposable,  IHandler<GroupMessage>, IHandler<IWatchDogMessage>
    {
        private readonly ILogger _logger;
        private readonly IDistributedMessagePublisher _publisher;
        private readonly ISerializer _serializer;

        public PubSubWatchDog(ILogger logger, IDistributedMessagePublisher publisher)
        {
            _logger = logger;
            _publisher = publisher;

            _serializer = SerializersFactory.Instance.GetSerializer(typeof(GroupMessage));
        }

        string PackPubMessage<T>(T message, string type)
        {
            StringBuilder sb=new StringBuilder();
            sb.AppendFormat("{0}::{1}::", NodeSettings.Instance.Name, type);
            var msg =_serializer.SerializeToString(message);
            sb.Append(msg);
            return sb.ToString();
        }

        public void Handle(GroupMessage message)
        {
            var msg = PackPubMessage(message, nameof(GroupMessage));
            _publisher.PublishMessage(msg);
        }

        public void Handle(IWatchDogMessage message)
        {
            var msg = PackPubMessage(message, nameof(IWatchDogMessage));
            _publisher.PublishMessage(msg);
        }

        protected override void Dispose(bool disposing)
        {
            _publisher.Dispose();

            base.Dispose(disposing);
        }
    }
}
﻿using System.Text;
using System.Threading;
using BusLib.BatchEngineCore.Groups;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using BusLib.Helper;
using BusLib.Serializers;

namespace BusLib.BatchEngineCore.WatchDog
{
    internal class PubSubWatchDog :SafeDisposable,  IHandler<IWatchDogMessage> //IHandler<GroupMessage>, 
    {
        private readonly ILogger _logger;
        private readonly IDistributedMessagePublisher _publisher;
        private readonly ISerializer _serializer;

        public PubSubWatchDog(ILogger logger, IPubSubFactory publisherFactory, CancellationToken cancellationToken)
        {
            _logger = logger;
            _publisher = publisherFactory.GetPublisher(cancellationToken, logger, nameof(IWatchDogMessage));

            _serializer = SerializersFactory.Instance.GetSerializer(typeof(GroupMessage));
        }

        string SerializeMessage<T>(T message)
        {
            StringBuilder sb=new StringBuilder();
            //sb.AppendFormat("{0}::{1}::", NodeSettings.Instance.Name, type);
            var msg =_serializer.SerializeToString(message);
            sb.Append(msg);
            return sb.ToString();
        }

        //public void Handle(GroupMessage message)
        //{
        //    var msg = SerializeMessage(message); // nameof(GroupMessage));
        //    _publisher.PublishMessage(msg, nameof(GroupMessage));
        //}

        public void Handle(IWatchDogMessage message)
        {
            var msg = SerializeMessage(message);
            if (message is ProcessInputIdleWatchDogMessage processIdleMessage)
            {
                _publisher.PublishMessage(msg, nameof(ProcessInputIdleWatchDogMessage));
            }
            else if (message is GroupMessage groupMessage)
            {
                _publisher.PublishMessage(msg, nameof(GroupMessage));
            }

        }

        protected override void Dispose(bool disposing)
        {
            _publisher.Dispose();

            base.Dispose(disposing);
        }
    }
}
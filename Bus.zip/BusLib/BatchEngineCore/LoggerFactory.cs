﻿using System;
using BusLib.Core;

namespace BusLib.BatchEngineCore
{
    public class LoggerFactory
    {
        public static ILogger GetSystemLogger()
        {
            throw new NotImplementedException();
        }

        public static ILogger GetTaskLogger(long taskId, long processId, Guid correlationId)
        {
            throw new NotImplementedException();
        }

        public static ILogger GetGroupLogger(long groupId, int groupKey)
        {
            throw new NotImplementedException();
        }

        public static ILogger GetProcessLogger(long processId, long processKey)
        {
            throw new NotImplementedException();
        }
    }
}
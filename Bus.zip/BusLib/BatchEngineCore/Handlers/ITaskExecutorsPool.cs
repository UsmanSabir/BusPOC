﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using BusLib.BatchEngineCore.Process;
using BusLib.Core;
using BusLib.Helper;

namespace BusLib.BatchEngineCore.Handlers
{
    interface ITaskExecutorsPool
    {
        ProcessConsumer Get(long processId, int processStateProcessKey);
    }

    class TaskExecutorsPool : RepeatingProcess, ITaskExecutorsPool
    {
        readonly ConcurrentDictionary<long, ProcessConsumer> _processConsumer = new ConcurrentDictionary<long, ProcessConsumer>();
        private readonly IStateManager _stateManager;
        private readonly CancellationToken _token;
        private readonly ICacheAside _cacheAside;
        private const int TaskTimoutCheckInterval = 2000;
        private IProcessRepository _processRepository;

        #region commented

        //private Task GetTimeoutObserverTask()
        //{
        //    var task = Task.Factory.StartNew(async () =>
        //    {
        //        while (!_token.IsCancellationRequested)
        //        {

        //            try
        //            {
        //                await Task.Delay(Math.Min(TaskTimoutCheckInterval, _processNotificationThresholdMilliSec), _token);

        //                if (_token.IsCancellationRequested)
        //                    return;

        //                await SweepTimedoutTasks();

        //                CheckLastInputInterval();

        //            }
        //            catch (TaskCanceledException e)
        //            {
        //                var msg =
        //                    $"Timeout observer task canceled Process: {_processKey} by token {(_processToken.IsCancellationRequested ? "ProcessToken" : (_parentToken.IsCancellationRequested ? "ParentToken" : "NoToken"))} with msg {e.Message}";
        //                Logger.Info(msg);
        //            }
        //            catch (OperationCanceledException e)
        //            {
        //                var msg =
        //                    $"Timeout observer task canceled Process: {_processKey} by token {(_processToken.IsCancellationRequested ? "ProcessToken" : (_parentToken.IsCancellationRequested ? "ParentToken" : "NoToken"))} with msg {e.Message}";
        //                _logger.Info(msg);
        //            }
        //            catch (Exception e)
        //            {
        //                _logger.Error($"Timeout observer got unexpected error with message {e.Message}", e);
        //            }
        //        }
        //        _logger.Trace($"Timeout observer stopped for Process: {_processKey} by token {(_processToken.IsCancellationRequested ? "ProcessToken" : (_parentToken.IsCancellationRequested ? "ParentToken" : "NoToken"))}");

        //    }, _processToken);
        //    return task;
        //}

        #endregion

        public TaskExecutorsPool(ILogger logger, ICacheAside cacheAside, CancellationToken token, IStateManager stateManager, IProcessRepository processRepository) : base(nameof(TaskExecutorsPool), logger)
        {
            _cacheAside = cacheAside;
            _token = token;
            _stateManager = stateManager;
            _processRepository = processRepository;
            Start(_token);
        }


        public ProcessConsumer Get(long processId, int processKey)
        {
            return GetConsumer(processId, processKey);
        }

        ProcessConsumer GetConsumer(long processId, int processKey)
        {
            var consumer = _processConsumer.GetOrAdd(processId, id=> BuildProcessConsumer(id, processKey));
            return consumer;
        }

        private ProcessConsumer BuildProcessConsumer(long processId, int processKey)
        {
            Logger.Trace($"Process consumer build start for processId {processId}");
            var taskHandler = _processRepository.GetProcessTaskHandler(processKey);
            ProcessConsumer consumer = new ProcessConsumer(_token, processId, _stateManager, LoggerFactory.GetSystemLogger(), _cacheAside, taskHandler, _processRepository.GetSerializer(taskHandler));
            consumer.Start();
            consumer.Completion.ContinueWith(c =>
            {
                Logger.Trace($"Process consumer for processId {processId} stopped and removing from storage");
                //todo publish consumer complete notification
                _processConsumer.TryRemove(processId, out ProcessConsumer cns);
            });

            Logger.Trace($"Process consumer created processId {processId}");
            return consumer;
        }

        //private ProcessConfiguration GetProcessConfigurationFromPId(int processId)
        //{
        //    //todo get global configuration if process configuration missing
        //    var context = _cacheAside.GetProcessExecutionContext(processId);
        //    return context.Configuration;            
        //}
        
        internal override void PerformIteration()
        {
            foreach (var pair in _processConsumer)
            {
                if(Interrupter.IsCancellationRequested)
                    return;

                Robustness.Instance.SafeCall(async () =>
                {
                    await pair.Value.SweepItems();
                });
                
            }
        }
    }
}

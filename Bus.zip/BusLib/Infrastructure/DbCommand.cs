﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusLib.Infrastructure
{
    class DbCommand : ICommand
    {
        public Action Action => throw new NotImplementedException();
    }
}

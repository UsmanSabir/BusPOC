﻿namespace BusLib.Core
{
    public interface IErrorNotification
    {
        void NotifyError(string error);
    }
}
﻿using System;

namespace BusLib.Core.Events
{
    //https://csharpvault.com/weak-event-pattern/
    public interface IEventAggregator
    {
        void Publish(string @event, string parameter = null);

        void Broadcast<T>(T message);

        void Subscribe<T>(Action<T> action); //todo
    }
}
﻿using BusLib.Infrastructure;

namespace BusLib.Helper.SystemHealth
{
    public class CacheHealthProvider
    {
        private IProcessDataStorage _storage;
    }
}
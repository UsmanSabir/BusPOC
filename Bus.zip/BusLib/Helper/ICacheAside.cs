﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Runtime.Caching;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Exceptions;
using BusLib.Core;
using BusLib.Infrastructure;

namespace BusLib.Helper
{
    /// <summary>
    /// DataStore to avoid repeated access data source
    /// </summary>
    public interface ICacheAside
    {
        //MemoryCache.Default;  //20 mins expiry of pool
        IProcessExecutionContext GetProcessExecutionContext(long processId);

        IProcessConfiguration GetProcessConfiguration(int processKey);

        object GetProcessData(int processId, string dataKey); // might be from central cache, a dictionary of string,object type to store data

        T GetProcessData<T>(int processId, string dataKey); // might be from central cache
    }

    //todo
    class CacheAside:ICacheAside
    {
        private readonly IStateManager _stateManager;

        readonly ConcurrentDictionary<int, IProcessConfiguration> _processConfigurations=new ConcurrentDictionary<int, IProcessConfiguration>();
        readonly ConcurrentDictionary<long, IProcessExecutionContext> _processExecutionContexts=new ConcurrentDictionary<long, IProcessExecutionContext>();
        private readonly IProcessDataStorage _storage;

        public CacheAside(IStateManager stateManager, IProcessDataStorage storage)
        {
            _stateManager = stateManager;
            _storage = storage;
        }


        public IProcessExecutionContext GetProcessExecutionContext(long processId)
        {
            var context = _processExecutionContexts.GetOrAdd(processId, id =>
            {
                var process = _stateManager.GetProcessById(processId);
                if (process == null)
                {
                    throw new FrameworkException($"BatchProcess not found for process id {processId}");
                }

                var config = GetProcessConfiguration(process.ProcessKey);
                var executionContext = new ProcessExecutionContext(LoggerFactory.GetProcessLogger(processId, process.ProcessKey), process, config, _storage);
                return executionContext;
            });

            return context;
        }

        public IProcessConfiguration GetProcessConfiguration(int processKey)
        {
            var cfg = _processConfigurations.GetOrAdd(processKey, key =>
            {
                var config = _stateManager.GetProcessConfiguration(key);
                return config;
            });
            if (cfg== null)
            {
                _processConfigurations.TryRemove(processKey, out cfg);
                throw new FrameworkException($"Process configuration not found for process key {processKey}");
            }

            return cfg;
        }

        public object GetProcessData(int processId, string dataKey)
        {
            return null; throw new System.NotImplementedException();
        }

        public T GetProcessData<T>(int processId, string dataKey)
        {
            return default; //throw new System.NotImplementedException();
        }
    }
}
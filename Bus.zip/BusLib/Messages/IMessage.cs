﻿namespace BusLib
{
    public interface IMessage { }
}

﻿namespace BusLib.Messages
{
    public interface INotification : IMessage
    {

    }

    public interface INotification<T>: INotification
    {

    }
}

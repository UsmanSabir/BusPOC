﻿using BusLib.Core;
using BusLib.Messages;
using System;
using System.Threading;
using System.Threading.Tasks;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Groups;
using BusLib.BatchEngineCore.Handlers;
using BusLib.BatchEngineCore.Process;
using BusLib.BatchEngineCore.PubSub;
using BusLib.BatchEngineCore.Volume;
using BusLib.BatchEngineCore.WatchDog;
using BusLib.Core.Events;
using BusLib.Helper;
using BusLib.Infrastructure;
using BusLib.PipelineFilters;
using BusLib.ProcessLocks;
using BusLib.Serializers;

namespace BusLib
{
    public class Bus
    {
        static Bus _instance;
        public static Bus Instance => _instance ?? (_instance = new Bus());
        public IEventAggregator EventAggregator { get; private set; }
        
        private Pipeline<TaskMessage> _taskProcessorPipeline;

        Pipeline<ICommand> _commandPipeLine;
        private IFrameworkLogger _logger;
        private readonly TaskExecutorsPool _taskExecutorsRepo;
        //private Pipeline<GroupMessage> _grouPipeline;
        private Pipeline<IWatchDogMessage> _watchDogPipeline;
        private ProcessVolumePipeline _volumePipeline;

        private IBatchEngineSubscribers _branchEngineSubscriber;

        //private CancellationTokenSource _cancellationTokenSource=;
        CancellationToken _cancellationToken= CancellationToken.None;
        private ICacheAside _cacheAside;
        private TaskProducerWorker _taskProducer;

        internal static IEntityFactory EntityFactory;//todo
        internal static IStateManager StateManager;//todo
        internal static IVolumeHandler VolumeHandler;//todo
        internal static IProcessDataStorage Storage;//todo
        internal static IPubSubFactory PubSubFactory;//todo
        internal static IDistributedMutexFactory DistributedMutexFactory; //todo

        private readonly ProcessRepository _processRepository;
        //private readonly ProcessWatchDog _watchDog;
        
        ReaderWriterLockSlim _watchDogSync=new ReaderWriterLockSlim();
        private DistributedMutex _leaderManager;
        private CancellationTokenSource _watchDogCancelationTokenSource= null;

        public Bus()
        {
            HookExceptionEvents();
            _logger = LoggerFactory.GetSystemLogger();
            _cacheAside = new CacheAside(StateManager, Storage);
            _processRepository = new ProcessRepository();
            _taskExecutorsRepo = new TaskExecutorsPool(_logger, _cacheAside, _cancellationToken, StateManager, _processRepository);
            
            EventAggregator = new TinyEventAggregator();

            BuildCommandHandlerPipeline();
            _taskProcessorPipeline = GetTaskProcessorPipeLine();
            //_grouPipeline=new GroupHandlerPipeline(_stateManager, _logger, _branchEngineSubscriber);
            
            _volumePipeline = new ProcessVolumePipeline(_cancellationToken, _logger, StateManager, _cacheAside, _processRepository, VolumeHandler);
            _branchEngineSubscriber = new BatchEngineSubscribers();
            
            //_watchDog = new ProcessWatchDog(_logger, StateManager, _branchEngineSubscriber, _cacheAside, SerializersFactory.Instance, EntityFactory, EventAggregator, Storage);
            //watchDog.Start(_cancellationToken);//todo
            // _grouPipeline = new Pipeline<GroupMessage>(_watchDog);
            //_watchDogPipeline = new Pipeline<IWatchDogMessage>(_watchDog);

            _taskProducer =new TaskProducerWorker(_logger, _cacheAside, VolumeHandler);

            _leaderManager = DistributedMutexFactory.CreateDistributedMutex("BPEM", RunLocalWatchDog, () => SwitchToPubSubWatchDog(null));
        }

        private Task RunLocalWatchDog(CancellationToken token)
        {
            var completionSource = new TaskCompletionSource<bool>();
            token.Register(() => { SwitchToPubSubWatchDog(completionSource); });

            SwitchToLocalWatchDog();

            return completionSource.Task;
        }

        private void SwitchToLocalWatchDog()
        {
            _watchDogSync.EnterWriteLock();
            try
            {
                _logger.Info("Switching to Master node");
                _watchDogCancelationTokenSource?.Cancel();

                var watchDog = new ProcessWatchDog(_logger, StateManager, _branchEngineSubscriber, _cacheAside, SerializersFactory.Instance, EntityFactory, EventAggregator, Storage);
                _watchDogPipeline = new Pipeline<IWatchDogMessage>(watchDog);

                _watchDogCancelationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(_cancellationToken);
                _watchDogCancelationTokenSource.Token.Register(() =>
                {
                    _logger.Info("Master node ended");
                    watchDog.Dispose();
                });
                watchDog.Start(_watchDogCancelationTokenSource.Token);


                _processRepository.InvokeOnMaster();
                _logger.Info("Switching to Master node complete");
            }
            catch (Exception e)
            {
                _logger.Error("Error switching watchdog to primary node", e);
            }
            finally
            {
                _watchDogSync.ExitWriteLock();
            }
        }

        private void SwitchToPubSubWatchDog(TaskCompletionSource<bool> completionSource)
        {
            _watchDogSync.EnterWriteLock();

            try
            {
                _logger.Info("Switching to Slave node");
                _watchDogCancelationTokenSource?.Cancel();

                var pubSubWatchDog = new PubSubWatchDog(_logger, PubSubFactory, _cancellationToken);
                _watchDogPipeline = new Pipeline<IWatchDogMessage>(pubSubWatchDog);

                _watchDogCancelationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(_cancellationToken);
                _watchDogCancelationTokenSource.Token.Register(() =>
                {
                    _logger.Info("Slave node ended");
                    pubSubWatchDog.Dispose();
                });

                completionSource?.SetResult(true);
                _logger.Info("Switching to Slave node complete");
                _processRepository.InvokeOnSlave();
            }
            catch (Exception e)
            {
                _logger.Error("Error switching watchdog to secondary node", e);
                completionSource.SetException(e);
            }
            finally
            {
                _watchDogSync.ExitWriteLock();
            }
        }

        #region Unhandled Exceptions

        private void HookExceptionEvents()
        {
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;
        }

        private void TaskScheduler_UnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
        {
            _logger.Fetal($"Unhandled task exception message {e.Exception?.GetBaseException()?.ToString() ?? string.Empty}", e.Exception);
            e.SetObserved();
            ((AggregateException)e.Exception).Handle(ex =>
            {
                _logger.Fetal($"Task unhandled exception type: {ex.ToString()}", ex);
                return true;
            });
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            _logger.Fetal($"Unhandled application error with terminating flag {e.IsTerminating} and message {e.ExceptionObject??string.Empty}");
            
        }

        #endregion

        bool ValidateEnvironment()
        {
            //todo
            return true;
        }

        public void Start()
        {
            if (!ValidateEnvironment())
            {
                return;
            }

            _leaderManager.RunTaskWhenMutexAcquired(_cancellationToken); // .Wait(_cancellationToken);

            _taskExecutorsRepo.Start(_cancellationToken);
            _taskProducer.Start(_cancellationToken);
            //_watchDog.Start(_cancellationToken);//todo. run on leader node only
            
        }

        internal void HandleVolumeRequest(ProcessExecutionContext msg)
        {
            _volumePipeline.Invoke(msg);
        }


        //internal void HandleGroupMessage(GroupMessage msg)
        //{
        //    _grouPipeline.Invoke(msg);
        //}

        internal void HandleWatchDogMessage(IWatchDogMessage msg)
        {
            try
            {
                _watchDogSync.EnterReadLock();

                _watchDogPipeline.Invoke(msg);

            }
            finally
            {
                _watchDogSync.ExitReadLock();
            }
        }

        internal void HandleTaskMessage(TaskMessage msg)
        {
            _taskProcessorPipeline.Invoke(msg);
        }

        private Pipeline<TaskMessage> GetTaskProcessorPipeLine()
        {
            Pipeline<TaskMessage> tasksPipeline=new TaskProcessingPipeline(LoggerFactory.GetSystemLogger(), _taskExecutorsRepo);
            return tasksPipeline;
        }

        private void BuildCommandHandlerPipeline()
        {
            _commandPipeLine = new Pipeline<ICommand>(new CommandHandler());
            _commandPipeLine.RegisterFeatureDecorator(new PerfMonitorHandler<ICommand>());
        }
                
        public void Execute(ICommand message)
        {
            _commandPipeLine.Invoke(message);
        }

        internal void QueryAction<T>(Func<T> action, Action<T> onResult)
        {
            
        }

        public void ExecuteSystemCommand(ISystemCommand message)
        {
            if(message.PipeLineKey == nameof(ICommand))
            {
                _commandPipeLine.HandleSystemCommand(message);
            }
        }


        public void TestDecorator(ICommand command)
        {
            Execute(command);

            //_decorator.Disable();

            Execute(command);

            //_decorator.Enable();
            Execute(command);
            Execute(command);

        }
    }
}

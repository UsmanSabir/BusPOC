﻿using BusLib.Core;

namespace BusLib.ProcessLocks
{
    public class InProcessLock:ILock
    {
        public void Dispose()
        {
        }
    }
}
﻿using System;
using NS.Utilities.Context;

namespace BusImpl.Logs
{
    /// <summary>
    /// ProcessContext : Used for additional Context values for bpem.
    /// </summary>.
    public class ProcessContext : Context
    {
        #region Fields
        public int ProcessId { get; set; }
        public string ProcessName { get; set; }
        public int ProcessQueueId { get; set; }
        public string Status { get; set; }
        public int BatchId { get; set; }
        public string BatchStatus { get; set; }
        //public string refId { get; set; } //Context already has field named _referenceId
        public string TaskStatus { get; set; }
        public int TaskId { get; set; }
        public bool PriorityQueueInd { get; set; }
        #endregion
        #region Functions

        ///// <summary>
        ///// GetContextObject
        ///// </summary>
        ///// <returns></returns>
        //public Context GetContextObject()
        //{

        //    return new Context()
        //    {
        //        ApplicationCode = ProcessHelper.GetAppCode(),
        //        ContextId = ContextId,
        //        SessionId = SessionId,
        //        SessionCode = SessionCode,
        //        LoginId = LoginId, //Environment.UserName,
        //        MachineIp = ConfigurationManager.AppSettings["NodeAddress"],
        //        UserName = UserName, //Environment.UserName,
        //        SubTenantId = SubTenantId,
        //        ReferenceId = ReferenceId,
        //        Key = Key,
        //        CustomParameters = new Utilities.SerializableDictionary<string, object>()
        //        {
        //            { "ServerIP", ConfigurationManager.AppSettings["ApplicationServer"]}
        //        },
        //    };
        //}

        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="refId"></param>
        /// <returns></returns>
        public ProcessContext Copy(int? refId)
        {
            //to-do: fields of Context class if used need to copy also 
            return new ProcessContext()
            {
                ApplicationCode = ApplicationCode,
                LoginId = LoginId,
                MachineIp = MachineIp,
                UserName = UserName,
                CustomParameters = CustomParameters,
                ContextId = ContextId,
                SessionId = SessionId,
                SessionCode = SessionCode,
                ProcessId = ProcessId,
                ReferenceId = refId,
                ProcessQueueId = ProcessQueueId,
                ProcessName = ProcessName,
                SubTenantId = SubTenantId,
                PriorityQueueInd = PriorityQueueInd,
                Key = Key

            };

        }

        #endregion
    }

    public static class CtxExt
    {
        public static ProcessContext Copy(this Context context, int? refId)
        {
            if (context is ProcessContext processCtx)
            {
                return processCtx.Copy(refId);
            }

            var ctxCpy = new ProcessContext()
            {
                ApplicationCode = context.ApplicationCode,
                ContextId = context.ContextId,
                LoginId = context.LoginId,
                UserName = context.UserName,
                MachineIp = context.MachineIp,
                CustomParameters = context.CustomParameters,
                SessionId = context.SessionId,
                Key = context.Key,
                ReferenceId = refId,
                SubTenantId = context.SubTenantId
            };

            return ctxCpy;
        }
    }
}
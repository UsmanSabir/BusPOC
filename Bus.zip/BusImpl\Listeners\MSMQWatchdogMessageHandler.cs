﻿using BusLib.BatchEngineCore.Process;

namespace BusImpl.Listeners
{
    public class MSMQWatchdogMessageHandler:IMasterSlaveObserver
    {
        private bool _isMaster = false;

        public void OnMaster()
        {
            _isMaster = true;
        }

        public void OnSlave()
        {
            _isMaster = false;
        }

        void OnMessageArrived()
        {
            if (_isMaster)
            {

            }
        }
    }
}
﻿using System;
using BusLib.BatchEngineCore.PubSub;

namespace BusImpl.Empty
{
    public class EmptyPub: IDistributedMessagePublisher
    {
        public void Dispose()
        {
            
        }

        public void PublishMessage(string message, string type)
        {
            
        }

        public void PublishMessage<T>(T message)
        {
            
        }
    }

    class EmptySub: IDistributedMessageSubscriber
    {
        public void Dispose()
        {
            
        }

        public void Subscribe(string message, Action<string> action)
        {
            
        }

        public void Subscribe<T>(Action<T> action)
        {
            
        }
    }
}
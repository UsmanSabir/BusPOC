﻿using System;
using BusLib.BatchEngineCore;
using NFS.ServiceContracts;
using NS.ServiceModel;

namespace BusImpl.ServiceChannels
{
    public static class ProcessResourceExt
    {
        public static ProxyClient<T> GetService<T>(this IProcessExecutionContext context) //where T:IDisposable
        {
            var result = context.GetSetResource($"R_{typeof(T).Name}", () =>
            {
                ProxyClient<T> proxy = new ProxyClient<T>();
                return proxy;
            });

            return result;
        }

        public static ProxyClient<T> GetService<T>(this ITaskContext context)
        {
            var result = context.ProcessExecutionContext.GetService<T>();
            return result;
        }

        static void test()
        {

            
        }
    }
}
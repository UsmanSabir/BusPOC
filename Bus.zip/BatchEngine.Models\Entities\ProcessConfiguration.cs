
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessConfig
	public partial class ProcessConfiguration : BaseModel
	{
		
				private Int32 _id;
				private Int32 _processid;
				private Int32 _processkey;
				private Int32 _batchsize;
				private Int32? _processtimeoutmins;
				private Int32? _tasktimeout;
				private Int32? _processretries;
				private Int32? _taskretries;
				private Int32? _retrydelaymilli;
				private Int32 _maxvolumeretries;
				private Int32? _queuesize;
				private Int32? _prntprcsid;
				private Int32? _errorthreshold;
		
		//public ProcessConfiguration ProcessConfiguration { get { return this; } } //Self reference property

		
		public Int32 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Int32 PROCESSID
		{
			get { return _processid; }
			set
			{
				CheckSetProperty(ref _processid, value);
			}
		}

		
		public Int32 PROCESSKEY
		{
			get { return _processkey; }
			set
			{
				CheckSetProperty(ref _processkey, value);
			}
		}

		
		public Int32 BATCHSIZE
		{
			get { return _batchsize; }
			set
			{
				CheckSetProperty(ref _batchsize, value);
			}
		}

		
		public Int32? PROCESSTIMEOUTMINS
		{
			get { return _processtimeoutmins; }
			set
			{
				CheckSetProperty(ref _processtimeoutmins, value);
			}
		}

		
		public Int32? TASKTIMEOUT
		{
			get { return _tasktimeout; }
			set
			{
				CheckSetProperty(ref _tasktimeout, value);
			}
		}

		
		public Int32? PROCESSRETRIES
		{
			get { return _processretries; }
			set
			{
				CheckSetProperty(ref _processretries, value);
			}
		}

		
		public Int32? TASKRETRIES
		{
			get { return _taskretries; }
			set
			{
				CheckSetProperty(ref _taskretries, value);
			}
		}

		
		public Int32? RETRYDELAYMILLI
		{
			get { return _retrydelaymilli; }
			set
			{
				CheckSetProperty(ref _retrydelaymilli, value);
			}
		}

		
		public Int32 MAXVOLUMERETRIES
		{
			get { return _maxvolumeretries; }
			set
			{
				CheckSetProperty(ref _maxvolumeretries, value);
			}
		}

		
		public Int32? QUEUESIZE
		{
			get { return _queuesize; }
			set
			{
				CheckSetProperty(ref _queuesize, value);
			}
		}

		
		public Int32? PRNTPRCSID
		{
			get { return _prntprcsid; }
			set
			{
				CheckSetProperty(ref _prntprcsid, value);
			}
		}

		
		public Int32? ERRORTHRESHOLD
		{
			get { return _errorthreshold; }
			set
			{
				CheckSetProperty(ref _errorthreshold, value);
			}
		}

		

		
	}

		public class ProcessConfigurationValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "PROCESSID", "PROCESSKEY", "BATCHSIZE", "MAXVOLUMERETRIES",  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		              
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
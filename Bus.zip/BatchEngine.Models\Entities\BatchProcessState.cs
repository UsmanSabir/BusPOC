
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessState
	public partial class BatchProcessState : BaseModel
	{
		
				private Int64 _id;
				private Guid _correlationid;
				private DateTime? _updatedon;
				private Int32 _retrycount;
				private Int32 _companyid;
				private Int32 _branchid;
				private DateTime _processingdate;
				private Int32 _processid;
				private Int32 _groupseqid;
				private String _dependentprocessids;
				private Boolean _isvolumegenerated;
				private Boolean _hasvolume;
				private Int64? _parentid;
				private Int64 _groupid;
				private Boolean _isfinished;
				private Boolean _isstopped;
				private String _criteria;
				private DateTime? _starttime;
				private String _currentstate;
				private Int32 _subtenantid;
				private DateTime? _completetime;
				private DateTime? _generationcompletetime;
				private String _resultstatus;
				private Boolean? _groupstopper;
				private String _queuename;
				private Int32? _queueseq;
		
		//public BatchProcessState BatchProcessState { get { return this; } } //Self reference property

		
		public Int64 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Guid CORRELATIONID
		{
			get { return _correlationid; }
			set
			{
				CheckSetProperty(ref _correlationid, value);
			}
		}

		
		public DateTime? UPDATEDON
		{
			get { return _updatedon; }
			set
			{
				CheckSetProperty(ref _updatedon, value);
			}
		}

		
		public Int32 RETRYCOUNT
		{
			get { return _retrycount; }
			set
			{
				CheckSetProperty(ref _retrycount, value);
			}
		}

		
		public Int32 COMPANYID
		{
			get { return _companyid; }
			set
			{
				CheckSetProperty(ref _companyid, value);
			}
		}

		
		public Int32 BRANCHID
		{
			get { return _branchid; }
			set
			{
				CheckSetProperty(ref _branchid, value);
			}
		}

		
		public DateTime PROCESSINGDATE
		{
			get { return _processingdate; }
			set
			{
				CheckSetProperty(ref _processingdate, value);
			}
		}

		
		public Int32 PROCESSID
		{
			get { return _processid; }
			set
			{
				CheckSetProperty(ref _processid, value);
			}
		}

		
		public Int32 GROUPSEQID
		{
			get { return _groupseqid; }
			set
			{
				CheckSetProperty(ref _groupseqid, value);
			}
		}

		
		public String DEPENDENTPROCESSIDS
		{
			get { return _dependentprocessids; }
			set
			{
				CheckSetProperty(ref _dependentprocessids, value);
			}
		}

		
		public Boolean ISVOLUMEGENERATED
		{
			get { return _isvolumegenerated; }
			set
			{
				CheckSetProperty(ref _isvolumegenerated, value);
			}
		}

		
		public Boolean HASVOLUME
		{
			get { return _hasvolume; }
			set
			{
				CheckSetProperty(ref _hasvolume, value);
			}
		}

		
		public Int64? PARENTID
		{
			get { return _parentid; }
			set
			{
				CheckSetProperty(ref _parentid, value);
			}
		}

		
		public Int64 GROUPID
		{
			get { return _groupid; }
			set
			{
				CheckSetProperty(ref _groupid, value);
			}
		}

		
		public Boolean ISFINISHED
		{
			get { return _isfinished; }
			set
			{
				CheckSetProperty(ref _isfinished, value);
			}
		}

		
		public Boolean ISSTOPPED
		{
			get { return _isstopped; }
			set
			{
				CheckSetProperty(ref _isstopped, value);
			}
		}

		
		public String CRITERIA
		{
			get { return _criteria; }
			set
			{
				CheckSetProperty(ref _criteria, value);
			}
		}

		
		public DateTime? STARTTIME
		{
			get { return _starttime; }
			set
			{
				CheckSetProperty(ref _starttime, value);
			}
		}

		
		public String CURRENTSTATE
		{
			get { return _currentstate; }
			set
			{
				CheckSetProperty(ref _currentstate, value);
			}
		}

		
		public Int32 SUBTENANTID
		{
			get { return _subtenantid; }
			set
			{
				CheckSetProperty(ref _subtenantid, value);
			}
		}

		
		public DateTime? COMPLETETIME
		{
			get { return _completetime; }
			set
			{
				CheckSetProperty(ref _completetime, value);
			}
		}

		
		public DateTime? GENERATIONCOMPLETETIME
		{
			get { return _generationcompletetime; }
			set
			{
				CheckSetProperty(ref _generationcompletetime, value);
			}
		}

		
		public String RESULTSTATUS
		{
			get { return _resultstatus; }
			set
			{
				CheckSetProperty(ref _resultstatus, value);
			}
		}

		
		public Boolean? GROUPSTOPPER
		{
			get { return _groupstopper; }
			set
			{
				CheckSetProperty(ref _groupstopper, value);
			}
		}

		
		public String QUEUENAME
		{
			get { return _queuename; }
			set
			{
				CheckSetProperty(ref _queuename, value);
			}
		}

		
		public Int32? QUEUESEQ
		{
			get { return _queueseq; }
			set
			{
				CheckSetProperty(ref _queueseq, value);
			}
		}

		

		
	}

		public class BatchProcessStateValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "CORRELATIONID", "RETRYCOUNT", "COMPANYID", "BRANCHID", "PROCESSINGDATE", "PROCESSID", "GROUPSEQID", "ISVOLUMEGENERATED", "HASVOLUME", "GROUPID", "ISFINISHED", "ISSTOPPED", "CRITERIA", "CURRENTSTATE", "SUBTENANTID", "RESULTSTATUS",  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		            ["DEPENDENTPROCESSIDS"] = 500
		        , ["CRITERIA"] = 4000
		   , ["CURRENTSTATE"] = 50
		     , ["RESULTSTATUS"] = 50
		   , ["QUEUENAME"] = 50
		  
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
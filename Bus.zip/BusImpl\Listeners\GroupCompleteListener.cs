﻿using System;
using BusLib.BatchEngineCore.Groups;
using BusLib.BatchEngineCore.PubSub;

namespace BusImpl.Listeners
{
    public class GroupCompleteListener:IGroupSubscriber
    {
        public int GroupKey { get; } = 0;

        public void OnGroupStarting(IGroupStartContext context)
        {
            
        }

        public void OnGroupSubmitted(IGroupStartContext context)
        {
            
        }

        public void OnGroupComplete(IGroupCompleteContext context)
        {
            //if (context.IsResubmitted)
            //    throw new InvalidOperationException("Process already submitted");

            //context.Resubmit(context.Criteria, "Rollover");
        }
    }
}
﻿using System;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;

namespace BatchEngine.Models.BusStateWrapper
{
    public class BatchTaskWrapper: IReadWritableTaskState
    {
        internal readonly BatchTaskState State;

        public BatchTaskWrapper(BatchTaskState state)
        {
            State = state;
        }

        public bool IsFinished 
        {
            get => State.ISFINISHED;
            set => State.ISFINISHED=value;
        }

        public bool IsStopped 
        {
            get => State.ISSTOPPED;
            set => State.ISSTOPPED = value;
        }

        public long Id 
        {
            get => State.ID;
            set => State.ID = value;
        }

        public long ProcessId 
        {
            get => State.PROCESSID;
            set => State.PROCESSID = value;
        }

        public string Payload 
        {
            get => State.PAYLOAD;
            set => State.PAYLOAD = value;
        }

        public DateTime? UpdatedOn
        {
            get => State.UPDATEDON;
            set => State.UPDATEDON = value;
        }

        public ResultStatus Status 
        {
            get => ResultStatus.FromName(State.CURRENTSTATE);
            set => State.CURRENTSTATE = value.Name;
        }

        public string CurrentState
        {
            get => State.CURRENTSTATE;
            set => State.CURRENTSTATE = value;
        }

        public int FailedCount
        {
            get => State.FAILEDCOUNT;
            set => State.FAILEDCOUNT = value;
        }

        public int DeferredCount 
        {
            get => State.DEFERREDCOUNT;
            set => State.DEFERREDCOUNT = value;
        }

        public string NodeKey 
        {
            get => State.NODEKEY;
            set => State.NODEKEY = value;
        }

        public DateTime? StartedOn
        {
            get => State.STARTEDON;
            set => State.STARTEDON = value;
        }

        public DateTime? CompletedOn
        {
            get => State.COMPLETEDON;
            set => State.COMPLETEDON=value;
        }
    }
}
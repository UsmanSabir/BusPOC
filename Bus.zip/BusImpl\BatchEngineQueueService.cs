﻿using System.Linq;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.JobScheduler;
using NS.ORM;
using NS.ORM.UoW;

namespace BusImpl
{
    public class BatchEngineQueueService : IBatchEngineQueueService
    {
        public int GetProcessSeqNoForQueue(string queueName, long refId, ITransaction transaction)
        {
            //var contextExt = EntityContextExt.Create<BatchEngineQueue>().UsingUnitOfWork(transaction as IUnitOfWork);
            var controller = DbController.Create((IUnitOfWork) transaction.TransactionObject);
            var quieId = controller.GetCustomItem<int>(Constant.SQLAddProcessToQueue, queueName, refId);
            return quieId;
        }

        public bool IsQueueSeqReached(string queueName, int seqNumber, long refId)
        {
            var previousQueue = BatchEngineQueue.GetPreviousQueue(queueName, seqNumber); //previousQueue
            if (previousQueue==null || previousQueue.Count==0)
            {
                return true;
            }

            return previousQueue.First().ISFINISHED;

            //int lastSeq = seqNumber - 1;
            //var ext = EntityContextExt.Create<BatchEngineQueue>();
            //ext.Read(s => s.QUEUENAME == queueName && s.QUEUESEQ == lastSeq);
            //if (ext.Entity.Count == 0)
            //    return true; //no previous items in queue

            //return ext.Entity.First().ISFINISHED;
        }


        public bool MarkQueueSeqFinish(string queueName, int seqNumber, ITransaction transaction)
        {
            var controller = DbController.Create((IUnitOfWork) transaction.TransactionObject);
            var rowsEffected = controller.ExecuteNonQuery(Constant.SQLMarkQueueFinished, queueName, seqNumber);
            return rowsEffected > 0;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;
using BusLib.Core.Events;
using BusLib.JobSchedular;
using BusLib.JobScheduler;
using BusLib.Serializers;
using NS.BaseModels;
using NS.ORM;

namespace BusImpl
{
    internal class JobSchedulerLocal:JobSchedulerBase
    {
        private readonly IEventAggregator _eventAggregator;
        
        public JobSchedulerLocal(ISerializersFactory factory, IBatchLoggerFactory loggerFactory, 
            IBatchEngineQueueService batchEngineQueueService, IEventAggregator eventAggregator)
            : base(factory, loggerFactory, batchEngineQueueService)
        {
            _eventAggregator = eventAggregator;
        }

        protected override void Publish(long groupId)
        {
            try
            {
                _eventAggregator.PublishAsync(this, Constants.EventProcessGroupAdded, groupId.ToString());
            }
            catch (Exception e)
            {
                SystemLogger.Error("Failed to publish ProcessGroupAddedMessage for groupId {groupId} having error {error}", groupId, e);
            }
        }
    }
}
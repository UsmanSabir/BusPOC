﻿using BatchEngine.Core;
using BatchEngine.Core.Subscribers;

namespace BatchBootstrapper
{
    public class BisProcess: ProcessSubscriberBase
    {
        public override int ProcessId { get; } = 0;

        //public override bool CanExecute(IProcessExecutionContext context)
        //{
        //    bool canExe = false; //call function

        //    if (!canExe)
        //    {
        //        context.Logger.Info("Process can't execute because its not month-end");
        //    }

        //    return canExe;
        //}
    }
}
﻿using BatchEngine.Core;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Subscribers;

namespace BatchBootstrapper.Groups
{
    public class GroupSubscriber:IGroupSubscriber
    {
        public int GroupKey { get; } = 0;

        public void OnGroupStarting(IGroupStartContext context)
        {
            
        }

        public void OnGroupSubmitted(IGroupStartContext context)
        {
            
        }

        public void OnGroupComplete(IGroupCompleteContext context)
        {
            //foreach (var contextCriterion in context.Criteria)
            //{
                
            //}

            //context.Resubmit();
        }
    }
}
﻿using BatchEngine.Core;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Subscribers;

namespace BatchBootstrapper.Groups
{
    public class GroupSubscriber: GroupSubscriberBase
    {
        public override int GroupKey { get; } = 0;

        public override void OnGroupStarting(IGroupStartContext context)
        {
            
        }

        public override void OnGroupSubmitted(IGroupStartContext context)
        {
            
        }

        public override void OnGroupComplete(IGroupCompleteContext context)
        {
            //foreach (var contextCriterion in context.Criteria)
            //{
                
            //}

            //context.Resubmit();
        }
    }
}
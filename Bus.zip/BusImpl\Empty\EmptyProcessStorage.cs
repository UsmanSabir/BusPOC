﻿using System;
using BusLib.Infrastructure;

namespace BusImpl.Empty
{
    public class EmptyProcessStorage : IProcessDataStorage
    {
        public void AddOrUpdateProcessData<T>(long processStateId, string key, T value, TimeSpan expireIn)
        {
            throw new NotImplementedException();
        }

        public T GetProcessData<T>(long processStateId, string key)
        {
            throw new NotImplementedException();
        }

        public void CleanProcessData(string processId)
        {
            //throw new NotImplementedException();
        }

        public bool IsHealthy()
        {
            //throw new NotImplementedException();
            return true;
        }

        public void RefreshIfNotHealth()
        {
            
        }
    }
}
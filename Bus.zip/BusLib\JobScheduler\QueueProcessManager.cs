﻿using System;
using System.Collections.Generic;
using System.Linq;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Groups;
using BusLib.BatchEngineCore.PubSub;
using BusLib.BatchEngineCore.Volume;
using BusLib.Core;
using BusLib.Core.Events;
using BusLib.Helper;
using BusLib.Infrastructure;

namespace BusLib.JobScheduler
{
    public interface IQueueProcessManager:IDisposable
    {
        void HandleQueueProcess(IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity);
    }

    class QueManagerProcessSubscriber: ProcessSubscriberBase
    {
        private QueueProcessManager _queueProcessManager=null;

        public QueManagerProcessSubscriber()
        {
            
        }
        public override int ProcessKey { get; } = 0;

        public override void OnProcessFinalized(IProcessCompleteContext context)
        {
            _queueProcessManager?.OnProcessFinalized(context);
        }


        public void SetListener(QueueProcessManager queueProcessManager)
        {
            _queueProcessManager = queueProcessManager;
        }
    }

    internal class QueueProcessManager: IQueueProcessManager
    {
        private readonly IBatchEngineQueueService _batchEngineQueueService;

        private readonly ProcessVolumePipeline _volumePipeline;

        private readonly IBatchLoggerFactory _loggerFactory;

        private readonly ICacheAside _cacheAside;

        private readonly IProcessDataStorage _storage;
        
        readonly object _syncLock = new object();

        readonly List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> _queuedProcess =
                new List<(IReadWritableProcessState processes, IReadWritableGroupEntity groupDetailsGroupEntity)>();

        private readonly IFrameworkLogger _systemLogger;

        public QueueProcessManager(IBatchEngineQueueService batchEngineQueueService,
            ProcessVolumePipeline volumePipeline, IBatchLoggerFactory loggerFactory, ICacheAside cacheAside,
            IProcessDataStorage storage, IResolver resolver)
        {
            _batchEngineQueueService = batchEngineQueueService;
            _volumePipeline = volumePipeline;
            _loggerFactory = loggerFactory;
            _cacheAside = cacheAside;
            _storage = storage;

            _systemLogger = loggerFactory.GetSystemLogger();

            var queSub = resolver.Resolve<QueManagerProcessSubscriber>();
            queSub.SetListener(this);
            //_eventAggregator = eventAggregator;
            //_subRem = eventAggregator.Subscribe<TextMessage>(ProcessRemoved, Constants.EventProcessFinished);
        }

        private void ProcessRemoved(TextMessage obj)
        {
            
        }
        
        
        //public override int ProcessKey { get; } = 0;

        public void OnProcessFinalized(IProcessCompleteContext context)
        {
            if (context.Process.QueueSeq.HasValue && context.Process.QueueSeq.Value > 0)
            {
                //todo Queued process completed

                List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> list;

                lock (_syncLock)
                {
                    list = _queuedProcess.Where(r=>r.process.QueueName==context.Process.QueueName).ToList(); //get a copy in lock
                }

                
                {
                    List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> process2remove =
                        new List<(IReadWritableProcessState, IReadWritableGroupEntity)>();

                    foreach (var pair in list)
                    {
                        var readWritableProcessState = pair.process;
                        var groupDetailsGroupEntity = pair.@group;

                        try
                        {
                            var isSubmitted = SubmitQueueProcessForVolume(readWritableProcessState, groupDetailsGroupEntity);
                            if (isSubmitted)
                            {
                                process2remove.Add(pair);
                            }
                        }
                        catch (Exception e)
                        {
                            _systemLogger.Error("Error submitting Queued process Id {processId} for volume. {error}", readWritableProcessState.Id, e);
                        }
                    }

                    if (process2remove.Count > 0)
                    {
                        lock (_syncLock)
                        {
                            foreach (var pair in process2remove)
                            {
                                _queuedProcess.Remove(pair);
                            }
                        }
                    }
                }
            }
        }

        private bool SubmitQueueProcessForVolume(IReadWritableProcessState readWritableProcessState,
            IReadWritableGroupEntity groupDetailsGroupEntity)
        {
            if (readWritableProcessState.QueueSeq.HasValue == false || readWritableProcessState.QueueSeq.Value == 0)
            {
                throw new ApplicationException($"Process Id {readWritableProcessState.Id} has null or 0 QueueSeq value");
            }

            var isQueueSeqReached = _batchEngineQueueService.IsQueueSeqReached(readWritableProcessState.QueueName,
                readWritableProcessState.QueueSeq.Value, readWritableProcessState.GroupId);

            if (isQueueSeqReached)
            {
                var p = readWritableProcessState;


                var volumeMessage = new ProcessExecutionContext(
                    _loggerFactory.GetProcessLogger(p.Id, p.ProcessId, p.CorrelationId), p,
                    _cacheAside.GetProcessConfiguration(p.ProcessId), _storage, groupDetailsGroupEntity);

                _volumePipeline.Invoke(volumeMessage);
                return true;
            }

            return false;
        }

        protected void Dispose(bool disposing)
        {
            //if (!IsDisposed)
            {
                //_eventAggregator.Unsubscribe(_subRem);
                lock (_syncLock)
                {
                    _queuedProcess.Clear();
                }
            }

            //base.Dispose(disposing);
        }

        public void HandleQueueProcess(IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity)
        {
            var submitted = SubmitQueueProcessForVolume(process, groupDetailsGroupEntity);

            if (!submitted)
            {
                lock (_syncLock)
                {
                    _queuedProcess.Add((process, groupDetailsGroupEntity));
                }
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
    }
}
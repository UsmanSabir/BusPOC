﻿namespace BusLib.BatchEngineCore
{
    public interface IContextSwitchHandler
    {
        void ContextSwitchStarting();
        void ContextSwitchCompleted();
    }
}

/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessGroupDetail
	public partial class BatchProcessGroupDetail : BaseModel
	{
		
				private Int32 _id;
				private Int32 _groupkey;
				private Int32 _processid;
				private Int32? _parentprocessid;
				private String _dependentprocessids;
				private Boolean _act_ind;
		
		//public BatchProcessGroupDetail BatchProcessGroupDetail { get { return this; } } //Self reference property

		
		public Int32 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Int32 GROUPKEY
		{
			get { return _groupkey; }
			set
			{
				CheckSetProperty(ref _groupkey, value);
			}
		}

		
		public Int32 PROCESSID
		{
			get { return _processid; }
			set
			{
				CheckSetProperty(ref _processid, value);
			}
		}

		
		public Int32? PARENTPROCESSID
		{
			get { return _parentprocessid; }
			set
			{
				CheckSetProperty(ref _parentprocessid, value);
			}
		}

		
		public String DEPENDENTPROCESSIDS
		{
			get { return _dependentprocessids; }
			set
			{
				CheckSetProperty(ref _dependentprocessids, value);
			}
		}

		
		public Boolean ACT_IND
		{
			get { return _act_ind; }
			set
			{
				CheckSetProperty(ref _act_ind, value);
			}
		}

		

		
	}

		public class BatchProcessGroupDetailValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "GROUPKEY", "PROCESSID", "ACT_IND"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		       ["DEPENDENTPROCESSIDS"] = 500
		  
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusImpl.Redis;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;

namespace SampleDashboard
{
    public partial class Form1 : Form
    {
        private RedisPubSubFactory _pubSubFactory;
        private IDistributedMessageSubscriber _sub;
        private IDistributedMessagePublisher _pub;

        private const string dashboardChannel = "Dashboard";
        private const string statusRequest = "status";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _pubSubFactory = new RedisPubSubFactory("localhost");
            _pub = _pubSubFactory.GetPublisher(CancellationToken.None, new EmptyLogger(), dashboardChannel);
            _sub = _pubSubFactory.GetSubscriber(CancellationToken.None, new EmptyLogger(), dashboardChannel);
            var name = "HealthMessage"; // statusRequest;// typeof(HealthMessage).Name;
            _sub.Subscribe(name, OnMessageReceived);
        }

        private void OnMessageReceived(string obj)
        {
            this.BeginInvoke((Action)(() => { richTextBox1.Text = obj; }));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _pub.PublishMessage("health", statusRequest);
        }
    }

    class EmptyLogger:ILogger
    {
        public void Trace(string message)
        {
            
        }

        public void Info(string info)
        {
            
        }

        public void Warn(string warn)
        {
            
        }

        public void Warn(string message, Exception e)
        {
            
        }

        public void Error(string error)
        {
            
        }

        public void Error(string error, Exception exception)
        {
            
        }

        public void Fetal(string error)
        {
            
        }

        public void Fetal(string error, Exception exception)
        {
            
        }
    }
}

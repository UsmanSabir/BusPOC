﻿namespace BusLib.BatchEngineCore.PubSub
{
    public interface IBroadcastMessage
    {
        
    }
}
﻿using System.Threading;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Core;

namespace BusImpl.Empty
{
    public class EmptyPubSubFactory: IPubSubFactory
    {
        
        public EmptyPubSubFactory()
        {
            
        }
        public IDistributedMessagePublisher GetPublisher(CancellationToken token, ILogger logger,
            string channelName = null)
        {
            return new EmptyPub();
        }

        public IDistributedMessageSubscriber GetSubscriber(CancellationToken token, ILogger logger,
            string channelName = null)
        {
            return new EmptySub();
        }
    }
}
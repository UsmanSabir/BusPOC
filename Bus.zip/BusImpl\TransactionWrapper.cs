﻿using BusLib.BatchEngineCore;
using NS.ORM.UoW;

namespace BusImpl
{
    public class TransactionWrapper:ITransaction
    {
        private readonly IUnitOfWork _unitOfWork;

        public TransactionWrapper(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public void Dispose()
        {
            _unitOfWork?.Dispose();
        }

        public void Commit()
        {
            _unitOfWork?.Save();
        }

        public void Rollback()
        {
            _unitOfWork?.Dispose();
        }

        public bool IsOpen()
        {
            return _unitOfWork?.IsOpen() ?? false;
        }

        public object TransactionObject => _unitOfWork;
    }
}
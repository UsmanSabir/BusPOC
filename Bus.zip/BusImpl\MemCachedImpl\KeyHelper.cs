﻿using NS.Utilities.Context;
using NS.Utilities.Helper;

namespace BusImpl.MemCachedImpl
{
    public class KeyHelper
    {
        public static string CreateMultitenantKey(string key)
        {
            Context context = LogContext.ContextToLog;
            if (context == null)
                return key;

            return CacheKeys.CreateRelatedKey(context.SubTenantId.ToString(), key);
        }

        /// <summary>
        /// Returns cache key.
        /// </summary>
        /// <param name="key">cache key.</param>
        /// <param name="isKeyMultitenant">Indicates if cache key is multitenant wise</param>
        /// <returns></returns>
        public static string GetKey(string key, bool isKeyMultitenant)
        {
            if (isKeyMultitenant)
                key = CreateMultitenantKey(key);
            return key;
        }
    }
}
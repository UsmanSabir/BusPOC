﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Threading;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Volume;
using BusLib.Helper;
using BusLib.Infrastructure;
using BusLib.Serializers;
using NS.ORM;
using NS.ORM.UoW;
using NS.Utilities.Helper;

namespace BusImpl
{
    class VolumeHandler: IVolumeHandler
    {
        private readonly IResolver _resolver;
        private readonly ISerializersFactory _serializersFactory;

        public VolumeHandler(IResolver resolver)
        {
            _resolver = resolver;
            _serializersFactory = SerializersFactory.Instance;
        }

        public void Handle<T>(IEnumerable<T> volume, IProcessExecutionContextWithVolume processContext, CancellationToken token)
        {
            if (volume==null)
            {
                processContext.Logger.Info("No volume returned");
                return;
            }

            bool hasVolume = false;
            var serializer = _serializersFactory.GetSerializer<T>();
            int currentCount = 0;
            int batchSize = 100;

            IUnitOfWork uow = null;
            EntityContextExt<BatchTaskState> ext=null;

            try
            {

                Bus.HandleDbCommand(new DbAction(DbActions.Transaction, () => //create transaction in Db Bus pipeline
                {
                    ext = EntityContextExt<BatchTaskState>.Create();
                    uow = ext.InitiateUnitOfWork();
                    var controller = DbController.Create(uow);
                    var volumeDeletedCount = controller.ExecuteNonQuery(Constant.SQLDeleteProcessVolume, processContext.ProcessState.Id);
                    if (volumeDeletedCount > 0)
                    {
                        processContext.Logger.Warn($"Existing volume {volumeDeletedCount} deleting");
                    }
                }));
            
                //using (var unitOfWork = ) //IsolationLevel.Snapshot //todo check isolation level with db team, is it enabled by default
                {
                    foreach (var v in volume)
                    {
                        var payLoad = serializer.SerializeToString(v);
                        var state = ext.CreateNew();

                        state.PAYLOAD = payLoad;
                        state.PROCESSID = processContext.ProcessState.Id;
                        state.CURRENTSTATE = ResultStatus.Empty.Name;

                        currentCount++;
                        if (currentCount >= batchSize)
                        {
                            token.ThrowIfCancellationRequested();

                            hasVolume = true;
                            ext.Persist();
                            currentCount = 0;
                            ext.Entity.Clear();//remove persisted items
                        }
                    }
                    if (ext.Entity?.Count>0)
                    {
                        token.ThrowIfCancellationRequested();
                        hasVolume = true;
                        ext.Persist();
                    }
                
                    uow.Save();
                }
            }
            finally
            {
                uow?.Dispose();
            }

            if(hasVolume)
                processContext.SetVolumeGenerated();

        }

        private Bus _bus;
        protected Bus Bus
        {
            get { return _bus ?? (_bus = _resolver.Resolve<Bus>()); }
        }

        public IReadWritableTaskState GetNextTaskWithTransaction(out ITransaction transaction)
        {
            IUnitOfWork unitOfWork = null;
            transaction = null;
            int tries = 0;
            ITransaction trans = null;
            BatchTaskWrapper batchTaskWrapper = null;

            Retry:

            tries++;
            try
            {
                Bus.HandleDbCommand(new DbAction(DbActions.Transaction, () =>
                {
                    var ext = EntityContextExt<BatchTaskState>.Create();
                    unitOfWork = ext.InitiateUnitOfWork();

                    ext.ReadWithSql(Constant.SQLReadDataQueue, DateTime.UtcNow);
                    if (ext.Entity?.Count > 0)
                    {
                        trans = new TransactionWrapper(unitOfWork); //todo what if db connection lost
                        batchTaskWrapper = new BatchTaskWrapper(ext.Entity.First());
                    }
                    //else
                    //{
                    //    return null;
                    //}

                }));
                transaction = trans;
                return batchTaskWrapper;

            }
            catch (Exception)
            {
                unitOfWork?.Dispose();
                if(tries<3)
                    goto Retry;
                
                //throw;
                return null;

            }
        }
    }
}
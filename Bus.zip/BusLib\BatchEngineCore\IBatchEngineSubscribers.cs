﻿using System.Collections.Generic;
using System.Linq;
using BusLib.BatchEngineCore.Groups;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Helper;

namespace BusLib.BatchEngineCore
{
    public interface IBatchEngineSubscribers
    {
        IEnumerable<IGroupSubscriber> GetGroupSubscribers();
        IEnumerable<IProcessSubscriber> GetProcessSubscribers();
    }

    public class BatchEngineSubscribers: IBatchEngineSubscribers
    {
        private readonly IReadOnlyList<IGroupSubscriber> _groupSubscribers; 
        private readonly IReadOnlyList<IProcessSubscriber> _processSubscribers; 

        public BatchEngineSubscribers(IResolver resolver)
        {
            _groupSubscribers = resolver.Resolve<IEnumerable<IGroupSubscriber>>().ToList();
            _processSubscribers = resolver.Resolve<IEnumerable<IProcessSubscriber>>().ToList();
        }

        public IEnumerable<IGroupSubscriber> GetGroupSubscribers()
        {
            return _groupSubscribers;//.AsReadOnly();
        }

        public IEnumerable<IProcessSubscriber> GetProcessSubscribers()
        {
            return _processSubscribers;
        }
    }



}
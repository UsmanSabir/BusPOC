﻿using System;
using NS.ORM.Helper;
using NS.ORM.SqlLoggers;

namespace NS.ORM
{
    /// <summary>
    /// Global configuration store for ORM
    /// </summary>
    public class GlobalConfig
    {
        #region Singleton

        private GlobalConfig()
        {
            
        }

        static readonly Lazy<GlobalConfig> _lazyInstance=new Lazy<GlobalConfig>((() => new GlobalConfig()));

        /// <summary>
        /// Global configurations of ORM
        /// </summary>
        public static GlobalConfig Configurations => _lazyInstance.Value;


        #endregion

        /// <summary>
        /// Sql logger
        /// </summary>
        public ISqlLogger SqlLogger { get; set; } = null;


        /// <summary>
        /// EnableSqlLogging
        /// </summary>
        public bool EnableSqlLogging { get; set; } = true;

        /// <summary>
        /// Enable/disable logging of each command executing through ORM. An expensive operaion with performance overhead. Use with caution.
        /// </summary>
        public bool EnableSqlDeepLogging { get; set; } = false;

        /// <summary>
        /// 
        /// </summary>
        public Action ConnectionClosedActon { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Action CommandExecutingAction { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Action ConnectionOpenedActon { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Action ConnectionOpeningActon { get; set; } 
                                                             
        /// <summary>
        /// 
        /// </summary>
        public Action<Exception> ErrorAction { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Action CommandExecutedAction { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Action<Action> DbCallWrapper { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Action<Action> DbTransactionWrapper { get; set; }
    }
}
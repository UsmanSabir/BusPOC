﻿using System.Collections.Concurrent;
using NS.BaseModels;
using NS.Utilities.Configuration;
using NS.Utilities.Helper;
using System.Collections.Generic;
using System.Linq;
namespace NS.ORM
{
    /// <summary>
    /// This class is for Server Validation
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ServerValidator<T> where T : BaseModel, new()
    {
        // ReSharper disable once FieldCanBeMadeReadOnly.Local
        // ReSharper disable once InconsistentNaming
        // ReSharper disable once StaticMemberInGenericType
        private static ConcurrentDictionary<int, Dictionary<string, string>> screenValidation = new ConcurrentDictionary<int, Dictionary<string, string>>();

        /// <summary>
        /// Validation on Save.
        /// </summary>
        /// <param name="action"> Action Id </param>
        /// <param name="target"> Source for Validate</param>
        /// <param name="screenId"> Screen Id </param>
        /// <param name="langId"> Language Id </param>
        /// <param name="appCode"> Application Code </param>
        /// <param name="subTenentId">Sub Tenent Id</param>
        /// <para>[WB] 07/11/2017  1.0 Method Updated.</para>>
        /// <para>[WB] 9/25/2017  1.0 Method Updated.</para>>
        /// <returns></returns>
        public static bool ValidateEntity(string action, T target, int screenId, int langId, string appCode,int subTenentId)
        {
            var list = new List<T> { target };
            var c = new EntityContext<T>(list)
            {
                ValidationSettingsProviderFactory = entityName =>
                {
                    var entityxml = string.Empty;
                    Dictionary<string, string> vEDictionary;
                    screenValidation.TryGetValue(screenId, out vEDictionary);
                    if (vEDictionary == null)
                    {
                        GetMandatoryConfiguration(screenId, langId, appCode, subTenentId);
                        screenValidation.TryGetValue(screenId, out vEDictionary);
                    }
                    vEDictionary?.TryGetValue(entityName, out entityxml);
                    return entityxml;
                },
                ScreenId = screenId.ToString()
            };
            var res = c.ValidateAggregate(action);
            return res.IsValid;
        }

        /// <summary>
        /// Entity mandatory configurations
        /// </summary>
        /// <returns> void </returns> 
        /// <para>[WB] 07/11/2017  1.0 Method Updated.</para>>
        /// <para>[WB] 9/25/2017  1.0 Method Updated.</para>>
        private static void GetMandatoryConfiguration(int screenId, int langId, string appCode, int subTenentId)
        {
            var controller = DbController.Create(GetUmsConnectionString());
            var vDictionary = new Dictionary<string, string>();
            string sql = $"select SCAN_DATA from LOC_SCAN where SCAN_TYPE_KEY='V' and SCRN_ID={screenId} and LANG_ID={langId} AND APPL_KEY ='{appCode}' AND SUB_TNNT_ID ={subTenentId}";
            var list = controller.GetCustomList<string>(sql);
            foreach (var enty in list.ToList())
            {
                var entityName = XmlSerializationHelper.DeSerializeFromString<EntityName>(enty);
                vDictionary.Add(entityName.Name, enty);
            }
            screenValidation.TryAdd(screenId, vDictionary);
        }
        private static string GetUmsConnectionString()
        {
            IConnectionStringSetting settings;
            var connectionString = "";
            var connectionstringName = "UserManagementDatabase";
            if (DependencyHelper.TryGetInstance(out settings, string.Empty, connectionstringName))
            {
                connectionString = settings?.ConnectionString;
            }
            return connectionString;
        }

    }

}

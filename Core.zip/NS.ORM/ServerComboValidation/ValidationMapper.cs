﻿using System.Reflection;
using NS.Utilities.ComboValidationMapping;
using System;
using System.Linq;
using System.Collections.Generic;
using NS.BaseModels;
using NS.Utilities.Helper;
using NS.Utilities.Configuration;
using NS.ORM.ServerComboValidation.Models;
using System.IO;
using NS.ExceptionHandling;
using NS.Utilities.Enums;

namespace NS.ORM.ServerComboValidation
{
    internal class ValidationMapper
    {
        static bool _hasInited = false;
        internal static void Initialize()
        {
            if (_hasInited) return;
            _hasInited = true;
            var detailedLogs = System.Configuration.ConfigurationManager.AppSettings["DetailedLogs"];
            var detailedLogsInd = false;
            if (!string.IsNullOrEmpty(detailedLogs))
            {
                detailedLogsInd = bool.Parse(detailedLogs);//try parse
            }
            var validateIndConfig = System.Configuration.ConfigurationManager.AppSettings["ServerDataValidation"];
            if (string.IsNullOrEmpty(validateIndConfig)) return;
            var validateInd = bool.Parse(validateIndConfig);
            if (!validateInd) return;
            StreamWriter sw = null;
            StreamWriter swMap = null;
            if (detailedLogsInd)
            {
                sw = new StreamWriter("D:\\DataValidationMappingLogs.txt");
                swMap = new StreamWriter("D:\\DataValidationMappingDetailsLogs.txt");
            }
            try
            {
                //StreamWriter sw = new StreamWriter("DataValidationLogs.txt");
                if (detailedLogsInd) sw.WriteLine("Data validation Mapping Started......");

                if (ServerValidationMapping.ComboValidationMappingDictionary != null) return;
                List<ScreenCodeSetupValidateComboPoco> cacheTemplateList = FillScreenCodesData();

                if (detailedLogsInd) sw.WriteLine("Loading NS.Cache.Models......");
                var cacheAssembly = Assembly.Load("NS.Cache.Models");
                //var cacheAssembly = Assembly.LoadFrom(@"D:\Shared\Source Code\WPFUI\CMS.WPF\bin\Debug\NS.Cache.Models.dll");
                if (cacheAssembly == null)
                {
                    throw new ValidationException("Unable to load assembly NS.Cache.Models");

                }
                if (detailedLogsInd) sw.WriteLine("Loaded.");
                var cacheClassesType = cacheAssembly.GetExportedTypes()?.Where(t => t.IsClass);
                if (cacheClassesType == null)
                {
                    throw new ValidationException("Classes not found in NS.Cache.Models");

                }
                Dictionary<string, MappingHierarchy> mappingDictionary = new Dictionary<string, MappingHierarchy>();

                // Cache files not found against standard naming convensions.
                var cacheNotListed = new List<string>();

                // Cache files found against standard naming convensions.
                var cacheCatered = new List<string>();
                if (detailedLogsInd) sw.WriteLine("Loading CMS.WPF.Models......");
                var currentAssembly = Assembly.Load("CMS.WPF.Models");
                //var currentAssembly = Assembly.Load("NS.WPF.Models");
                //var currentAssembly = Assembly.LoadFrom(@"D:\Shared\Source Code\WPFUI\CMS.WPF\bin\Debug\CMS.WPF.Models.dll");
                if (currentAssembly == null)
                {
                    throw new ValidationException("Unable to load assembly CMS.WPF.Models");

                }
                if (detailedLogsInd) sw.WriteLine("Loaded.");
                if (detailedLogsInd) sw.WriteLine("Loading classes from CMS.WPF.Models.");
                //var classesType = currentAssembly.GetExportedTypes().Where(t => t.IsClass && t.Name == "FaParam").ToList();
                var classesType = currentAssembly.GetExportedTypes()?.Where(t => t.IsClass).ToArray();
                if (classesType == null && classesType.Length <= 0)
                {
                    throw new ValidationException("Classes not found in CMS.WPF.Models");

                }
                if (detailedLogsInd) sw.WriteLine("Loaded.");
                if (detailedLogsInd) sw.WriteLine("Mapping Initiated.....");
                for (int index = 0; index < classesType.Length; index++)
                {
                    var classType = classesType[index];
                    var map = CreateMapping(cacheClassesType, cacheTemplateList, cacheNotListed, cacheCatered, classType, swMap, detailedLogsInd, "   ");
                    //if (map.MappingHierarchies.Count > 0 || map.MappingProperties.Count > 0)
                    if (!mappingDictionary.ContainsKey(classType.Name))
                        mappingDictionary.Add(classType.Name, map);
                }
                if (detailedLogsInd)
                {
                    sw.WriteLine("Mapping Completed!");
                    if (cacheNotListed.Count > 0)
                    {
                        sw.WriteLine("Following caches not found:");
                        foreach (var c in cacheNotListed)
                        {
                            sw.WriteLine("  - " + c);
                        }
                    }
                }
                ServerValidationMapping.ComboValidationMappingDictionary = mappingDictionary;
                if (detailedLogsInd) sw.WriteLine("Creating Lookup Lists...");
                CreateLookupLists(sw, detailedLogsInd);
                if (detailedLogsInd) sw.WriteLine("Created Lookup Lists!");
                if (detailedLogsInd) sw.WriteLine("Data validation Mapping Done Successfully!");
            }
            catch (Exception ex)
            {
                throw new ValidationException("ValidationMapping not created! " + ex.Message);
            }
            finally
            {
                if (detailedLogsInd)
                {
                    sw.Flush(); sw.Close();
                    swMap.Flush(); swMap.Close();
                }
            }
        }
        
        private static void CreateLookupLists(StreamWriter sw, bool detailedLogsInd)
        {
            if (detailedLogsInd) sw.WriteLine("Loading NS.CacheService......");
            Assembly asm = Assembly.Load("NS.CacheService");
            if (asm == null)
            {
                ExceptionHandler.HandleException(new Exception("Unable to load assembly NS.CacheService"), ExceptionHandlingPolicy.BusinessPolicy);
                return;
            }
            if (detailedLogsInd) sw.WriteLine("Loading CacheLogic......");
            var cacheLogicClass = asm.GetExportedTypes()?.FirstOrDefault(x => x.Name == "CacheLogic");
            if (cacheLogicClass == null)
            {
                ExceptionHandler.HandleException(new Exception("Classes not found in NS.CacheService"), ExceptionHandlingPolicy.BusinessPolicy);
                return;
            }
            if (detailedLogsInd) sw.WriteLine("Loading CreateLookupLists......");
            var cmsLookupsMethod = cacheLogicClass.GetMethod("CreateLookupLists");
            if (cmsLookupsMethod == null)
            {
                ExceptionHandler.HandleException(new Exception("CreateLookupLists not found in CacheLogic"), ExceptionHandlingPolicy.BusinessPolicy);
                return;
            }
            if (detailedLogsInd) sw.WriteLine("Instantiating CacheLogic object......");
            var fakeObject = Activator.CreateInstance(cacheLogicClass, new object[] { });
            if (detailedLogsInd) sw.WriteLine("Invoking CreateLookupLists Method......");
            cmsLookupsMethod.Invoke(fakeObject, new object[] { });
            if (detailedLogsInd) sw.WriteLine("Invoking Done.");
        }
        private static List<ScreenCodeSetupValidateComboPoco> FillScreenCodesData()            
        {
            var controller = DbController.Create(GetBusinessDbConnectionString());
            var vDictionary = new Dictionary<string, string>();
            string sql = $"SELECT SCRN_ID, NME, SCRN_TABL_NME, SCRN_KEY_COLN, ENTY_NME  FROM dbo.CM_SCRN_CODE";
            var context = new EntityContextExt<ScreenCodeSetupValidateComboPoco>();
            var cacheTemplateList = context.Read(x => x.ACT_IND == true).Entity;
            return cacheTemplateList;
        }
        private static string GetBusinessDbConnectionString()
        {
            IConnectionStringSetting settings;
            var connectionString = "";
            var connectionstringName = "BusinessDatabase";
            if (DependencyHelper.TryGetInstance(out settings, string.Empty, connectionstringName))
            {
                connectionString = settings?.ConnectionString;
            }
            return connectionString;
        }
      //private static Dictionary<string, MappingHierarchy> modelPropertiesDict = new Dictionary<string, MappingHierarchy>();
        private static MappingHierarchy CreateMapping(IEnumerable<Type> cacheClassesType, List<ScreenCodeSetupValidateComboPoco> cacheTemplateList, List<string> cacheNotListed, List<string> cacheCatered, Type model, StreamWriter sw, bool detailedLogsInd, string hierarchyChar)
        {
            MappingHierarchy mapping = new MappingHierarchy();            
            // If type is a standard type.
            if (IsStandardType(model)) return mapping;

            var className = GetClassName(model);
            if (IsStandardTypeString(className)) return mapping;
            
            if (detailedLogsInd)
            {
                sw.WriteLine(hierarchyChar + className + ":");
                hierarchyChar += "   ";
            }
            //if (modelPropertiesDict.TryGetValue(className, out temp))
            //    return temp;
            //modelPropertiesDict.Add(className, mapping);
            var props = model.GetProperties();

            foreach (var prop in props)
            {
                // Get all mapping properties.
                //Check here if the property is standard Type (int,str etc) other wise it should not be mapped to primary key 
                //also try try keeping cache list as sorted and apply binary search if possible for performance reasons
                var cacheTemplate = cacheTemplateList.FirstOrDefault(x => x.SCRN_KEY_COLN == prop.Name);
                if (cacheTemplate != null && cacheTemplate.ENTY_NME != null && cacheTemplate.ENTY_NME != "NULL")
                {
                    var entyName = cacheTemplate.ENTY_NME + "Cache";                    
                    if (!cacheClassesType.Any(x => x.Name == (entyName)))
                    {
                        if (!cacheNotListed.Exists(x => x == entyName)) cacheNotListed.Add(entyName);
                    }
                    //else
                    //{
                    //    if (!cacheCatered.Exists(x => x == entyName)) cacheCatered.Add(entyName); 
                    //} 

                    if (detailedLogsInd)
                        sw.WriteLine(hierarchyChar + prop.Name + " , "+ entyName);

                    mapping.MappingProperties.Add(entyName, Tuple.Create(prop.Name, cacheTemplate.SCRN_KEY_COLN));
                }

                // Get all mapping hierarchies.
                var subClassType = prop.PropertyType;
                if (IsStandardType(subClassType)) continue;
                var subClassName = GetClassName(subClassType);
                if (IsStandardTypeString(subClassName)) continue;
                // When sub Type property is same as main type property than it will overflow.
                if (className == subClassName)
                {
                    continue;
                }
                //MappingHierarchy temp1;

                //if (modelPropertiesDict.ContainsKey(prop.Name))
                //{
                //    modelPropertiesDict.TryGetValue(prop.Name, out temp1);
                //    if (mapping.MappingHierarchies.ContainsKey(prop.Name))                        
                //    if (temp1 == null)
                //        mapping.MappingHierarchies.Add(prop.Name, temp1);
                //}

                var subMap = CreateMapping(cacheClassesType, cacheTemplateList, cacheNotListed, cacheCatered, subClassType, sw, detailedLogsInd, hierarchyChar + "   ");
                if (subMap.MappingProperties.Count > 0 || subMap.MappingHierarchies.Count > 0)
                {
                    var propSubName = prop.Name;
                    if (detailedLogsInd)
                        sw.WriteLine(hierarchyChar + propSubName + ":");
                    if (!mapping.MappingHierarchies.ContainsKey(propSubName))
                        mapping.MappingHierarchies.Add(propSubName, subMap);
                }
            }            
            return mapping;
        }


        private static string GetClassName(Type classType)
        {
            var className = classType.Name;
            if (className.Contains("`") && classType.GenericTypeArguments.Length > 0)
            {
                var classTypeParts = className.Split('`');
                var classPropertyType = classType.GenericTypeArguments[0].Name;
                return classPropertyType;
            }
            else
            {
                return className;
            }
        }

        // Ignore Standard types for not extracting and parsing its sub types and properties.
        private static bool IsStandardType(Type classType)
        {
            var className = classType.Name;
            if (!classType.IsClass) return true;
            bool isValid = IsStandardTypeString(className);
            //if (!isValid && !valids.Exists(x => x== typeName))
            //valids.Add(typeName);
            return isValid;
        }

        private static bool IsStandardTypeString(string className)
        {
            string[] types = { "Boolean", "DateTime", "String", "Int32", "Decimal", "EntityState", "Byte[]", "Int64", "Object" };
            var isValid = types.Any(t => t == className);
            return isValid;
        }
    }
}

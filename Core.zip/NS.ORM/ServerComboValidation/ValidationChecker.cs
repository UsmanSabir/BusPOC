﻿using NS.BaseModels;
using NS.Utilities.ComboValidationMapping;
using System.Reflection;
using System;
using System.Linq;
using NS.ExceptionHandling;
using NS.Utilities.Enums;
using System.IO;

namespace NS.ORM.ServerComboValidation
{
    internal class ValidationChecker
    {
        internal static bool CheckCombosValidation(BaseModel model, int languageId, int companyId)
        {
            var detailedLogs = System.Configuration.ConfigurationManager.AppSettings["DetailedLogs"];
            var detailedLogsInd = false;
            if (!string.IsNullOrEmpty(detailedLogs))
            {
                detailedLogsInd = bool.Parse(detailedLogs);
            }
            StreamWriter sw = null;
            try
            {
                if (detailedLogsInd)
                    sw = new StreamWriter("D:\\DataValidationCheckingLoadingLogs.txt");
                //var validateIndConfig = System.Configuration.ConfigurationManager.AppSettings["ServerDataValidation"];
                var validateIndConfig = "true";
                if (string.IsNullOrEmpty(validateIndConfig)) return true;
                var validateInd = bool.Parse(validateIndConfig);
                if (!validateInd) return true;

                bool isValid = true;
                if (detailedLogsInd) sw.WriteLine("Validation Checking Process Initiated......");
                MappingHierarchy mapping;
                if (detailedLogsInd) sw.WriteLine("Getting Validation Mappings......");
                var mappings = ServerValidationMapping.ComboValidationMappingDictionary;
                if (mappings == null)
                {
                    Exception ex = new Exception("ComboValidationMappingDictionary is null!");
                    ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                    return false;
                }
                string modelName = model.GetType().Name;
                mappings.TryGetValue(modelName, out mapping);

                if (mapping == null)
                {
                    Exception ex = new Exception("Model: " + modelName + " not mapped when Validation mapping done!");
                    ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.BusinessPolicy);
                    return false;
                }
                if (detailedLogsInd) sw.WriteLine("Validation Mappings Got it.");
                if (detailedLogsInd) sw.WriteLine("Loading assembly NS.CacheService...");
                Assembly asm = Assembly.Load("NS.CacheService");
                if (detailedLogsInd) sw.WriteLine("Loading class cacheLogic...");
                var cacheLogicClass = asm.GetExportedTypes().FirstOrDefault(x => x.Name == "CacheLogic");
                if (detailedLogsInd) sw.WriteLine("Loading Method ParseCompleteModel...");
                var cmsLookupsMethod = cacheLogicClass.GetMethod("ParseCompleteModel");
                if (cmsLookupsMethod == null)
                {
                    ExceptionHandler.HandleException(new Exception("ParseCompleteModel not found in CacheLogic"), ExceptionHandlingPolicy.BusinessPolicy);
                    return false;
                }
                var fakeObject = Activator.CreateInstance(cacheLogicClass, new object[] { });
                if (detailedLogsInd) sw.WriteLine("Loaded all.");
                if (detailedLogsInd) sw.WriteLine("Invoking Method ParseCompleteModel...");
                var valid = cmsLookupsMethod.Invoke(fakeObject, new object[] { model, mapping, languageId, companyId });
                isValid = bool.Parse(valid.ToString());
                if (detailedLogsInd) sw.WriteLine("Validation Checking Process Completed.");
                return isValid;
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.CommunicationPolicy);
                return false;
            }
            finally
            {
                if (detailedLogsInd)
                {
                    sw.Flush();
                    sw.Close();
                }
            }
        }

        /*
        static object _fakeCacheModelsObject { get; set; }
        static Type _cmsCacheItemEnum { get; set; }
        static Type _cacheLogicClass { get; set; }
        static object _fakeCacheItemEnumObject { get; set; }
        static MethodInfo _cmsLookupsMethod { get; set; }
        static FieldInfo[] _CMSCacheItems { get; set; }
        public static bool CheckCombosValidation(BaseModel model)
        {
            bool isValid = true;
            MappingHierarchy mapping;
            var mappings = ServerValidationMapping.ComboValidationMappingDictionary;
            if (mappings == null) return isValid;
            mappings.TryGetValue(model.GetType().Name, out mapping);
            if (mapping == null) return isValid;
            isValid = ParseModel(model, new KeyValuePair<string, MappingHierarchy>(model.ToString(), mapping));
            return isValid;
        }
        private static bool GetComboValueValidity(object modelPropertyValue, string cacheName, string propertyName)
        {
            //if (_fakeCacheModelsObject == null)
            //{
            Assembly cacheModelsAsm = Assembly.Load(@"NS.Cache.Models");
            var cmsLookupsClass = cacheModelsAsm.GetExportedTypes().FirstOrDefault(x => x.Name == "CMSLookups");
            _fakeCacheModelsObject = Activator.CreateInstance(cmsLookupsClass);
            Assembly cmsCacheItemAsm = Assembly.Load(@"NS.Resources");
            _cmsCacheItemEnum = cmsCacheItemAsm.GetExportedTypes().FirstOrDefault(x => x.Name == "CmsCacheItems");
            _fakeCacheItemEnumObject = Activator.CreateInstance(_cmsCacheItemEnum);
            Assembly asm = Assembly.Load("NS.CacheService");
            _cacheLogicClass = asm.GetExportedTypes().FirstOrDefault(x => x.Name == "CacheLogic");
            _cmsLookupsMethod = _cacheLogicClass.GetMethod("FillCmsCache");
            _CMSCacheItems = _cmsCacheItemEnum.GetFields();
            //}

            //var value = ((NS.Utilities.Enums.CacheAttribute)_CMSCacheItems.GetCustomAttributes().ToList()[0]).EntityName;
            var value = _cmsCacheItemEnum.GetFields()?.FirstOrDefault(x => x.Name.ToLower() == cacheName.ToLower())?.GetValue(_fakeCacheItemEnumObject);

            value = TryGetCacheEnumField(cacheName);

            if (value == null)
            {
                ExceptionHandler.HandleException(new ArgumentException()
                {
                    Source = "Cache Enum not found against: " + value
                }
                , ExceptionHandlingPolicy.BusinessPolicy);
                return true;
            }
            var fakeObject = Activator.CreateInstance(_cacheLogicClass, new object[] { });
            _cmsLookupsMethod.Invoke(fakeObject, new object[] { value, DateTime.Now, 1, 1, _fakeCacheModelsObject });
            var lookupList = _fakeCacheModelsObject.GetType().GetProperty("Lookups").GetValue(_fakeCacheModelsObject);
            return Parse(lookupList as IEnumerable, propertyName, modelPropertyValue);
            //[0]["CRCY_ID"] = 1;
            //return true;
        }
        public static bool Parse(IEnumerable targetCollection, string propToCompare, object compareTarget)
        {
            foreach (var item in targetCollection)
            {
                var cacheData = item.GetType().GetProperty("CacheData").GetValue(item) as IEnumerable;
                foreach (var subItem in cacheData)
                {
                    var getSubItemProp = subItem.GetType().GetProperty(propToCompare);
                    if (getSubItemProp == null)
                    {
                        ExceptionHandler.HandleException(new ArgumentException()
                        {
                            Source = "Cache Property not found: " + getSubItemProp.Name + "," + propToCompare
                        }
                        , ExceptionHandlingPolicy.BusinessPolicy);
                        return true;
                    }
                    var val = getSubItemProp.GetValue(subItem);

                    //null check
                    if (compareTarget.Equals(val))
                        return true;
                }

            }
            return false;
        }
        private static bool ParseModel(BaseModel model, KeyValuePair<string, MappingHierarchy> mapping)
        {
            bool isValid = true;
            var modelType = model.GetType();
            foreach (var prop in mapping.Value.MappingProperties)
            {
                var propertyInfo = modelType.GetProperty(prop.Value.Item1);
                var modelPropertyValue = propertyInfo.GetValue(model);
                if (!GetComboValueValidity(modelPropertyValue, prop.Key, prop.Value.Item2))
                    return false;
            }
            foreach (var map in mapping.Value.MappingHierarchies)
            {
                var modelChildType = modelType.GetProperty(map.Key);
                var modelChild = modelChildType?.GetValue(model) as BaseModel;
                if (modelChild != null)
                {
                    isValid = ParseModel(modelChild, map);
                    if (!isValid) return false;
                }
            }
            return isValid;
        }

        private static object TryGetCacheEnumField(string cacheName)
        {
            //var value = _CMSCacheItems.FirstOrDefault(x => x.Name == cacheName.ToLower())?.GetValue(_fakeCacheItemEnumObject);     
            foreach (var field in _CMSCacheItems)
            {
                var entityEnum = field.GetCustomAttributes()?.FirstOrDefault()?.GetType()?.GetProperty("EntityName");
                var value = entityEnum?.GetValue(field?.GetCustomAttributes()?.FirstOrDefault());
                if (value == null)
                    continue;
                if (value.ToString() == cacheName)
                    return field.GetValue(_fakeCacheItemEnumObject);

            }
            return null;
        }
        */
    }
}

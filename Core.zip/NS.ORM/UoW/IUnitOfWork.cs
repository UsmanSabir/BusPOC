﻿using System;

namespace NS.ORM.UoW
{
    /// <summary>
    /// Provides a mechanism of handling crud operations
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Enum created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public interface IUnitOfWork : IDisposable
    {
        /// <summary>
        /// Facilitates database  operations (see <see cref="DbController"/>)
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Getter property created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        DbController Controller { get; }

        /// <summary>
        /// Persists changes on database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Signature created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        void Save();
    }
}
﻿using System;

namespace NS.ORM.UoW
{
    /// <summary>
    /// Implementation of IUnitOfWork. See <see cref="IUnitOfWork"/>
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Enum created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public sealed class UnitOfWork : IUnitOfWork
    {
        private readonly Action _saveAction;
        private readonly Action _rollbackAction;
        private readonly Func<bool> _isOpen;
        private bool _saved;
        private bool _isDisposed = false;
        /// <summary>
        /// Constructor for UnitofWork.
        /// </summary>
        /// <param name="controller">DbController</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public UnitOfWork(DbController controller)
        {
            Controller = controller;
        }

        /// <summary>
        /// Constructor for UnitofWork.
        /// </summary>
        /// <param name="controller">DbController</param>
        /// <param name="saveAction">Action to execute when committing.</param>
        /// <param name="rollbackAction">Action to execute when rollback.</param>
        /// <param name="isOpen"></param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public UnitOfWork(DbController controller, Action saveAction, Action rollbackAction, Func<bool> isOpen)
        {
            _saveAction = saveAction;
            _rollbackAction = rollbackAction;
            _isOpen = isOpen;
            Controller = controller;
        }

        /// <summary>
        /// Facilitates database  operations (see <see cref="DbController"/>)
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Getter property created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public DbController Controller { get; }

        /// <summary>
        /// Check is connection open
        /// </summary>
        /// <returns></returns>
        public bool IsOpen()
        {
            return _isOpen?.Invoke() ?? true;
        }

        /// <summary>
        /// Saves changes to database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public void Save()
        {
            _saveAction?.Invoke();
            _saved = true;
        }

        /// <summary>
        /// Disposes and performs rollback if saved is not executed.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// <para>[AQ] 03/07/2017  2.0 Method modified.</para>
        /// </remarks>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        /// <summary>
        /// Custom Dispose(bool) Implementation. Takes care of Managed and Unmanaged resources
        /// </summary>
        /// <param name="isDisposing">A true value directs the function to clean managed resources along with unmanaged resources. A false value directs the function to clean native/un-managed resources only</param>
        /// <remarks>
        /// <para>[AQ] 03/07/2017  1.0 Method created.</para>
        /// </remarks>
        private void Dispose(bool isDisposing) {

            if (!_isDisposed) {

                if (isDisposing) {

                    //Dispose managed resource only
                    if (!_saved)
                    {
                        _rollbackAction?.Invoke();
                    }
                }
                //Dispose any unmanaged resources
                //Dispose any native resources
                //A function that disposes native/unmanaged resources only can be called here.
                _isDisposed = true;
            }
        }
    }
}
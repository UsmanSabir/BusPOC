﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using NS.BaseModels;
using NS.ORM.UoW;

namespace NS.ORM
{
    /// <summary>
    /// TransactionManager class of ORM
    /// </summary>
    public class UnitOfWorkManager:IDisposable
    {
        private readonly string _connectionString;
        private readonly bool _overrideConnectionString;

        ConcurrentQueue<Action<IUnitOfWork>> _queue = new ConcurrentQueue<Action<IUnitOfWork>>();
        private IsolationLevel _isolationLevel;
        private bool _useIsolationLevel;

        /// <summary>
        /// TransactionManager
        /// </summary>
        /// <param name="connectionString"></param>
        public UnitOfWorkManager(string connectionString)
        {
            _connectionString = connectionString;
            _overrideConnectionString = true;
        }

        /// <summary>
        /// TransactionManager
        /// </summary>
        public UnitOfWorkManager()
        {
            
        }

        /// <summary>
        /// Set Isolation level on transaction
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <returns></returns>
        public UnitOfWorkManager UsingIsolationLevel(IsolationLevel isolationLevel)
        {
            _isolationLevel = isolationLevel;
            _useIsolationLevel = true;
            return this;
        }


        /// <summary>
        /// Queue command to execute in transaction later
        /// </summary>
        /// <param name="command"></param>
        public void QueueCommand(Action<IUnitOfWork> command)
        {
            _queue.Enqueue(command);
        }

        /// <summary>
        /// Queue commands to execute in transaction later
        /// </summary>
        /// <param name="commands"></param>
        public void QueueCommand(params Action<IUnitOfWork>[] commands)
        {
            foreach (var command in commands)
            {
                _queue.Enqueue(command);
            }
        }

        /// <summary>
        /// Queue entity persist in transaction
        /// </summary>
        /// <param name="entities"></param>
        /// <typeparam name="T"></typeparam>
        public void QueuePersist<T>(List<T> entities) where T : BaseModel, new()
        {
            void Act(IUnitOfWork uow)
            {
                var ext = EntityContextExt.Create(entities).UsingUnitOfWork(uow);
                ext.Persist();
            }

            QueueCommand(Act);
        }

        DbController CreateDbController()
        {
            if(_overrideConnectionString)
                return DbController.Create(_connectionString);
            else
                return DbController.Create();
        }

        /// <summary>
        /// Execute and commit transaction
        /// </summary>
        public void Commit()
        {
            var action = GlobalConfig.Configurations.DbTransactionWrapper;
            if (action != null)
                action(ExecuteInTransaction);
            else
                ExecuteInTransaction();
        }

        private void ExecuteInTransaction()
        {
            using (var controller = CreateDbController())
            {
                if (_useIsolationLevel)
                    controller.UsingIsolationLevel(_isolationLevel);

                using (var uow = controller.UsingUnitOfWork())
                {
                    while (_queue.TryDequeue(out Action<IUnitOfWork> action))
                    {
                        action(uow);
                    }

                    uow.Save();
                }
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            _queue = null;
        }
    }
}
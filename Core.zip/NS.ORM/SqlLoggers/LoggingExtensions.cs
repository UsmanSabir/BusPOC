﻿using NS.ORM.SqlLoggers;

// ReSharper disable once CheckNamespace
namespace NS.ORM
{
    /// <summary>
    /// 
    /// </summary>
    public static class LoggingExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        public static GlobalConfig UseTraceLogging(this GlobalConfig config)
        {
            config.SqlLogger = new TraceLogger();
            return config;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        public static GlobalConfig UseConsoleLogging(this GlobalConfig config)
        {
            config.SqlLogger = new ConsoleLogger();
            return config;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="config"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static GlobalConfig UseFileLogging(this GlobalConfig config, string path)
        {
            config.SqlLogger = new FileLogger(path);
            return config;
        }
    }
}
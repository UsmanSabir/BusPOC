﻿using System;
using System.Collections.Generic;
using System.Linq;
using NS.Utilities.Helper;

namespace NS.ORM.SqlLoggers
{
    /// <summary>
    /// SlqLogger write to Debug listeners 
    /// </summary>
    public class FileLogger:ISqlLogger
    {
        private readonly string _filePath;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="filePath"></param>
        public FileLogger(string filePath)
        {
            _filePath = filePath;
        }

        /// <summary>
        /// LogSql
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        public void LogSql(string sql, params object[] parameters)
        {
            System.IO.File.AppendAllText(_filePath, $"{sql} -- {string.Join(", ", (parameters ?? new object[] { }).Select(p => p?.ToString()??"NULL"))} {Environment.NewLine}");
        }

        /// <summary>
        /// LogDeepSql
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        public void LogDeepSql(string sql, Dictionary<string, object> parameters)
        {
            System.IO.File.AppendAllText(_filePath, $"{sql} -- DEEP -- {string.Join(", ", (parameters ?? new Dictionary<string, object>()).Select(p => $"[ {p.Key} : {p.Value??"NULL"} ]"))} {Environment.NewLine}");
        }
    }
}
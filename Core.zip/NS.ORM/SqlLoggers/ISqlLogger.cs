﻿using System.Collections.Generic;

namespace NS.ORM.SqlLoggers
{
    /// <summary>
    /// Sql statments logger
    /// </summary>
    public interface ISqlLogger
    {
        /// <summary>
        /// Log sql statments
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        void LogSql(string sql, params object[] parameters);

        /// <summary>
        /// Log deep sql statments
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        void LogDeepSql(string sql, Dictionary<string,object> parameters);
    }
}
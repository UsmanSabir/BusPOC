﻿using System;
using System.Collections.Concurrent;
using NS.ORM.UoW;

namespace NS.ORM
{
    /// <summary>
    /// TransactionManager class of ORM
    /// </summary>
    public class TransactionManager:IDisposable
    {
        private string _connectionString;
        private bool _overrideConnectionString = false;

        ConcurrentQueue<Action<IUnitOfWork>> _queue = new ConcurrentQueue<Action<IUnitOfWork>>();
        private IsolationLevel _isolationLevel;
        private bool _useIsolationLevel = false;

        public TransactionManager(string connectionString)
        {
            _connectionString = connectionString;
            _overrideConnectionString = true;
        }

        public TransactionManager()
        {
            
        }

        public TransactionManager UsingIsolationLevel(IsolationLevel isolationLevel)
        {
            _isolationLevel = isolationLevel;
            _useIsolationLevel = true;
            return this;
        }


        /// <summary>
        /// Queue command to execute in transaction later
        /// </summary>
        /// <param name="command"></param>
        public void QueueCommand(Action<IUnitOfWork> command)
        {
            _queue.Enqueue(command);
        }

        DbController CreateDbController()
        {
            if(_overrideConnectionString)
                return DbController.Create(_connectionString);
            else
                return DbController.Create();
        }

        /// <summary>
        /// Execute and commit transaction
        /// </summary>
        public void Commit()
        {
            var action = GlobalConfig.Configurations.DbTransactionWrapper;
            if (action != null)
                action(ExecuteInTransaction);
            else
                ExecuteInTransaction();
        }

        private void ExecuteInTransaction()
        {
            using (var controller = CreateDbController())
            {
                if (_useIsolationLevel)
                    controller.UsingIsolationLevel(this._isolationLevel);

                using (var uow = controller.UsingUnitOfWork())
                {
                    while (_queue.TryDequeue(out Action<IUnitOfWork> action))
                    {
                        action(uow);
                    }

                    uow.Save();
                }
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            _queue = null;
        }
    }
}
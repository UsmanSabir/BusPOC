﻿using System;
using System.Data;

namespace NS.ORM.Definitions.Classes
{
    /// <summary>
    /// Wrapper interface for IDataReader (see <see cref="IDataReader"/>)
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Interface created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public interface IDbReader : IDataReader
	{
        /// <summary>
        /// Property to get InnerDataReader
        /// </summary>
        /// <returns> A <see cref="IDataReader"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Propety Created</para>
        /// </remarks>
		IDataReader InnerReader { get; }

        /// <summary>
        /// Method that returns boolean
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="bool"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
        bool GetBoolean(string name);

        /// <summary>
        /// Method that returns byte
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="byte"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		byte GetByte(string name);

        /// <summary>
        /// Method that returns long type value
        /// </summary>
        /// <param name="name"></param>
        /// <param name="fieldOffset"></param>
        /// <param name="buffer"></param>
        /// <param name="bufferoffset"></param>
        /// <param name="length"></param>
        /// <returns> A <see cref="long"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		long GetBytes(string name, long fieldOffset, byte[] buffer, int bufferoffset, int length);

        /// <summary>
        /// Method that returns char
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="char"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		char GetChar(string name);

        /// <summary>
        /// Method that returns long type value
        /// </summary>
        /// <param name="name"></param>
        /// <param name="fieldoffset"></param>
        /// <param name="buffer"></param>
        /// <param name="bufferoffset"></param>
        /// <param name="length"></param>
        /// <returns> A <see cref="long"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		long GetChars(string name, long fieldoffset, char[] buffer, int bufferoffset, int length);

        /// <summary>
        /// Method that returns string
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="string"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		string GetDataTypeName(string name);

        /// <summary>
        /// Method that returns DateTime object
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="DateTime"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		DateTime GetDateTime(string name);

        /// <summary>
        /// Method that returns decimal value
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="decimal"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		decimal GetDecimal(string name);

        /// <summary>
        /// Method that returns double value
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="double"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		double GetDouble(string name);

        /// <summary>
        /// Method that returns Type object
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="Type"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		Type GetFieldType(string name);

        /// <summary>
        /// Method that returns float value
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="float"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		float GetFloat(string name);

        /// <summary>
        /// Method that returns Guid type value
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="Guid"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		Guid GetGuid(string name);

        /// <summary>
        /// Method that returns short type value
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="short"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		short GetInt16(string name);

        /// <summary>
        /// Method that returns int value
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="int"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		int GetInt32(string name);

        /// <summary>
        /// Method that returns long type value
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="long"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		long GetInt64(string name);

        /// <summary>
        /// Method that returns string
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="string"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		string GetName(string name);

        /// <summary>
        /// Method that returns string
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="string"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		string GetString(string name);

        /// <summary>
        /// Method that returns object
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="object"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
		object GetValue(string name);
        // ReSharper disable once InconsistentNaming

        /// <summary>
        /// Method that checks DB value and returns bool
        /// </summary>
        /// <param name="name"></param>
        /// <returns> A <see cref="bool"/>
        /// </returns>
        /// <remarks>
        /// <para>[UA] 20/6/2016 1.0 Method Created</para>
        /// </remarks>
        bool IsDBNull(string name);
	}
}

﻿using System;
using System.Collections.Generic;
using NS.BaseModels;

namespace NS.ORM.Definitions.Classes
{
    /// <summary>
    /// Interface for reading entities in a multi-resultset command.
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public interface IModelReader : IDisposable
    {
        /// <summary>
        /// Get List of entities
        /// </summary>
        /// <typeparam name="T">The type of entity.</typeparam>
        /// <returns>List of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        List<T> GetList<T>() where T : BaseModel;

        /// <summary>
        /// Get List of entities by using the specified entity definition (see <see cref="BaseDefination"/>)
        /// </summary>
        /// <typeparam name="T">The type of entity.</typeparam>
        /// <param name="defination">The entity definition.</param>
        /// <returns>List of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        List<T> GetWithDefination<T>(BaseDefination defination) where T : BaseModel;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using NS.BaseModels;

namespace NS.ORM.Definitions.Classes
{
    /// <summary>
    /// Database batches chainer
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public sealed class DbBatch
    {
        #region Fields

        private readonly Action<DbBatch, IEnumerable<BaseModel>, Action<List<BaseModel>>> _initilizor;
        private bool _isSucceeded;
        private readonly List<DbBatch> _successor = new List<DbBatch>();
        private readonly Queue<DbBatch> _successorQueue = new Queue<DbBatch>();
        //List<string> queries=new List<string>();


        //List<KeyValuePair<string,Func<ModelReader,IEnumerable<DbBatch>, IList<BaseModel>>>> queries = 
        //    new List<KeyValuePair<string, Func<ModelReader, IEnumerable<DbBatch>, IList<BaseModel>>>>();
        readonly List<KeyValuePair<string, Func<IModelReader, DbBatch, List<BaseModel>>>> _queries =
            new List<KeyValuePair<string, Func<IModelReader, DbBatch, List<BaseModel>>>>();

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor for DbBatch
        /// </summary>
        /// <param name="initilizor">Intialize action</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public DbBatch(Action<DbBatch, IEnumerable<BaseModel>, Action<List<BaseModel>>> initilizor = null)
        {

            if (initilizor == null)
            {
                //throw new ArgumentNullException(nameof(initilizor));
                initilizor = (batch, models, arg3) => { };
            }

            _initilizor = initilizor;
        }

        #endregion

        #region Properties
        /// <summary>
        /// Holds the next DbBatch instance
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Getter property created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<DbBatch> Successor => _successor;

        #endregion

        #region Public Members

        //public void AddQuery<T>(string sql, 
        //    //Action action
        //    Func<ModelReader,IEnumerable<DbBatch>, IList<T>> processor
        //    ) where T: BaseModel
        //{
        //    if (sql == null)
        //        throw new ArgumentNullException(nameof(sql));

        //    queries.Add(new KeyValuePair<string, Func<ModelReader, IEnumerable<DbBatch>, IList<BaseModel>>>
        //        (sql, (Func<ModelReader, IEnumerable<DbBatch>, IList<BaseModel>>) processor));
        //}

        /// <summary>
        /// Adds query to queries collection.
        /// </summary>
        /// <param name="sql">Sql query.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public void AddQuery(string sql)
        {
            if (sql == null)
                throw new ArgumentNullException(nameof(sql));

            _queries.Add(new KeyValuePair<string, Func<IModelReader, DbBatch, List<BaseModel>>>
                (sql, EmptyProcessor));
        }

        /// <summary>
        /// Adds query to queries collection with processor function.
        /// </summary>
        /// <param name="sql">Sql query</param>
        /// <param name="processor">Query processor</param>
        /// <remarks>
        /// <para>[US] 30/08/2016  1.0 Method created.</para>
        /// </remarks>
        public void AddQuery(string sql,
            //Action action
            Func<IModelReader, DbBatch, List<BaseModel>> processor
            ) //where T : BaseModel
        {
            if (sql == null)
                throw new ArgumentNullException(nameof(sql));

            _queries.Add(new KeyValuePair<string, Func<IModelReader, DbBatch, List<BaseModel>>>
                (sql, //(Func<ModelReader, DbBatch, IList<BaseModel>>)
                processor));
        }

        /// <summary>
        /// Adds query to queries collection with processor function.
        /// </summary>
        /// <param name="sql">Sql query</param>
        /// <param name="processor">Query processor</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public void AddQuery(string sql,
            //Action action
            Func<IModelReader, DbBatch, IList<BaseModel>> processor
            ) //where T : BaseModel
        {
            if (sql == null)
                throw new ArgumentNullException(nameof(sql));

            _queries.Add(new KeyValuePair<string, Func<IModelReader, DbBatch, List<BaseModel>>>
                (sql, (reader, batch) =>
                {
                    if (processor != null)
                    {
                        var re = processor(reader, batch);
                        return re as List<BaseModel>?? re?.ToList();
                    }
                    return null;
                }));
        }

        /// <summary>
        /// Add parameter for queries
        /// </summary>
        /// <param name="name"></param>
        /// <param name="val"></param>
        public void AddParam(string name, object val)
        {
            if(ParameterList == null)
                ParameterList = new Dictionary<string, object>();

            ParameterList.Add(name, val);

        }

        internal Dictionary<string, object> ParameterList { get; set; }

        /// <summary>
        /// Gets queries from query collection.
        /// </summary>
        /// <returns>Read-only collection of query with query processor method</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public ReadOnlyCollection<KeyValuePair<string, Func<IModelReader, DbBatch, List<BaseModel>>>> GetQueries()
        {
            return _queries.AsReadOnly();//.Select(q=>q.Key).ToList().AsReadOnly();
        }

        /// <summary>
        /// Adds the specified DbBatch to successor batch queue.
        /// </summary>
        /// <param name="batch">The DbBatch to add</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public void AddSuccessor(DbBatch batch)
        {
            if (batch == null)
                throw new ArgumentNullException(nameof(batch));

            _successor.Add(batch);
            _successorQueue.Enqueue(batch);
        }

        /// <summary>
        /// Sets initializer 
        /// </summary>
        /// <param name="initVals">Enumeration of entity objects</param>
        /// <param name="postAction">Action to execute</param>
        /// <returns>True if inialization is successful</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public bool ProcessInitilizer(IEnumerable<BaseModel> initVals, Action<List<BaseModel>> postAction)
        {
            if (_isSucceeded)
                return true;

            var baseModels = initVals as IList<BaseModel> ?? initVals.ToList();
            _initilizor(this, baseModels, postAction);
            if (baseModels.Any())
                MarkAsSuccess();

            //_isSucceeded = true;
            return true;
        }


        internal void MarkAsSuccess()
        {
            _isSucceeded = true;
        }

        /// <summary>
        /// Gets next batch from successor queue
        /// </summary>
        /// <returns>DbBatch</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public DbBatch RetrieveSuccessor()
        {
            return _successorQueue.Dequeue();

        }

        /// <summary>
        /// Gets next batch from successor queue
        /// </summary>
        /// <returns>Enumeration of DbBatch.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public IEnumerable<DbBatch> GetNextBatch()
        {
            yield return this;

            foreach (DbBatch dbBatch in _successor.Where(s => s._isSucceeded).SelectMany(s => s.GetNextBatch()))
            {
                yield return dbBatch;
            }
        }

        #endregion

        #region Private Members

        private List<BaseModel> EmptyProcessor(IModelReader arg1, DbBatch arg2)
        {
            return null;
        }

        //HACK: removed unused method
        //IEnumerable<DbBatch> GetNextBatchAndSelf()
        //{
        //    yield return this;
        //    foreach (DbBatch dbBatch in _successor.Where(s => s._isSucceeded))
        //    {
        //        yield return dbBatch;
        //    }
        //}

        #endregion
    }
}
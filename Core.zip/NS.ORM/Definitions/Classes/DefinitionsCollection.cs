﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NS.BaseModels;

namespace NS.ORM.Definitions.Classes
{
    /// <summary>
    /// Holds collection of BaseModel to BaseDefintion registrations.
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public sealed class DefinitionsCollection
    {
        private static DefinitionsCollection _instance;

        /// <summary>
        /// Singleton of DefinitionsCollection that will be used to register entities
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Getter property created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>        
        /// </remarks>
        public static DefinitionsCollection Instance => _instance ?? (_instance = new DefinitionsCollection());

        private readonly ConcurrentDictionary<Type, Lazy<BaseDefination>> _typeDefinations;

        static DefinitionsCollection()
        {
            _instance=new DefinitionsCollection();
        }

        /// <summary>
        /// Constructor for DefinitionsCollection
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public DefinitionsCollection()
        {
            _typeDefinations=new ConcurrentDictionary<Type, Lazy<BaseDefination>>();
            
            //_typeDefinations.Add(typeof(Product), new Lazy<BaseDefination>(()=> new ProductDefinationNext()));
        }

        /// <summary>
        /// Resolves entity type to defintion.
        /// </summary>
        /// <param name="type">The entity type to resolve.</param>
        /// <returns>The entity definition.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public BaseDefination GetModelDefinationNext(Type type)
        {
           if (_typeDefinations.ContainsKey(type))
                return _typeDefinations[type].Value;
            
            var pDef = type.Name + "Definition";

            if (!_assmInitilized)
            {
                _assmInitilized = true;

                //var loadedAssemblies = AppDomain.CurrentDomain.GetAssemblies().Concat(new List<Assembly>(){System.Reflection.Assembly.GetExecutingAssembly()}).ToList();

                //loadedAssemblies
                //    .SelectMany(x => x.GetReferencedAssemblies())
                //    .Distinct()
                //    .Where(y => loadedAssemblies.Any((a) => a.FullName == y.FullName) == false)
                //    .ToList()
                //    .ForEach(x => loadedAssemblies.Add(AppDomain.CurrentDomain.Load(x)));

                //                var loadedAssemblies1 = AppDomain.CurrentDomain.GetAssemblies().Concat(new List<Assembly>(){System.Reflection.Assembly.GetExecutingAssembly()}).ToList();

                //var refasm = loadedAssemblies1.SelectMany(x => x.GetReferencedAssemblies());
                //Debug.WriteLine(refasm.Count());

                var loadedAssemblies = AppDomain.CurrentDomain.GetAssemblies().ToList();
                var loadedPaths = loadedAssemblies.Select(a =>
                {
                    try
                    {
                        return a.Location;
                    }
                    catch (Exception)
                    {
                        return null;
                    }
                }).Where(a=>!string.IsNullOrEmpty(a)).ToArray();

                var referencedPaths = Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory, "*.dll"); //*.Definitions.dll
                var toLoad =
                    referencedPaths.Where(r => !loadedPaths.Contains(r, StringComparer.InvariantCultureIgnoreCase))
                        .ToList();
                toLoad.ForEach(
                    path =>
                    {
                        try
                        {
                            loadedAssemblies.Add(AppDomain.CurrentDomain.Load(AssemblyName.GetAssemblyName(path)));
                        }
                        catch (Exception)
                        {
                            // ignored
                        }
                    });
            }

            var asmbs = AppDomain.CurrentDomain.GetAssemblies();
            Type orDefault = asmbs.SelectMany(s =>
            {
                try
                {
                    return s.GetTypes();
                }
                catch (ReflectionTypeLoadException ex)
                {
                    return ex.Types.Where(x => x != null);
                }
                catch (Exception)
                {
                    // ignored
                }
                return new Type[] {};

            }).FirstOrDefault(a=>a!=null && a.Name==pDef);
            if (orDefault != null)
            {
                _typeDefinations.TryAdd(type, new Lazy<BaseDefination>(() => (BaseDefination)Activator.CreateInstance(orDefault)));
                return _typeDefinations[type].Value;
            }

            throw new KeyNotFoundException("Defination not found for type "+ type.FullName);
/*
            return null; 
*/
        }

        private bool _assmInitilized;

        internal void Register(Type type, Func<BaseDefination> definationInitilizer)
        {
            //TODO: type check of type param for BaseModel class
            _typeDefinations.TryAdd(type, new Lazy<BaseDefination>(definationInitilizer));
        }

        /// <summary>
        /// Registers entity type and its definition.
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <typeparam name="TDef">The entity definition</typeparam>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public void Register<T,TDef>() where T: BaseModel where TDef: BaseDefination
        {
            var type = typeof(T);
            if(!_typeDefinations.ContainsKey(type))
                _typeDefinations.TryAdd(type, new Lazy<BaseDefination>(Activator.CreateInstance<TDef>));
        }
    }
}

﻿namespace NS.ORM.Definitions
{
    /// <summary>
    /// Enum to specify Update method.
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Enum created.</para>
    /// <para>[ZA] 24/02/2016  1.0 Documentation added.</para>
    /// </remarks>
    public enum UpdateMethod
    {
        /// <summary>
        /// Update record
        /// </summary>
        /// /// <remarks>
        /// <para>[ZA]  24/02/2016  1.0 Documentation added.</para>
        /// </remarks>
        Update = 0,

        /// <summary>
        /// First delete and then insert a new record
        /// </summary>
        /// <remarks>
        /// <para>[ZA]  24/02/2016  1.0 Documentation added.</para>
        /// </remarks>
        DeleteThenInsert
    }
}

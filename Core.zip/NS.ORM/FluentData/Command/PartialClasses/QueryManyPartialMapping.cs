﻿using System;
using System.Collections.Generic;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
    internal sealed partial class DbCommand
	{
        public TList QueryManyPartialMapping<TEntity, TList>(Action<TEntity, IDbReader> partialMapper)
            where TList : IList<TEntity>
		{
			var items = default(TList);

			Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
			{
				items = new QueryHandler<TEntity>(Data).ExecuteMany<TList>(null, null, partialMapper);
			});

			return items;
		}

        public TList QueryManyPartialMapping<TEntity, TList>(Action<TEntity, dynamic> partialMapper) where TList : IList<TEntity>
		{
			var items = default(TList);

			Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
			{
				items = new QueryHandler<TEntity>(Data).ExecuteMany<TList>(null, null, partialMapper);
			});

			return items;
	    }

	    
	}
}

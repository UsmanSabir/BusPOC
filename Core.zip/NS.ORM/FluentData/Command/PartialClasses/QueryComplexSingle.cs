﻿using System;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
    internal sealed partial class DbCommand
	{
		public TEntity QueryComplexSingle<TEntity>(Func<IDbReader, TEntity> customMapper)
		{
			var item = default(TEntity);

			Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
			{
				if (Data.Reader.Read())
					item = customMapper(Data.Reader);
			});

			return item;
		}

		public TEntity QueryComplexSingle<TEntity>(Func<dynamic, TEntity> customMapper)
		{
			var item = default(TEntity);

			Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
			{
				if (Data.Reader.Read())
					item = customMapper(new DynamicDataReader(Data.Reader));
			});

			return item;
		}
	}
}

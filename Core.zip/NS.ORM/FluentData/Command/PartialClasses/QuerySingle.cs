﻿using System;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
    internal sealed partial class DbCommand
    {
        public TEntity QuerySingle<TEntity>(Action<TEntity, IDbReader> customMapper)
        {
            var item = default(TEntity);

            Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
            {
                item = new QueryHandler<TEntity>(Data).ExecuteSingle(null, null, customMapper);
            });

            return item;
        }

        public TEntity QuerySingle<TEntity>(Action<TEntity, dynamic> customMapper)
        {
            var item = default(TEntity);

            Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
            {
                //HACK: bug fixed, it was always calling IDbReader action
                //existing
                //item = new QueryHandler<TEntity>(Data).ExecuteSingle(customMapper, null);
                item = new QueryHandler<TEntity>(Data).ExecuteSingle(null, customMapper);
            });

            return item;
        }
    }
}
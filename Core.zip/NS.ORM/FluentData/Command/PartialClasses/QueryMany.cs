﻿using System;
using System.Collections.Generic;
using System.Data;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
    internal sealed partial class DbCommand
	{
        public TList QueryMany<TEntity, TList>(Action<TEntity, IDbReader> customMapper = null)
            where TList : IList<TEntity>
		{
			var items = default(TList);

            Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
            {
                //HACK: 
                //items = new QueryHandler<TEntity>(Data).ExecuteMany<TList>(customMapper, null);
                items = new QueryHandler<TEntity>(Data).ExecuteMany<TList>(null, null, customMapper);
            });

			return items;
		}

	    public TList QueryMany<TEntity, TList>(Action<TEntity, dynamic> customMapper) where TList : IList<TEntity>
		{
			var items = default(TList);

			Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
			{
				items = new QueryHandler<TEntity>(Data).ExecuteMany<TList>(null, customMapper);
			});

			return items;
	    }


        public List<TEntity> QueryMany<TEntity>(Action<TEntity, IDbReader> customMapper)
	    {
	        //return Data.Context.Data.FluentDataProvider.QueryMany<TEntity, List<TEntity>>(Data, customMapper);
            //HACK: existing
			return QueryMany<TEntity, List<TEntity>>(customMapper);
		}

		public List<TEntity> QueryMany<TEntity>(Action<TEntity, dynamic> customMapper)
		{
			return QueryMany<TEntity, List<TEntity>>(customMapper);
		}

		public DataTable QueryManyDataTable()
		{
			var dataTable = new DataTable();

			Data.ExecuteQueryHandler.ExecuteQuery(true, () => dataTable.Load(Data.Reader.InnerReader, LoadOption.OverwriteChanges));

			return dataTable;
		}
	}
}

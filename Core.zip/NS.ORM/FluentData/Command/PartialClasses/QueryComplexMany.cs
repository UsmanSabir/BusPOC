﻿using System;
using System.Collections.Generic;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
    internal sealed partial class DbCommand
	{
		public void QueryComplexMany<TEntity>(IList<TEntity> list, Action<IList<TEntity>, IDbReader> customMapper)
		{
			Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
			{
				while(Data.Reader.Read())
					customMapper(list, Data.Reader);
			});
		}

		public void QueryComplexMany<TEntity>(IList<TEntity> list, Action<IList<TEntity>, dynamic> customMapper)
		{
			Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
			{
				while (Data.Reader.Read())
					customMapper(list, Data.Reader);
			});
		}
	}
}

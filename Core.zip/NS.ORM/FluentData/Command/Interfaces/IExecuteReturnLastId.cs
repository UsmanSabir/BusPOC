﻿using System;

namespace NS.ORM.FluentData.Command
{
    internal interface IExecuteReturnLastId
    {
        T ExecuteReturnLastId<T>(string identityColumnName = null);        
    }
}
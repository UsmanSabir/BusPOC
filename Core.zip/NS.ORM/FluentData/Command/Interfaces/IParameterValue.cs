﻿namespace NS.ORM.FluentData.Command
{
    internal interface IParameterValue
    {
        TParameterType ParameterValue<TParameterType>(string outputParameterName);        
    }
}
﻿namespace NS.ORM.FluentData.Command
{
    internal interface IExecute
    {
        int Execute();        
    }
}
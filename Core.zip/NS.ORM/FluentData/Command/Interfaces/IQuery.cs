﻿using System;
using System.Collections.Generic;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
    internal interface IQuery
    {
        //List<object> QueryMany(Type customMapper, Action<object, IDbReader> action);


        List<TEntity> QueryMany<TEntity>(Action<TEntity, IDbReader> customMapper = null);
        List<TEntity> QueryMany<TEntity>(Action<TEntity, dynamic> customMapper);
        TList QueryMany<TEntity, TList>(Action<TEntity, IDbReader> customMapper = null) where TList : IList<TEntity>;
        TList QueryManyPartialMapping<TEntity, TList>(Action<TEntity, dynamic> partialMapper) where TList : IList<TEntity>;
        TList QueryManyPartialMapping<TEntity, TList>(Action<TEntity, IDbReader> partialMapper) where TList : IList<TEntity>;
        TList QueryMany<TEntity, TList>(Action<TEntity, dynamic> customMapper) where TList : IList<TEntity>;
        
        void QueryComplexMany<TEntity>(IList<TEntity> list, Action<IList<TEntity>, IDbReader> customMapper);
        void QueryComplexMany<TEntity>(IList<TEntity> list, Action<IList<TEntity>, dynamic> customMapper);
        TEntity QuerySingle<TEntity>(Action<TEntity, IDbReader> customMapper = null);
        TEntity QuerySingle<TEntity>(Action<TEntity, dynamic> customMapper);
        TEntity QuerySinglePartialMapping<TEntity>(Action<TEntity, IDbReader> partialMapper);
        TEntity QuerySinglePartialMapping<TEntity>(Action<TEntity, dynamic> partialMapper);
        
        TEntity QueryComplexSingle<TEntity>(Func<IDbReader, TEntity> customMapper);
        TEntity QueryComplexSingle<TEntity>(Func<dynamic, TEntity> customMapper);

       
    }
}
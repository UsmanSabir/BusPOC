﻿using System.Data;
using System.Text;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
	internal sealed class DbCommandData
	{
		public DbContext Context { get; private set; }
		public System.Data.IDbCommand InnerCommand { get; }
		public bool UseMultipleResultsets { get; set; }
        public IDbReader Reader { get; set; }
	    public ExecuteQueryHandler ExecuteQueryHandler { get; set; }
		public StringBuilder Sql { get; private set; }

		public DbCommandData(DbContext context, System.Data.IDbCommand innerCommand)
		{
			Context = context;
			InnerCommand = innerCommand;
			InnerCommand.CommandType = (CommandType)DbCommandTypes.Text;
			Sql = new StringBuilder();
		}
	}
}

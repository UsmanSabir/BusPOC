﻿using System;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
	internal sealed class QueryCustomEntityHandler<TEntity> : IQueryTypeHandler<TEntity>
	{
		//private readonly AutoMapper _autoMapper;//HACK: disabled built-in auto map
        private readonly DbCommandData _data;

		public QueryCustomEntityHandler(DbCommandData data)
		{
			_data = data;
			//_autoMapper = new AutoMapper(_data, typeof(TEntity));//HACK: disabled built-in auto map
		}

		public bool IterateDataReader { get { return true; } }

        //HACK: added new argument
        public object HandleType(Action<TEntity, IDbReader> customMapperReader, Action<TEntity, dynamic> customMapperDynamic, Action<TEntity, IDbReader> partialMapperReader)
		{
			var item = (TEntity)_data.Context.Data.EntityFactory.Create(typeof(TEntity));

			if (customMapperReader != null)
				customMapperReader(item, _data.Reader);
			else if (customMapperDynamic != null)
			    customMapperDynamic(item, new DynamicDataReader(_data.Reader.InnerReader));
			else
			{
                //_autoMapper.AutoMap(item);  

			    if (partialMapperReader == null)
                    throw new InvalidOperationException("Custom mapper provided is null for type: " + typeof(TEntity).Name);

                partialMapperReader(item,_data.Reader);

            }

            return item;
		}
	}
}

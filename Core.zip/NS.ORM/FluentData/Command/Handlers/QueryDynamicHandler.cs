﻿using System;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
	internal sealed class QueryDynamicHandler<TEntity> : IQueryTypeHandler<TEntity>
	{
	    // ReSharper disable once PrivateFieldCanBeConvertedToLocalVariable
		private readonly DbCommandData _data;
		private readonly DynamicTypeAutoMapper _autoMapper;

		public bool IterateDataReader { get { return true; } }

		public QueryDynamicHandler(DbCommandData data)
		{
			_data = data;
			_autoMapper = new DynamicTypeAutoMapper(_data.Reader.InnerReader);
		}

        public object HandleType(Action<TEntity, IDbReader> customMapperReader, Action<TEntity, dynamic> customMapperDynamic, Action<TEntity, IDbReader> partialMapperReader)
		{
			var item = _autoMapper.AutoMap();
			return item;
		}
	}
}

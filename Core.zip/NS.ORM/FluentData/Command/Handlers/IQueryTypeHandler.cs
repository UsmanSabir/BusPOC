﻿using System;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
	internal interface IQueryTypeHandler<TEntity>
	{
		bool IterateDataReader { get; }
		//object HandleType(Action<TEntity, IDbReader> customMapperReader, Action<TEntity, dynamic> customMapperDynamic);
	    object HandleType(Action<TEntity, IDbReader> customMapperReader, Action<TEntity, dynamic> customMapperDynamic,
	        Action<TEntity, IDbReader> partialMapperReader);
	}
}
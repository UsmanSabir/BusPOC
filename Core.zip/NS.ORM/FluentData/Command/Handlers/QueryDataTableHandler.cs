﻿using System;
using System.Data;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
	internal sealed class QueryDataTableHandler<TEntity> : IQueryTypeHandler<TEntity>
	{
		private readonly DbCommandData _data;

		public bool IterateDataReader { get { return false; } }

		public QueryDataTableHandler(DbCommandData data)
		{
			_data = data;
		}

        public object HandleType(Action<TEntity, IDbReader> customMapperReader, Action<TEntity, dynamic> customMapperDynamic, Action<TEntity, IDbReader> partialMapperReader)
		{
			var dataTable = new DataTable();
			dataTable.Load(_data.Reader.InnerReader, LoadOption.OverwriteChanges);
			
			return dataTable;
		}
	}
}

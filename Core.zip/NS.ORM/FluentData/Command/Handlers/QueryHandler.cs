﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using NS.ORM.Definitions.Classes;
using NS.ORM.Helper;

namespace NS.ORM.FluentData.Command
{
    internal sealed class QueryHandler<TEntity>
    {
	    private readonly DbCommandData _data;
	    private readonly IQueryTypeHandler<TEntity> _typeHandler;

	    public QueryHandler(DbCommandData data)
	    {
		    _data = data;
			if (typeof(TEntity) == typeof(object) || typeof(TEntity) == typeof(ExpandoObject))
				_typeHandler = new QueryDynamicHandler<TEntity>(data);
			else if (typeof(TEntity) == typeof(DataTable))
				_typeHandler = new QueryDataTableHandler<TEntity>(data);
			else if (ReflectionHelper.IsCustomEntity<TEntity>())
				_typeHandler = new QueryCustomEntityHandler<TEntity>(data);
			else
				_typeHandler = new QueryScalarHandler<TEntity>(data);
		}

        public TList ExecuteMany<TList>(Action<TEntity, IDbReader> customMapperReader,
                                    Action<TEntity, dynamic> customMapperDynamic, Action<TEntity, IDbReader> partialMapperReader = null
					)
			where TList : IList<TEntity>
		{
			var items = (TList)_data.Context.Data.EntityFactory.Create(typeof(TList));
		    var reader = _data.Reader.InnerReader;
			
			if (_typeHandler.IterateDataReader)
			{
				while (reader.Read())
				{
                    var item = (TEntity)_typeHandler.HandleType(customMapperReader, customMapperDynamic, partialMapperReader);
					items.Add(item);
				}
			}
			else
			{
                var item = (TEntity)_typeHandler.HandleType(customMapperReader, customMapperDynamic,partialMapperReader);
				items.Add(item);
			}

			return items;
		}

        //HACK: 
        internal IList<TEntity> ExecuteMany(Type type, Action<TEntity, IDbReader> customMapperReader,
                                    Action<TEntity, dynamic> customMapperDynamic, Action<TEntity, IDbReader> partialMapperReader = null
                    )
        {
            var items = (IList<TEntity>)_data.Context.Data.EntityFactory.Create(type);
            var reader = _data.Reader.InnerReader;

            if (_typeHandler.IterateDataReader)
            {
                while (reader.Read())
                {
                    var item = (TEntity)_typeHandler.HandleType(customMapperReader, customMapperDynamic, partialMapperReader);
                    items.Add(item);
                }
            }
            else
            {
                var item = (TEntity)_typeHandler.HandleType(customMapperReader, customMapperDynamic, partialMapperReader);
                items.Add(item);
            }

            return items;
        }

        internal TEntity ExecuteSingle(Action<TEntity, IDbReader> customMapperReader,
                                   Action<TEntity, dynamic> customMapperDynamic, Action<TEntity, IDbReader> partialMapperReader = null)
		{
			var item = default(TEntity);
			if (!_typeHandler.IterateDataReader || _data.Reader.InnerReader.Read())
                item = (TEntity)_typeHandler.HandleType(customMapperReader, customMapperDynamic, partialMapperReader);
				
			return item;
		}
    }
}

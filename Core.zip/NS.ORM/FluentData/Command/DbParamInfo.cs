﻿namespace NS.ORM.FluentData.Command
{
    internal class DbParamInfo
    {
        public DbParamInfo()
        {
            DbType = DataTypes.Object;
        }

        public DataTypes DbType { get; set; }

        public string Name { get; set; }

        public object Value { get; set; }
    }
}
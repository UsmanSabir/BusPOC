﻿
using NS.ORM.FluentData.Command;
using System.Data.SqlClient;

namespace NS.ORM.FluentData.Builders
{
    internal interface IBulkInsertBuilder<T> : IExecute
    {
        IBulkInsertBuilder<T> SetEventHandler(int notifyAfter,SqlRowsCopiedEventHandler handler);
        IBulkInsertBuilder<T> SetBulkCopyOption(SqlBulkCopyOptions bulkOption);
        int ExecuteMany();
    }
}

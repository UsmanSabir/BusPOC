﻿
using NS.ORM.FluentData.Command;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace NS.ORM.FluentData.Builders
{
    internal sealed class BulkInsertBuilder<T> : IBulkInsertBuilder<T>
    {
        IDbCommand command;
        public ObjectDataReader<T> Data { get; set; }
        public string TableName;
        public IEnumerable<string> ClrDbMapping;
        SqlBulkCopyOptions bulkCopyOption = SqlBulkCopyOptions.Default;
        int _batchSize;
        int _notifyAfter;
        SqlRowsCopiedEventHandler bulkRowsHandler;

        internal BulkInsertBuilder(IDbCommand dbCommand, IEnumerable<T> items, List<string> clrMapping, string tableName, int batchSize)
        {
            Data = new ObjectDataReader<T>(items.GetEnumerator(), clrMapping);
            TableName = tableName;
            command = dbCommand;
            ClrDbMapping = clrMapping;
            _batchSize = batchSize;
        }
        public IBulkInsertBuilder<T> SetEventHandler(int notifyAfterRecords, SqlRowsCopiedEventHandler handler)
        {
            bulkRowsHandler = handler;
            _notifyAfter = notifyAfterRecords;
            return this;
        }
        public IBulkInsertBuilder<T> SetBulkCopyOption(SqlBulkCopyOptions bulkOption)
        {
            bulkCopyOption = bulkOption;
            return this;
        }
        public int Execute()
        {
            var connection = (SqlConnection)command.Data.InnerCommand.Connection;

            using (var bulk = new SqlBulkCopy(connection.ConnectionString, bulkCopyOption))
            {
                bulk.DestinationTableName = TableName;
                foreach (var mpgm in ClrDbMapping)
                {
                    bulk.ColumnMappings.Add(mpgm, mpgm);
                }
                bulk.EnableStreaming = true;
                bulk.BatchSize = _batchSize;
                if (bulkRowsHandler != null)
                {
                    bulk.NotifyAfter = _notifyAfter;
                    bulk.SqlRowsCopied += bulkRowsHandler;
                }

                bulk.WriteToServer(Data);
            }
            return 0;
        }

        public int ExecuteMany()
        {
            var connection = (SqlConnection)command.Data.InnerCommand.Connection;
            if (command.Data.Context.Data.Transaction == null)
                command.Data.Context.Data.Transaction = command.Data.Context.Data.Connection.BeginTransaction((System.Data.IsolationLevel)command.Data.Context.Data.IsolationLevel);
            var transaction = (SqlTransaction)command.Data.Context.Data.Transaction;

            using (var bulk = new SqlBulkCopy(connection, bulkCopyOption, transaction))
            {
                bulk.DestinationTableName = TableName;
                foreach (var mpgm in ClrDbMapping)
                {
                    bulk.ColumnMappings.Add(mpgm, mpgm);
                }
                bulk.EnableStreaming = true;
                bulk.BatchSize = _batchSize;
                if (bulkRowsHandler != null)
                {
                    bulk.NotifyAfter = _notifyAfter;
                    bulk.SqlRowsCopied += bulkRowsHandler;
                }

                bulk.WriteToServer(Data);
                return 0;
                //return GetPreparedCommand().Execute();
            }
        }
        private IDbCommand GetPreparedCommand()
        {
            command.ClearSql.Sql("SELECT SCOPE_IDENTITY()");
            return command;
        }
        
    }
}

﻿using NS.ORM.FluentData.Command;

namespace NS.ORM.FluentData.Builders
{
	internal abstract class BaseInsertBuilder
	{
		public BuilderData Data { get; set; }
		protected ActionsHandler Actions { get; set; }

	    private bool _isIdentityInsert = false;

	    public BaseInsertBuilder(IDbCommand command, string name,bool isIdentityInsert)
	    {
	        Data =  new BuilderData(command, name);
	        Actions = new ActionsHandler(Data);
	        _isIdentityInsert = isIdentityInsert;

	    }

        private IDbCommand GetPreparedCommand()
		{
            if(_isIdentityInsert)
			    Data.Command.ClearSql.Sql(string.Format("SET IDENTITY_INSERT {0} ON; {1}; SET IDENTITY_INSERT {0} OFF;", Data.ObjectName, Data.Command.Data.Context.Data.FluentDataProvider.GetSqlForInsertBuilder(Data)));
            else
                Data.Command.ClearSql.Sql(Data.Command.Data.Context.Data.FluentDataProvider.GetSqlForInsertBuilder(Data));
			return Data.Command;
		}

		public int Execute()
		{
			return GetPreparedCommand().Execute();
		}

		public T ExecuteReturnLastId<T>(string identityColumnName = null)
		{
			return GetPreparedCommand().ExecuteReturnLastId<T>(identityColumnName);
		}
	}
}

﻿using NS.ORM.FluentData.Command;

namespace NS.ORM.FluentData.Builders
{
	internal interface IInsertUpdateBuilderDynamic
	{
		BuilderData Data { get; }
		dynamic Item { get; }
		IInsertUpdateBuilderDynamic Column(string columnName, object value, DataTypes parameterType = DataTypes.Object, int size = 0);
		IInsertUpdateBuilderDynamic Column(string propertyName, DataTypes parameterType = DataTypes.Object, int size = 0);
	}
}

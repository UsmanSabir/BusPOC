﻿using NS.ORM.FluentData.Command;

namespace NS.ORM.FluentData.Builders
{
	internal interface IInsertUpdateBuilder
	{
		BuilderData Data { get; }
		IInsertUpdateBuilder Column(string columnName, object value, DataTypes parameterType = DataTypes.Object, int size = 0);
	}
}

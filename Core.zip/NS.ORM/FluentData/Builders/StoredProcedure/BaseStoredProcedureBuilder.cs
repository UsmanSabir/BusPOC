﻿using System;
using System.Collections.Generic;
using NS.ORM.Definitions.Classes;
using NS.ORM.FluentData.Command;

namespace NS.ORM.FluentData.Builders
{
	internal abstract class BaseStoredProcedureBuilder
	{
		public BuilderData Data { get; set; }
		protected ActionsHandler Actions { get; set; }

		public BaseStoredProcedureBuilder(IDbCommand command, string name)
		{
			Data = new BuilderData(command, name);
			Actions = new ActionsHandler(Data);
		}

		private IDbCommand GetPreparedDbCommand()
		{
			Data.Command.CommandType(DbCommandTypes.StoredProcedure);
			Data.Command.ClearSql.Sql(Data.Command.Data.Context.Data.FluentDataProvider.GetSqlForStoredProcedureBuilder(Data));
			return Data.Command;
		}

		public void Dispose()
		{
			Data.Command.Dispose();
		}

		public TParameterType ParameterValue<TParameterType>(string outputParameterName)
		{
			return Data.Command.ParameterValue<TParameterType>(outputParameterName);
		}

		public int Execute()
		{
			return GetPreparedDbCommand().Execute();
		}

        public List<TEntity> QueryMany<TEntity>(Action<TEntity, IDbReader> customMapper = null)
		{
			return GetPreparedDbCommand().QueryMany(customMapper);
		}

		public List<TEntity> QueryMany<TEntity>(Action<TEntity, dynamic> customMapper)
		{
			return GetPreparedDbCommand().QueryMany(customMapper);
		}

		public TList QueryMany<TEntity, TList>(Action<TEntity, IDbReader> customMapper = null) where TList : IList<TEntity>
		{
			return GetPreparedDbCommand().QueryMany<TEntity, TList>(customMapper);
		}

		public TList QueryMany<TEntity, TList>(Action<TEntity, dynamic> customMapper) where TList : IList<TEntity>
		{
			return GetPreparedDbCommand().QueryMany<TEntity, TList>(customMapper);
		}

        public void QueryComplexMany<TEntity>(IList<TEntity> list, Action<IList<TEntity>, IDbReader> customMapper)
		{
			GetPreparedDbCommand().QueryComplexMany(list, customMapper);
		}

		public void QueryComplexMany<TEntity>(IList<TEntity> list, Action<IList<TEntity>, dynamic> customMapper)
		{
			GetPreparedDbCommand().QueryComplexMany(list, customMapper);
		}

        public TEntity QuerySingle<TEntity>(Action<TEntity, IDbReader> customMapper = null)
		{
			return GetPreparedDbCommand().QuerySingle(customMapper);
		}

		public TEntity QuerySingle<TEntity>(Action<TEntity, dynamic> customMapper)
		{
			return GetPreparedDbCommand().QuerySingle(customMapper);
		}

		public TEntity QueryComplexSingle<TEntity>(Func<IDbReader, TEntity> customMapper)
		{
			return GetPreparedDbCommand().QueryComplexSingle(customMapper);
		}

		public TEntity QueryComplexSingle<TEntity>(Func<dynamic, TEntity> customMapper)
		{
			return GetPreparedDbCommand().QueryComplexSingle(customMapper);
		}



        #region Customized Methods
        //HACK: Custom methods.
        public TEntity QuerySinglePartialMapping<TEntity>(Action<TEntity, IDbReader> partialMapperReader)
        {
            return GetPreparedDbCommand().QuerySinglePartialMapping(partialMapperReader);
        }

        public TEntity QuerySinglePartialMapping<TEntity>(Action<TEntity, dynamic> partialMapperReader)
        {
            return GetPreparedDbCommand().QuerySinglePartialMapping(partialMapperReader);
        }

        public TList QueryManyPartialMapping<TEntity, TList>(Action<TEntity, IDbReader> partialMapper)
            where TList : IList<TEntity>
        {
            return GetPreparedDbCommand().QueryManyPartialMapping<TEntity, TList>(partialMapper);
        }

        public TList QueryManyPartialMapping<TEntity, TList>(Action<TEntity, dynamic> partialMapper) where TList : IList<TEntity>
        {
            return GetPreparedDbCommand().QueryManyPartialMapping<TEntity, TList>(partialMapper);
        } 
        #endregion

	}
}

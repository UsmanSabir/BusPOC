﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using NS.ORM.FluentData.Command;

namespace NS.ORM.FluentData
{
	internal sealed class DataReaderHelper
	{
		internal static List<DataReaderField> GetDataReaderFields(IDataReader reader)
		{
			var columns = new List<DataReaderField>();

			for (var i = 0; i < reader.FieldCount; i++)
			{
				var column = new DataReaderField(i, reader.GetName(i), reader.GetFieldType(i));

				if (columns.SingleOrDefault(x => x.LowerName == column.LowerName) == null)
					columns.Add(column);
			}

			return columns;
		}
	}
}

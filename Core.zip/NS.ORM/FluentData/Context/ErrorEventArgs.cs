﻿using System;
using System.Data;

// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable UnusedAutoPropertyAccessor.Global

namespace NS.ORM.FluentData
{
	internal sealed class ErrorEventArgs : EventArgs
	{
		public IDbCommand Command { get; private set; }
		public Exception Exception { get; set; }

		public ErrorEventArgs(IDbCommand command, Exception exception)
		{
			Command = command;
			Exception = exception;
		}
	}
}

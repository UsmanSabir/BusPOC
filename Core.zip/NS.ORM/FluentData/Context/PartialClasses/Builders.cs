﻿using System.Dynamic;
using NS.ORM.FluentData.Builders;
using System.Collections.Generic;

namespace NS.ORM.FluentData
{
	internal sealed partial class DbContext
	{
		public ISelectBuilder<TEntity> Select<TEntity>(string sql)
		{
			return new SelectBuilder<TEntity>(CreateCommand).Select(sql);
		}

		public IInsertBuilder Insert(string tableName,bool isIdentityInsert)
		{
			return new InsertBuilder(CreateCommand, tableName, isIdentityInsert);
		}

		public IInsertBuilder<T> Insert<T>(string tableName, T item,bool isIdentityInsert)
		{
			return new InsertBuilder<T>(CreateCommand, tableName, item, isIdentityInsert);
		}

		public IInsertBuilderDynamic Insert(string tableName, ExpandoObject item,bool isIdentityInsert)
		{
			return new InsertBuilderDynamic(CreateCommand, tableName, item, isIdentityInsert);
		}

		public IUpdateBuilder Update(string tableName)
		{
			return new UpdateBuilder(Data.FluentDataProvider, CreateCommand, tableName);
		}

		public IUpdateBuilder<T> Update<T>(string tableName, T item)
		{
			return new UpdateBuilder<T>(Data.FluentDataProvider, CreateCommand, tableName, item);
		}

		public IUpdateBuilderDynamic Update(string tableName, ExpandoObject item)
		{
			return new UpdateBuilderDynamic(Data.FluentDataProvider, CreateCommand, tableName, item);
		}

		public IDeleteBuilder Delete(string tableName)
		{
			return new DeleteBuilder(CreateCommand, tableName);
		}

		public IDeleteBuilder<T> Delete<T>(string tableName, T item)
		{
			return new DeleteBuilder<T>(CreateCommand, tableName, item);
		}

		private void VerifyStoredProcedureSupport()
		{
			if (!Data.FluentDataProvider.SupportsStoredProcedures)
				throw new FluentDataException("The selected database does not support stored procedures.");
		}

		public IStoredProcedureBuilder StoredProcedure(string storedProcedureName)
		{
			VerifyStoredProcedureSupport();
			return new StoredProcedureBuilder(CreateCommand, storedProcedureName);
		}

		public IStoredProcedureBuilder<T> StoredProcedure<T>(string storedProcedureName, T item)
		{
			VerifyStoredProcedureSupport();
			return new StoredProcedureBuilder<T>(CreateCommand, storedProcedureName, item);
		}

		public IStoredProcedureBuilderDynamic StoredProcedure(string storedProcedureName, ExpandoObject item)
		{
			VerifyStoredProcedureSupport();
			return new StoredProcedureBuilderDynamic(CreateCommand, storedProcedureName, item);
		}

        public IBulkInsertBuilder<T> BulkInsert<T>(IEnumerable<T> item, List<string> clrMapping, string tableName, int batchSize)
        {
            return new BulkInsertBuilder<T>(CreateCommand, item, clrMapping,tableName, batchSize);
        }
    }
}

﻿using System;
using System.Configuration;
using System.Data.Common;
using System.Diagnostics;
using System.Reflection;
using NS.Utilities.Configuration;
using NS.Utilities.Helper;

namespace NS.ORM.FluentData
{
    internal sealed partial class DbContext
    {
        #region Static Lazy Cache
        private static string _oracleProviderName;

        public static Lazy<Assembly> OracleAssembly = new Lazy<Assembly>(InitOracleAssembly);

        private static Assembly InitOracleAssembly()
        {
            var asmName = OracleAssemblyName;
            var oracleAssembly = Assembly.LoadFrom(asmName);
            return oracleAssembly;
        }

        static readonly Lazy<IDbProvider> _oracleManagedProvider = new Lazy<IDbProvider>(InitProvider);

        private static IDbProvider InitProvider()
        {
            IDbProvider p = (IDbProvider)OracleAssembly.Value.CreateInstance(OracleProviderName);
            return p;
        }

        static object _locker = new object();

        //HACK: removed redundant field initializer
        //static IDbProvider _provider = null;
        static IDbProvider _provider;
        #endregion

        public IDbContext ConnectionString(string connectionString, IDbProvider fluentDataProvider, string providerName = null)
        {
            SqlStatmentProcessor = s => s;

            if (string.IsNullOrEmpty(providerName))
            {
                if (fluentDataProvider == null)
                    throw new ArgumentNullException(nameof(fluentDataProvider), "DataProvider not provided in connection string or factory");
                providerName = fluentDataProvider.ProviderName;
            }

            if (fluentDataProvider == null)
            {
                if (string.IsNullOrWhiteSpace(providerName))
                {
                    throw new ArgumentNullException(nameof(providerName), "ProviderName not provided in connection string");
                }

                fluentDataProvider = _provider ?? (_provider = GetProvider(providerName.Trim().ToUpper()));

            }

            var adoNetProvider = DbProviderFactories.GetFactory(providerName);
            return ConnectionString(connectionString, fluentDataProvider, adoNetProvider);
        }

        IDbProvider GetProvider(string providerName)
        {
            IDbProvider fluentDataProvider;
            lock (_locker)
            {
                if (_provider != null)
                    return _provider;

                if (providerName.Equals("SYSTEM.DATA.SQLCLIENT"))
                {
                    fluentDataProvider = new SqlServerProvider();
                }
                else if (providerName.Equals("ORACLE.MANAGEDDATAACCESS.CLIENT"))
                {
                    try
                    {
                        //oracleManagedProvider = OracleAssembly.Value.CreateInstance(OracleProviderName);
                        //var type = Type.GetType("FluentData.OracleManagedProvider");
                        fluentDataProvider = _oracleManagedProvider.Value;
                        //t;// Activator.CreateInstance(type);
                        //new OracleManagedProvider();

                        SqlStatmentProcessor = s => s.Replace('@', ':');
                    }
                    catch (Exception ex)
                    {
                        if (Debugger.IsAttached)
                            Debugger.Break();

                        throw new Exception("Error creating oracle managed provider" + Environment.NewLine + ex.Message, ex);
                    }
                }
                else if (providerName.Equals("ORACLE.DATAACCESS.CLIENT"))
                {
                    fluentDataProvider = new OracleProvider();
                    SqlStatmentProcessor = s => s.Replace('@', ':');
                }
                else
                {
                    throw new Exception("Invalid provider name" + providerName);
                }

            }
            return fluentDataProvider;
        }


        public static string OracleAssemblyName
        {
            get
            {
                var asm = ConfigurationManager.AppSettings["OracleAssembly"] ?? "FluentData.OracleManaged.dll";
                return asm;
            }
        }

        public static string OracleProviderName
        {
            get
            {
                if (string.IsNullOrEmpty(_oracleProviderName))
                {
                    _oracleProviderName = ConfigurationManager.AppSettings["OracleAssemblyProvider"] ??
                                         "FluentData.OracleManagedProvider";
                }
                return _oracleProviderName;
            }
        }

        public IDbContext ConnectionString(string connectionString, IDbProvider fluentDataProvider, DbProviderFactory adoNetProviderFactory)
        {
            Data.ConnectionString = connectionString;
            Data.FluentDataProvider = fluentDataProvider;
            Data.AdoNetProvider = adoNetProviderFactory;
            return this;
        }

        public IDbContext ConnectionStringName(string connectionstringName, IDbProvider dbProvider)
        {
            IConnectionStringSetting settings;
            string connectionString;
            string providerName;
            if (DependencyHelper.TryGetInstance(out settings, string.Empty, connectionstringName))
            {
                connectionString = settings?.ConnectionString;
                providerName = settings?.ProviderName;
            }
            else
            {
                var settingsFromConfig = ConfigurationManager.ConnectionStrings[connectionstringName];
                connectionString = settingsFromConfig?.ConnectionString;
                providerName = settingsFromConfig?.ProviderName;
            }
            if (string.IsNullOrEmpty(connectionString))
                throw new FluentDataException("A connectionstring with the specified name was not found.");

            ConnectionString(connectionString, dbProvider, providerName);
            return this;
        }

        public Func<string, string> SqlStatmentProcessor { get; private set; }

        public IDbContext ConnectionStringName(string connectionstringName)
        {
            IConnectionStringSetting settings;
            string connectionString;
            string providerName;
#if !SKIPF

            if (DependencyHelper.TryGetInstance(out settings, string.Empty, connectionstringName))
            {
                connectionString = settings?.ConnectionString;
                providerName = settings?.ProviderName;
            }
            else
#endif
            {
                var settingsFromConfig = ConfigurationManager.ConnectionStrings[connectionstringName];
                connectionString = settingsFromConfig?.ConnectionString;
                providerName = settingsFromConfig?.ProviderName;
            }
            if (string.IsNullOrEmpty(connectionString))
                throw new FluentDataException("A connectionstring with the specified name was not found.");

            ConnectionString(connectionString, null, providerName);
            return this;
        }
    }
}

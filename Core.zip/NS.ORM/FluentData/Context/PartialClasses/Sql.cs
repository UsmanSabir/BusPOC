﻿using System.Data;
using NS.ORM.FluentData.Command;
using IDbCommand = NS.ORM.FluentData.Command.IDbCommand;

namespace NS.ORM.FluentData
{
    internal sealed partial class DbContext
    {
        private DbCommand CreateCommand
        {
            get
            {
                IDbConnection connection;

                if (Data.UseTransaction
                    || Data.UseSharedConnection)
                {
                    if (Data.Connection == null)
                    {
                        Data.Connection = Data.AdoNetProvider.CreateConnection();
                        if (Data.Connection != null)
                            Data.Connection.ConnectionString = Data.ConnectionString;
                    }
                    connection = Data.Connection;
                }
                else
                {
                    connection = Data.AdoNetProvider.CreateConnection();
                    if (connection != null)
                        connection.ConnectionString = Data.ConnectionString;
                }
                if (connection == null)
                    throw new FluentDataException("Unable to create connection to the specified database.");
                var cmd = connection.CreateCommand();
                cmd.Connection = connection;

                return new DbCommand(this, cmd);
            }
        }

        public IDbCommand Sql(string sql, params object[] parameters)
        {
            var command = CreateCommand.Sql(sql).Parameters(parameters);
            return command;
        }

        public IDbCommand MultiResultSql
        {
            get
            {
                var command = CreateCommand.UseMultiResult(true);
                return command;
            }
        }

        public bool IsMultiResultSqlSupported
        {
            get { return Data.FluentDataProvider.SupportsMultipleResultsets; }
        }
    }
}

﻿namespace NS.ORM.FluentData
{
	internal sealed partial class DbContext
	{
		public IDbContext EntityFactory(IEntityFactory entityFactory)
		{
			Data.EntityFactory = entityFactory;
			return this;
		}
	}
}

﻿namespace NS.ORM.FluentData
{
	internal sealed partial class DbContext
	{
		public IDbContext CommandTimeout(int timeout)
		{
			Data.CommandTimeout = timeout;
			return this;
		}
	}
}

﻿using System;
using System.Data;

// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable UnusedAutoPropertyAccessor.Global

namespace NS.ORM.FluentData
{
	internal sealed class CommandEventArgs : EventArgs
	{
		public IDbCommand Command { get; private set; }

		public CommandEventArgs(IDbCommand command)
		{
			Command = command;
		}
	}
}

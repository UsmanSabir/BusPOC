﻿using System;

namespace NS.ORM.FluentData
{
	internal class EntityFactory : IEntityFactory
	{
		public virtual object Create(Type type)
		{
			return Activator.CreateInstance(type);
		}
	}
}

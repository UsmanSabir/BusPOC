﻿using System;
using System.Data;
using System.Data.Common;
using IsolationLevel = NS.ORM.UoW.IsolationLevel;

namespace NS.ORM.FluentData
{
	internal sealed class DbContextData
	{
		public bool UseTransaction { get; set; }
		public bool UseSharedConnection { get; set; }
		public IDbConnection Connection { get; set; }
		public DbProviderFactory AdoNetProvider { get; set; }
		public IsolationLevel IsolationLevel { get; set; }
		public IDbTransaction Transaction { get; set; }
		public IDbProvider FluentDataProvider { get; set; }
		public string ConnectionString { get; set; }
		public IEntityFactory EntityFactory { get; set; }
		public bool IgnoreIfAutoMapFails { get; set; }
		public int CommandTimeout { get; set; }
        public Action<ConnectionEventArgs> OnConnectionOpening { get; set; }
        public Action<ConnectionEventArgs> OnConnectionOpened { get; set; }
		public Action<ConnectionEventArgs> OnConnectionClosed { get; set; }
		public Action<CommandEventArgs> OnExecuting { get; set; }
		public Action<CommandEventArgs> OnExecuted { get; set; }
		public Action<ErrorEventArgs> OnError { get; set; }

		public DbContextData()
		{
			IgnoreIfAutoMapFails = false;
			UseTransaction = false;
			IsolationLevel = IsolationLevel.ReadCommitted;
			EntityFactory = new EntityFactory();
		    CommandTimeout = 600;// Int32.MinValue;
		}
	}
}

﻿using System;

namespace NS.ORM.FluentData
{
	internal interface IEntityFactory
	{
		object Create(Type type);
	}
}

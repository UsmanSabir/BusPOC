using System;
using System.Data.Common;
using System.Dynamic;
using NS.ORM.FluentData.Builders;
using NS.ORM.FluentData.Command;
using System.Collections.Generic;
using NS.ORM.UoW;

namespace NS.ORM.FluentData
{
	internal interface IDbContext : IDisposable
	{
		DbContextData Data { get; }
		IDbContext IgnoreIfAutoMapFails(bool ignoreIfAutoMapFails);
		IDbContext UseTransaction(bool useTransaction);
		IDbContext UseSharedConnection(bool useSharedConnection);
		IDbContext CommandTimeout(int timeout);
		IDbCommand Sql(string sql, params object[] parameters);
		IDbCommand MultiResultSql { get; }
        bool IsMultiResultSqlSupported { get; }
		ISelectBuilder<TEntity> Select<TEntity>(string sql);
		IInsertBuilder Insert(string tableName,bool isIdentityInsert);
		IInsertBuilder<T> Insert<T>(string tableName, T item, bool isIdentityInsert);
		IInsertBuilderDynamic Insert(string tableName, ExpandoObject item, bool isIdentityInsert);
		IUpdateBuilder Update(string tableName);
		IUpdateBuilder<T> Update<T>(string tableName, T item);
		IUpdateBuilderDynamic Update(string tableName, ExpandoObject item);
		IDeleteBuilder Delete(string tableName);
		IDeleteBuilder<T> Delete<T>(string tableName, T item);
		IStoredProcedureBuilder StoredProcedure(string storedProcedureName);
		IStoredProcedureBuilder<T> StoredProcedure<T>(string storedProcedureName, T item);
		IStoredProcedureBuilderDynamic StoredProcedure(string storedProcedureName, ExpandoObject item);
		IDbContext EntityFactory(IEntityFactory entityFactory);
		IDbContext ConnectionString(string connectionString, IDbProvider fluentDataProvider, string providerName = null);
		IDbContext ConnectionString(string connectionString, IDbProvider fluentDataProvider, DbProviderFactory adoNetProviderFactory);
		IDbContext ConnectionStringName(string connectionstringName, IDbProvider dbProvider);
		IDbContext IsolationLevel(IsolationLevel isolationLevel);
		IDbContext Commit();
		IDbContext Rollback();
        IDbContext OnConnectionOpening(Action<ConnectionEventArgs> action);
        IDbContext OnConnectionOpened(Action<ConnectionEventArgs> action);
		IDbContext OnConnectionClosed(Action<ConnectionEventArgs> action);
        IDbContext OnExecuting(Action<CommandEventArgs> action);
		IDbContext OnExecuted(Action<CommandEventArgs> action);
		IDbContext OnError(Action<ErrorEventArgs> action);

        Func<string, string> SqlStatmentProcessor { get; }
        IBulkInsertBuilder<T> BulkInsert<T>(IEnumerable<T> item, List<string> clrMapping, string tableName,int batchSize);

    }
}
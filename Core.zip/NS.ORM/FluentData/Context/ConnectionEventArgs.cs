﻿using System;
using System.Data;

// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable UnusedAutoPropertyAccessor.Global

namespace NS.ORM.FluentData
{
	internal sealed class ConnectionEventArgs : EventArgs
	{
		public IDbConnection Connection { get; private set; }

		public ConnectionEventArgs(IDbConnection connection)
		{
			Connection = connection;
		}
	}
}

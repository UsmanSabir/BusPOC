﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using NS.ORM.Definitions.Classes;
using NS.ORM.FluentData.Builders;
using NS.ORM.FluentData.Command;
using NS.ORM.FluentData.Common;
using NS.ORM.FluentData.Common.Builders;
using IDbCommand = NS.ORM.FluentData.Command.IDbCommand;
using ParameterDirection = System.Data.ParameterDirection;

namespace NS.ORM.FluentData
{
    internal class SqlServerProvider : IDbProvider
	{
        private const string OptionRecompileSyntax = " OPTION(RECOMPILE) ";

        public string ProviderName
		{ 
			get
			{
				return "System.Data.SqlClient";
			} 
		}

		public bool SupportsOutputParameters
		{
			get { return true; }
		}

		public bool SupportsMultipleResultsets
		{
			get { return true; }
		}

		public bool SupportsMultipleQueries
		{
			get { return true; }
		}

		public bool SupportsStoredProcedures
		{
			get { return true; }
		}

		public bool RequiresIdentityColumn
		{
			get { return false; }
		}

		public IDbConnection CreateConnection(string connectionString)
		{
			return ConnectionFactory.CreateConnection(ProviderName, connectionString);
		}

		public string GetParameterName(string parameterName)
		{
			return "@" + parameterName;
		}

		public string GetSelectBuilderAlias(string name, string alias)
		{
			return name + " as " + alias;
		}

		public string GetSqlForSelectBuilder(SelectBuilderData data)
		{
			var sql = new StringBuilder();
			if (data.PagingCurrentPage == 1)
			{
				if (data.PagingItemsPerPage == 0)
					sql.Append("select");
				else
					sql.Append("select top " + data.PagingItemsPerPage.ToString());
				sql.Append(" " + data.Select);
				sql.Append(" from " + data.From);
				if (data.WhereSql.Length > 0)
					sql.Append(" where " + data.WhereSql);
				if (data.GroupBy.Length > 0)
					sql.Append(" group by " + data.GroupBy);
				if (data.Having.Length > 0)
					sql.Append(" having " + data.Having);
				if (data.OrderBy.Length > 0)
					sql.Append(" order by " + data.OrderBy);
				return sql.ToString();
			}
			else
			{
				sql.Append(" from " + data.From);
				if(data.WhereSql.Length > 0)
					sql.Append(" where " + data.WhereSql);
				if(data.GroupBy.Length > 0)
					sql.Append(" group by " + data.GroupBy);
				if(data.Having.Length > 0)
					sql.Append(" having " + data.Having);

				var pagedSql = string.Format(@"with PagedPersons as
								(
									select top 100 percent {0}, row_number() over (order by {1}) as FLUENTDATA_ROWNUMBER
									{2}
								)
								select *
								from PagedPersons
								where fluentdata_RowNumber between {3} and {4}",
				                             data.Select,
				                             data.OrderBy,
				                             sql,
				                             data.GetFromItems(),
				                             data.GetToItems());
				return pagedSql;
			}
		}

		public string GetSqlForInsertBuilder(BuilderData data)
		{
			return new InsertBuilderSqlGenerator().GenerateSql(this, "@", data);
		}

		public string GetSqlForUpdateBuilder(BuilderData data)
		{
			return new UpdateBuilderSqlGenerator().GenerateSql(this, "@", data);
		}

		public string GetSqlForDeleteBuilder(BuilderData data)
		{
			return new DeleteBuilderSqlGenerator().GenerateSql(this, "@", data);
		}

		public string GetSqlForStoredProcedureBuilder(BuilderData data)
		{
			return data.ObjectName;
		}

		public DataTypes GetDbTypeForClrType(Type clrType)
		{
			return new DbTypeMapper().GetDbTypeForClrType(clrType);
		}

	    public Tuple<string, List<DbParamInfo>> ApplySqlOptimization(string sql, string[] names, object[] ids, bool avoidRecompile=false)
	    {
	        if (names == null || names.Length == 0 || ids == null || ids.Length == 0)
	            return Tuple.Create<string, List<DbParamInfo>>(sql + (avoidRecompile?string.Empty: OptionRecompileSyntax), null);

	        if (avoidRecompile)
	        {
	            return ApplyParameterSniffingVariables(sql, names, ids);
	        }
	        else
	        {
	            return ApplyOptionRecompile(sql, names, ids);
            }
	    }

	    private Tuple<string, List<DbParamInfo>> ApplyOptionRecompile(string sql, string[] names, object[] ids)
	    {
	        List<DbParamInfo> parameters = new List<DbParamInfo>();
	        
	        for (var i = 0; i < names.Length; i++)
	        {
	            var nm = names[i];
	            var val = ids[i]; //assuming that ids and names have same array length
                parameters.Add(new DbParamInfo() { Name = nm, Value = val, DbType = DataTypes.Object});
	        }

	        return Tuple.Create(sql + OptionRecompileSyntax, parameters);
	    }

        private Tuple<string, List<DbParamInfo>> ApplyParameterSniffingVariables(string sql, string[] names, object[] ids)
	    {
	        List<DbParamInfo> parameters = new List<DbParamInfo>();
	        DataTypes clrType = DataTypes.Object;
	        StringBuilder sbParam = new StringBuilder();

	        for (var i = 0; i < names.Length; i++)
	        {
	            var nm = names[i];
	            var val = ids[i]; //assuming that ids and names have same array length

	            var uniqName = Guid.NewGuid().ToString("N");

	            sbParam.Append($"DECLARE {GetParameterName(nm)} ");
	            if (val != null)
	            {
	                clrType = GetDbTypeForClrType(val.GetType());
	            }

	            var typeString = GetDbSyntaxForDbType(clrType);

	            sbParam.Append(typeString);

	            sbParam.AppendLine($" = {GetParameterName(uniqName)} ");

	            parameters.Add(new DbParamInfo() {DbType = clrType, Name = uniqName, Value = val});
	        }

	        sbParam.AppendLine(sql);

	        return Tuple.Create(sbParam.ToString(), parameters);
	    }

	    string GetDbSyntaxForDbType(DataTypes type)
	    {
            switch (type)
            {
                case DataTypes.StringFixedLength:
                case DataTypes.String:
                case DataTypes.AnsiStringFixedLength:
                case DataTypes.AnsiString:
                    return "varchar";

                case DataTypes.Binary:
                    return "varbinary";

                case DataTypes.Byte:
                    return "tinyint";

                case DataTypes.Boolean:
                    return "bit";

                case DataTypes.Currency:
                    return "money";

                case DataTypes.Date:
                    return "date";

                case DataTypes.DateTime:
                    return "datetime";

                case DataTypes.DateTime2:
                    return "datetime2";

                case DataTypes.DateTimeOffset:
                    return "datetimeoffset";

                case DataTypes.Decimal:
                    return "decimal";

                case DataTypes.Double:
                    return "float";

                case DataTypes.Guid:
                    return "uniqueidentifier";

                case DataTypes.Int16:
                    return "smallint";

                case DataTypes.Int32:
                    return "int";

                case DataTypes.Int64:
                case DataTypes.UInt64:
                    return "bigint";

                case DataTypes.Object:
                    return "sql_variant";

                case DataTypes.SByte:
                    return "tinyint";

                case DataTypes.Single:
                    return "real";
                
                case DataTypes.Time:  // timeSpan
                    return "time";

                case DataTypes.UInt32:
                case DataTypes.UInt16:
                    return "int";
                    
                case DataTypes.VarNumeric:
                    return "numeric";
                    
                case DataTypes.Xml:
                    return "xml";

                default:
                    return "varchar";

            }
            
	    }

	    public object ExecuteReturnLastId<T>(IDbCommand command, string identityColumnName = null)
        {
            if (command.Data.Sql[command.Data.Sql.Length - 1] != ';')
                command.Sql(";");

            command.Sql("select SCOPE_IDENTITY()");

            object lastId = null;

            command.Data.ExecuteQueryHandler.ExecuteQuery(false, () =>
            {
                lastId = command.Data.InnerCommand.ExecuteScalar();
            });

            return lastId;
        }

        public void OnCommandExecuting(IDbCommand command)
		{
		}

		public string EscapeColumnName(string name)
		{
			if (name.Contains("["))
				return name;
			return "[" + name + "]";
		}


        public IDbDataParameter CreateParamRefCur(string name, ParameterDirection direction)
        {
            throw new NotImplementedException();
        }


        public TList QueryMany<TEntity, TList>(DbCommandData cmdData, Action<TEntity, IDbReader> customMapper = null) where TList : IList<TEntity>
        {
            throw new NotImplementedException();
        }


        public bool UseCustomMultipleQueryHandler
        {
            get { return false; }
        }


        public IDataReader GetDataReader(DbCommand cmd, int paramIdx)
        {
            throw new NotImplementedException();
        }

        public Queue<int> GetOutParamIndexes(DbCommand cmd)
        {
            throw new NotImplementedException();
        }

        public string TempTableQuery { get; } = @"if object_id('tempdb..#tt_audt_trck') is not null
begin
update #tt_audt_trck
set trck_id='{0}'
end
else
begin
select '{0}' trck_id into #tt_audt_trck
end";

        public string TableSequenceQuery { get; } = @"select next value for {0}";

        public string TableRecordExist { get; } = @"IF NOT EXISTS ( SELECT 1 FROM {0})
BEGIN
    select 0;
END
ELSE
BEGIN
	select 1;
END";

        public string TableIdentityIncrementQuery { get; } = "SELECT IDENT_INCR('{0}')";

        public string TableCurrentIdentityQuery { get; } = "SELECT IDENT_CURRENT('{0}')";

        public string TableScopeIdentityQuery { get; } = "SELECT SCOPE_IDENTITY()";
    }

}

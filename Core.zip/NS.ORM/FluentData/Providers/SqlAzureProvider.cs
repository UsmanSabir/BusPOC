﻿namespace NS.ORM.FluentData
{
	internal sealed class SqlAzureProvider : SqlServerProvider
	{
	}
}

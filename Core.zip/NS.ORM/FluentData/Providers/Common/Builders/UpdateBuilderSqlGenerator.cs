﻿using System.Text;
using NS.ORM.FluentData.Builders;

namespace NS.ORM.FluentData.Common.Builders
{
    internal sealed class UpdateBuilderSqlGenerator
	{
		public string GenerateSql(IDbProvider provider, string parameterPrefix, BuilderData data)
		{
		    StringBuilder setSql = new StringBuilder();
		    foreach (var column in data.Columns)
		    {
		        if (setSql.Length > 0)
		            setSql.Append(", ");

		        setSql.Append(string.Format("{0} = {1}{2}",
		            provider.EscapeColumnName(column.ColumnName),
		            parameterPrefix,
		            column.ParameterName));
		    }

		    StringBuilder whereSql = new StringBuilder();
		    foreach (var column in data.Where)
		    {
		        if (whereSql.Length > 0)
		            whereSql.Append(" and ");

		        whereSql.Append(string.Format("{0} = {1}{2}",
		            provider.EscapeColumnName(column.ColumnName),
		            parameterPrefix,
		            column.ParameterName));
		    }

		    var sql = string.Format("update {0} set {1} where {2}",
		        data.ObjectName,
		        setSql.ToString(),
		        whereSql.ToString());
		    return sql;
        }
	}
}

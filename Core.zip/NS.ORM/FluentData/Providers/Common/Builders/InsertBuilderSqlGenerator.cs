﻿using System.Text;
using NS.ORM.FluentData.Builders;

namespace NS.ORM.FluentData.Common.Builders
{
    internal sealed class InsertBuilderSqlGenerator
	{
		public string GenerateSql(IDbProvider provider, string parameterPrefix, BuilderData data)
		{
			StringBuilder insertSql = new StringBuilder();
		    StringBuilder valuesSql = new StringBuilder();
			foreach (var column in data.Columns)
			{
				if (insertSql.Length > 0)
				{
					insertSql.Append(",");
					valuesSql.Append(",");
				}

				insertSql.Append(provider.EscapeColumnName(column.ColumnName));
				valuesSql.Append(parameterPrefix).Append(column.ParameterName);
			}

			var sql = string.Format("insert into {0}({1}) values({2})",
										data.ObjectName,
										insertSql.ToString(),
										valuesSql.ToString());
			return sql;
		}
	}
}

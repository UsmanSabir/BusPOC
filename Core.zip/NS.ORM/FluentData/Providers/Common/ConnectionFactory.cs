﻿using System.Data;
using System.Data.Common;

namespace NS.ORM.FluentData.Common
{
    internal sealed class ConnectionFactory
    {
        public static IDbConnection CreateConnection(string providerName, string connectionString)
        {
            var factory = DbProviderFactories.GetFactory(providerName);

            var connection = factory.CreateConnection();
            if (connection != null)
                connection.ConnectionString = connectionString;
            return connection;
        }
    }
}

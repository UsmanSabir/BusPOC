﻿using System;
using System.Collections.Generic;
using System.Data;
using NS.ORM.Definitions.Classes;
using NS.ORM.FluentData.Builders;
using NS.ORM.FluentData.Command;
using IDbCommand = NS.ORM.FluentData.Command.IDbCommand;
using ParameterDirection = System.Data.ParameterDirection;

namespace NS.ORM.FluentData
{
    internal interface IDbProvider
	{
		string ProviderName { get; }
		bool SupportsMultipleResultsets { get; }
		bool SupportsMultipleQueries { get; }
		bool SupportsOutputParameters { get; }
		bool SupportsStoredProcedures { get; }
		bool RequiresIdentityColumn { get; }
		string GetParameterName(string parameterName);
		string GetSelectBuilderAlias(string name, string alias);
		string GetSqlForSelectBuilder(SelectBuilderData data);
		string GetSqlForInsertBuilder(BuilderData data);
		string GetSqlForUpdateBuilder(BuilderData data);
		string GetSqlForDeleteBuilder(BuilderData data);
		string GetSqlForStoredProcedureBuilder(BuilderData data);
		DataTypes GetDbTypeForClrType(Type clrType);
	    Tuple<string, List<DbParamInfo>> ApplySqlOptimization(string sql, string[] names, object[] ids, bool avoidRecompile);
        object ExecuteReturnLastId<T>(IDbCommand command, string identityColumnName);
		void OnCommandExecuting(IDbCommand command);
		string EscapeColumnName(string name);
	    IDbDataParameter CreateParamRefCur(string name, ParameterDirection direction);
	    bool UseCustomMultipleQueryHandler { get; }

        TList QueryMany<TEntity, TList>(DbCommandData cmdData, Action<TEntity, IDbReader> customMapper = null)
	        where TList : IList<TEntity>;

	    IDataReader GetDataReader(DbCommand cmd, int paramIdx);

	    Queue<int> GetOutParamIndexes(DbCommand cmd);

        string TempTableQuery { get; }

        string TableSequenceQuery { get; }

        string TableRecordExist { get; }

        string TableIdentityIncrementQuery { get; }

        string TableCurrentIdentityQuery { get; }

        string TableScopeIdentityQuery { get; }
	}
}

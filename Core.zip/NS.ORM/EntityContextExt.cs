﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text;
using NS.BaseModels;
using NS.ORM.Definitions;
using NS.ORM.Definitions.Classes;
using NS.ORM.Helper;
using NS.ORM.UoW;
using System.Xml.Serialization;
using NS.Utilities.Enums;
using System.Data.SqlClient;
using NS.ExceptionHandling;
using NS.ORM.FluentData;
using NS.Utilities.Context;

namespace NS.ORM
{
    /// <summary>
    /// Provides database operations on entity.
    /// </summary>
    /// <typeparam name="T">Any type implenting BaseModel. See <seealso cref="BaseModel"/></typeparam>
    /// <remarks>Inherits EntityContext. see <seealso cref="EntityContext{T}"/>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// </remarks>
    public sealed class EntityContextExt<T> : EntityContext<T>, IDisposable where T : BaseModel, new()
    {

        private string _connectionString;
        private string _provider;
        private bool _useCustomProvider;
        private readonly BaseDefination _definition;
        //private bool _usingUnitOfWork;
        private IUnitOfWork _unitOfWork;
        private bool _isInTransactionMode;
        private bool _isDisposed;
        private int _commandTimeOut = Int32.MinValue;
        private DbController _sharedController=null;
        private bool _enableQueryPlanOptimization=false;
        private bool _enableQueryPlanOptimizationAvoidRecompile=false;

        //        const string _wrapQuery = @"select * from (select res.*, nam= row_number() over (order by {1})
        // from ({0}) res) res1
        //  where res1.nam >({2}) and res1.nam < {3} 

        //";

        #region Constructor
        /// <summary>
        /// Initializes entity.
        /// </summary>
        /// <param name="entity">Collection of type T</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// </remarks>
        public EntityContextExt(List<T> entity) : base(entity)
        {
            _definition = typeof(T).ToDefination();
        }

        ///// <summary>
        ///// Initializes entity.
        ///// </summary>
        ///// <param name="entity">Collection of type T</param>
        ///// <remarks>
        ///// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        ///// </remarks>
        //public EntityContextExt(IEnumerable<T> entity) : base(entity.ToList())
        //{
        //    _defination = typeof(T).ToDefination();
        //}

        /// <summary>
        /// Initializes entity with default constructor.
        /// </summary>
        /// <remarks>
        /// <para>[US] 10/03/2016  1.0 Constructor created.</para>
        /// </remarks>
        public EntityContextExt() : this(null)
        {

        }

        #endregion

        #region Public Members

        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="entity">Collection of type T. Default is null.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <example>
        /// Sample code for creating entity context.
        /// <code>
        /// EntityContextExt&lt;SomeType&gt; ctx = EntityContextExt.Create&lt;SomeType&gt;();
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(List<T> entity = null)
        {

            var controller = new EntityContextExt<T>(entity);
            //any future thing

#if DEBUG
            if (GlobalConfig.Configurations.SqlLogger == null)
                GlobalConfig.Configurations.UseTraceLogging();
#endif

            return controller;
        }

        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="entity">Collection of type T. Default is null.</param>
        /// <param name="commandTimeOut">Command Time Out.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <example>
        /// Sample code for creating entity context.
        /// <code>
        /// EntityContextExt&lt;SomeType&gt; ctx = EntityContextExt.Create&lt;SomeType&gt;();
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(int commandTimeOut, List<T> entity = null)
        {

            //var controller = new EntityContextExt<T>(entity);
            var controller = Create(entity);
            //any future thing
            controller._commandTimeOut = commandTimeOut;
            return controller;
        }

        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="entity">Collection of type T. Default is null.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <example>
        /// Sample code for creating entity context.
        /// <code>
        /// EntityContextExt&lt;SomeType&gt; ctx = EntityContextExt.Create&lt;SomeType&gt;();
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(IList<T> entity)
        {
            return Create(entity as List<T> ?? entity?.ToList());
        }

        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="entity">Collection of type T. Default is null.</param>
        /// <param name="commandTimeOut">Command Time Out.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <example>
        /// Sample code for creating entity context.
        /// <code>
        /// EntityContextExt&lt;SomeType&gt; ctx = EntityContextExt.Create&lt;SomeType&gt;();
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(IList<T> entity, int commandTimeOut)
        {
            return Create(commandTimeOut, entity as List<T> ?? entity?.ToList());
        }
        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="connectionString">Database connection string.</param>
        /// <param name="provider">Database provider.<seealso cref="DbProvider"/>. Default is SqlServer.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <example>Sample code for creating context.
        /// <code>
        /// string connectionString = "Get connection string from config";
        /// EntityContextExt&lt;SomeType&gt; ctx = EntityContextExt.Create&lt;SomeType&gt;(connectionString);
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(string connectionString, DbProvider provider = DbProvider.SqlServer)//, IDbProvider provider= null)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentNullException(nameof(connectionString));

            var prd = provider == DbProvider.SqlServer ? "System.Data.SqlClient" : "FluentData.OracleManagedProvider";

            var controller = Create();
            controller._connectionString = connectionString;
            controller._provider = prd;
            controller._useCustomProvider = true;

            return controller;
        }

        /// <summary>
        /// Creates entity context of the specified type using providezd command time out.
        /// </summary>
        /// <param name="connectionString">Database connection string.</param>
        /// <param name="provider">Database provider.<seealso cref="DbProvider"/>. Default is SqlServer.</param>
        /// <param name="commandTimeOut">Command Time Out.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <example>Sample code for creating context.
        /// <code>
        /// string connectionString = "Get connection string from config";
        /// EntityContextExt&lt;SomeType&gt; ctx = EntityContextExt.Create&lt;SomeType&gt;(connectionString);
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(int commandTimeOut, string connectionString, DbProvider provider = DbProvider.SqlServer)//, IDbProvider provider= null)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentNullException(nameof(connectionString));

            var prd = provider == DbProvider.SqlServer ? "System.Data.SqlClient" : "FluentData.OracleManagedProvider";

            var controller = Create(commandTimeOut);
            controller._connectionString = connectionString;
            controller._provider = prd;
            controller._useCustomProvider = true;

            return controller;
        }

        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="entity">Entity object.</param>
        /// <param name="connectionString">Database connection string.</param>
        /// <param name="provider">Database provider.<seealso cref="DbProvider"/>. Default is SqlServer.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(List<T> entity, string connectionString, DbProvider provider = DbProvider.SqlServer)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentNullException(nameof(connectionString));

            var prd = provider == DbProvider.SqlServer ? "System.Data.SqlClient" : "NS.ORM.OracleManaged";

            var controller = Create(entity);
            controller._connectionString = connectionString;
            controller._provider = prd;
            controller._useCustomProvider = true;

            return controller;
        }

        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="entity">Entity object.</param>
        /// <param name="connectionString">Database connection string.</param>
        /// <param name="commandTimeOut">Command Time Out.</param>
        /// <param name="provider">Database provider.<seealso cref="DbProvider"/>. Default is SqlServer.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(List<T> entity, int commandTimeOut, string connectionString, DbProvider provider = DbProvider.SqlServer)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentNullException(nameof(connectionString));

            var prd = provider == DbProvider.SqlServer ? "System.Data.SqlClient" : "NS.ORM.OracleManaged";

            var controller = Create(entity, commandTimeOut);
            controller._connectionString = connectionString;
            controller._provider = prd;
            controller._useCustomProvider = true;

            return controller;
        }
        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="entity">Entity object.</param>
        /// <param name="connectionString">Database connection string.</param>
        /// <param name="provider">Database provider.<seealso cref="DbProvider"/>. Default is SqlServer.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(IList<T> entity, string connectionString, DbProvider provider = DbProvider.SqlServer)
        {
            return Create(entity as List<T> ?? entity?.ToList(), connectionString, provider);
        }

        /// <summary>
        /// Creates entity context of the specified type.
        /// </summary>
        /// <param name="entity">Entity object.</param>
        /// <param name="connectionString">Database connection string.</param>
        /// <param name="provider">Database provider.<seealso cref="DbProvider"/>. Default is SqlServer.</param>
        /// <param name="commandTimeOut">Command Time Out.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create(IList<T> entity, int commandTimeOut, string connectionString, DbProvider provider = DbProvider.SqlServer)
        {
            return Create(entity as List<T> ?? entity?.ToList(), commandTimeOut, connectionString, provider);
        }
        #endregion

        internal DbController GetController()
        {
            if (_unitOfWork != null)
            {
                return DbController.Create(_commandTimeOut,_unitOfWork).WithEntityScope(EntityScopeFunc).WithSequenceScope(SequenceScopeFunc); //connection string is picked from existing unitOfWork instance. no need to overload
            }

            if (_sharedController != null)
            {
                _sharedController.EnableQueryPlanOptimizationFlag = _enableQueryPlanOptimization;
                _sharedController.EnableQueryPlanOptimizationAvoidRecompile = _enableQueryPlanOptimizationAvoidRecompile;
                return _sharedController;
            }

            if (_useCustomProvider)
            {
                var c = DbController.Create(_commandTimeOut, _connectionString, _provider)
                    .WithEntityScope(EntityScopeFunc).WithSequenceScope(SequenceScopeFunc);
                c.EnableQueryPlanOptimizationFlag = _enableQueryPlanOptimization;
                c.EnableQueryPlanOptimizationAvoidRecompile = _enableQueryPlanOptimizationAvoidRecompile;
                return c;
            }
            else
            {
                var c = DbController.Create(_commandTimeOut).WithEntityScope(EntityScopeFunc)
                    .WithSequenceScope(SequenceScopeFunc);
                c.EnableQueryPlanOptimizationFlag = _enableQueryPlanOptimization;
                c.EnableQueryPlanOptimizationAvoidRecompile = _enableQueryPlanOptimizationAvoidRecompile;
                return c;
            }
        }



        /// <summary>
        /// Apply custom database configuration.
        /// </summary>
        /// <param name="connectionString">Database connection string.</param>
        /// <param name="provider">Database provider.<seealso cref="DbProvider"/>. Default is SqlServer.</param>
        /// <returns>Instance of EntityContextExt{T}. See cref="EntityContextExt{T}"/></returns>
        /// <remarks>
        /// <para>[US] 10/03/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> UseConnectionString(string connectionString, DbProvider provider = DbProvider.SqlServer)
        {
            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentNullException(nameof(connectionString));

            var prd = provider == DbProvider.SqlServer ? "System.Data.SqlClient" : "FluentData.OracleManagedProvider";

            _connectionString = connectionString;
            _provider = prd;
            _useCustomProvider = true;

            return this;
        }

        /// <summary>
        /// Set ChildSelector delegate
        /// </summary>
        /// <param name="entityScopeFunc">A delegate to decide, should child entity be included in aggregate filling. Func Arguments are "Type entityChild, string entityParent, string aggregateId, string propertyName"</param>
        /// <returns></returns>
        public EntityContextExt<T> WithEntityScope(Func<Type, string, string, string, bool> entityScopeFunc)
        {
            EntityScopeFunc = entityScopeFunc;
            return this;
        }
        /// <summary>
        /// Set Child Sequence Delegate
        /// </summary>
        /// <param name="sequenceScopeFunc"></param>
        /// <returns></returns>
        public EntityContextExt<T> WithSequenceScope(Func<Type, bool> sequenceScopeFunc)
        {
            SequenceScopeFunc = sequenceScopeFunc;
            return this;
        }

        /// <summary>
        /// Apply optimization techniques in complex queries Consult with ORM team before using this feature.
        /// </summary>
        /// <returns></returns>
        public EntityContextExt<T> EnableQueryPlanOptimization(bool avoidRecompile = false)
        {
            _enableQueryPlanOptimization = true;
            _enableQueryPlanOptimizationAvoidRecompile = avoidRecompile;
            
            return this;
        }


        #region Public Properties

        /// <summary>
        /// A delegate to decide, should child entity be included in aggregate filling. Func Arguments are "Type entityChild, string entityParent, string aggregateId"
        /// </summary>
        public Func<Type, string, string, string, bool> EntityScopeFunc { get; set; }
        
        /// <summary>
        /// A delegate set Parent Id into its chields entities.
        /// </summary>
        public Action<BaseModel, int> IdInjector { get; set; }

        /// <summary>
        /// A delegate to decide, should child entry used provided identity type or not
        /// </summary>
        public Func<Type, bool> SequenceScopeFunc { get; set; }
        #endregion


        /// <summary>
        /// Reads entity by specified parameters.
        /// </summary>
        /// <param name="ids">One or more values for query parameters. Can be null if query has no parameters.</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <example>
        /// <code>
        /// string connectionString = "Get connection string from config";
        /// EntityContextExt&lt;SomeType&gt; ctx = EntityContextExt.Create&lt;SomeType&gt;(connectionString).ReadWithDepth(1, 707);
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> Read(params object[] ids)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph<T>(ids);
            }
            return this;
        }

        /// <summary>
        /// Reads entity by specified parameters.
        /// </summary>
        /// <param name="parameters">One or more values for query parameters. Can be null if query has no parameters.</param>
        /// <param name="depth">Aggregate depth to read</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <example>
        /// <code>
        /// string connectionString = "Get connection string from config";
        /// EntityContextExt&lt;SomeType&gt; ctx = EntityContextExt.Create&lt;SomeType&gt;(connectionString).ReadWithDepth(1, 707);
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> Read(Dictionary<string, object> parameters, int? depth = null)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph<T>(string.Empty, depth, parameters?.Keys.ToList(), parameters?.Values.ToArray());
            }
            return this;
        }

        /// <summary>
        /// Reads entity using specified expression.
        /// </summary>
        /// <param name="expression">Lamda expression which will be used to filter data.</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> Read(Expression<Func<T, bool>> expression)
        {
            //using (DbController controller = GetController())
            //{
            //    Entity = controller.ReadEntityGraph(expression: expression);
            //}
            // ReSharper disable once RedundantArgumentDefaultValue
            Read(expression, depth: null, digDeepExpression: false);
            return this;
        }
        /// <summary>
        /// Read entity using Specified expression and using query parameters
        /// </summary>
        /// <param name="expression">Lamda expression which will be used to filter data.</param>
        /// <param name="depth">Instance of EntityContextExt{T}.</param>
        /// <param name="externalParameters">One or more values for query parameters. Can be null if query has no parameters.</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[WB] 28/12/2017  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> Read(int? depth, Expression<Func<T, bool>> expression, List<KeyValuePair<string, object>> externalParameters)
        {
            var definition = typeof(T).ToDefination();
            var aggrId = definition.EntityId;

            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph(expression, aggrId, externalParameters, depth, GetColumnAlias);
            }
            return this;
        }

        private string GetColumnAlias(string columnName)
        {
            string tableNameAlias = null;
            _definition.ColumnTable?.TryGetValue(columnName, out tableNameAlias);
            return tableNameAlias;
        }

        /// <summary>
        /// Reads entity using specified expression.
        /// </summary>
        /// <param name="expression">Lamda expression which will be used to filter data.</param>
        /// <param name="depth">Number of levels to process in entity graph. Default is null. </param>
        /// <param name="digDeepExpression">Digs down deeper in the expression to parse inline function call and evaluate them. if true, it will parse expressions with functions in it but will take extra CPU cycles and will have performance impact</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> Read(Expression<Func<T, bool>> expression
            , int? depth, bool digDeepExpression = false)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph(expression: expression, depth: depth, digDeepExpression: digDeepExpression, memberTableNameFactory: GetColumnAlias);
            }
            return this;
        }

        /// <summary>
        /// Get entity list based on sql key name provided in designer
        /// </summary>
        /// <param name="key">Query key name</param>
        /// <param name="arguments">Query arguments</param>
        /// <returns></returns>
        public EntityContextExt<T> ReadByKey(string key, Dictionary<string, object> arguments = null)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.GetEntityByKey<T>(key, arguments);
            }
            return this;
        }

        #region Paged (commented)

        /// <summary>
        /// Read paged data 
        /// </summary>
        /// <param name="expression">Filter expression (Lambda)</param>
        /// <param name="take">Read number of rows</param>
        /// <param name="skip">Skip number of rows</param>
        /// <param name="orderBy">Orderby for paging</param>
        /// <returns></returns>
        public EntityContextExt<T> ReadPage(Expression<Func<T, bool>> expression, int take, int skip,
           string orderBy)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.ReadPage(_definition, expression, take, skip, orderBy);
            }
            return this;

        }

        /// <summary>
        /// Read paged data By Lambda and using External Parameters
        /// </summary>
        /// <param name="expression">Filter expression (Lambda)</param>
        /// <param name="externalParameters">External parameters</param>
        /// <param name="take">Read number of rows</param>
        /// <param name="skip">Skip number of rows</param>
        /// <param name="orderBy">Orderby for paging</param>
        /// <returns></returns>
        public EntityContextExt<T> ReadPage(Expression<Func<T, bool>> expression, List<KeyValuePair<string, object>> externalParameters, int take, int skip,
           string orderBy)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.ReadPage(_definition, expression, externalParameters, take, skip, orderBy);
            }
            return this;

        }

        /// <summary>
        /// Read paged data 
        /// </summary>
        /// <param name="criteria">Filter criteria, A 'where' clause</param>
        /// <param name="parameters">Named/Value parameters dictionary used in 'where' clause</param>
        /// <param name="take">Read number of rows</param>
        /// <param name="skip">Skip number of rows</param>
        /// <param name="orderBy">Orderby for paging</param>
        /// <returns></returns>
        public EntityContextExt<T> ReadPage(string criteria, Dictionary<string, object> parameters, int take, int skip,
           string orderBy)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.ReadPage<T>(_definition, criteria, parameters, take, skip, orderBy);
            }
            return this;

        }

        /// <summary>
        /// Read paged data 
        /// </summary>
        /// <param name="take">Read number of rows</param>
        /// <param name="ids">Filter parameters</param>
        /// <returns></returns>
        public EntityContextExt<T> ReadPage(int take, params object[] ids)
        {
            return ReadPage(take, skip: 0, orderBy: string.Empty, ids: ids);
        }

        /// <summary>
        /// Read paged data 
        /// </summary>
        /// <param name="take">Read number of rows</param>
        /// <param name="skip">Skip number of rows</param>
        /// <param name="orderBy">Orderby for paging</param>
        /// <param name="ids">Filter parameters</param>
        /// <returns></returns>
        public EntityContextExt<T> ReadPage(int take, int skip = 0,
            string orderBy = null, params object[] ids)
        {


            using (DbController controller = GetController())
            {
                Entity = controller.ReadPage<T>(_definition, take, skip, orderBy, ids);
            }
            return this;
        }

        /// <summary>
        /// Read paged data 
        /// </summary>
        /// <param name="take">Read number of rows</param>
        /// <param name="skip">Skip number of rows</param>
        /// <param name="where">custom where clause</param>
        /// <param name="orderBy">Orderby for paging</param>
        /// <param name="parameterNames">parameter names used in where clause</param>
        /// <param name="ids">Filter parameters</param>
        /// <returns></returns>
        public EntityContextExt<T> ReadPage(int take, int skip,
            string where,
            string orderBy, List<string> parameterNames, params object[] ids)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.ReadPage<T>(_definition, take, skip, where, orderBy, parameterNames, ids);
            }
            return this;
        }


        //public EntityContextExt<T> ReadPage(Expression<Func<T, bool>> expression, int take, int skip,
        //   string orderBy)
        //{
        //    var translator = new QueryTranslator();
        //    var tuple = translator.Translate(expression);
        //    string whereClause = tuple.Item1;
        //    var prms = tuple.Item2;

        //    return ReadPage(take, skip, whereClause, orderBy, prms.Select(s => s.Key).ToList(), prms.Select(s => s.Value).ToArray());
        //}

        //public EntityContextExt<T> ReadPage(int take, int skip,
        //    // string where, 
        //    string orderBy, params object[] ids)
        //{
        //    string where=string.Empty;
        //    if (ids != null && ids.Length > 0)
        //        where = _defination.Where;

        //    return ReadPage(take, skip, where, orderBy, _defination.ParameterNames, ids);
        //}

        //public EntityContextExt<T> ReadPage(int take, int skip, 
        //    string where, 
        //    string orderBy, List<string> parameterNames,  params object[] ids)
        //{

        //    var orderByCol=string.IsNullOrEmpty(orderBy)? _defination.IdentityColumn:
        //    orderBy;
        //    if(string.IsNullOrWhiteSpace(orderByCol))
        //        throw new ArgumentException(nameof(orderBy));

        //    var sqlBuilder= new StringBuilder();

        //    sqlBuilder.AppendLine(_defination.SelectQuery);

        //    if (!string.IsNullOrWhiteSpace(where))
        //    {
        //        //_defination.ParameterNames
        //        sqlBuilder.AppendLine(where);
        //    }

        //    //var wre = string.IsNullOrWhiteSpace(where) ? _defination.Where : where;
        //    //var wre = _defination.Where ;

        //    var pagingSql = WrapPagingSql(sqlBuilder.ToString(), orderBy, skip, take);

        //    using (DbController controller = GetController())
        //    {
        //        if (ids != null && ids.Length > 0)
        //        {
        //            //_defination.ParameterNames
        //            //parameterNames = _defination.ParameterNames;

        //            Entity = controller.GetEntityWithCustomSql<T>(pagingSql, parameterNames, ids);
        //        }
        //        else
        //        {
        //            Entity = controller.GetEntityWithCustomSql<T>(pagingSql);
        //        }

        //    }
        //    return this;
        //}

        //string WrapPagingSql(string sql, string orderBy, int skip, int take)
        //{
        //    var pagedSql = string.Format(_wrapQuery, sql, orderBy, skip, skip + take);
        //    return pagedSql;
        //}



        #endregion


        /// <summary>
        /// Reads entity upto specified levels.
        /// </summary>
        /// <param name="depth">Number of levels to process in entity graph.</param>
        /// <param name="ids">One or more values for query parameters. Can be null if query has no parameters.</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> ReadWithDepth(int depth, params object[] ids)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph<T>(depth, ids);
            }
            return this;
        }

        /// <summary>
        /// Reads entity upto specified levels.
        /// </summary>
        /// <param name="sql">Sql statment</param>
        /// <param name="ids">One or more values for query parameters. Can be null if query has no parameters.</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> ReadWithSql(string sql, params object[] ids)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.GetEntityWithCustomSql<T>(sql, ids);
            }
            return this;
        }

        /// <summary>
        /// Reads entity with sql statement. It will not read full aggregate, but entity only
        /// </summary>
        /// <param name="sql">Sql statment</param>
        /// <param name="keyValParams">One or more key-values for query parameters. Can be null if query has no parameters defined.</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> GetEntityWithSql(string sql, Dictionary<string, object> keyValParams = null)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.GetEntityWithSql<T>(sql, keyValParams);
            }
            return this;
        }

        /// <summary>
        /// Reads entity with StoredProcedure statement. It will not read full aggregate, but entity only
        /// </summary>
        /// <param name="namedParameters">One or more key-values for query parameters. Can be null if query has no parameters defined.</param>
        /// <param name="spName"></param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 01/09/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> ReadFromSp(string spName, Dictionary<string, object> namedParameters = null)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.SpCallForEntity<T>(spName, namedParameters);
            }
            return this;
        }



        /// <summary>
        /// Get entity list based on sql key name provided in designer
        /// </summary>
        /// <param name="key">Key name</param>
        /// <param name="keyValParams">Query parameters</param>
        /// <returns></returns>
        public EntityContextExt<T> ReadEntityByKey(string key, Dictionary<string, object> keyValParams)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.GetEntityByKey<T>(key, keyValParams);
            }

            return this;
        }

        /// <summary>
        /// Get entity list based on sql key name provided in designer
        /// </summary>
        /// <param name="key">Key name</param>
        /// <param name="keyValParams">Query parameters</param>
        /// <returns></returns>
        /// <remarks>Prototype for partial classes</remarks>
        public EntityContextExt<T> ReadEntityByKey(Dictionary<string, object> keyValParams, [CallerMemberName] string key = null)
        {
            return ReadEntityByKey(key, keyValParams);

            //using (DbController controller = GetController())
            //{
            //    Entity = controller.GetEntityByKey<T>(key, keyValParams);
            //}

            //return this;
        }

        /// <summary>
        /// Get entity list based on sql key name provided in designer
        /// </summary>
        /// <param name="key">Key name</param>
        /// <returns></returns>
        /// <remarks>Prototype for partial classes</remarks>
        public EntityContextExt<T> ReadEntityByKey([CallerMemberName] string key = null)
        {
            return ReadEntityByKey(key, null);
            //using (DbController controller = GetController())
            //{
            //    Entity = controller.GetEntityByKey<T>(key);
            //}

            //return this;
        }

        /// <summary>
        /// Reads From Aggregate Hierarchy
        /// </summary>
        /// <param name="whereCondition">Search criteria(where clause)</param>
        /// <param name="parameters">One or more values for query parameters. Can be null if query has no parameters.</param>
        /// <param name="depth">Aggregate depth to read</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 15/08/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> ReadFromAggregate<TU>(string whereCondition, Dictionary<string, object> parameters, int? depth = null)
            where TU : BaseModel
        {
            var definition = typeof(TU).ToDefination();
            var aggrId = definition.EntityId;


            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph<T>(aggrId, whereCondition, depth, parameters?.Keys.ToList(), parameters?.Values.ToArray());
            }
            return this;
        }

        /// <summary>
        /// Reads From Aggregate Hierarchy
        /// </summary>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 15/08/2016  1.0 Method created.</para>
        /// </remarks>
        public EntityContextExt<T> ReadFromAggregate<TU>()
            where TU : BaseModel
        {

            var definition = typeof(TU).ToDefination();
            var aggrId = definition.EntityId;


            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph<T>(aggrId, null, null, null, null);
            }
            return this;
        }

        /// <summary>
        /// Reads From Aggregate Hierarchy
        /// </summary>
        /// <param name="parameters"></param>
        /// <param name="depth"></param>
        /// <typeparam name="TU"></typeparam>
        /// <returns></returns>
        public EntityContextExt<T> ReadFromAggregate<TU>(Dictionary<string, object> parameters, int? depth = null)
            where TU : BaseModel
        {
            var definition = typeof(TU).ToDefination();
            var aggrId = definition.EntityId;


            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph<T>(aggrId, null, depth, parameters?.Keys.ToList(), parameters?.Values.ToArray());
            }
            return this;
        }

        /// <summary>
        /// Reads From Aggregate Hierarchy
        /// </summary>
        /// <param name="aggregateId">Aggregate Name</param>
        /// <param name="parameters"></param>
        /// <param name="depth"></param>
        /// <returns></returns>
        public EntityContextExt<T> ReadFromAggregate(string aggregateId, Dictionary<string, object> parameters = null, int? depth = null)
        {
            var aggrId = aggregateId;


            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph<T>(aggrId, null, depth, parameters?.Keys.ToList(), parameters?.Values.ToArray());
            }
            return this;
        }

        /// <summary>
        /// Reads From Aggregate Hierarchy
        /// </summary>
        /// <param name="expression"></param>
        /// <param name="depth"></param>
        /// <typeparam name="TU">AggregateType</typeparam>
        /// <returns></returns>
        public EntityContextExt<T> ReadFromAggregate<TU>(Expression<Func<T, bool>> expression, int? depth = null)
            where TU : BaseModel
        {
            var definition = typeof(TU).ToDefination();
            var aggrId = definition.EntityId;

            using (DbController controller = GetController())
            {
                Entity = controller.ReadEntityGraph(expression,aggrId,null, depth, GetColumnAlias);
            }
            return this;
        }

        /// <summary>
        /// Fill Childs
        /// </summary>
        /// <param name="depth"></param>
        /// <param name="aggregateId"></param>
        /// <returns></returns>
        public EntityContextExt<T> FillChilds(int? depth = null, string aggregateId = null)
        {
            using (DbController controller = GetController())
            {
                Entity = controller.FillChilds(Entity, depth, aggregateId);
            }
            return this;
        }

        /// <summary>
        /// Fill Childs
        /// </summary>
        /// <param name="depth"></param>
        /// <returns></returns>
        // ReSharper disable once UnusedMember.Local
        public EntityContextExt<T> FillChilds<TU>(int? depth = null)
            where TU : BaseModel
        {
            var definition = typeof(TU).ToDefination();
            var aggrId = definition.EntityId;

            return FillChilds(depth, aggrId);
        }



        /// <summary>
        /// Search entities based on given criteria 
        /// </summary>
        /// <param name="searchExpression">a custom where clause</param>
        /// <param name="parameters">Name/Value parameter pairs</param>
        /// <param name="attach">attach results with EntityContextExt</param>
        /// <returns>Search results</returns>
        /// <example>Search("ProductId=707");</example>
        /// <remarks>
        /// <para>[US] 21/03/2016  1.0 Method created.</para>
        /// </remarks>
        public IList<T> Search(string searchExpression, Dictionary<string, object> parameters, //SerializableDictionary<string, object> parameters,
            bool attach = false)

        {
            return Search(searchExpression, parameters, 1, attach);
        }

        /// <summary>
        /// Search entities based on given criteria 
        /// </summary>
        /// <param name="searchExpression">a custom where clause</param>
        /// <param name="parameters">Name/Value parameter pairs</param>
        /// <param name="depth">entity depth</param>
        /// <param name="attach">attach results with EntityContextExt</param>
        /// <returns>Search results</returns>
        /// <example>Search("ProductId=707");</example>
        /// <remarks>
        /// <para>[US] 21/03/2016  1.0 Method created.</para>
        /// </remarks>
        public IList<T> Search(string searchExpression, Dictionary<string, object> parameters, int? depth, bool attach = false)
        {
            //var where = _dbContext.Context.SqlStatmentProcessor(sql);
            using (DbController controller = GetController())
            {
                var ret = controller.ReadEntityGraph<T>(searchExpression, depth, parameters?.Keys.ToList(), parameters?.Values.ToArray());
                if (attach)
                {
                    if (Entity == null)
                    {
                        Entity = new List<T>();
                    }
                    if (ret != null)
                        foreach (var entity in ret)
                        {
                            Entity.Add(entity);
                        }
                }

                return ret;
            }
        }

        /// <summary>
        /// Reads entity children by using specified parameters (Lazy loading).
        /// </summary>
        /// <typeparam name="TChild">The type of child whose data will be retrieved from database.</typeparam>
        /// <param name="ids">One or more values for query parameters. Can be null if query has no parameters.</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public IEnumerable<TChild> Read<TChild>(params object[] ids)
            where TChild : BaseModel
        {
            using (DbController controller = GetController())
            {
                return controller.ReadEntityGraph<TChild>(1, ids);
            }
        }

        /// <summary>
        /// Reads entity children by specified expression (Lazy loading).
        /// </summary>
        /// <typeparam name="TChild">The type of child whose data will be retrieved from database.</typeparam>
        /// <param name="expression">Lamda expression which will be used to filter data.</param>
        /// <param name="depth">Number of levels to process in entity graph. Default is null.</param>
        /// <returns>Instance of EntityContextExt{T}.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public List<TChild> Read<TChild>(Expression<Func<TChild, bool>> expression, int? depth = null)
            where TChild : BaseModel
        {
#if DEBUG
            if (!_definition.HaveType(_definition.EntityId, typeof(TChild)))
            {
                throw new InvalidOperationException($"{typeof(TChild)} is not part of {typeof(T)} entity");
            }
#endif

            using (DbController controller = GetController())
            {
                return controller.ReadEntityGraph(expression: expression, depth: depth, memberTableNameFactory: GetColumnAlias);
            }
        }

        /// <summary>
        /// Saves changes in current entity context to database.
        /// </summary>
        /// <remarks>
        /// <param name="isValidateServer">Validate Model on Server Side or Not</param>
        /// <param name="useIdentityType">Identity Type use for insert (Scope Identity (Default), Use Sequence, Skip )</param>
        /// <param name="extendedSkipList">List of Skip Columns while Insertion</param>
        /// <param name="passIdentityType">Determine whether provided identity Type pass to childs or childs use Default Identity Type (Scope Identity)</param>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[WRB] 07/11/2017  1.1 Method Updated.</para>>
        /// </remarks>
        //[Obsolete("Use Persist without context i.e. 'Persist()'. Context parameter overload will be removed soon")]
        public void Persist(bool isValidateServer = true, InsertIdentityType useIdentityType = InsertIdentityType.ScopeIdentity, bool extendedSkipList = false,bool passIdentityType = false)//Context context
        {
            //var validateMantoryInd = false;
            //if (isValidateServer)
            //{
            //    var validateMantory = System.Configuration.ConfigurationManager.AppSettings["ServerMandatoryValidation"];
            //    if (string.IsNullOrEmpty(validateMantory))
            //        validateMantoryInd = false;
            //    else
            //    {
            //        var validateInd = bool.Parse(validateMantory);
            //        if (!validateInd)
            //            validateMantoryInd = false;
            //    }
            //}
            //if (isValidateServer)
            //{
            //    var validateIndConfig = System.Configuration.ConfigurationManager.AppSettings["ServerDataValidation"];
            //    if (string.IsNullOrEmpty(validateIndConfig))
            //        isValidateServer = false;
            //    else
            //    {
            //        var validateInd = bool.Parse(validateIndConfig);
            //        if (!validateInd)
            //            isValidateServer = false;
            //    }
            //}
            //if (isValidateServer)
            //    ValidationMapper.Initialize();

            if (_unitOfWork != null)
            {
                foreach (var poco in Entity)
                {
                    //if (isValidateServer)
                    //{
                    //    if (!ValidationChecker.CheckCombosValidation(poco, LogContext.ContextToLog.LanguageId, 1))
                    //    {
                    //        throw new ValidationException("Server validation failed for Combo Validation Failed!");
                    //    }
                    //}
                    //if (LogContext.AuditTrailInfo != null)
                    //{
                    //    var screenActionId = LogContext.AuditTrailInfo.ActionId;
                    //    if (screenActionId == "Save" && validateMantoryInd)
                    //    {

                    //        if (!ServerValidator<T>.ValidateEntity(screenActionId, poco, LogContext.AuditTrailInfo.ScreenId, 
                    //                                                LogContext.ContextToLog.LanguageId, LogContext.ContextToLog.ApplicationCode, 
                    //                                                LogContext.ContextToLog.SubTenantId))
                    //            throw new ValidationException("Server validation failed!");                        
                    //    }                        
                    //}

                    var ctlr = _unitOfWork.Controller.IdGenerated;
                    _unitOfWork.Controller.IdGenerated = IdInjector;
                    _unitOfWork.Controller.Persist(poco, useIdentityType, extendedSkipList, passIdentityType);
                    _unitOfWork.Controller.IdGenerated = ctlr;
                }
                return;
            }

            //Getting the user context which would be provided at EntityContextExt.Create method.
            var ctx = LogContext.ContextToLog;// new Context(LogContext.ContextToLog, null);
                                              //Retry mechanism..
#if !SKIPF
            TransientFaultHandler.ExecuteAction(() =>
            {
#endif
                using (DbController controller = GetController())
                {
                    controller.IdGenerated = IdInjector;

                    using (var uow = controller.UsingUnitOfWork())
                    {
                        foreach (var poco in Entity)
                        {
                            //if (isValidateServer)
                            //{
                            //    if (!ValidationChecker.CheckCombosValidation(poco, LogContext.ContextToLog.LanguageId, 1))
                            //    {
                            //        throw new ValidationException("Server validation failed for Combo Validation Failed!");
                            //    }
                            //}
                            //if (LogContext.AuditTrailInfo != null)
                            //{
                            //    var screenActionId = LogContext.AuditTrailInfo.ActionId;
                            //    if (screenActionId == "Save" && validateMantoryInd)
                            //    {
                            //        if (!ServerValidator<T>.ValidateEntity(screenActionId, poco, LogContext.AuditTrailInfo.ScreenId, LogContext.ContextToLog.LanguageId, LogContext.ContextToLog.ApplicationCode,
                            //            LogContext.ContextToLog.SubTenantId))
                            //            throw new ValidationException("Server validation failed!");                                
                            //    }                            
                            //}
                            controller.Persist(poco, useIdentityType, extendedSkipList, passIdentityType);
                        }

                        uow.Save();

                        Accept();
                    }
                }
#if !SKIPF
            }, ctx, TransientRetryStrategy.Default, TransientDetectionStrategy.OrmDetectionStrategy);
#endif

        }
        /// <summary>
        /// Insert Bulk Records 
        /// </summary>
        /// <param name="batchSize">No of Records write to Server in One Batch</param>
        /// <param name="sqlBulkCopyOptions">Bulk Copy Option</param>
        /// <param name="notifyAfter">Number of Records to notify handler</param>
        /// <param name="handler">Notify Handler</param>
        /// <para>[WB] 11/05/2018  1.0 Method created.</para>
        public void InsertBulk(SqlBulkCopyOptions sqlBulkCopyOptions= SqlBulkCopyOptions.Default, int batchSize= 10000, int notifyAfter= 10000, SqlRowsCopiedEventHandler handler=null)
        {
            using (DbController controller = GetController())
            {
                    controller.BulkInsert(Entity, sqlBulkCopyOptions, batchSize, notifyAfter, handler);
            }
        }

        /// <summary>
        /// Insert Bulk Records 
        /// </summary>
        /// <param name="handleTracking">Hndle Tracking Fields such as Inserted/Updated Date and User</param>
        /// <param name="batchSize">No of Records write to Server in One Batch</param>
        /// <param name="sqlBulkCopyOptions">Bulk Copy Option</param>
        /// <param name="notifyAfter">Number of Records to notify handler</param>
        /// <param name="handler">Notify Handler</param>
        /// <para>[WB] 11/05/2018  1.0 Method created.</para>
        public void BulkInsertAggregate(bool handleTracking=false,SqlBulkCopyOptions sqlBulkCopyOptions = SqlBulkCopyOptions.Default, int batchSize = 10000, int notifyAfter = 10000, SqlRowsCopiedEventHandler handler = null)
        {
            if (_unitOfWork != null)
            {
                _unitOfWork.Controller.BulkInsertAggregate(Entity, handleTracking, sqlBulkCopyOptions, batchSize, notifyAfter, handler);
                return;
            }
            using (DbController controller = GetController())
            {
                using (var uow = controller.UsingUnitOfWork())
                {
                    controller.BulkInsertAggregate(Entity, handleTracking, sqlBulkCopyOptions, batchSize, notifyAfter, handler);
                    uow.Save();
                    Accept();
                }
            }
        }


        ///// <summary>
        ///// Saves changes in current entity context to database.
        ///// </summary>
        ///// <remarks>
        ///// <para>[US] 23/02/2016  1.0 Method created.</para>
        ///// </remarks>
        //public void Persist()
        //{
        //    Persist(null);
        //}

        void Accept()
        {
            //TODO: call "AcceptChanges" instead of scanning aggregate. but its in BETA
            AcceptChanges();

            //ScanEntity(a =>
            //{
            //    if (a.State != EntityState.Delete && a.State != EntityState.New)
            //        a.State = EntityState.NotModified;
            //});
        }

        /// <summary>
        /// Add existing unit of work (transaction) to EntityContextExt
        /// </summary>
        /// <param name="uow"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public EntityContextExt<T> UsingUnitOfWork(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException(nameof(uow));

            //_usingUnitOfWork = true;
            _unitOfWork = uow;
            _unitOfWork.Controller.OnSaveAction(Accept);
            _unitOfWork.Controller.OnSaveAction(ResetUnitOfWork);
            _unitOfWork.Controller.OnRollbackAction(ResetUnitOfWork);
            return this;
        }

        /// <summary>
        /// Starts a new unit of work (transaction) on entity context that can be passed to other EntityContextExt
        /// </summary>
        /// <returns>Unit Of Work<see cref="IUnitOfWork" /></returns>
        /// <exception cref="InvalidOperationException"></exception>
        public IUnitOfWork InitiateUnitOfWork(IsolationLevel level = IsolationLevel.ReadCommitted)
        {
            if (_unitOfWork != null)
                throw new InvalidOperationException("Unit of Work already exist. Either shared connection or transaction is already enabled");

            var uow = GetController().UsingIsolationLevel(level).UsingUnitOfWork(Accept);
            _unitOfWork = uow;
            _isInTransactionMode = true;
            _unitOfWork.Controller.OnSaveAction(ResetUnitOfWork);
            _unitOfWork.Controller.OnRollbackAction(ResetUnitOfWork);


            return _unitOfWork;
        }

        /// <summary>
        /// Enables shared connection throughout the context lifecycle. Use with caution, It will conflict with UnitOfWork
        /// </summary>
        /// <exception cref="InvalidOperationException"></exception>
        public EntityContextExt<T> EnableSharedConnection()
        {
            if (_unitOfWork != null)
                throw new InvalidOperationException("Cannot enable shared connection if Unit of Work already exist. You are already on shared connection");
            if (_sharedController != null)
                throw new InvalidOperationException("This context already has a shared connection");

            var c = GetController();
            c.EnableSharedConnection();
            _sharedController = c;
            return this;
        }
        
        /// <summary>
        /// Enables shared connection throughout the context lifecycle. Use with caution, It will conflict with UnitOfWork
        /// </summary>
        /// <exception cref="InvalidOperationException"></exception>
        public EntityContextExt<T> EnableSharedConnectionFromContext<TU>(EntityContextExt<TU> contextExt) where TU : BaseModel, new()
        {
            if (_unitOfWork != null)
                throw new InvalidOperationException("Cannot enable shared connection if Unit of Work already exist. You are already on shared connection");

            if (_sharedController != null)
                throw new InvalidOperationException("This context already has a shared connection");

            if (contextExt._sharedController == null)
                throw new InvalidOperationException("Provided context don't have shared connection. Please Enable shared connection on EntityContextExt first");

            
            
            _sharedController = contextExt._sharedController;
            return this;
        }

        /// <summary>
        /// Enables shared connection throughout the context lifecycle. Use with caution, It will conflict with UnitOfWork
        /// </summary>
        /// <exception cref="InvalidOperationException"></exception>
        public SharedDbConnection GetShareableDbConnection()
        {
            if (_sharedController == null)
                EnableSharedConnection();

            var visitor = new SharedDbConnection { Controller = _sharedController };
            return visitor;
        }

        /// <summary>
        /// Enables shared connection with existing connection
        /// </summary>
        /// <exception cref="InvalidOperationException"></exception>
        public EntityContextExt<T> SetSharedConnection(SharedDbConnection visitor)
        {
            if (_unitOfWork != null)
                throw new InvalidOperationException("Cannot enable shared connection if Unit of Work already exist. You are already on shared connection");

            if (_sharedController != null && !ReferenceEquals(visitor.Controller, _sharedController))
                throw new InvalidOperationException("This context already has a shared connection");

            _sharedController = visitor.Controller;
            return this;
        }


        /// <summary>
        /// Save changes i.e. Commit transation
        /// </summary>
        /// <exception cref="InvalidOperationException"></exception>
        public void SaveChanges()
        {
            if (_unitOfWork == null)
                return;// throw new InvalidOperationException("Unit of Work not found");
            if (!_isInTransactionMode)
                throw new InvalidOperationException("Save changes can be called only on EntityContext that Initiates UnitOfWork by calling InitiateUnitOfWork");

            _unitOfWork.Save();
            _unitOfWork.Dispose();
            //_unitOfWork.Controller.Dispose();
            //_unitOfWork = null;
            ////_usingUnitOfWork = false;
            //_isInTransactionMode = false;
            ResetUnitOfWork();
        }


        /// <summary>
        /// Discard changes i.e. Rollback transaction
        /// </summary>
        /// <exception cref="InvalidOperationException"></exception>
        public void DiscardChanges()
        {
            if (_unitOfWork == null)
                return;// throw new InvalidOperationException("Unit of Work not found");
            if (!_isInTransactionMode)
                throw new InvalidOperationException("Discard changes can be called only on EntityContext that Initiates UnitOfWork by calling InitiateUnitOfWork");

            _unitOfWork.Dispose(); //rollback
            //_unitOfWork.Controller.Dispose();
            //_unitOfWork = null;
            ////_usingUnitOfWork = false;
            //_isInTransactionMode = false;
            ResetUnitOfWork();
        }

        void ResetUnitOfWork()
        {
            _unitOfWork?.Controller.Dispose();
            _unitOfWork = null;
            //_usingUnitOfWork = false;
            _isInTransactionMode = false;

            _sharedController?.Dispose();
        }

        #region Child Getter via Property (commented)
        //public IEnumerable<TChild> Read<TChild>(Expression<Func<T, BaseModel>> selector, params object[] ids) where TChild : BaseModel
        //{
        //    var prop = (PropertyInfo)((MemberExpression)selector.Body).Member;
        //    var type = prop.PropertyType;

        //    var tnType = typeof (TChild);
        //    if(tnType!=type)
        //        throw new InvalidCastException("Provided property type and Argument type not matched");

        //    using (DbController controller = GetController())
        //    {
        //        return controller.ReadEntityGraph<TChild>(ids);
        //    }
        //}

        #endregion

        /// <summary>
        /// Gets all entity objects (including its children) in the specified entity.
        /// </summary>
        /// <param name="item">The entity object</param>
        /// <returns>Enumeration of entity objects.</returns>
        /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public IEnumerable<BaseModel> GetAll(BaseModel item)
        {
            if (item != null)
            {
                yield return item;
                var defination = item.GetType().ToDefination();
                foreach (var child in defination.GetChilds(item).SelectMany(GetAll))
                {
                    yield return child;
                }
            }
        }

        /// <summary>
        /// Executes the specifed action on entity in context. See <see cref="NS.ORM.EntityContext{T}.Entity"/>
        /// </summary>
        /// <param name="scanAction">The action to execute.</param>
        /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public override void ScanEntity(Action<BaseModel> scanAction)
        {
            if (Entity != null && scanAction != null)
            {
                foreach (
                    var ent in
                        Entity.SelectMany(GetAll).Where(a => a != null))
                {
                    scanAction(ent);
                }
            }
        }

        /// <summary>
        /// Accept changes
        /// </summary>
        /// <param name="item">The entity object</param>
        /// <returns>Enumeration of entity objects.</returns>
        /// <remarks>
        /// <para>[US] 11/04/2016  1.0 Method created.</para>
        /// </remarks>
        internal IEnumerable<BaseModel> AcceptChangesInternal(BaseModel item)
        {
            if (item != null)
            {
                yield return item;
                var defination = item.GetType().ToDefination();
                foreach (var child in defination.AcceptChildCollections(item).SelectMany(AcceptChangesInternal))
                {
                    yield return child;
                }
            }
        }

        /// <summary>
        /// Accept changes i.e. remove all deleted and new entities from aggregate and set rest of entities as not-modified/NotModified.
        /// Be careful! This method doesn't persist changes to database. 
        /// </summary>
        /// <remarks>
        /// <para>[US] 11/04/2016  1.0 Method created.</para>
        /// </remarks>
        public void AcceptChanges(bool setRowState = true)
        {
            if (Entity != null)
            {
                var clean = Entity.Where(a => a.State == EntityState.Delete || a.State == EntityState.New).ToList();
                if (clean.Count > 0)
                {
                    //if (!Entity.IsReadOnly)
                    {
                        clean.ForEach(c => Entity.Remove(c));
                    }
                    //else
                    //{
                    //    Entity = Entity.Except(clean).ToList();
                    //    //TODO: if readonly/fixedlength list, throw exception???
                    //}
                }

                foreach (
                    var ent in
                        Entity.SelectMany(AcceptChangesInternal).Where(a => a != null))
                {
                    if (setRowState)
                    {
                        ent.State = EntityState.NotModified;
                    }
                }
            }
        }

        /// <summary>
        /// Creates object of the specified type and add it to Controller's Entity collection
        /// </summary>
        /// <returns>The instance of the specified type.</returns>
        /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public T CreateNew()
        {
            var e = CreateNew<T>();
            var eList = Entity ?? (Entity = new List<T>());// as IList<T>;
            eList.Add(e);
            return e;
        }

        /// <summary>
        /// Creates object of the specified type.
        /// </summary>
        /// <typeparam name="TU">The type of object to create.</typeparam>
        /// <returns>The instance of the specified type.</returns>
        /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public TU CreateNew<TU>() where TU : BaseModel, new()
        {
            TU item = new TU();
            //if (_auditingOn)
            //    item.AuditOn = true;

            return item;
        }

        /// <summary>
        /// Performs cleanup
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[AQ] 03/07/2017  1.1 Comments added.</para>
        /// <para>[AQ] 03/07/2017  2.0 Method modified.</para>
        /// </remarks>
        public void Dispose()
        {
            Dispose(true);
            //GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Custom Dispose(bool) Implementation. Takes care of Managed and Unmanaged resources
        /// </summary>
        /// <param name="isDisposing">A true value directs the function to cleanup managed resources along with unmanaged resources. A false value directs the function to clean native/un-managed resources only</param>
        /// <remarks>
        /// <para>[AQ] 03/07/2017  1.0 Method created.</para>
        /// </remarks>
        private void Dispose(bool isDisposing)
        {
            if (!_isDisposed)
            {

                if (isDisposing)
                {
                    //Dispose managed resource only
                    ResetUnitOfWork();
                }
                //Dispose any unmanaged resources
                //Dispose any native resources
                //A function that disposes native/unmanaged resources only can be called here.
                _isDisposed = true;
            }

        }

        /// <summary>
        /// Join entity with Other entity for reading purpose
        /// </summary>
        /// <param name="expression">Join expression</param>
        /// <param name="select">override default select statement</param>
        /// <typeparam name="TU">Joining entity</typeparam>
        /// <returns></returns>
        /// <para>[US] 29/08/2016  1.0 Method created.</para>
        /// <example>See ORM unit test for example (TestReadV2Join)</example>
        public EntityJoin<TU> Join<TU>(Expression<Func<T, TU, bool>> expression, string select = null)
        {
            return EntityJoin<T>.CreateJoin(expression, _definition, this, select);
        }

        /// <summary>
        /// EntityJoin class. Its not intended to be used directly by user/developer. ORM Engine uses it internally
        /// </summary>
        /// <typeparam name="TA"></typeparam>
        /// <para>[US] 29/08/2016  1.0 Class created.</para>
        public class EntityJoin<TA>
        {
            private string _selectSql;
            private readonly string _joinSql;
            private readonly string _tuTableName;
            private int _parameterCounter;
            Tuple<string, List<KeyValuePair<string, object>>> _rets;
            private EntityContextExt<T> _context;

            /// <summary>
            /// constructor
            /// </summary>
            /// <param name="selectSql"></param>
            /// <param name="joinSql"></param>
            /// <param name="tuTableName"></param>
            /// <param name="parameterCounter"></param>
            public EntityJoin(string selectSql, string joinSql, string tuTableName, int parameterCounter)
            {
                _selectSql = selectSql;
                _joinSql = joinSql;
                _tuTableName = tuTableName;
                _parameterCounter = parameterCounter;
            }

            /// <summary>
            /// Append where criteria
            /// </summary>
            /// <param name="condition"></param>
            /// <returns></returns>
            /// <para>[US] 29/08/2016  1.0 Method created.</para>
            public EntityJoin<TA> Where(Expression<Func<TA, bool>> condition)
            {
                if (condition != null)
                {
                    //ConditionComposer<T1> composer=new ConditionComposer<T1>();
                    QueryTranslator translator = new QueryTranslator();
                    translator.MemberTableNameFactory = s => _tuTableName;
                    translator.ParameterCounter = _parameterCounter;
                    var rets = translator.Translate<TA>(condition);
                    _parameterCounter = translator.ParameterCounter;
                    if (_rets == null)
                        _rets = rets;
                    else
                    {
                        _rets.Item2.AddRange(rets.Item2);
                        _rets = Tuple.Create(_rets.Item1 + " AND " + rets.Item1, _rets.Item2);
                    }
                }
                return this;
            }

            /// <summary>
            /// Append where criteria
            /// </summary>
            /// <param name="searchExpression"></param>
            /// <param name="parameters"></param>
            /// <returns></returns>
            /// <para>[WRB] 23/08/2017  1.0 Method created.</para>
            public EntityJoin<TA> Where(string searchExpression, List<KeyValuePair<string, object>> parameters)
            {
                var rets = Tuple.Create(searchExpression, parameters);
                if (_rets == null)
                    _rets = rets;
                else
                {
                    _rets.Item2.AddRange(rets.Item2);
                    _rets = Tuple.Create(_rets.Item1 + " AND " + rets.Item1, _rets.Item2);
                }
                return this;
            }

            /// <summary>
            /// Add join
            /// </summary>
            /// <param name="expression"></param>
            /// <typeparam name="TU"></typeparam>
            /// <returns></returns>
            /// <para>[US] 29/08/2016  1.0 Method created.</para>
            public EntityJoin<TU> Join<TU>(Expression<Func<TA, TU, bool>> expression)
            {
                var r = AppendJoin(expression, typeof(TA).ToDefination(), this);
                return r;
            }

            /// <summary>
            /// Read entity based on join
            /// </summary>
            /// <returns></returns>
            /// <para>[US] 29/08/2016  1.0 Method created.</para>
            public EntityContextExt<T> Read()
            {
                Dictionary<string, object> dictionary = null;
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(_selectSql);
                sb.AppendLine(_joinSql);
                if (_rets != null)
                {
                    sb.Append(" WHERE ");
                    sb.AppendLine(_rets.Item1);
                    dictionary = _rets.Item2.ToDictionary(r => r.Key, s => s.Value);
                }

                var sql = sb.ToString();
                _context.GetEntityWithSql(sql, dictionary);
                return _context;
            }


            internal static EntityJoin<TU> CreateJoin<TU, TP>(Expression<Func<TP, TU, bool>> expression,
                BaseDefination definition,
                EntityContextExt<T> context, string select)
            {
                var joiner = AppendJoin(expression, definition, null);
                joiner._context = context;
                if (!string.IsNullOrWhiteSpace(select))
                    joiner._selectSql = select;

                return joiner;
            }

            internal static EntityJoin<TU> AppendJoin<TU, TP>(Expression<Func<TP, TU, bool>> expression, BaseDefination definition,
                EntityJoin<TP> joiner) //, EntityContextExt<T> context
            {
                StringBuilder sb = new StringBuilder();
                var joinExpression = QueryTranslator.GetBinaryExpression(expression.Body);
                var leftExpressionName = QueryTranslator.GetMemberExpression(joinExpression.Left).Member.Name;
                var rightExpressionName = QueryTranslator.GetMemberExpression(joinExpression.Right).Member.Name;

                var selectQuery = joiner == null ? definition.SelectQuery : joiner._selectSql;

                //sb.Append("SELECT DISTINCT " + selectQuery.Trim().Substring(7));// FAILED FOR XML TYPE
                //sb.Append(selectQuery);

                var tTableName = definition.UpdateTableName;
                var tuTableName = typeof(TU).ToDefination().UpdateTableName;
                var lcolumnName = leftExpressionName;//QueryTranslator.GetColumnName(leftExpression);
                var rcolumnName = rightExpressionName;//QueryTranslator.GetColumnName(rightExpression);

                string tTableNameAlias = string.Empty, tuTableNameAlias = string.Empty;
                definition.ColumnTable?.TryGetValue(lcolumnName, out tTableNameAlias);
                typeof(TU).ToDefination().ColumnTable?.TryGetValue(rcolumnName, out tuTableNameAlias);

                if (joiner != null) sb.Append(joiner._joinSql);

                var joinString = " JOIN " + $"{tuTableName} {tuTableNameAlias} ON {$"{(string.IsNullOrEmpty(tTableNameAlias) ? tTableName : tTableNameAlias)}.{lcolumnName}"} = {$"{(string.IsNullOrEmpty(tuTableNameAlias) ? tuTableName : tuTableNameAlias)}.{rcolumnName}"} ";
                sb.AppendLine(joinString);

                var joinHelper = new EntityJoin<TU>(selectQuery, sb.ToString(), tuTableName, joiner?._parameterCounter ?? 0)
                {
                    _rets = joiner?._rets,
                    _context = joiner?._context,
                };

                return joinHelper;

            }
        }
    }

    /// <summary>
    /// Static class for creating EntityContext
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public static class EntityContextExt
    {
        /// <summary>
        /// Creates entity context of the specified entity type
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <param name="entity">Enumeration of entity objects. Default is null.</param>
        /// <returns>EntityContextExt of the specified entity type</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static EntityContextExt<T> Create<T>(List<T> entity = null) where T : BaseModel, new()
        {
            return EntityContextExt<T>.Create(entity);
        }

        /// <summary>
        /// Creates entity context of the specified entity type
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <param name="entity">Enumeration of entity objects. Default is null.</param>
        /// <param name="commandTimeOut">Command Time Out.</param>
        /// <returns>EntityContextExt of the specified entity type</returns>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create<T>(int commandTimeOut, List<T> entity = null) where T : BaseModel, new()
        {
            return EntityContextExt<T>.Create(entity, commandTimeOut);
        }

        /// <summary>
        /// Creates entity context of the specified entity type
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <param name="entity">Enumeration of entity objects. Default is null.</param>
        /// <returns>EntityContextExt of the specified entity type</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create<T>(IList<T> entity) where T : BaseModel, new()
        {
            return EntityContextExt<T>.Create(entity as List<T> ?? entity?.ToList());
        }

        /// <summary>
        /// Creates entity context of the specified entity type
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <param name="entity">Enumeration of entity objects. Default is null.</param>
        /// <param name="commandTimeOut">Enumeration of entity objects. Default is null.</param>
        /// <returns>EntityContextExt of the specified entity type</returns>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create<T>(IList<T> entity, int commandTimeOut) where T : BaseModel, new()
        {
            return EntityContextExt<T>.Create(entity as List<T> ?? entity?.ToList(), commandTimeOut);
        }

        /// <summary>
        /// Creates entity context of the specified entity type
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <param name="connectionString">The connection string</param>
        /// <param name="provider">The database provider</param>
        /// <returns>EntityContextExt of the specified entity type</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static EntityContextExt<T> Create<T>(string connectionString, DbProvider provider = DbProvider.SqlServer) where T : BaseModel, new()
        {
            return EntityContextExt<T>.Create(connectionString, provider);
        }

        /// <summary>
        /// Creates entity context of the specified entity type
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <param name="connectionString">The connection string</param>
        /// <param name="provider">The database provider</param>
        /// <param name="commandTimeOut">Command Time Out</param>
        /// <returns>EntityContextExt of the specified entity type</returns>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create<T>(int commandTimeOut, string connectionString, DbProvider provider = DbProvider.SqlServer) where T : BaseModel, new()
        {
            return EntityContextExt<T>.Create(commandTimeOut, connectionString, provider);
        }

        /// <summary>
        /// Creates entity context of the specified entity type
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <param name="entity">Enumeration of entity objects.</param>
        /// <param name="connectionString">The connection string</param>
        /// <param name="provider">The database provider. Default is SqlServer.</param>
        /// <returns>EntityContextExt of the specified entity type</returns>
        ///  /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static EntityContextExt<T> Create<T>(IList<T> entity, string connectionString, DbProvider provider = DbProvider.SqlServer) where T : BaseModel, new()
        {
            return EntityContextExt<T>.Create(entity, connectionString, provider);
        }

        /// <summary>
        /// Creates entity context of the specified entity type
        /// </summary>
        /// <typeparam name="T">The entity type</typeparam>
        /// <param name="entity">Enumeration of entity objects.</param>
        /// <param name="connectionString">The connection string</param>
        /// <param name="commandTimeOut">The connection string</param>
        /// <param name="provider">The database provider. Default is SqlServer.</param>
        /// <returns>EntityContextExt of the specified entity type</returns>
        ///  /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static EntityContextExt<T> Create<T>(IList<T> entity, int commandTimeOut, string connectionString, DbProvider provider = DbProvider.SqlServer) where T : BaseModel, new()
        {
            return EntityContextExt<T>.Create(entity, commandTimeOut, connectionString, provider);
        }
    }
    /// <summary>
    /// This is a class for Entity Name
    /// </summary>
    [XmlRoot("Entity")]
    public class EntityName
    {
        private string _nameField;
        /// <remarks/>
        [XmlAttribute]
        public string Name
        {
            get
            {
                return _nameField;
            }
            set
            {
                _nameField = value;
            }
        }

    }

    /// <summary>
    /// Repersent Identity Type
    /// <para>[WRB] 07/11/2017  1.0 Enum Created for Insert.</para>>
    /// </summary>
    public enum InsertIdentityType
    {
        /// <summary>
        /// Use Scope Identity
        /// </summary>
        [Key("ScopeIdentity")]
        ScopeIdentity,
        /// <summary>
        /// Set Identity Insert Off
        /// </summary>
        [Key("SkipIdentity")]
        SkipIdentity,

        /// <summary>
        /// Use Sequence Table for Identity
        /// </summary>
        [Key("UseSequence")]
        UseSequence
    }

    /// <summary>
    /// SharedDbConnection
    /// </summary>
    public class SharedDbConnection
    {
        internal DbController Controller { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using NS.BaseModels;
using NS.ORM.Definitions;
using NS.ORM.Definitions.Classes;
using NS.ORM.FluentData;
using NS.ORM.FluentData.Command;

namespace NS.ORM.Helper
{
    /// <summary>
    /// Provides multi-resultset reading from command(see <see cref="IDbCommand"/>)
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    internal sealed class ModelReader: IModelReader
    {
        #region Fields

        //private readonly DbBatch _batch;//HACK: commented unused field
        private readonly IDbContext _dbContext;
        private readonly object[] _ids;
        private readonly Action<string, IEnumerable<object>> _onSqlStatmentGenerated;
        //private readonly bool _multiResultsetSupported = true;//﻿Field initializer value ignored during initialization
        private readonly bool _multiResultsetSupported;



        private IDbCommand _cmd;
        private readonly Queue<string> _queryQueue;
        private DbBatch _batch;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor for ModelReader.
        /// </summary>
        /// <param name="cmd">The command to use for data reading.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public ModelReader(IDbCommand cmd)
        {
            _cmd = cmd;
            _multiResultsetSupported = true;
        }

        /// <summary>
        /// Constructor for ModelReader.
        /// </summary>
        /// <param name="dbContext">DbContext</param>
        /// <param name="batch">DbBatch</param>
        /// <param name="ids">Values of query parameters</param>
        /// <param name="onSqlStatmentGenerated"></param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public ModelReader(IDbContext dbContext, DbBatch batch, object[] ids, Action<string, IEnumerable<object>> onSqlStatmentGenerated)
        {
            _dbContext = dbContext;
            _batch = batch;//HACK: commented unused field
            _queryQueue=new Queue<string>();
            foreach (var pair in batch.GetQueries())
            {
                _queryQueue.Enqueue(pair.Key);
            }
            _ids = ids;
            _onSqlStatmentGenerated = onSqlStatmentGenerated;
            _multiResultsetSupported = false;
        }

        #endregion

        #region IModelReader Members

        /// <summary>
        /// Get List of entities
        /// </summary>
        /// <typeparam name="T">The type of entity.</typeparam>
        /// <returns>List of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> GetList<T>() where T : BaseModel
        {
            var def = typeof(T).ToDefination();
            //return _cmd.QueryMany<T>(def.CustomMapper);
            return GetWithDefination<T>(def);
        }

        //public List<T> GetAuto<T>(Action<T, IDbReader> customMapper=null) where T : BaseModel
        //{
        //    return _cmd.QueryMany<T>(customMapper);
        //}

        //public List<T> GetManual<T>(Action<T, IDbReader> manualMapper=null) where T : BaseModel
        //{
        //    return _cmd.QueryMany<T>(manualMapper);
        //}


        /// <summary>
        /// Get List of entities by using the specified entity definition
        /// </summary>
        /// <typeparam name="T">The type of entity.</typeparam>
        /// <param name="defination">The entity definition.</param>
        /// <returns>List of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> GetWithDefination<T>(BaseDefination defination) where T : BaseModel
        {
            if (_multiResultsetSupported)
            {
                if (defination.UseManualMapping)
                    return _cmd.QueryMany<T>(defination.ManualMapping);
                else
                    return _cmd.QueryMany<T>(defination.CustomMapper); 
            }
            else
            {
                //in case of oracle, a db hit will be sent for each sql statment instead of multiresultset
                var sql = _queryQueue.Dequeue();
                sql = _dbContext.SqlStatmentProcessor(sql); //sql.Replace('@', ':'); //Hack: oracle parameter name starts with ':' instead of '@'

                _onSqlStatmentGenerated?.Invoke(sql, _ids);

                var selectBuilder = _dbContext.Sql(sql, _ids); //(sql).Parameters(_ids);
                if (_batch != null && _batch.ParameterList != null)
                {
                    foreach (var pair in _batch.ParameterList)
                    {
                        selectBuilder = selectBuilder.Parameter(pair.Key, pair.Value);
                    }
                }

                if (defination.UseManualMapping)
                    return selectBuilder.QueryMany<T>(defination.ManualMapping);
                else
                    return selectBuilder.QueryMany<T>(defination.CustomMapper); 

            }
        }

        /// <summary>
        /// Performs cleanup
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public void Dispose()
        {
            _cmd = null;
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace NS.ORM.Helper
{
    //Usman Sabir : First version created
    //Reference https://msdn.microsoft.com/library/bb546158(v=vs.110).aspx
    // ReSharper disable once InconsistentNaming
    internal class NFSQueryTranslator : ExpressionVisitor
    {
        private StringBuilder _sb;
        private List<KeyValuePair<string, object>> _sqlParams;
        //HACK: removed redundant field initializer
        //private int _prmCounter = 0;
        private int _prmCounter;
        private string _orderBy = string.Empty;

        //HACK: removed redundant field initializer
        //private int? _skip = null;
        private int? _skip;

        //HACK: removed redundant field initializer
        //private int? _take = null;
        private int? _take;

        private string _whereClause = string.Empty;

        public int? Skip
        {
            get
            {
                return _skip;
            }
        }

        public int? Take
        {
            get
            {
                return _take;
            }
        }

        public string OrderBy
        {
            get
            {
                return _orderBy;
            }
        }

        public string WhereClause
        {
            get
            {
                return _whereClause;
            }
        }

        public List<KeyValuePair<string, object>> SqlParams
        {
            get { return _sqlParams; }
        }

        public Tuple<string, List<KeyValuePair<string, object>>> Translate(Expression expression)
        {
            _sb = new StringBuilder();
            _sqlParams = new List<KeyValuePair<string, object>>();
            _prmCounter = 0;
            Visit(expression);
            _whereClause = _sb.ToString();
            var tpl = Tuple.Create(_whereClause, _sqlParams);
            return tpl;// _whereClause;
        }

        private static Expression StripQuotes(Expression e)
        {
            while (e.NodeType == ExpressionType.Quote)
            {
                e = ((UnaryExpression)e).Operand;
            }
            return e;
        }

        //more help from msdn https://msdn.microsoft.com/library/bb546158(v=vs.110).aspx
        protected override Expression VisitMethodCall(MethodCallExpression m)
        {
            if (m.Method.DeclaringType == typeof(Queryable) && m.Method.Name == "Where")
            {
                Visit(m.Arguments[0]);
                LambdaExpression lambda = (LambdaExpression)StripQuotes(m.Arguments[1]);
                Visit(lambda.Body);
                return m;
            }
            else if (m.Method.Name == "Take")
            {
                if (ParseTakeExpression(m))
                {
                    Expression nextExpression = m.Arguments[0];
                    return Visit(nextExpression);
                }
            }
            else if (m.Method.Name == "Skip")
            {
                if (ParseSkipExpression(m))
                {
                    Expression nextExpression = m.Arguments[0];
                    return Visit(nextExpression);
                }
            }
            else if (m.Method.Name == "OrderBy")
            {
                if (ParseOrderByExpression(m, "ASC"))
                {
                    Expression nextExpression = m.Arguments[0];
                    return Visit(nextExpression);
                }
            }
            else if (m.Method.Name == "OrderByDescending")
            {
                if (ParseOrderByExpression(m, "DESC"))
                {
                    Expression nextExpression = m.Arguments[0];
                    return Visit(nextExpression);
                }
            }

            throw new NotSupportedException(string.Format("The method '{0}' is not supported", m.Method.Name));
        }

        protected override Expression VisitUnary(UnaryExpression u)
        {
            switch (u.NodeType)
            {
                case ExpressionType.Not:
                    _sb.Append(" NOT ");
                    Visit(u.Operand);
                    break;
                case ExpressionType.Convert:
                    Visit(u.Operand);
                    break;
                default:
                    throw new NotSupportedException(string.Format("The unary operator '{0}' is not supported", u.NodeType));
            }
            return u;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="b"></param>
        /// <returns></returns>
        protected override Expression VisitBinary(BinaryExpression b)
        {
            _sb.Append("(");
            Visit(b.Left);

            switch (b.NodeType)
            {
                case ExpressionType.And:
                    _sb.Append(" AND ");
                    break;

                case ExpressionType.AndAlso:
                    _sb.Append(" AND ");
                    break;

                case ExpressionType.Or:
                    _sb.Append(" OR ");
                    break;

                case ExpressionType.OrElse:
                    _sb.Append(" OR ");
                    break;

                case ExpressionType.Equal:
                    if (IsNullConstant(b.Right))
                    {
                        _sb.Append(" IS ");
                    }
                    else
                    {
                        _sb.Append(" = ");
                    }
                    break;

                case ExpressionType.NotEqual:
                    if (IsNullConstant(b.Right))
                    {
                        _sb.Append(" IS NOT ");
                    }
                    else
                    {
                        _sb.Append(" <> ");
                    }
                    break;

                case ExpressionType.LessThan:
                    _sb.Append(" < ");
                    break;

                case ExpressionType.LessThanOrEqual:
                    _sb.Append(" <= ");
                    break;

                case ExpressionType.GreaterThan:
                    _sb.Append(" > ");
                    break;

                case ExpressionType.GreaterThanOrEqual:
                    _sb.Append(" >= ");
                    break;

                default:
                    throw new NotSupportedException(string.Format("The binary operator '{0}' is not supported", b.NodeType));

            }

            Visit(b.Right);
            _sb.Append(")");
            return b;
        }

        int GetNextParam()
        {
            return _prmCounter++;
        }

        string GetNextParamString()
        {
            return GetNextParam().ToString();
        }

        protected override Expression VisitConstant(ConstantExpression c)
        {
            IQueryable q = c.Value as IQueryable;

            if (q == null && c.Value == null)
            {
                var s = GetNextParamString();
                _sb.Append(s); //sb.Append("NULL");
                _sqlParams.Add(new KeyValuePair<string, object>(s, DBNull.Value));
            }
            else if (q == null)
            {
                var s = GetNextParamString();
                _sqlParams.Add(new KeyValuePair<string, object>(s, c.Value));
                _sb.Append("@" + s);
                switch (Type.GetTypeCode(c.Value.GetType()))
                {
                    //case TypeCode.Boolean:
                    //    //sb.Append(s); //sb.Append(((bool)c.Value) ? 1 : 0);
                    //    break;

                    //case TypeCode.String:
                    //    sb.Append("@" + _prmCounter++); //
                    //    //sb.Append("'");
                    //    //sb.Append(c.Value);
                    //    //sb.Append("'");
                    //    break;

                    //case TypeCode.DateTime:
                    //    sb.Append("@" + _prmCounter++); //
                    //    //sb.Append("'");
                    //    //sb.Append(c.Value);
                    //    //sb.Append("'");
                    //    break;

                    case TypeCode.Object:
                        throw new NotSupportedException(string.Format("The constant for '{0}' is not supported", c.Value));

                    //default:
                    //    //sb.Append("@" + _prmCounter++); //sb.Append(c.Value);
                    //    break;
                }
            }

            return c;
        }

        protected override Expression VisitMember(MemberExpression m)
        {
            if (m.Expression != null && m.Expression.NodeType == ExpressionType.Parameter)
            {
                _sb.Append(m.Member.Name); //property name
                Debug.WriteLine(m.Member.Name);
                return m;
            }
            else if (m.NodeType == ExpressionType.MemberAccess)
            {
                //probably some object's property getter expression, compile and call getter
                var objectMember = Expression.Convert(m, typeof(object));
                var getterLambda = Expression.Lambda<Func<object>>(objectMember);
                var getter = getterLambda.Compile();

                var val = getter(); //here we get value
                var s = GetNextParamString();
                _sb.Append("@" + s); 
                _sqlParams.Add(new KeyValuePair<string, object>(s, val??DBNull.Value)); //pass DBNull in case of null
                return m;
            }
            
            //hmmm... be carefull while passing expression arguments
            throw new NotSupportedException(string.Format("The member '{0}' is not supported", m.Member.Name));
        }

        protected bool IsNullConstant(Expression exp)
        {
            return (exp.NodeType == ExpressionType.Constant && ((ConstantExpression)exp).Value == null);
        }

        private bool ParseOrderByExpression(MethodCallExpression expression, string order)
        {
            UnaryExpression unary = (UnaryExpression)expression.Arguments[1];
            LambdaExpression lambdaExpression = (LambdaExpression)unary.Operand;

            lambdaExpression = (LambdaExpression)Evaluator.PartialEval(lambdaExpression);

            MemberExpression body = lambdaExpression.Body as MemberExpression;
            if (body != null)
            {
                if (string.IsNullOrEmpty(_orderBy))
                {
                    _orderBy = string.Format("{0} {1}", body.Member.Name, order);
                }
                else
                {
                    _orderBy = string.Format("{0}, {1} {2}", _orderBy, body.Member.Name, order);
                }

                return true;
            }

            return false;
        }

        private bool ParseTakeExpression(MethodCallExpression expression)
        {
            ConstantExpression sizeExpression = (ConstantExpression)expression.Arguments[1];

            int size;
            if (int.TryParse(sizeExpression.Value.ToString(), out size))
            {
                _take = size;
                return true;
            }

            return false;
        }

        private bool ParseSkipExpression(MethodCallExpression expression)
        {
            ConstantExpression sizeExpression = (ConstantExpression)expression.Arguments[1];

            int size;
            if (int.TryParse(sizeExpression.Value.ToString(), out size))
            {
                _skip = size;
                return true;
            }

            return false;
        }
    }
}
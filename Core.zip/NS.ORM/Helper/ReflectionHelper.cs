﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
// ReSharper disable All

namespace NS.ORM.Helper
{
    /// <summary>
    /// Helper class for reflection
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
	public static class ReflectionHelper
	{
		private static readonly ConcurrentDictionary<Type, Dictionary<string, PropertyInfo>> _cachedProperties = new ConcurrentDictionary<Type, Dictionary<string, PropertyInfo>>();

        /// <summary>
        /// Extracts property name from expression
        /// </summary>
        /// <typeparam name="T">The type</typeparam>
        /// <param name="expression">Expression</param>
        /// <returns>Property name</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static string GetPropertyNameFromExpression<T>(Expression<Func<T, object>> expression)
		{
			string propertyPath = null;
			if (expression.Body is UnaryExpression)
			{
				var unaryExpression = (UnaryExpression) expression.Body;
				if (unaryExpression.NodeType == ExpressionType.Convert)
					propertyPath = unaryExpression.Operand.ToString();
			}

			if (propertyPath == null)
				propertyPath = expression.Body.ToString();

			propertyPath = propertyPath.Replace(expression.Parameters[0] + ".", string.Empty);

			return propertyPath;
		}

        /// <summary>
        /// Extracts property names from expression
        /// </summary>
        /// <typeparam name="T">The type</typeparam>
        /// <param name="expressions">Expression</param>
        /// <returns>List of property names</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static List<string> GetPropertyNamesFromExpressions<T>(Expression<Func<T, object>>[] expressions)
		{
			var propertyNames = new List<string>();
			foreach (var expression in expressions)
			{
				var propertyName = GetPropertyNameFromExpression(expression);
				propertyNames.Add(propertyName);
			}
			return propertyNames;
		}

        /// <summary>
        /// Gets the specified property value of object
        /// </summary>
        /// <param name="item">The object</param>
        /// <param name="property">The property</param>
        /// <returns>Value of the property in the specified object</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static object GetPropertyValue(object item, PropertyInfo property)
		{
			var value = property.GetValue(item, null);

			return value;
		}

        /// <summary>
        /// Gets the specified property value of object
        /// </summary>
        /// <param name="item">The object</param>
        /// <param name="propertyName">The name of property</param>
        /// <returns>Value of the property in the specified object</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static object GetPropertyValue(object item, string propertyName)
		{
			PropertyInfo property;
			foreach (var part in propertyName.Split('.'))
			{
				if (item == null)
					return null;

				var type = item.GetType();

				property = type.GetProperty(part);
				if (property == null)
					return null;

				item = GetPropertyValue(item, property);
			}
			return item;
		}

        /// <summary>
        /// Gets the specified property value of dynamic object
        /// </summary>
        /// <param name="item">The dynamic object</param>
        /// <param name="name">The name of property</param>
        /// <returns>Value of the property int the specified object</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static object GetPropertyValueDynamic(object item, string name)
		{
			var dictionary = (IDictionary<string, object>) item;

			return dictionary[name];
		}

        /// <summary>
        /// Gets properties of the specified type
        /// </summary>
        /// <param name="type">The type</param>
        /// <returns>Collection of property names and property infos</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static Dictionary<string, PropertyInfo> GetProperties(Type type)
		{
			var properties = _cachedProperties.GetOrAdd(type, BuildPropertyDictionary);

			return properties;
		}

		private static Dictionary<string, PropertyInfo> BuildPropertyDictionary(Type type)
		{
			var result = new Dictionary<string, PropertyInfo>();

			var properties = type.GetProperties();
			foreach (var property in properties)
			{
				result.Add(property.Name.ToLower(), property);
			}
			return result;
		}

        /// <summary>
        /// Checks if the specified object is List(Collection).
        /// </summary>
        /// <param name="item">The object</param>
        /// <returns>True  if the specified object is List(Collection).</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static bool IsList(object item)
		{
			if (item is ICollection)
				return true;

			return false;
		}

        /// <summary>
        /// Checks if the specified property is nullable.
        /// </summary>
        /// <param name="property">The property</param>
        /// <returns>True if the specified property is nullable.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static bool IsNullable(PropertyInfo property)
		{
			if (property.PropertyType.IsGenericType &&
				property.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
				return true;

			return false;
		}

        /// <summary>
        /// Includes a work around for getting the actual type of a Nullable type.
        /// </summary>
        /// <returns>The Type</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static Type GetPropertyType(PropertyInfo property)
		{
			if (IsNullable(property))
				return property.PropertyType.GetGenericArguments()[0];

			return property.PropertyType;
		}

        /// <summary>
        /// Gets the underlying type of generic type.
        /// </summary>
        /// <param name="property">The property</param>
        /// <returns>The type</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static Type GetGenericSafeType(PropertyInfo property)
        {
            if (property.PropertyType.IsGenericType)
                return property.PropertyType.GetGenericArguments()[0];

            return property.PropertyType;
        }

        /// <summary>
        /// Gets default value of the specified type
        /// </summary>
        /// <param name="type">The type</param>
        /// <returns>Instance of the specified type</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static object GetDefault(Type type)
		{
			if (type.IsValueType)
				return Activator.CreateInstance(type);
			return null;
		}

        /// <summary>
        /// Checks if the specified type is basic clr type.
        /// </summary>
        /// <param name="type">The type</param>
        /// <returns>True if the specified type is basic clr type</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
		public static bool IsBasicClrType(Type type)
		{
			if (type.IsEnum
				|| type.IsPrimitive
				|| type.IsValueType
				|| type == typeof(string)
				|| type == typeof(DateTime))
				return true;

			return false;
		}

        /// <summary>
        /// Checks if the specified type is custom type.
        /// </summary>
        /// <typeparam name="T">The type</typeparam>
        /// <returns>True if the type is custom type</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static bool IsCustomEntity<T>()
		{
			var type = typeof (T);
			if(type.IsClass && Type.GetTypeCode(type) == TypeCode.Object)
				return true;
			return false;
		}
	}
}

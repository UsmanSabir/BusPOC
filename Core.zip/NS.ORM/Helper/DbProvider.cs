﻿namespace NS.ORM.Helper
{
    /// <summary>
    /// Enum for database providers
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Enum created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public enum DbProvider
    {
        /// <summary>
        /// Specifies that the database is Sql server
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Entry created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Entry created.</para>
        /// </remarks>
        SqlServer,

        /// <summary>
        /// Specifies that the database is Oracle
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Entry created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Entry created.</para>
        /// </remarks>
        Oracle
    }
}
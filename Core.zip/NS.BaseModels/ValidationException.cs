﻿using System;

namespace NS.BaseModels
{
    /// <summary>
    /// custom validation exception purpose is to differentiate between the system generated exception in case of validation failure
    /// </summary>
    public sealed class ValidationException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationException"/>  class
        /// </summary>
        /// <param name="message">the exception message</param>
        public ValidationException(string message) : base(message)
        {
        }
    }
}

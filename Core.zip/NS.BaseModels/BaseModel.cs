﻿
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using NS.Utilities;
#if RICHCLIENT
using System.ComponentModel;

#endif


// ReSharper disable ExplicitCallerInfoArgument

namespace NS.BaseModels
{
    /// <summary>
    /// Base class for entities
    /// </summary>
    /// <remarks><para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 24/02/2016  1.0 Documentation added.</para>
    /// <para>[US] 29/02/2016  1.0 Object state maintenance (old/new value collection) modified.</para></remarks>
    public class BaseModel
#if RICHCLIENT

        :  INotifyPropertyChanging, WPF.BaseModels.INotifyValidationHandler

#endif

    {
        /// <summary>
        /// The state
        /// </summary>
        private EntityState _state;
        /// <summary>
        /// The ignore setter check
        /// </summary>
        internal protected bool IgnoreSetterCheck;

        //private Lazy<Dictionary<string, object>> _modifiedFields = new Lazy<Dictionary<string, object>>(Init);
        //private Dictionary<string, object> _modifiedFields;



        /// <summary>
        /// Constructor for BaseModel. Also sets entity state to New.
        /// </summary>
        /// <remarks>[ZA] 24/02/2016  1.0 Documentation added.</remarks>
        public BaseModel()
        {
            _state = EntityState.New;
        }

        #region Lazy Initilizer(commented)

        //static Dictionary<string, object> Init()
        //{
        //    if (_ignoreSetterCheck)
        //        return null;

        //    Trace.WriteLine("ModifiedFields Initilization called");
        //    return new Dictionary<string, object>();
        //}

        #endregion


        /// <summary>
        /// Checks the set property.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="backingField">The backing field.</param>
        /// <param name="newVal">The new value.</param>
        /// <param name="name">The name.</param>
        protected virtual void CheckSetProperty<T>(ref T backingField, T newVal, string name)
        {
            //HACK:
            // ReSharper disable once ExplicitCallerInfoArgument
            CheckSetProperty(ref backingField, newVal, false, name);
        }

        /// <summary>
        /// Sets value of entity property and maintains entity state.
        /// </summary>
        /// <typeparam name="T">The type of value.</typeparam>
        /// <param name="backingField">Instance of type T whose value will be set.</param>
        /// <param name="newVal">The value that will be assigned to <see cref="backingField" /></param>
        /// <param name="isChildCollection">Specifies if the property being modified is child collection.</param>
        /// <param name="name">Name of the property whose value is being updated.</param>
        /// <param name="onChange">Action to execute on property value change.</param>
        protected virtual void CheckSetProperty<T>(ref T backingField, T newVal,
            bool isChildCollection = false, [CallerMemberName] string name = null, Action onChange = null)
        {

            if (IgnoreSetterCheck || isChildCollection) //deserializing or db loading
            {
#if RICHCLIENT
                //requested by Faizan
                //if (isChildCollection)
                //{

                //    OnPropertyChanging(name);

                //}
#endif

                backingField = newVal;
#if RICHCLIENT
                //requested by Faizan
                //if (isChildCollection)
                //{
                //    OnPropertyChanged(name);
                //}
#endif
                return;
            }


            #region altrenate
            //if (oldValue == null && newValue == null)
            //{
            //    return false;
            //}

            //if ((oldValue == null && newValue != null) || !oldValue.Equals((T)newValue))
            //{
            //    oldValue = newValue;
            //    FirePropertyChanged(propertyName);
            //    return true;
            //} 
            #endregion

            if (!EqualityComparer<T>.Default.Equals(backingField, newVal))
            // if (!Equals(_backingField, newVal))
            {
#if RICHCLIENT
                OnPropertyChanging(name);
                RaiseValidateEvent(backingField, newVal, name);
#endif

                #region Audit (commented)
                //if (!string.IsNullOrEmpty(name) && AuditOn)
                //{
                //    //if (!isChildCollection)// !(newVal is ICollection))
                //    {
                //        var dic = GetDictionary();
                //        if (!dic.ContainsKey(name)
                //            || (State == EntityState.NotModified || State == EntityState.DataModified))
                //        //already contains original value on first change of property. keep original value instead of 2nd modified value
                //        {
                //            GetDicValuePair(name).OldValue = backingField;
                //        }

                //        GetDicValuePair(name).NewValue = newVal;
                //    }
                //} 
                #endregion

                backingField = newVal;

                onChange?.Invoke();

                SetStateModified();

#if RICHCLIENT
                OnPropertyChanged(name);
#endif

            }
        }

#if RICHCLIENT
        protected void RaiseValidateEvent<T>(T backingField, T newVal, string name)
        {
            WPF.BaseModels.ValidationEventRaiser.RaiseEvent(this, name, backingField, newVal, ValidationHandler);
        }
#endif


        /// <summary>
        /// Sets the state modified.
        /// </summary>
        protected void SetStateModified()
        {
            switch (_state)
            {
                case EntityState.New:
                    State = EntityState.NewModified;
                    break;
                case EntityState.NotModified:
                    State = EntityState.DataModified;
                    break;
            }
        }

        /// <summary>
        /// Resets the state.
        /// </summary>
        internal protected void ResetState()
        {
            switch (_state)
            {
                case EntityState.NewModified:
                    State = EntityState.New;
                    break;
                case EntityState.DataModified:
                    State = EntityState.NotModified;
                    break;
            }
        }

        /// <summary>
        /// Clears entity changes and resets entity state based on <see cref="resetState" /> argument.
        /// </summary>
        /// <param name="resetState">True to reset entity state. Default is true.</param>
        /// <remarks>[ZA] 24/02/2016  1.0 Documentation added.</remarks>
        public virtual void Commit(bool resetState = true)
        {
            //ModifiedFields?.Clear();//clear all changes
            if (resetState)
                ResetState();
        }

        /// <summary>
        /// Clear entity changes and set entity state
        /// </summary>
        /// <param name="state">Entity state</param>
        /// <remarks>[ZA] 24/02/2016  1.0 Documentation added.</remarks>
        public void Commit(EntityState state)
        {
            Commit(false);

            State = state;
        }

        //public IDisposable BeginEdit(EntityState state = EntityState.NotModified)
        //{
        //    _ignoreSetterCheck = true;
        //    var st = state;
        //    return new DisposableAction(() =>
        //    {
        //        _ignoreSetterCheck = false;
        //        Commit(false);
        //        State = st;
        //    });
        //}


        #region May be usefull for serialization
        /// <summary>
        /// Called when [deserialized].
        /// </summary>
        /// <param name="c">The c.</param>
        [OnDeserialized]
        private void OnDeserialized(StreamingContext c)
        {
            IgnoreSetterCheck = false;
        }

        /// <summary>
        /// Called when [deserializing].
        /// </summary>
        /// <param name="c">The c.</param>
        [OnDeserializing]
        private void OnDeserializing(StreamingContext c)
        {
            IgnoreSetterCheck = true;
        }
        #endregion


        /// <summary>
        /// Current entity state
        /// </summary>
        /// <value>The state.</value>
        /// <remarks>[ZA] 24/02/2016  1.0 Documentation added.</remarks>
        public EntityState State
        {
            get { return _state; }
            set { _state = value; }
        }

#if RICHCLIENT


        public event PropertyChangedEventHandler PropertyChanged;
        public event PropertyChangingEventHandler PropertyChanging;
        public event WPF.BaseModels.PropertyChangingValidationEventHandler ValidationHandler;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected virtual void OnPropertyChanging([CallerMemberName] string propertyName = null)
        {
            PropertyChanging?.Invoke(this, new PropertyChangingEventArgs(propertyName));
        }
#endif



    }


    /// <summary>
    /// Class TrackableModel.
    /// </summary>
    /// <seealso cref="NS.BaseModels.BaseModel" />
    public class TrackableModel : BaseModel
    {
        /// <summary>
        /// The audit on
        /// </summary>
        public bool AuditOn = true;

        /// <summary>
        /// The modified fields
        /// </summary>
        private SerializableDictionary<string, ValuePair> _modifiedFields;

        /// <summary>
        /// Sets value of entity property and maintains entity state.
        /// </summary>
        /// <typeparam name="T">The type of value.</typeparam>
        /// <param name="backingField">Instance of type T whose value will be set.</param>
        /// <param name="newVal">The value that will be assigned to <see cref="backingField" /></param>
        /// <param name="isChildCollection">Specifies if the property being modified is child collection.</param>
        /// <param name="name">Name of the property whose value is being updated.</param>
        /// <param name="onChange">Action to execute on property value change.</param>
        protected override void CheckSetProperty<T>(ref T backingField, T newVal,
            bool isChildCollection = false, [CallerMemberName] string name = null, Action onChange = null)
        {

            if (IgnoreSetterCheck || isChildCollection) //deserializing or db loading
            {
#if RICHCLIENT
                //requested by Faizan
                //if (isChildCollection)
                //{

                //    OnPropertyChanging(name);

                //}
#endif

                backingField = newVal;
#if RICHCLIENT
                //requested by Faizan
                //if (isChildCollection)
                //{
                //    OnPropertyChanged(name);
                //}
#endif
                return;
            }


            #region altrenate
            //if (oldValue == null && newValue == null)
            //{
            //    return false;
            //}

            //if ((oldValue == null && newValue != null) || !oldValue.Equals((T)newValue))
            //{
            //    oldValue = newValue;
            //    FirePropertyChanged(propertyName);
            //    return true;
            //} 
            #endregion

            if (!EqualityComparer<T>.Default.Equals(backingField, newVal))
            // if (!Equals(_backingField, newVal))
            {
#if RICHCLIENT
                OnPropertyChanging(name);
                RaiseValidateEvent(backingField, newVal, name);
#endif

                if (!string.IsNullOrEmpty(name) && AuditOn)
                {
                    //if (!isChildCollection)// !(newVal is ICollection))
                    {
                        var dic = GetDictionary();
                        if (!dic.ContainsKey(name)
                            || (State == EntityState.NotModified || State == EntityState.DataModified))
                        //already contains original value on first change of property. keep original value instead of 2nd modified value
                        {
                            GetDicValuePair(name).OldValue = backingField;
                        }

                        GetDicValuePair(name).NewValue = newVal;
                    }
                }
                backingField = newVal;

                onChange?.Invoke();

                SetStateModified();

#if RICHCLIENT
                OnPropertyChanged(name);
#endif

            }
        }


        /// <summary>
        /// Gets the dictionary.
        /// </summary>
        /// <returns>SerializableDictionary&lt;System.String, ValuePair&gt;.</returns>
        SerializableDictionary<string, ValuePair> GetDictionary()
        {
            return _modifiedFields ?? (_modifiedFields = new SerializableDictionary<string, ValuePair>());
        }
        /// <summary>
        /// Gets the dic value pair.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns>ValuePair.</returns>
        ValuePair GetDicValuePair(string key)
        {
            var dic = GetDictionary();

            if (!dic.ContainsKey(key))
                dic[key] = new ValuePair();

            return dic[key];
        }


        /// <summary>
        /// Holds entity changes
        /// </summary>
        /// <value>The modified fields.</value>
        /// <remarks>[ZA] 24/02/2016  1.0 Documentation added.</remarks>
        public SerializableDictionary<string, ValuePair> ModifiedFields
        {
            get { return _modifiedFields; }
            set { _modifiedFields = value; }
        }

        /// <summary>
        /// Clears entity changes and resets entity state based on <see cref="resetState" /> argument.
        /// </summary>
        /// <param name="resetState">True to reset entity state. Default is true.</param>
        /// <remarks>[ZA] 24/02/2016  1.0 Documentation added.</remarks>
        public override void Commit(bool resetState = true)
        {
            ModifiedFields?.Clear();//clear all changes
            if (resetState)
                ResetState();
        }

    }



#if DEBUG
    //Requires testing

    /// <summary>
    /// see http://stackoverflow.com/questions/5170333/binaryformatter-deserialize-unable-to-find-assembly-after-ilmerge
    /// </summary>
    /// <seealso cref="System.Runtime.Serialization.SerializationBinder" />
    sealed class PreMergeToMergedDeserializationBinder : SerializationBinder
    {
        /// <summary>
        /// Binds to type.
        /// </summary>
        /// <param name="assemblyName">Name of the assembly.</param>
        /// <param name="typeName">Name of the type.</param>
        /// <returns>Type.</returns>
        public override Type BindToType(string assemblyName, string typeName)
        {
            // For each assemblyName/typeName that you want to deserialize to
            // a different type, set typeToDeserialize to the desired type.
            //String exeAssembly = Assembly.GetExecutingAssembly().FullName;

            // The following line of code returns the type.
            var typeToDeserialize = Type.GetType($"{typeName}, {assemblyName}");

            return typeToDeserialize;
        }
    }

#endif

    /// <summary>
    /// Class TrackingFieldNames.
    /// </summary>
    public class TrackingFieldNames
    {
        /// <summary>
        /// The insr by
        /// </summary>
        public const string InsrBy = "insr_by";
        /// <summary>
        /// The updt by
        /// </summary>
        public const string UpdtBy = "updt_by";
        /// <summary>
        /// The insr DTE
        /// </summary>
        public const string InsrDte = "insr_dte";
        /// <summary>
        /// The updt DTE
        /// </summary>
        public const string UpdtDte = "updt_dte";
    }

}
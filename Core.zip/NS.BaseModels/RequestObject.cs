﻿using System;
using System.Runtime.Serialization;
using NS.Utilities.Context;
// ReSharper disable ConvertToAutoProperty

namespace NS.BaseModels
{
    /// <summary>
    /// Wrapper class for all request objects, it contains properties related to request.
    /// </summary>
    /// <typeparam name="T">Type of the request object.</typeparam>
    /// <remarks>
    /// <para>[AHA] 04/03/2016  1.0 Class created.</para>
    /// <para>[AHA] 31/03/2016  1.0 Updated properties.</para>
    /// <para>[RS] 18/05/2016  1.0 Added a new constructor and a AuditTrailInfo property</para>
    /// </remarks>
    [DataContract]
    public sealed class RequestObject<T>
    {
        #region Private Memebers

        private Context _context;
        private AuditTrailInfo _auditTrailInfo;
        private T _object;
        private WorkflowInputParams _workflowParams;

        #endregion

        #region Private Methods

        /// <summary>
        /// A private method to generate a compact user info against the provided user.
        /// </summary>
        /// <returns>A <see cref="Context"/> object which contains cmpact user information. </returns>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Method signature created.</para>
        /// </remarks>
        /// <summary>
        /// Public constructor to initialize the request object with current user info and request.
        /// </summary>
        /// <param name="currentUserInfo">Information related to current user.</param>
        /// <param name="requestObject">Original requst object</param>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Constructor created.</para>
        /// </remarks>
        public RequestObject(Context currentUserInfo, T requestObject)
        {
            if (requestObject is Context)
                throw new Exception("Both objects can't belong to the UserInfo Class.");

            _context = currentUserInfo; //To-Do: Can be replaced with compact user if required.
            _object = requestObject;
        }

        /// <summary>
        /// Public constructor to initialize the request object with current user info, audit trail info and request.
        /// </summary>
        /// <param name="currentUserInfo">Information related to current user.</param>
        /// <param name="auditTrailInfo">Audit trail information.</param>
        /// <param name="requestObject">Original requst object</param>
        /// <remarks>
        /// <para>[MRS] 18/05/2016  1.0 Constructor created.</para>
        /// </remarks>
        public RequestObject(Context currentUserInfo, AuditTrailInfo auditTrailInfo, T requestObject)
        {
            if (requestObject is Context)
                throw new Exception("Both objects can't belong to the UserInfo Class.");

            _context = currentUserInfo; //To-Do: Can be replaced with compact user if required.
            _auditTrailInfo = auditTrailInfo;
            _object = requestObject;
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Property to conatin the information related to current context.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public Context Context
        {
            get { return _context; }
            set { _context = value; }
        }

        /// <summary>
        /// Property to conatin the information related to current audit trail info.
        /// </summary>
        /// <remarks>
        /// <para>[RS] 18/05/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public AuditTrailInfo AuditTrailInfo
        {
            get { return _auditTrailInfo; }
            set { _auditTrailInfo = value; }
        }

        /// <summary>
        /// Property to contain the request object.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public T Object
        {
            get { return _object; }
            set { _object = value; }
        }


        /// <summary>
        /// Property which contains workflow parameters.
        /// </summary>
        /// <remarks>
        /// <para>[ZA] 19/01/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public WorkflowInputParams WorkflowInput
        {
            get { return _workflowParams; }
            set { _workflowParams = value; }
        }
        #endregion
    }
}

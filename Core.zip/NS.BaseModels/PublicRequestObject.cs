﻿
namespace NS.BaseModels
{

    /// <summary>
    /// Wrapper class for all public request objects, it conatins properties related to request.
    /// </summary>
    /// <typeparam name="T">Type of the request object.</typeparam>
    /// <remarks>
    /// <para>[AHA] 05/07/2017  1.0 Class created.</para>
    /// </remarks>
    public class PublicRequestObject<T>
    {

        #region Private Members

        private int _subTenantId;
        private T _object;
        private int _languageId;

        #endregion

        #region Public Properties

        /// <summary>
        /// Sub Tenant ID against which current request is required to be processed.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 05/07/2017  1.0 Property created.</para>
        /// </remarks>
        public int SubTenantId
        {
            get { return _subTenantId; }
            set { _subTenantId = value; }
        }

        /// <summary>
        /// Actual request object.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 05/07/2017  1.0 Property created.</para>
        /// </remarks>
        public T Object
        {
            get { return _object; }
            set { _object = value; }
        }

        /// <summary>
        /// Language ID to use for current request.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 05/07/2017  1.0 Property created.</para>
        /// </remarks>
        public int LanguageId
        {
            get { return _languageId; }
            set { _languageId = value; }
        }

        #endregion

    }
}

﻿
using NS.Utilities;
using System.Collections;

namespace NS.BaseModels
{
    /// <summary>
    /// Class BaseModelHelper.
    /// </summary>
    public static class BaseModelHelper
    {
        /// <summary>
        /// Creates the deep copy.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="baseModel">The base model.</param>
        /// <returns>T.</returns>
        public static T CreateDeepCopy<T>(this T baseModel) where T : BaseModel
        {
            byte[] serializedEntity = NfsEntitySerializer.SerializeEntity(baseModel);
            return NfsEntitySerializer.DeserializeEntity<T>(serializedEntity);
        }

        /// <summary>
        /// Create a deep copy and update state to NewModified.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="baseModel">The base model</param>
        /// <returns>Copy of object with state of all childen set to EntityState.NewModified</returns>
        public static T CreateDeepCopyAndUpdateState<T>(this T baseModel) where T : BaseModel
        {
            var copy = CreateDeepCopy(baseModel);
            UpdateState(copy);
            return copy;
        }

        private static void UpdateState<T>(this T baseModel, EntityState state = EntityState.NewModified) where T : BaseModel
        {
            baseModel.State = state;
            foreach (var property in baseModel.GetType().GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance))
            {
                dynamic obj = property.GetValue(baseModel);
                if (obj is IEnumerable && property.PropertyType.IsGenericType)
                {
                    foreach (var item in obj)
                    {
                        UpdateState(item, state);
                    }
                }
                else if (obj is BaseModel)
                {
                    UpdateState(obj, state);
                }
            }
        }
    }
}

﻿using System.Runtime.Serialization;
using NS.Utilities;

namespace NS.BaseModels
{
    /// <summary>
    /// Holds the search criteria and its parameters.
    /// </summary>
    /// <remarks>
    /// <para>[ZA] 22/03/2016  1.0 Class created.</para>
    /// </remarks>
    [DataContract]
    public sealed class SearchInfo
    {
        /// <summary>
        /// Where clause for searching objects.
        /// </summary>
        /// <remarks>
        /// <para>[ZA] 22/03/2016  1.0 Class created.</para>
        /// </remarks>
        [DataMember]
        public string SearchCriteria { get; set; }

        /// <summary>
        /// Parameter name/value collection.
        /// </summary>
        /// <remarks>
        /// <para>[ZA] 22/03/2016  1.0 Class created.</para>
        /// </remarks>
        [DataMember]
        public SerializableDictionary<string, object> Parameters { get; set; }

        /// <summary>
        /// Operators collection against parameters.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 26/10/2018  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public SerializableDictionary<string, string> Operators { get; set; }
    }
}

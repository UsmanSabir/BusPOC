﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NS.BaseModels;
using NS.Utilities.Helper;
using NS.Validation;
using NS.Validation.Factory;
// ReSharper disable ConvertToAutoProperty

// ReSharper disable once CheckNamespace
namespace NS.ORM
{
    /// <summary>
    /// Contains collection of specified generic type T. Also provides entity validation.
    /// </summary>
    /// <typeparam name="T">The type whose data will be held by EntityContext.</typeparam>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public class EntityContext<T> where T : BaseModel, new()
    {
        private IValidator _validator;
        private string _screenId;

        #region Constructor
        /// <summary>
        /// Initializes entity.
        /// </summary>
        /// <param name="entity">Collection of type T</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public EntityContext(List<T> entity)
        {
            Entity = entity;
            //_validator = GetValidator<T>();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EntityContext{T}"/> class.
        /// </summary>
        /// <param name="entity">The entity.</param>
        public EntityContext(IList<T> entity):this(entity as List<T>??entity?.ToList())
        {
            
        }

        #endregion

        #region Properties
        /// <summary>
        /// Collection of objects of type T.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Property created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> Entity { get; protected set; }

        private IValidator Validator => _validator ?? (_validator = GetValidator(typeof(T)));

        /// <summary>
        /// Returns true if the entity satisfies the configured validation rules.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Property created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        //public bool IsValid
        //{
        //    get
        //    {
        //        var res = ValidateAggregate();
        //        return res.IsValid;
        //    }
        //}

        public Func<string, string> ValidationSettingsProviderFactory { get; set; }

        /// <summary>
        /// Gets or sets the screen identifier.
        /// </summary>
        /// <value>The screen identifier.</value>
        public string ScreenId
        {
            get { return _screenId; }
            set { _screenId = value; }
        }

        //readonly Lazy<BaseValidation> _aggregateValidationDefinition = new Lazy<BaseValidation>(() => GetValidationDefinition(typeof(T)));
        

        #endregion

        #region Public Members
        /// <summary>
        /// Performs entity validation 
        /// </summary>
        /// <returns>ValidationResult. See <seealso cref="ValidationResult"/></returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public ValidationResult Validate(T entity, string actionName)
        {
            var validator = Validator;
            var result = validator.Validate(entity, actionName); //Entity.First());
            return result;
        }

        #region Validation Old (commented)

        /// <summary>
        /// Performs Aggregate validation 
        /// </summary>
        /// <returns>ValidationResult. See <seealso cref="ValidationResult"/></returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        //public ValidationResult ValidateAggregate()
        //{
        //    var compisiteResult = new ValidationResult()
        //    {
        //        IsValid = true,
        //        Errors = new List<ValidationError>()
        //    };

        //    //var validator = Validator;
        //    //foreach (var ent in Entity)
        //    {
        //        ScanEntity(r =>
        //        {
        //            var validator = GetValidator(r.GetType());

        //            var res = validator.Validate(r);
        //            if (!res.IsValid)
        //            {
        //                compisiteResult.IsValid = res.IsValid; //not valid
        //                res.Errors.ForEach(compisiteResult.Errors.Add);
        //            }
        //        });


        //    }

        //    return compisiteResult;
        //}

        #endregion

        /// <summary>
        /// Gets Validation definition file generated by ORM
        /// </summary>
        /// <returns>BaseValidation</returns>
        /// <remarks>
        /// <para>[US] 30/03/2016  1.0 Method created.</para>
        /// </remarks>
        public BaseValidation GetValidationDefinition()
        {
            var val = ValidationCollections.Instance.GetModelValidation(typeof(T));
            return val;
        }

        /// <summary>
        /// Gets Validation definition file generated by ORM
        /// </summary>
        /// <returns>BaseValidation</returns>
        /// <remarks>
        /// <para>[US] 30/03/2016  1.0 Method created.</para>
        /// </remarks>
        public BaseValidation GetValidationDefinition<TU>()
        {
            var val = ValidationCollections.Instance.GetModelValidation(typeof(TU));
            return val;
        }

        /// <summary>
        /// Gets Validation definition file generated by ORM
        /// </summary>
        /// <returns>BaseValidation</returns>
        /// <remarks>
        /// <para>[US] 30/03/2016  1.0 Method created.</para>
        /// </remarks>
        public static BaseValidation GetValidationDefinition(Type tp)
        {
            var val = ValidationCollections.Instance.GetModelValidation(tp);
            return val;
        }


        /// <summary>
        /// Performs specific action on all aggregate entities
        /// </summary>
        /// <param name="action">Action delegate</param>
        /// <remarks>
        /// <para>[US] 30/03/2016  1.0 Method created.</para>
        /// </remarks>
        public virtual void ScanEntity(Action<BaseModel> action)
        {
            foreach (var ent in Entity)
            {
                ScanEntityInternal(ent, action);
            }
        }

        void ScanEntityInternal(BaseModel obj, Action<BaseModel> action)
        {
            if (obj == null) return;

            action?.Invoke(obj);

            Type objType = obj.GetType();
            var properties = ReflectionHelper.GetProperties(objType).Values;//.GetProperties(); //PropertyInfo[]
            foreach (PropertyInfo property in properties)
            {
                object propValue = property.GetValue(obj, null);
                var elems = propValue as IList;
                if (elems != null)
                {
                    foreach (var item in elems)
                    {
                        ScanEntityInternal(item as BaseModel, action);
                    }
                }
                #region Ignore Properties
                //else
                //{
                //    // This will not cut-off System.Collections because of the first check
                //    if (property.PropertyType.Assembly == objType.Assembly)
                //    {
                //        Console.WriteLine("{0}{1}:", "", property.Name);

                //        ScanEntities(propValue, indent + 2);
                //    }
                //    else
                //    {
                //        Console.WriteLine("{0}{1}: {2}", indentString, property.Name, propValue);
                //    }
                //} 
                #endregion
            }
        }

        /// <summary>
        /// Register Custom Validation Rule
        /// </summary>
        /// <typeparam name="TU">Entity Type</typeparam>
        /// <param name="func">Rule Func</param>
        /// <param name="property">Property name</param>
        /// <param name="ruleName">Rule name</param>
        /// <param name="actions">Actions list e.g. Save, Submit</param>
        public void RegisterCustomValidationRule<TU>(Func<TU, bool> func, string property, string ruleName, List<string> actions) where TU : BaseModel
        {
            //or can use Predicate<TU>

            var validator = GetValidator(typeof(TU)) as IValidator<TU>;
            if (validator==null)
            {
                throw new ApplicationException($"Validator of type {typeof(TU).Name} not found");
            }

            validator.RegisterCustomRule(func, property, ruleName, actions);
        }

        /// <summary>
        /// Performs Aggregate validation. Set ScreenId <see cref="ScreenId"/> for screen based validation
        /// </summary>
        /// <returns>ValidationResult. See <seealso cref="ValidationResult"/></returns>
        /// <remarks>
        /// <para>[US] 13/04/2016  1.0 Method created.</para>
        /// </remarks>
        public ValidationResult ValidateAggregate(string actionName)
        {
            var compisiteResult = new ValidationResult()
            {
                IsValid = true,
                Errors = new List<ValidationError>()
            };

            //var validator = Validator;
            for (int index = 0; index < Entity.Count; index++)
            {
                var ent = Entity[index];
                var path = $"{nameof(Entity)}[{index}].";

                RunValidate(ent, path, (r,p) =>
                {
                    var validator = GetValidator(r.GetType());

                    var res = validator.Validate(r, actionName);
                    if (!res.IsValid)
                    {
                        compisiteResult.IsValid = res.IsValid; //not valid
                        res.Errors.ForEach(error =>
                        {
                            error.Path = p;
                            compisiteResult.Errors.Add(error);
                        });
                    }
                });
            }

            return compisiteResult;
        }

        void RunValidate(BaseModel entity, string path, Action<BaseModel, string> action)//ValidationResult result, 
        {
            if (entity == null) return;
            
            action?.Invoke(entity, path);

            Type objType = entity.GetType();
            //Lazy<BaseValidation> itemValiditionDefinition = new Lazy<BaseValidation>(() => GetValidationDefinition(objType));
            

            var properties = ReflectionHelper.GetChildEntityProperties(objType);
            var childCollection = properties.Item1;
            var childItem = properties.Item2;
            foreach (var property in childCollection)
            {
                var propertyInfo = property.Key;
               // var childType = property.Value;

                object propValue = propertyInfo.GetValue(entity, null);
                var elems = propValue as IList;
                if (elems != null && elems.Count > 0)
                {
                    for (int index = 0; index < elems.Count; index++)
                    {
                        var p = path + propertyInfo.Name + "[" + index + "].";
                        var item = elems[index];
                        RunValidate(item as BaseModel, p, action);
                    }
                    //return;
                }

                #region Empty Collection is not Validated

                //else
                //{
                //    var p = path + propertyInfo.Name;
                //    ValidateNull(entity, itemValiditionDefinition.Value, _aggregateValidationDefinition.Value.AggregateName, childType, result, propertyInfo.Name, p);

                //}

                #endregion


                #region commented

//else
                //{
                //    childType = property.PropertyType;

                //    //TODO: validate child entity
                //    object propValue = property.GetValue(obj, null);

                //    if (propValue == null)
                //    {


                //    }
                //    else
                //    {
                //        RunValidate(propValue as BaseModel, result, action);
                //        return;
                //    }
                //}

                //TODO: validate parent child type/relation, is it part of current aggregate, if yes
                //Not valid(Validation Error) if child type has any mandatory field

                //var validator = GetValidator(objType);
                //ValidateNull(obj, result, objType, childType, property);

                #endregion

            }

            foreach (var propertyInfo in childItem)
            {
                //var childType = propertyInfo.PropertyType;

                //TODO: validate child entity
                object propValue = propertyInfo.GetValue(entity, null);
                var p = $"{path}{propertyInfo.Name}.";
                if (propValue == null)
                {
                    //Null item is not validated
                    //ValidateNull(entity, itemValiditionDefinition.Value, _aggregateValidationDefinition.Value.AggregateName, childType, result, propertyInfo.Name, p);
                }
                else
                {
                    RunValidate(propValue as BaseModel, p, action);
                }
            }
        }

        // ReSharper disable once UnusedMember.Local
        //US: 01-06-2016 - For Future use
        private void ValidateNull(BaseModel entity, BaseValidation entityValidationDefinition, string aggregateName, Type childType, ValidationResult result, string propertyName, string path)
        {
            if (entityValidationDefinition != null && entityValidationDefinition.HasChild(aggregateName, childType.Name))
            {
                //child exist in aggregate, check if any of its property is mandatory
                //var childValidDef = GetValidationDefinition(childType);
                var validator = GetValidator(childType);
                
                if (validator.HasAnyMandatoryField()) //(childValidDef != null && childValidDef.MandatoryFields.Any())
                {
                    //now that's a validation error, child has mandatory field
                    result.IsValid = false;
                    result.Errors.Add(new ValidationError
                    {
                        Property = propertyName,
                        Path=path,
                        Rule = "Empty Child",
                        Context = new WeakReference(entity)
                    });
                }
            }
        }

        #endregion

        #region Private Members

        ////IValidator<T> GetValidator<T>()
        //IValidator GetValidator()
        //{
        //    //return (IValidator<T>)CreateInstance();
        //    //return CreateInstance();
        //    return GetValidator(typeof (T));
        //}

        IValidator GetValidator(Type tp)
        {
            if (ValidationSettingsProviderFactory == null)
            {
                throw new InvalidOperationException("ValidationSettingsProviderFactory not provided. Please initiate 'ValidationSettingsProviderFactory' property first");
            }
            // ReSharper disable once RedundantNameQualifier
            var validationFactory = DependencyHelper.GetInstance<IValidationFactory>("validation"); //ServiceLocator.Current.GetInstance<ValidationFactory>().GetValidator<T>();
            validationFactory.ValidationSettingsFactoryMethod = ValidationSettingsProviderFactory;
            var validator = validationFactory.GetValidator(tp, ScreenId);
            return validator;
        }


        //IValidator<T> CreateInstance()
        //{
        //    // ReSharper disable once RedundantNameQualifier
        //    var validationFactory = NS.Utilities.Helper.DependencyHelper.GetInstance<ValidationFactory>("validation"); //ServiceLocator.Current.GetInstance<ValidationFactory>().GetValidator<T>();
        //    var validator = validationFactory.GetValidator<T>();
        //    return validator;
        //    //return App.Instance.ValidatorFactory.GetValidator(validatorType);
        //}

        #endregion
    }
}

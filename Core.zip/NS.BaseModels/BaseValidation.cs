﻿
using System;
using System.Collections.Generic;
using System.Linq;

namespace NS.BaseModels
{
    /// <summary>
    /// Class BaseValidation.
    /// </summary>
    public abstract class BaseValidation
    {
        /// <summary>
        /// The rules
        /// </summary>
        List<FieldRule> _rules;

        /// <summary>
        /// Gets or sets the mandatory fields.
        /// </summary>
        /// <value>The mandatory fields.</value>
        public abstract List<string> MandatoryFields { get; protected set; }
        /// <summary>
        /// Gets or sets the maximum length fields.
        /// </summary>
        /// <value>The maximum length fields.</value>
        public abstract Dictionary<string, int> MaxLengthFields { get; protected set; }

        /// <summary>
        /// Gets or sets the column table.
        /// </summary>
        /// <value>The column table.</value>
        public System.Collections.ObjectModel.ReadOnlyDictionary<string, string> ColumnTable { get; protected set; }

        /// <summary>
        /// Gets or sets the childs.
        /// </summary>
        /// <value>The childs.</value>
        public Dictionary<string,List<string>> Childs { get; protected set; }

        /// <summary>
        /// Gets the name of the aggregate.
        /// </summary>
        /// <value>The name of the aggregate.</value>
        public virtual string AggregateName { get; }=string.Empty;

        /// <summary>
        /// Determines whether the specified aggr name has child.
        /// </summary>
        /// <param name="aggrName">Name of the aggr.</param>
        /// <param name="childTypeName">Name of the child type.</param>
        /// <returns><c>true</c> if the specified aggr name has child; otherwise, <c>false</c>.</returns>
        public bool HasChild(string aggrName, string childTypeName)
        {
            var exist = Childs != null && Childs.ContainsKey(aggrName) && Childs[aggrName] != null &&
            Childs[aggrName].Contains(childTypeName);

            return exist;

            //return ChildTables != null && ChildTables.Any(s => s.Equals(childTypeName, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Gets the rules.
        /// </summary>
        /// <returns>List&lt;FieldRule&gt;.</returns>
        public List<FieldRule> GetRules()
        {
            if (_rules == null)
            {
                _rules = new List<FieldRule>();
                MandatoryFields.ForEach(f =>
                {
                    FieldRule r = new FieldRule()
                    {
                        Name = f,
                        IsMandatory = true
                    };
                    _rules.Add(r);
                });
                foreach (KeyValuePair<string, int> pair in MaxLengthFields)
                {
                    var rule = _rules.FirstOrDefault(r => r.Name.Equals(pair.Key, StringComparison.OrdinalIgnoreCase));
                    if (rule == null)
                    {
                        rule = new FieldRule() {Name = pair.Key, MaxLength = pair.Value};
                        _rules.Add(rule);
                    }
                    else
                    {
                        rule.MaxLength = pair.Value;
                    }
                }
            }

            return _rules;
        }

    }

    /// <summary>
    /// Class FieldRule.
    /// </summary>
    public class FieldRule
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is mandatory.
        /// </summary>
        /// <value><c>true</c> if this instance is mandatory; otherwise, <c>false</c>.</value>
        public bool IsMandatory { get; set; }

        /// <summary>
        /// Gets or sets the maximum length.
        /// </summary>
        /// <value>The maximum length.</value>
        public int? MaxLength { get; set; } 
    }

    //class TastVali:BaseValidation
    //{
    //    public override List<string> MandatoryFields { get; protected set; } 
    //        = new List<string>() {"a","b"};

    //    public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
    //    {
    //        ["a"]=5,
    //        ["b"]=3
    //    };
    //}
}
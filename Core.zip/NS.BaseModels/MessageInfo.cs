﻿using System.Runtime.Serialization;
using NS.Utilities.Enums;

namespace NS.BaseModels
{
    /// <summary>
    /// Class which will be used to represent the response message and related information for a service.
    /// </summary>
    /// <remarks>
    /// <para>[AHA] 04/03/2016  1.0 Class created.</para>
    /// </remarks>
    [DataContract]
    public sealed class MessageInfo
    {
        #region Public Properties

        /// <summary>
        /// Property which contains relevant message code.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public string CustomMessage { get; set; }

        /// <summary>
        /// Property which contains relevant message title.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public string Title { get; set; }

        /// <summary>
        /// Property which contains actual message.
        /// </summary>
        [DataMember]
        public string Message { get; set; }

        /// <summary>
        /// Property <see cref="MessageType"/> which tells about message type.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public MessageType Type { get; set; }

        /// <summary>
        /// Property to specify any arguments related to the message.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public object[] Args { get; set; }

        /// <summary>
        /// Property which contrains name of the type.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public string Name { get; set; }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NS.BaseModels
{
    public class WrapperResponseObject<T>
    {
        #region Private Members

        private CallStatus _status;
        private string _messageCode;
        private string _message;
        private T _data;

        #endregion

        #region Constructors

        public WrapperResponseObject()
        {
            _status = CallStatus.Success;
        }

        #endregion

        #region Public Properties


        public CallStatus Status
        {
            get { return _status; }
            set { _status = value; }
        }

        public string MessageCode
        {
            get { return _messageCode; }
            set { _messageCode = value; }
        }

        public string Message
        {
            get { return _message; }
            set { _message = value; }

        }

        public T Data
        {
            get { return _data; }
            set { _data = value; }
        }

        #endregion

    }

    public enum CallStatus
    {
        Failure = -1,
        Success = 1,
        PartialPassed = 2
    }
}

﻿using System;
using System.Collections.Generic;
using NS.BaseModels;

// ReSharper disable once CheckNamespace
namespace NS.Validation
{
    internal interface IValidator
    {
        ValidationResult Validate(BaseModel entity, string action = null);

        ValidationResult ValidateProperty(BaseModel entity, string propertyName, string action = null);

        bool InitializeEntity(BaseModel entity);

        bool HasAnyMandatoryField();

    }

    internal interface IValidator<T>:IValidator where T:BaseModel
    {
        //[Obsolete]
        //ValidationResult ValidateEntity(T entity);

        ValidationResult Validate(T entity, string action = null);


        ValidationResult ValidateProperty(T entity, string propertyName, string action = null);

        bool InitializeEntity(T entity);

        void RegisterCustomRule(Func<T, bool> func, string property, string ruleName, List<string> actions);
    }

    
}
﻿using System;

// ReSharper disable once CheckNamespace
namespace NS.Validation.Factory
{
    internal interface IValidationFactory
    {
        //IValidator<T> GetValidator<T>() where T : BaseModel;
        

        IValidator GetValidator(Type t, string screenId);


        Func<string, string> ValidationSettingsFactoryMethod { get; set; }

    }


    ///// <summary>
    ///// Validation settings provider interface
    ///// </summary>
    //public interface IValidationSettingsProvider //TODO: register them with unity
    //{


    //    /// <summary>
    //    /// Get user settings xml either from server side Db call or client side service call
    //    /// </summary>
    //    /// <param name="entityName">name of entity</param>
    //    /// <returns>xml string</returns>
    //    string GetEntityValidationSettings(string entityName);
    //}

    ///// <summary>
    ///// Business Rule Validator interface
    ///// </summary>
    //public interface IBizRuleValidator //TODO: register them with unity
    //{
    //    /// <summary>
    //    /// Validate business rules on given entity at client and server side.
    //    /// </summary>
    //    /// <param name="ruleName">Biz rule name</param>
    //    /// <param name="context">Entity to run rule on</param>
    //    /// <returns>true or false based on rule decision</returns>
    //    bool ValidateRule(string ruleName, object context);
    //}
}
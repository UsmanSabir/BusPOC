﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using NS.BaseModels;
using NS.ExceptionHandling;
using NS.Utilities.Enums;
#if DEBUG
using NS.Utilities.Helper;
#endif
using NS.Validation.Engine;

// ReSharper disable once CheckNamespace
namespace NS.Validation.Factory
{
    /// <summary>
    /// Validation provider factory
    /// </summary>
    /// <remarks>
    /// <para>[US] 03/04/2016  1.0 class created.</para>
    /// </remarks>
    internal sealed class ValidationFactory : IValidationFactory
    {
#region Tag Names

        private const string fieldTag = "Field";
        private const string nameTag = "Name";
        private const string maxlengthTag = "MaxLength";
        private const string mandatoryindTag = "MandatoryInd";
        private const string defaultvalTag = "DefaultVal";
        private const string businessrulevalTag = "BusinessRuleVal";
        private const string actionTag = "Action";
        private const string idTag = "Id";
#endregion

        readonly ConcurrentDictionary<string, IValidator> _dictionary = new ConcurrentDictionary<string, IValidator>(); //key= typeName + ScreenId
        //readonly ConcurrentDictionary<Type, IValidator> _dictionary = new ConcurrentDictionary<Type, IValidator>();
        //private readonly IValidationSettingsProvider _validationSettingsProvider;
        //private readonly IBizRuleValidator _bizRuleValidator;

        private readonly List<string> _trackingFields2SkipValidation;

        public ValidationFactory()//IBizRuleValidator bizRuleValidator//IValidationSettingsProvider validationSettingsProvider, 
        {
            _trackingFields2SkipValidation=new List<string>
            {
                TrackingFieldNames.InsrBy,
                TrackingFieldNames.UpdtBy,
                TrackingFieldNames.InsrDte,
                TrackingFieldNames.UpdtDte,
            };

            //_validationSettingsProvider = validationSettingsProvider;
            //_bizRuleValidator = bizRuleValidator;
        }

        public IValidator GetValidator(Type tp, string screenId)
        {
            var type = tp;// typeof(T);
            var obj = _dictionary.GetOrAdd($"{type.Name}{screenId ?? string.Empty}", t =>
            {
                var def = GetValidationDefinition(type);
                return def;
            });

            var validator = obj ;
            return validator;
        }

        public Func<string, string> ValidationSettingsFactoryMethod { get; set; }

        private IValidator GetValidationDefinition(Type tp)
        {
            //get some json or xml by entity name
            //var dm = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>("");
            //dynamic d = JObject.Parse("{number:1000, str:'string', array: [1,2,3,4,5,6]}");
            //var d = JObject.Parse("{number:1000, str:'string', array: [1,2,3,4,5,6]}");

            Dictionary<string, FieldValidationInfo> fieldsDic = new Dictionary<string, FieldValidationInfo>();


            //var val = ValidationCollections.Instance.GetModelValidation(tp);
            //if (val != null)
            //{
            //    var rules = val.GetRules();
            //    rules.ForEach(r =>
            //    {
            //        //skip tracking fields
            //        if (!_trackingFields2SkipValidation.Contains(r.Name.ToLower()))
            //        {
            //            var fieldInfo = new FieldValidationInfo()
            //            {
            //                Name = r.Name,
            //                MandatoryInd = r.IsMandatory ? "T" : "F",
            //                MaxLength = r.MaxLength?.ToString(),
            //                Actions = new List<string> {"db"}
            //            };

            //            fieldsDic.Add(r.Name.ToLower(), fieldInfo);
            //        }
            //    });
            //}

            var settingsXml = ValidationSettingsFactoryMethod?.Invoke(tp.Name); //_validationSettingsProvider.GetEntityValidationSettings(tp.Name);
            if (!string.IsNullOrWhiteSpace(settingsXml))
            {
#if DEBUG
                var json = JsonConverterHelper.XmlToJson(settingsXml);
                var rexml = JsonConverterHelper.JsonToXml(json);
                settingsXml = rexml;
                // var d = JsonConverterHelper.ParseJson(json);



#endif

                ParseXml(settingsXml, fieldsDic);
            }

            var t = typeof (EntityValidator<>);
            
            var g = t.MakeGenericType(tp);

            var constructed = Activator.CreateInstance(g, fieldsDic);//, _bizRuleValidator

            //var v = new EntityValidator<T>(fieldsDic, _bizRuleValidator);
            return constructed as IValidator;
        }

        private void ParseXml(string settingsXml, Dictionary<string, FieldValidationInfo> fieldsDic)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                doc.LoadXml(settingsXml);
                var docEle = doc.DocumentElement;
                var fields = docEle?.SelectNodes(fieldTag);

                if (fields != null)
                {
                    foreach (XmlNode field in fields)
                    {
                        if (field.Attributes != null)
                        {
                            var fname = field.Attributes[nameTag].InnerText;
                            var id = field.Attributes[idTag]?.InnerText;
                            //skip tracking fields
                            if (_trackingFields2SkipValidation.Contains(fname.ToLower()))
                                continue;

                            var maxLength = field.SelectSingleNode(maxlengthTag)?.InnerText;
                            var mandatoryInd = field.SelectSingleNode(mandatoryindTag)?.InnerText;
                            var defaultVal = field.SelectSingleNode(defaultvalTag)?.InnerText;
                            var businessRuleVal = field.SelectSingleNode(businessrulevalTag)?.InnerText;
                            var actions = field.SelectSingleNode(actionTag)?.InnerText;
                            
                            FieldValidationInfo fieldInfo;
                            if (fieldsDic.ContainsKey(fname.ToLower()))
                            {
                                fieldInfo = fieldsDic[fname.ToLower()];

                                //override with configured values
                                fieldInfo.MandatoryInd = mandatoryInd;
                                fieldInfo.MaxLength = maxLength;
                                fieldInfo.DefaultValue = defaultVal;
                                fieldInfo.BusinessRuleVal = businessRuleVal;
                                fieldInfo.Id = id;
                            }
                            else
                            {
                                fieldInfo = new FieldValidationInfo
                                {
                                    Name = fname,
                                    MandatoryInd = mandatoryInd,
                                    MaxLength = maxLength,
                                    DefaultValue = defaultVal, //TODO: type conversion
                                    BusinessRuleVal = businessRuleVal,
                                    Actions = new List<string>(),
                                    Id=id
                                };
                                fieldsDic.Add(fname.ToLower(), fieldInfo);
                            }

                            if (!string.IsNullOrWhiteSpace(actions))
                            {
                                var acts = actions.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries);
                                //acts.ForEach(fieldInfo.Actions.Add);
                                foreach (var act in acts)
                                {
                                    fieldInfo.Actions.Add(act.Trim());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                ExceptionHandler.HandleException(e, ExceptionHandlingPolicy.LogOnlyPolicy);
            }
        }
    }

    class FieldValidationInfo
    {
        public string Name { get; set; }
        public string MaxLength { get; set; } //TODO: or UserLength
        public string MandatoryInd { get; set; }
        public string DefaultValue { get; set; }
        public string BusinessRuleVal { get; set; }
        public List<string> Actions { get; set; }
        public string Id { get; set; }
    }

    class EntityValidator<T> : IValidator<T> where T : BaseModel
    {
        private readonly Dictionary<string, FieldValidationInfo> _fieldsDic;
        private List<Action<T>> _entityInitilizers;

        //func, property, ruleName, actions, controlId
        List<Tuple<Func<T, bool>, string, string, List<string>, string>> _validationRules;
        //func, property, ruleName, actions
        List<Tuple<Func<T, bool>, string, string, List<string>>> _customRules;
        //List<Tuple<string, Func<T, bool>, string, string, List<string>>> _bizValidationRules;

        //private readonly IBizRuleValidator _bizRuleValidator;

        public EntityValidator(Dictionary<string, FieldValidationInfo> fieldsDic)//, IBizRuleValidator bizRuleValidator)
        {
            _fieldsDic = fieldsDic;
            //_bizRuleValidator = bizRuleValidator;
        }

        public bool HasAnyMandatoryField()
        {
            var res = _fieldsDic != null && _fieldsDic.Values.Any(a => string.Equals(a.MandatoryInd, "T", StringComparison.OrdinalIgnoreCase));
            return res;
        }

        protected void BuildRules()
        {
            using (var validationEngineCompiler = new ValidationEngineCompiler())
            {
                _validationRules = new List<Tuple<Func<T, bool>, string, string, List<string>,string>>();
                //_bizValidationRules = new List<Tuple<string, Func<T, bool>, string, string, List<string>>>();
                _entityInitilizers = new List<Action<T>>(); //TODO: check already created

                List<Rule> rulesCollection = new List<Rule>();
                //List<KeyValuePair<string, Rule>> bizRulesCollection = new List<KeyValuePair<string, Rule>>();

                foreach (var a in _fieldsDic)
                //_fieldsDic.ForEach(a =>
                {
                    if (!string.IsNullOrWhiteSpace(a.Value.MaxLength))
                    {
                        var ruleMax = new Rule(a.Value.Name.Trim(), "MaxLength", a.Value.MaxLength.Trim(), nameof(a.Value.MaxLength), a.Value.Actions,a.Value.Id);
                        rulesCollection.Add(ruleMax);
                    }



                    if (!string.IsNullOrWhiteSpace(a.Value.BusinessRuleVal))
                    {

                    }


                    if (!string.IsNullOrWhiteSpace(a.Value.MandatoryInd) && a.Value.MandatoryInd.ToUpper() == "T")
                    {
                        //if (!string.IsNullOrWhiteSpace(a.Value.BusinessRuleVal))
                        //{
                        //    var ruleMandatory = new Rule(a.Value.Name.Trim(), "Notempty", string.Empty, "ConditionalMandatory", a.Value.Actions);
                        //    bizRulesCollection.Add(new KeyValuePair<string, Rule>(a.Value.BusinessRuleVal, ruleMandatory));
                        //}
                        //else
                        {
                            var ruleMandatory = new Rule(a.Value.Name.Trim(), "Notempty", string.Empty, "Mandatory", a.Value.Actions,a.Value.Id);
                            rulesCollection.Add(ruleMandatory);
                        }

                    }


                    //Default value initilizer
                    if (!string.IsNullOrWhiteSpace(a.Value.DefaultValue))
                    {
                        var fieldInitilizer = validationEngineCompiler.GetFieldInitilizer<T>(a.Key.Trim(), a.Value.DefaultValue);
                        _entityInitilizers.Add(fieldInitilizer);
                    }
                }
                //);



                rulesCollection.ForEach(v =>
                {
                    var func = validationEngineCompiler.CompileRule<T>(v);
                    var tuple = Tuple.Create(func, v.MemberName, v.RuleName, v.Actions,v.ControlId);
                    _validationRules.Add(tuple);
                });

                //bizRulesCollection.ForEach(v =>
                //{
                //    var func = validationEngineCompiler.CompileRule<T>(v.Value);
                //    //var tuple = Tuple.Create(v.Key, func, v.Value.MemberName, v.Value.RuleName, v.Value.Actions);
                //    //_bizValidationRules.Add(tuple);
                //});
            }

        }

        [Obsolete("Use Validate(T entity, string action=null)")]
        public ValidationResult ValidateEntity(T entity)
        {
            if (_validationRules == null)
                BuildRules();


            ValidationResult res = new ValidationResult()
            {
                Errors = new List<ValidationError>(),
                IsValid = true
            };

            _validationRules?.ForEach(r =>
            {
                if (!r.Item1(entity))
                {
                    res.IsValid = false;
                    res.Errors.Add(new ValidationError()
                    {
                        Property = r.Item2,
                        Rule = r.Item3
                    });
                }
            });

            //_bizValidationRules?.ForEach(r =>
            //{
            //    if (!r.Item2(entity))
            //    {
            //        bool bizRuleResult = true;// _bizRuleValidator.ValidateRule(r.Item4, entity);

            //        if (bizRuleResult)
            //        {
            //            res.IsValid = false;
            //            res.Errors.Add(new ValidationError()
            //            {
            //                BusinessRule = r.Item1,
            //                Property = r.Item3,
            //                Rule = r.Item4
            //            });
            //        }
            //    }
            //    //if property value is not null/empty, no need to evaluate business rule
            //});

            return res;
        }

        public ValidationResult Validate(T entity, string action = null)
        {

            var res = ValidateInternal(entity, string.Empty, action);

            return res;

#region moved


            //if (_validationRules == null)
            //    BuildRules();


            //ValidationResult res = new ValidationResult()
            //{
            //    Errors = new List<ValidationError>(),
            //    IsValid = true
            //};

            //_validationRules?.ForEach(r =>
            //{
            //    if(string.IsNullOrWhiteSpace(action) || r.Item4.Any(a=>a.Equals(action, StringComparison.OrdinalIgnoreCase)))
            //    if ( !r.Item1(entity))
            //    {
            //        res.IsValid = false;
            //        res.Errors.Add(new ValidationError()
            //        {
            //            Property = r.Item2,
            //            Rule = r.Item3
            //        });
            //    }
            //});

            //_bizValidationRules?.ForEach(r =>
            //{
            //    if (string.IsNullOrWhiteSpace(action) || r.Item5.Any(a => a.Equals(action, StringComparison.OrdinalIgnoreCase)))
            //        if (!r.Item2(entity))
            //    {
            //        //TODO invoke biz rule
            //        bool bizRuleResult = true; //TODO

            //        if (bizRuleResult)
            //        {
            //            res.IsValid = false;
            //            res.Errors.Add(new ValidationError()
            //            {
            //                BusinessRule = r.Item1,
            //                Property = r.Item3,
            //                Rule = r.Item4
            //            });
            //        }
            //    }
            //    //if property value is not null/empty, no need to evaluate business rule
            //});

            //return res;

#endregion

        }

        public ValidationResult ValidateProperty(T entity, string propertyName, string action = null)
        {
            var res = ValidateInternal(entity, propertyName, action);
            return res;
        }

        ValidationResult ValidateInternal(T entity, string propertyName, string action)
        {
            if (_validationRules == null)
                BuildRules();


            ValidationResult res = new ValidationResult()
            {
                Errors = new List<ValidationError>(),
                IsValid = true
            };

            _validationRules?.ForEach(r =>
            {
                if (string.IsNullOrWhiteSpace(action) || r.Item4.Any(a => a.Equals(action, StringComparison.OrdinalIgnoreCase) || a.Equals("db", StringComparison.OrdinalIgnoreCase))) //if any rule for given action or its db rule 
                {
                    if (string.IsNullOrWhiteSpace(propertyName) || r.Item2.Equals(propertyName)) //no property given or property is given property to validate
                        if (!r.Item1(entity)) //call rule func
                        {
                            res.IsValid = false;
                            res.Errors.Add(new ValidationError()
                            {
                                Property = r.Item2,
                                Rule = r.Item3,
                                Context = new WeakReference(entity),
                                ControlId=r.Item5
                            });
                        }
                }
            });

            _customRules?.ForEach(r =>
            {
                if (string.IsNullOrWhiteSpace(action) || r.Item4.Any(a => a.Equals(action, StringComparison.OrdinalIgnoreCase) || a.Equals("db", StringComparison.OrdinalIgnoreCase))) //if any rule for given action or its db rule 
                {
                    if (string.IsNullOrWhiteSpace(propertyName) || r.Item2.Equals(propertyName)) //no property given or property is given property to validate
                        if (!r.Item1(entity)) //call rule func
                        {
                            res.IsValid = false;
                            res.Errors.Add(new ValidationError()
                            {
                                Property = r.Item2,
                                Rule = r.Item3,
                                Context = new WeakReference(entity)
                            });
                        }
                }
            });

            //_bizValidationRules?.ForEach(r =>
            //{
            //    if (string.IsNullOrWhiteSpace(action) || r.Item5.Any(a => a.Equals(action, StringComparison.OrdinalIgnoreCase) || a.Equals("db", StringComparison.OrdinalIgnoreCase)))
            //    {
            //        if (string.IsNullOrWhiteSpace(propertyName) || r.Item2.Equals(propertyName)) //no property given or property is given property to validate
            //        {
            //            if (!r.Item2(entity))
            //            {
            //                //TODO invoke biz rule
            //                bool bizRuleResult = _bizRuleValidator.ValidateRule(r.Item4, entity);

            //                if (bizRuleResult)
            //                {
            //                    res.IsValid = false;
            //                    res.Errors.Add(new ValidationError()
            //                    {
            //                        BusinessRule = r.Item1,
            //                        Property = r.Item3,
            //                        Rule = r.Item4,
            //                        Context = new WeakReference(entity)
            //                    });

            //                }
            //            }
            //        }
            //    }
            //    //if property value is not null/empty, no need to evaluate business rule
            //});

            return res;
        }


        public void RegisterCustomRule(Func<T, bool> func, string property, string ruleName, List<string> actions)
        {
            var rulesCollection = _customRules ??
                                  (_customRules = new List<Tuple<Func<T, bool>, string, string, List<string>>>());

            rulesCollection.Add(new Tuple<Func<T, bool>, string, string, List<string>>(func, property, ruleName, actions ));
        }

        public bool InitializeEntity(T entity)
        {
            if (_entityInitilizers == null)
            {
                BuildRules();
            }

            _entityInitilizers?.ForEach(i => i(entity));
            return _entityInitilizers != null && _entityInitilizers.Count > 0;
        }

        ValidationResult IValidator.Validate(BaseModel entity, string action)
        {
            return Validate(entity as T, action);
        }

        ValidationResult IValidator.ValidateProperty(BaseModel entity, string propertyName, string action)
        {
            return ValidateProperty(entity as T, propertyName, action);
        }

        bool IValidator.InitializeEntity(BaseModel entity)
        {
            return InitializeEntity(entity as T);
        }
    }



}
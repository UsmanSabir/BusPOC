﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using NS.BaseModels;

// ReSharper disable once CheckNamespace
namespace NS.Validation.Engine
{
    /// <summary>
    /// Validations rule compiler
    /// </summary>
    /// <remarks>
    /// <para>[US] 03/04/2016  1.0 class created.</para>
    /// </remarks>
    internal sealed class ValidationEngineCompiler:IDisposable
    {
        public bool PassesRules<T>(List<Rule> rules, T toInspect)
        {
            return CompileRules<T>(rules).Invoke(toInspect);
        }
        public Func<T, bool> CompileRule<T>(Rule r)
        {
            var paramUser = Expression.Parameter(typeof(T));
            Expression expr = BuildExpr<T>(r, paramUser);

            return Expression.Lambda<Func<T, bool>>(expr, paramUser).Compile();
        }

        public Func<BaseModel, bool> CompileRule(Type tp, Rule r)
        {
            var paramUser = Expression.Parameter(tp);
            Expression expr = BuildExpr(tp, r, paramUser);

            return Expression.Lambda<Func<BaseModel, bool>>(expr, paramUser).Compile();
        }

        public Func<T, bool> CompileRules<T>(IList<Rule> rules)
        {
            var paramUser = Expression.Parameter(typeof(T));
            List<Expression> expressions = new List<Expression>();
            // ReSharper disable once LoopCanBeConvertedToQuery
            foreach (var r in rules)
            {
                expressions.Add(BuildExpr<T>(r, paramUser));
            }
            var expr = AndExpressions(expressions);

            return Expression.Lambda<Func<T, bool>>(expr, paramUser).Compile();
        }

        Expression AndExpressions(IList<Expression> expressions)
        {
            if (expressions.Count == 1)
                return expressions[0];
            Expression exp = Expression.And(expressions[0], expressions[1]);
            for (int i = 2; expressions.Count > i; i++)
            {
                exp = Expression.And(exp, expressions[i]);
            }
            return exp;
        }

        Expression BuildExpr<T>(Rule r, ParameterExpression param)
        {
            Expression propExpression;
            Type propType;
            ExpressionType tBinary;
            if (r.MemberName.Contains('.'))
            {
                String[] childProperties = r.MemberName.Split('.');
                var property = typeof(T).GetProperty(childProperties[0]);
                //var paramExp = Expression.Parameter(typeof(T), "SomeObject");

                propExpression = Expression.PropertyOrField(param, childProperties[0]);
                for (var i = 1; i < childProperties.Length; i++)
                {
                    property = property.PropertyType.GetProperty(childProperties[i]);
                    propExpression = Expression.PropertyOrField(propExpression, childProperties[i]);
                }
                propType = propExpression.Type;
            }
            else
            {
                propExpression = Expression.PropertyOrField(param, r.MemberName);
                propType = propExpression.Type;
            }

            // is the operator a known .NET operator?
            // ReSharper disable once AccessToStaticMemberViaDerivedType
            if (ExpressionType.TryParse(r.Operator, out tBinary))
            {
                var right = GetConstantExpression(r.TargetValue, propType);// Expression.Constant(Convert.ChangeType(r.TargetValue, propType));
                // use a binary operation, e.g. 'Equal' -> 'u.Age == 15'
                return Expression.MakeBinary(tBinary, propExpression, right);
            }
            else if (r.Operator.Equals("NotEmpty", StringComparison.InvariantCultureIgnoreCase))
            {
                #region NotEmpty
                if (propType == typeof(string))

                    return Expression.Not(Expression.Call(typeof(string), "IsNullOrWhiteSpace", null,
                        propExpression));


                //var def = default(propType);
                ConstantExpression right;
                if (propType.IsValueType && Nullable.GetUnderlyingType(propType) != null)
                {
                    right = Expression.Constant(GetDefaultValue(propType));//GetConstantExpression(r.TargetValue, tParam);
                    return Expression.MakeBinary(ExpressionType.NotEqual, propExpression, right);
                }
                 right = Expression.Constant(1);
                return Expression.MakeBinary(ExpressionType.Equal, right, right);

                //Expression.Lambda<Func<int>>(Expression.Call(func.Method));
                //var a= (o)=> !string.IsNullOrWhiteSpace(propExpression) 
                #endregion
            }
            else if (r.Operator.Equals("MaxLength", StringComparison.InvariantCultureIgnoreCase))
            {
                var prpExpression = Expression.PropertyOrField(param, r.MemberName);
                var propRight = Expression.Constant(GetDefaultValue(propType));

                var notNullExpression= Expression.MakeBinary(ExpressionType.Equal, prpExpression, propRight);

                //var name = r.MemberName + ".Length";
                var length = "Length";
                var lenPrpExpression = Expression.PropertyOrField(param, r.MemberName);
                //var property = typeof(T).GetProperty(r.MemberName);
                //property = property.PropertyType.GetProperty(length);

                var lenProp = Expression.PropertyOrField(lenPrpExpression, length);
                propType = lenProp.Type;
                var right2 = GetConstantExpression(r.TargetValue, propType);
                //ExpressionType.TryParse("LessThanOrEqual", out tBinary);
                Enum.TryParse("LessThanOrEqual", out tBinary);
                var propertyLengthExpression = Expression.MakeBinary(tBinary, lenProp, right2);

                var maxLengthExpr = Expression.OrElse(notNullExpression, propertyLengthExpression);
                return maxLengthExpr;
                
            }
            else
            {
                var method = propType.GetMethod(r.Operator);
                var tParam = method.GetParameters()[0].ParameterType;
                var right = GetConstantExpression(r.TargetValue, tParam); //Expression.Constant(Convert.ChangeType(r.TargetValue, tParam));
                // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
                return Expression.Call(propExpression, method, right);
            }
        }

        Expression BuildExpr(Type tp, Rule r, ParameterExpression param)
        {
            Expression propExpression;
            Type propType;
            ExpressionType tBinary;
            if (r.MemberName.Contains('.'))
            {
                String[] childProperties = r.MemberName.Split('.');
                var property = tp.GetProperty(childProperties[0]);
                //var paramExp = Expression.Parameter(typeof(T), "SomeObject");

                propExpression = Expression.PropertyOrField(param, childProperties[0]);
                for (var i = 1; i < childProperties.Length; i++)
                {
                    property = property.PropertyType.GetProperty(childProperties[i]);
                    propExpression = Expression.PropertyOrField(propExpression, childProperties[i]);
                }
                propType = propExpression.Type;
            }
            else
            {
                propExpression = Expression.PropertyOrField(param, r.MemberName);
                propType = propExpression.Type;
            }

            // is the operator a known .NET operator?
            // ReSharper disable once AccessToStaticMemberViaDerivedType
            if (ExpressionType.TryParse(r.Operator, out tBinary))
            {
                var right = GetConstantExpression(r.TargetValue, propType);// Expression.Constant(Convert.ChangeType(r.TargetValue, propType));
                // use a binary operation, e.g. 'Equal' -> 'u.Age == 15'
                return Expression.MakeBinary(tBinary, propExpression, right);
            }
            else if (r.Operator.Equals("NotEmpty", StringComparison.InvariantCultureIgnoreCase))
            {
                if (propType == typeof(string))

                    return Expression.Not(Expression.Call(typeof(string), "IsNullOrWhiteSpace", null,
                        propExpression));


                //var def = default(propType);
                var right = Expression.Constant(GetDefaultValue(propType));//GetConstantExpression(r.TargetValue, tParam);
                return Expression.MakeBinary(ExpressionType.NotEqual, propExpression, right);

                //Expression.Lambda<Func<int>>(Expression.Call(func.Method));
                //var a= (o)=> !string.IsNullOrWhiteSpace(propExpression)
            }
            else
            {
                var method = propType.GetMethod(r.Operator);
                var tParam = method.GetParameters()[0].ParameterType;
                var right = GetConstantExpression(r.TargetValue, tParam); //Expression.Constant(Convert.ChangeType(r.TargetValue, tParam));
                // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
                return Expression.Call(propExpression, method, right);
            }
        }

        object GetDefaultValue(Type t)
        {
            if (t.IsValueType)
                return Activator.CreateInstance(t);

            return null;
        }

        public Action<T> GetFieldInitilizer<T>(string propName, object val)
        {
            var parameterT = Expression.Parameter(typeof(T), "x");

            var propExpression = Expression.PropertyOrField(parameterT, propName);
            var propType = propExpression.Type;

            //var property = (PropertyInfo)propExpression.Member;
            //var setMethod = property.GetSetMethod();
            var right = GetConstantExpression(val, propType);


            //var newExpression =
            //    Expression.Lambda<Action<T>>(
            //        Expression.Call(parameterT, setMethod, right), parameterT
            //    );

            var expr = Expression.Lambda<Action<T>>(Expression.Assign(Expression.Property(parameterT, propName), right), parameterT);

            return expr.Compile(); //newExpression.Compile();
        }

        public Action<BaseModel> GetFieldInitilizer(Type tp, string propName, object val)
        {
            var parameterT = Expression.Parameter(tp, "x");

            var propExpression = Expression.PropertyOrField(parameterT, propName);
            var propType = propExpression.Type;

            //var property = (PropertyInfo)propExpression.Member;
            //var setMethod = property.GetSetMethod();
            var right = GetConstantExpression(val, propType);


            //var newExpression =
            //    Expression.Lambda<Action<T>>(
            //        Expression.Call(parameterT, setMethod, right), parameterT
            //    );

            var expr = Expression.Lambda<Action<BaseModel>>(Expression.Assign(Expression.Property(parameterT, propName), right), parameterT);

            return expr.Compile(); //newExpression.Compile();
        }

        private static ConstantExpression GetConstantExpression(object val, Type propType)
        {
            object tval;
            if (propType.IsGenericType && propType.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                tval = Convert.ChangeType(val, propType.GetGenericArguments()[0]);
            }
            else
            {
                tval = Convert.ChangeType(val, propType);
            }

            var right = Expression.Constant(tval, propType);
            return right;
        }


        public void Dispose()
        {
            
        }
    }
}
﻿
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NS.BaseModels;

// ReSharper disable once CheckNamespace
namespace NS.Validation
{
    /// <summary>
    /// Class ReflectionHelper.
    /// </summary>
    public sealed class ReflectionHelper
    {
        /// <summary>
        /// The cached properties
        /// </summary>
        private static readonly ConcurrentDictionary<Type, Dictionary<string, PropertyInfo>> _cachedProperties = new ConcurrentDictionary<Type, Dictionary<string, PropertyInfo>>();
        /// <summary>
        /// The cached child properties
        /// </summary>
        private static readonly ConcurrentDictionary<Type, Tuple<List<KeyValuePair<PropertyInfo, Type>>, List<PropertyInfo>>> _cachedChildProperties = new ConcurrentDictionary<Type, Tuple<List<KeyValuePair<PropertyInfo, Type>>, List<PropertyInfo>>>();

        /// <summary>
        /// Gets properties of the specified type
        /// </summary>
        /// <param name="type">The type</param>
        /// <returns>Collection of property names and property infos</returns>
        /// <remarks><para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para></remarks>
		public static Dictionary<string, PropertyInfo> GetProperties(Type type)
        {
            var properties = _cachedProperties.GetOrAdd(type, BuildPropertyDictionary);

            return properties;
        }


        /// <summary>
        /// Gets properties of the entity types added as child(s)
        /// </summary>
        /// <param name="type">The type</param>
        /// <returns>Collection of property names and property infos</returns>
        /// <remarks>[US] 13/04/2016  1.0 Method created.</remarks>
        public static Tuple<List<KeyValuePair<PropertyInfo, Type>>, List<PropertyInfo>> GetChildEntityProperties(Type type)
        {
            var properties = _cachedChildProperties.GetOrAdd(type, BuildChildEntityPropertyDictionary);

            return properties;
        }

        /// <summary>
        /// Builds the child entity property dictionary.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>Tuple&lt;List&lt;KeyValuePair&lt;PropertyInfo, Type&gt;&gt;, List&lt;PropertyInfo&gt;&gt;.</returns>
        private static Tuple<List<KeyValuePair<PropertyInfo, Type>>, List<PropertyInfo>> BuildChildEntityPropertyDictionary(Type type)
        {
            var properties = GetProperties(type).Values;
            var childProperties = properties.Where(t =>
                (t.PropertyType.IsGenericType &&
                 typeof (BaseModel).IsAssignableFrom(t.PropertyType.GenericTypeArguments[0])) //child collection
                || typeof (BaseModel).IsAssignableFrom(t.PropertyType) //child entity
                ).ToList();


            List<KeyValuePair<PropertyInfo, Type>> listChilds=new List<KeyValuePair<PropertyInfo, Type>>();
            List<PropertyInfo> childs=new List<PropertyInfo>();

            childProperties.ForEach(property =>
            {
                if (property.PropertyType.IsGenericType)
                {
                    var childType = property.PropertyType.GenericTypeArguments[0];
                    listChilds.Add(new KeyValuePair<PropertyInfo, Type>(property, childType));
                }
                else
                {
                    childs.Add(property);
                }
            });

            var tuple = Tuple.Create(listChilds, childs);

            return tuple;
        }

        /// <summary>
        /// Builds the property dictionary.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>Dictionary&lt;System.String, PropertyInfo&gt;.</returns>
        private static Dictionary<string, PropertyInfo> BuildPropertyDictionary(Type type)
        {
            var result = new Dictionary<string, PropertyInfo>();

            var properties = type.GetProperties();
            // ReSharper disable once LoopCanBeConvertedToQuery
            foreach (var property in properties)
            {
                result.Add(property.Name.ToLower(), property);
            }
            return result;
        }

    }
}
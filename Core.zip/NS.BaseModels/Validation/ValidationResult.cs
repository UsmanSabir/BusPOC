
using System;
using System.Collections.Generic;

// ReSharper disable once CheckNamespace
namespace NS.Validation
{
    /// <summary>
    /// ValidationResult, Result of Validate operation
    /// </summary>
    public sealed class ValidationResult
    {
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>The errors.</value>
        public List<ValidationError> Errors { get; set; }

        /// <summary>
        /// Returns true if ... is valid.
        /// </summary>
        /// <value><c>true</c> if this instance is valid; otherwise, <c>false</c>.</value>
        public bool IsValid { get; set; }
    }

    /// <summary>
    /// Validation Error details
    /// </summary>
    public class ValidationError
    {
        /// <summary>
        /// Property name of object where validation fails
        /// </summary>
        /// <value>The property.</value>
        public string Property { get; set; }


        /// <summary>
        /// Complete entity path in case of aggregate validation
        /// </summary>
        /// <value>The path.</value>
        public string Path { get; set; }

        /// <summary>
        /// Rule name that fails
        /// </summary>
        /// <value>The rule.</value>
        public string Rule { get; set; }

        /// <summary>
        /// Business rule that fails
        /// </summary>
        /// <value>The business rule.</value>
        public string BusinessRule { get; set; }

        //Store weak reference, so GC can collect it and no memory leakage occure
        /// <summary>
        /// Entity as weak reference on which validation rule failed
        /// </summary>
        /// <value>The context.</value>
        public WeakReference Context { get; set; }

        /// <summary>
        /// User Control Id of Property
        /// </summary>
        /// <value>The control identifier.</value>
        public string ControlId { get; set; }
    }
}
﻿using NS.Utilities.Enums;

namespace NS.BaseModels
{

    /// <summary>
    /// Wrapper class for all public response objects, it conatins properties related to response.
    /// </summary>
    /// <typeparam name="T">Type of the response object.</typeparam>
    /// <remarks>
    /// <para>[AHA] 05/07/2017  1.0 Class created.</para>
    /// </remarks>
    public class PublicResponseObject<T>
    {

        #region Private Memebers

        private string _messageCode;
        private MessageInfo _message;
        private string _responseCode;
        private MessageType _messageType;
        private T _resultSet;

        #endregion

        #region Public Properties

        /// <summary>
        /// Message code provided by the server.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 05/07/2017  1.0 Property created.</para>
        /// </remarks>
        public string MessageCode
        {
            get { return _messageCode; }
            set { _messageCode = value; }
        }

        /// <summary>
        /// Message provided by the server.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 05/07/2017  1.0 Property created.</para>
        /// </remarks>
        public MessageInfo Message
        {
            get { return _message; }
            set { _message = value; }
        }

        /// <summary>
        /// Response code provided by the server.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 05/07/2017  1.0 Property created.</para>
        /// </remarks>
        public string ResponseCode
        {
            get { return _responseCode; }
            set { _responseCode = value; }
        }

        /// <summary>
        /// Message type provided by the server.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 05/07/2017  1.0 Property created.</para>
        /// </remarks>
        public MessageType MessageType
        {
            get { return _messageType; }
            set { _messageType = value; }
        }

        /// <summary>
        /// Actual response object.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 05/07/2017  1.0 Property created.</para>
        /// </remarks>
        public T ResultSet
        {
            get { return _resultSet; }
            set { _resultSet = value; }
        }

        #endregion

    }
}

﻿
using NS.ExceptionHandling;
using NS.Utilities.Enums;
using System;

namespace NS.BaseModels
{
    /// <summary>
    /// Class which provides helper methods for service implementation.
    /// </summary>
    /// <remarks>[AHA] 1.0 01/10/2016  Class created</remarks>
    public static class ServiceHelper
    {
        /// <summary>
        /// Logics the safe call.
        /// </summary>
        /// <typeparam name="TResult">The type of the t result.</typeparam>
        /// <param name="func">The function.</param>
        /// <returns>ResponseObject&lt;TResult&gt;.</returns>
        public static ResponseObject<TResult> LogicSafeCall<TResult>(Func<ResponseObject<TResult>> func)
        {
            ResponseObject<TResult> response = null;
            try
            {
                response = func();
                if (response != null)
                    response = SuccessResponse(response.ResultSet, response.WorkflowInput, response.Message);
                else
                    response = NullResponse<TResult>("Logic class returned null response.");
            }
            catch (Exception exception)
            {
                ExceptionHandler.HandleException(exception, ExceptionHandlingPolicy.BusinessPolicy);
            }
            return response;
        }

        /// <summary>
        /// Method to generate standard Null response object.
        /// </summary>
        /// <typeparam name="TResult">Type of response object.</typeparam>
        /// <param name="message">Message to be included in response.</param>
        /// <returns>Standard null response.</returns>
        /// <remarks>[AHA] 1.0 10/04/2016  Method created.</remarks>
        public static ResponseObject<TResult> NullResponse<TResult>(string message)
        {
            ResponseObject<TResult> response = new ResponseObject<TResult>
            {
                Message = new MessageInfo { Type = MessageType.Error, Message = message },
                ResultSet = default(TResult)
            };
            return response;
        }

        /// <summary>
        /// Method to generate standard success response object.
        /// </summary>
        /// <typeparam name="TResult">Type of response object.</typeparam>
        /// <param name="data">Response data.</param>
        /// <param name="workFlowInput">The work flow input.</param>
        /// <returns>Standard success response.</returns>
        /// <remarks>[AHA] 1.0 10/04/2016  Method created.</remarks>
        public static ResponseObject<TResult> SuccessResponse<TResult>(TResult data, WorkflowInputParams workFlowInput = null, MessageInfo message = null)
        {
            ResponseObject<TResult> response = new ResponseObject<TResult>
            {
                Message = message ?? new MessageInfo { Type = MessageType.Success },
                ResultSet = data,
                WorkflowInput = workFlowInput
            };
            return response;
        }

        /// <summary>
        /// Method to handle service exception and generate standard error response.
        /// </summary>
        /// <typeparam name="TResult">Type of response object.</typeparam>
        /// <param name="policy">Error handling policy.</param>
        /// <param name="ex">Exception to handle.</param>
        /// <returns>Standard error response.</returns>
        /// <remarks>[AHA] 1.0 10/04/2016  Method created.</remarks>
        public static ResponseObject<TResult> ServiceErrorResponse<TResult>(ExceptionHandlingPolicy policy, Exception ex)
        {
            ResponseObject<TResult> response = new ResponseObject<TResult>();
            Exception wappedExceptionex;
            ExceptionHandler.HandleException(ex, policy, out wappedExceptionex);
            response.Message = new MessageInfo
            {
                Message = wappedExceptionex.Message,
                Type = MessageType.Error
            };
            response.ResultSet = default(TResult);
            return response;
        }

    }
}

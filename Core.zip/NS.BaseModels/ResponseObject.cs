﻿using System.Runtime.Serialization;
// ReSharper disable ConvertToAutoProperty

namespace NS.BaseModels
{
    /// <summary>
    /// Wrapper class for all response objects, it contains properties related to response.
    /// </summary>
    /// <typeparam name="T">Type of the response object.</typeparam>
    /// <remarks>
    /// <para>[AHA] 04/03/2016  1.0 Class created.</para>
    /// <para>[AHA] 31/03/2016  1.0 Property "Date" removed.</para>
    /// </remarks>
    [DataContract]
    public sealed class ResponseObject<T>
    {

        #region Private Memebers

        private MessageInfo _message;
        private int? _messageCode;
        private int? _responseCode;
        private T _resultSet;
        private WorkflowInputParams _workflowParams;
        #endregion

        #region Public Properties

        /// <summary>
        /// Property which contains response message.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public MessageInfo Message
        {
            get { return _message; }
            set { _message = value; }
        }

        /// <summary>
        /// Property which contains message code.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// <para>[AHA] 04/03/2016  1.0 Property renamed from "Code" to "MessageCode".</para>
        /// </remarks>
        [DataMember]
        public int? MessageCode
        {
            get { return _messageCode; }
            set { _messageCode = value; }
        }

        /// <summary>
        /// Property which contains response code.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 31/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public int? ResponseCode
        {
            get { return _responseCode; }
            set { _responseCode = value; }
        }

        /// <summary>
        /// Property which contains the actual response object.
        /// </summary>
        /// <remarks>
        /// <para>[AHA] 04/03/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public T ResultSet
        {
            get { return _resultSet; }
            set { _resultSet = value; }
        }

        /// <summary>
        /// Property which contains workflow parameters.
        /// </summary>
        /// <remarks>
        /// <para>[HAA] 10/31/2016  1.0 Property created.</para>
        /// </remarks>
        [DataMember]
        public WorkflowInputParams WorkflowInput
        {
            get { return _workflowParams; }
            set { _workflowParams = value; }
        }

        #endregion

    }
}

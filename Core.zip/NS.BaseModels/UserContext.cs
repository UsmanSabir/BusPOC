﻿using System;
using System.Globalization;
using NS.Utilities.Enums;

namespace NS.BaseModels
{
    /// <summary>
    /// Serializeable Class to hold context related information. 
    /// </summary>
    /// <remarks>
    /// [AHA]   15/02/2016  1.0 Class created.
    /// [AHA]   16/02/2016  1.0 Documentation updated.
    /// </remarks>
    [Serializable()]
    public sealed class UserContext
    {
        #region Private Members

        private Guid _contextId;
        private string _applicationId;
        private string _sessionId;
        private string _loginId;
        //private string _clientIp;//HACK: unused field
        private DateTime? _workDate;
        //private DateTime? _timeStamp;//HACK: unused field
        private CultureInfo _culture;
        private string _dateFormat;
        private NSLogLevel _logLevel;
        private string _message;
        private string _userName;

        #endregion

        #region Public Properties

        /// <summary>
        /// Property to get or set context ID.
        /// </summary>
        /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public Guid ContextId
        {
            get
            {
                return _contextId;
            }

            set
            {
                _contextId = value;
            }
        }

        /// <summary>
        /// Property to get or set applicaiton ID.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public string ApplicationId
        {
            get
            {
                return _applicationId;
            }

            set
            {
                _applicationId = value;
            }
        }

        /// <summary>
        /// Property to get or set User ID.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public string LoginId
        {
            get
            {
                return _loginId;
            }

            set
            {
                _loginId = value;
            }
        }

        /// <summary>
        /// Property to get or set Session ID.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public string SessionId
        {
            get
            {
                return _sessionId;
            }

            set
            {
                _sessionId = value;
            }
        }

        /// <summary>
        /// Property to get or set User Name.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public string UserName
        {
            get
            {
                return _userName;
            }

            set
            {
                _userName = value;
            }
        }

        /// <summary>
        /// Property to get or set Working/Processing Date.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public DateTime? WorkDate
        {
            get
            {
                return _workDate;
            }

            set
            {
                _workDate = value;
            }
        }

        /// <summary>
        /// Property to get or set Culture.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public CultureInfo Culture
        {
            get
            {
                return _culture;
            }

            set
            {
                _culture = value;
            }
        }

        /// <summary>
        /// Property to get or set Date Format.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public string DateFormat
        {
            get
            {
                return _dateFormat;
            }

            set
            {
                _dateFormat = value;
            }
        }

        /// <summary>
        /// Property to get or set Log Level.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public NSLogLevel LogLevel
        {
            get
            {
                return _logLevel;
            }

            set
            {
                _logLevel = value;
            }
        }

        /// <summary>
        /// Property to get or set Message to be logged.
        /// </summary>
        /// /// <remakrs>
        /// [AHA]   15/02/2016  1.0 Property Created.
        /// </remakrs>
        public string Message
        {
            get
            {
                return _message;
            }

            set
            {
                _message = value;
            }
        }

        #endregion
    }
}

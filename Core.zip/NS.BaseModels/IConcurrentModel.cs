﻿
using System;

namespace NS.BaseModels
{
    /// <summary>
    /// Interface IConcurrentModel
    /// </summary>
    public interface IConcurrentModel
    {
        // ReSharper disable once InconsistentNaming
        /// <summary>
        /// Gets the updt DTE.
        /// </summary>
        /// <value>The updt DTE.</value>
        DateTime UPDT_DTE { get; }
    }
}
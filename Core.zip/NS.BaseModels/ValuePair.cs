﻿using System;

namespace NS.BaseModels
{
    /// <summary>
    /// Class for holding object state.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <para>[US] 26/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
    /// </para>
    /// </remarks>
#if !SILVERLIGHT
    [Serializable]
    #endif
    public sealed class ValuePair
    {
        /// <summary>
        /// Hold the old value of the object.
        /// </summary>
        /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Property created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public object OldValue { get; set; }

        /// <summary>
        /// Holds the current value of the object.
        /// </summary>
        /// <remarks>
        /// <para>[US] 26/02/2016  1.0 Property created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public object NewValue { get; set; }

    }
}
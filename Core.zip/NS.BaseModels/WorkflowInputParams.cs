﻿using System.Runtime.Serialization;
using NS.Utilities.Context;
using System.Collections.Generic;

namespace NS.BaseModels
{
    /// <summary>
    /// Class which will be used to specify parameters to workflow engine service for invocation of workflow
    /// </summary>
    /// <remarks>
    /// <para>[AHA] 04/03/2016  1.0 Class created.</para>
    /// </remarks>
    [DataContract]
    public sealed class WorkflowInputParams
    {
        /// <summary>
        /// Request Id (Usually passed from Task Queue)
        /// </summary>
        [DataMember]
        public int RequestId { set; get; }
        /// <summary>
        /// Type of Request
        /// </summary>
        [DataMember]
        public string RequestType { set; get; }
        /// <summary>
        /// Module Name e.g. Proposal, Contract,Business Partner etc.
        /// </summary>
        [DataMember]
        public string Module { set; get; } // Module Code
        /// <summary>
        /// Reference Id e.g. Proposal Id, Contract Id, Business Partner Id etc.
        /// </summary>
        [DataMember]
        public int ReferenceId { set; get; } // Module ID
        /// <summary>
        /// ID of screen that wants to invoke workflow
        /// </summary>
        [DataMember]
        public int ScreenId { set; get; }
        /// <summary>
        /// Action of screen that wants to invoke workflow
        /// </summary>
        [DataMember]
        public string ScreenAction { set; get; }
        /// <summary>
        /// Current Request Status
        /// </summary>
        [DataMember]
        public string StatusFrom { set; get; }
        /// <summary>
        /// Next Request Status
        /// </summary>
        [DataMember]
        public string StatusTo { set; get; }
        /// <summary>
        /// User Session Object
        /// </summary>
        [DataMember]
        public Context Session { set; get; }        
        /// <summary>
        /// Entity Type Name
        /// </summary>
        [DataMember]
        public string EntityType { set; get; }
        /// <summary>
        /// Entity to be passed to workflow
        /// </summary>
        [DataMember]
        public BaseModel Entity { set; get; }
        /// <summary>
        /// List of entities to be passed to workflow
        /// </summary>
        [DataMember]
        public IEnumerable<dynamic> EntityList { set; get; }
        /// <summary>
        /// List of reference Ids passed to workflow
        /// </summary>
        [DataMember]
        public IEnumerable<string> ReferenceIdsList { set; get; }
        /// <summary>
        /// Holds workflow Id to invoke.
        /// </summary>
        [DataMember]
        public int SubWorkflowId { get; set; }

        /// <summary>
        /// Holds parent workflow intance id.
        /// </summary>
        [DataMember]
        public string ParentWkfInstanceId { get; set; }

        /// <summary>
        /// Holds parent request id.
        /// </summary>
        [DataMember]
        public int? ParentRequestId { get; set; }
        /// <summary>
        /// Application Key
        /// </summary>
        [DataMember]
        public string ApplicationKey { set; get; }

        /// <summary>
        /// External application or module key.
        /// SubTenantSync for multi company data sync.
        /// ContractOrigination for contract origination calls.
        /// Others for any other call.
        /// </summary>
        [DataMember]
        public string ExternalKey { set; get; }

        /// <summary>
        /// User Login Id. This property will be used in auto assign activity
        /// </summary>
        [DataMember]
        public string RequestAssignee { set; get; }
        /// <summary>
        /// Set to True in case of Pre Action Call e.g. PreSave, PreSumit etc.
        /// </summary>
        [DataMember]
        public bool PreAction { set; get; }
        /// <summary>
        /// Set to True in case of Post Action Call e.g. PostSave, PostSumit etc.
        /// </summary>
        [DataMember]
        public bool PostAction { set; get; }
        
        /// <summary>
        /// Set manual action for credit request such as sendback, change request etc.
        /// </summary>
        [DataMember]
        public string CreditReqManualAction { get; set; }

        /// <summary>
        /// Holds blaze call1 (auto) or call2 (manual).
        /// </summary>
        [DataMember]
        public string BlazeCallType { get; set; }

        /// <summary>
        /// Reference Number e.g. Proposal Number, Contract Number etc.
        /// </summary>
        [DataMember]
        public string ReferenceNumber { set; get; }

        /// <summary>
        /// Holds branch id.
        /// </summary>
        [DataMember]
        public int? BranchId { get; set; }
        /// <summary>
        /// Resume Parent WorkFlow Instance
        /// </summary>
        [DataMember]
        public bool ResumeParentWkfInstance { get; set; }

        /// <summary>
        /// Holds screen type such as Screen, Message flow, Process etc.
        /// </summary>
        [DataMember]
        public string ScreenType { get; set; }

        /// <summary>
        /// Holds name of the screen, optional if screenId is specified, mandatory if screenType is other than 'Screen'.
        /// </summary>
        [DataMember]
        public string ScreenName { get; set; }
    }
}

﻿
using System;
using NS.Utilities.Context;

namespace NS.BaseModels
{
    /// <summary>
    /// Class LogData.
    /// </summary>
    [Serializable]
    public sealed class LogData
    {
        /// <summary>
        /// Gets or sets the context to log.
        /// </summary>
        /// <value>The context to log.</value>
        public Context ContextToLog { get; set; }

        /// <summary>
        /// Gets or sets the stacktrace.
        /// </summary>
        /// <value>The stacktrace.</value>
        public string Stacktrace { get; set; }

        /// <summary>
        /// Gets or sets the exception message.
        /// </summary>
        /// <value>The exception message.</value>
        public string ExceptionMessage { get; set; }
    }
}

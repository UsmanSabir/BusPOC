﻿using System.Collections.Concurrent;
using BatchEngine.Core.Exceptions;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.CoreServices.Events;
using BatchEngine.Core.Infrastructure;

namespace BatchEngine.Core.Helper
{
    /// <summary>
    /// DataStore to avoid repeated access data source
    /// </summary>
    public interface ICacheAside
    {
        //MemoryCache.Default;  //20 mins expiry of pool
        IProcessExecutionContext GetProcessExecutionContext(long processId);

        IProcessConfiguration GetProcessConfiguration(int processId);

        object GetProcessData(int processId, string dataKey); // might be from central cache, a dictionary of string,object type to store data

        T GetProcessData<T>(int processId, string dataKey); // might be from central cache

        bool IsHealthy();
    }

    //todo
    class CacheAside:SafeDisposable, ICacheAside
    {
        private readonly IStateManager _stateManager;

        readonly ConcurrentDictionary<int, IProcessConfiguration> _processConfigurations=new ConcurrentDictionary<int, IProcessConfiguration>();
        readonly ConcurrentDictionary<long, ProcessExecutionContext> _processExecutionContexts=new ConcurrentDictionary<long, ProcessExecutionContext>();
        private readonly IProcessDataStorage _storage;
        private readonly IEventAggregator _eventAggregator;
        private readonly ILogger _logger;
        private readonly IBatchLoggerFactory _batchLoggerFactory;
        private readonly IResolver _resolver;
        private TinyMessageSubscriptionToken _subRem;

        public CacheAside(IStateManager stateManager, IProcessDataStorage storage, IEventAggregator eventAggregator,
            ILogger logger, IBatchLoggerFactory batchLoggerFactory, IResolver resolver)
        {
            _stateManager = stateManager;
            _storage = storage;
            _eventAggregator = eventAggregator;
            _logger = logger;
            _batchLoggerFactory = batchLoggerFactory;
            _resolver = resolver;
            _subRem =  eventAggregator.Subscribe<TextMessage>(ProcessRemoved, Constants.EventProcessFinished);

        }

        private void ProcessRemoved(TextMessage msg)
        {
            if (long.TryParse(msg.Parameter, out var processId))
            {
                Robustness.Instance.SafeCall(() =>
                {
                    if(_processExecutionContexts.TryRemove(processId, out ProcessExecutionContext pe))
                    {
                        _processConfigurations.TryRemove(pe.ProcessState.ProcessId, out IProcessConfiguration cnf);

                        pe?.Dispose();
                    }

                    _storage.CleanProcessData(msg.Parameter);

                }, _logger);
            }
        }


        public IProcessExecutionContext GetProcessExecutionContext(long processId)
        {
            var context = _processExecutionContexts.GetOrAdd(processId, id =>
            {
                var process = _stateManager.GetProcessById(processId);
                if (process == null)
                {
                    throw new FrameworkException($"BatchProcess not found for process id {processId}");
                }

                var config = GetProcessConfiguration(process.ProcessId);
                var groupEntity = _stateManager.GetGroupEntity(process.GroupId);
                var executionContext = new ProcessExecutionContext(_batchLoggerFactory.GetProcessLogger(processId, process.ProcessId, process.CorrelationId), process, config, _storage, groupEntity, _resolver);
                return executionContext;
            });

            return context;
        }

        public IProcessConfiguration GetProcessConfiguration(int processId)
        {
            var cfg = _processConfigurations.GetOrAdd(processId, key =>
            {
                var config = _stateManager.GetProcessConfiguration(key);
                return config;
            });
            if (cfg== null)
            {
                _processConfigurations.TryRemove(processId, out cfg);
                throw new FrameworkException($"Process configuration not found for process key {processId}");
            }

            return cfg;
        }

        public object GetProcessData(int processId, string dataKey)
        {
            return null; throw new System.NotImplementedException();
        }

        public T GetProcessData<T>(int processId, string dataKey)
        {
            return default; //throw new System.NotImplementedException();
        }

        public bool IsHealthy()
        {
            return _storage.IsHealthy();
        }

        protected override void Dispose(bool disposing)
        {
            if(disposing)
                _eventAggregator.Unsubscribe(_subRem);

            base.Dispose(disposing);
        }
    }
}
﻿namespace BatchEngine.Core.Helper.CB
{
    public enum CircuitBreakerStateEnum
    {
        None = 0,
        Open = 1,
        Closed = 2,
        HalfOpen = 3
    }
}

﻿using System;
using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core.Serializers
{
    
    internal class PrimitiveSerializer : ISerializer
    {
        public PrimitiveSerializer()
        {
            
        }

        public T DeserializeFromString<T>(string data)
        {
            if (string.IsNullOrWhiteSpace(data))
                return default(T);

            return (T)Convert.ChangeType(data, typeof(T));
        }

        public string SerializeToString<T>(T item)
        {
            if (item.Equals(default(T)))
                return string.Empty;

            return item.ToString();
        }
    }

    internal class StringSerializer : ISerializer
    {
        public StringSerializer()
        {

        }

        public T DeserializeFromString<T>(string data)
        {
            return (T)((object)data);
        }

        public string SerializeToString<T>(T item)
        {
            return item?.ToString();
        }
    }

    public class ObjectSerializer : ISerializer
    {
        public string SerializeToString<T>(T item)
        {
            var serializeObject = Newtonsoft.Json.JsonConvert.SerializeObject(item);
            return serializeObject;
            //var serialize = JSON.Serialize<T>(item, Options.IncludeInheritedUtc);
            //return serialize;
        }

        public T DeserializeFromString<T>(string data)
        {
            var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(data);
            return obj;
            //var item = JSON.Deserialize<T>(data);
            //return item;
        }
    }

    //internal class ObjectSerializer : ISerializer
    //{
    //    public ObjectSerializer()
    //    {

    //    }

    //    public T DeserializeFromString<T>(string data)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public string SerializeToString<T>(T item)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}

}

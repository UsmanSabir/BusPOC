﻿using System;
using System.Threading;
using System.Threading.Tasks;
using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core.ProcessLocks
{
    public interface IDistributedMutexFactory
    {
        DistributedMutex CreateDistributedMutex(string key, Func<CancellationToken, Task> taskToRunWhenLockAcquired,
            Action secondaryAction, IFrameworkLogger logger);
    }
}
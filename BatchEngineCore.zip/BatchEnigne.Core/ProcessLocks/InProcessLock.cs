﻿using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core.ProcessLocks
{
    public class InProcessLock:ILock
    {
        public void Dispose()
        {
        }
    }
}
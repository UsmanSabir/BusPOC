﻿using System;
using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core
{
    public interface ITaskState: ICompletableState
    {
        long Id { get; }

        long ProcessId { get; }

        string Payload { get; }

        DateTime? UpdatedOn { get; }

        ResultStatus Status { get; }

        string CurrentState { get; }

        int FailedCount { get; }

        int DeferredCount { get; }

        string NodeKey { get; }

        DateTime? StartedOn { get; }

        DateTime? CompletedOn { get; }
    }
}
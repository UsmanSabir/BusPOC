﻿namespace BatchEngine.Core.StatePersistence
{
    public class KeyConstants
    {
        public const string TaskPreviousState = "PreviousState";
        public const string TaskNextState = "NextState";

        public const string TaskStatePrefix = "s_";

    }
}
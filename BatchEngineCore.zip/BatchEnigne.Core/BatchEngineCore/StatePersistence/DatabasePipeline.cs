﻿using System.Threading;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.CoreServices.Events;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.PipelineFilters;

namespace BatchEngine.Core.StatePersistence
{
    internal class DatabasePipeline: Pipeline<Infrastructure.DbAction>
    {
        private readonly IEventAggregator _eventAggregator;
        private readonly DbCircuitBreakerFeatureHandler _handler;
        private readonly TinyMessageSubscriptionToken _healthSub;

        public DatabasePipeline(ILogger logger, CancellationToken token, int? maxDbCalls, IEventAggregator eventAggregator) : base(new DbActionCommandHandler())
        {
            _eventAggregator = eventAggregator;

            _healthSub = _eventAggregator.Subscribe4Broadcast<HealthMessage>(PublishHealth);
            

            if (maxDbCalls.HasValue && maxDbCalls.Value>0)
            {
                RegisterFeatureDecorator(new TimeBasedThrottlingFilter<DbAction>(maxDbCalls.Value, token, logger));
            }
            this._handler = new DbCircuitBreakerFeatureHandler(nameof(DatabasePipeline), logger, token, 9, 500);
            RegisterFeatureDecorator(_handler);
            //RegisterFeatureDecorator(new RetryFeatureHandler<DbAction>(9, 500, logger, token));
        }

        private void PublishHealth(HealthMessage healthMessage)
        {
            HealthBlock block = new HealthBlock()
            {
                Name = "DatabaseHealth"
            };

//#if DEBUG
//            block.AddMatrix("Active", false);
//#else
            block.AddMatrix("Active", _handler.IsClosed);
//#endif

            healthMessage.Add(block);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _healthSub != null) _eventAggregator.Unsubscribe(_healthSub);
            base.Dispose(disposing);
        }
    }
}
﻿using System.Threading;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.CoreServices.Events;
using BatchEngine.Core.Helper;
using BatchEngine.Core.PipelineFilters;
using BatchEngine.Core.Process;

namespace BatchEngine.Core.StatePersistence
{
    internal class ProcessVolumePipeline:Pipeline<ProcessExecutionContext>
    {
        public ProcessVolumePipeline(CancellationToken token, IFrameworkLogger logger, IStateManager stateManager,
            ICacheAside cacheAside, IProcessRepository processRepository, IVolumeHandler volumeHandler,
            IResolver resolver, IEventAggregator eventAggregator, IBatchEngineSubscribers batchEngineSubscribers,
            IContextSwitchHandler contextSwitchHandler)
            :base(new ProcessVolumeRequestHandler(logger, stateManager, cacheAside, processRepository, volumeHandler,
                token, resolver, eventAggregator, batchEngineSubscribers, contextSwitchHandler))
        {
            
            //RegisterFeatureDecorator(new ConsumerFilter<ProcessExecutionContext>(token, logger, "VolumeGeneratorConsumer"));
            RegisterFeatureDecorator(new PriorityConsumerFilter<ProcessExecutionContext>(token, logger, "VolumeGeneratorConsumer", r=> r.ProcessState.HasPriority, resolver.Resolve<IContextSwitchHandler>()));
        }

        //public ProcessVolumePipeline(IHandler<IProcessExecutionContext> handler):base(handler)
        //{

        //}
    }
}

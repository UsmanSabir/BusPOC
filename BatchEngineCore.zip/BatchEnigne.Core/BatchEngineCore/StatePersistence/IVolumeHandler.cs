﻿using System.Collections.Generic;
using System.Threading;
using BatchEngine.Core;

namespace BatchEngine.Core.StatePersistence
{
    public interface IVolumeHandler
    {
        //persist volume
        void Handle<T>(IEnumerable<T> volume, IProcessExecutionContextWithVolume processContext, CancellationToken token);

        IReadWritableTaskState GetNextTaskWithTransaction(out ITransaction transaction);

        IReadWritableTaskState GetPriorityNextTaskWithTransaction(out ITransaction transaction);
    }
}

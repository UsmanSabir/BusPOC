﻿namespace BatchEngine.Core.StatePersistence.Adapters
{
    public interface IVolumeAdapter<out T, in TU>
    {
        T Get(TU value);
    }
}
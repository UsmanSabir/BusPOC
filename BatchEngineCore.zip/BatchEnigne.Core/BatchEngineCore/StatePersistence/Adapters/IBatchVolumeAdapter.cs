﻿namespace BatchEngine.Core.StatePersistence.Adapters
{
    public interface IBatchVolumeAdapter<T>:IVolumeAdapter<T,T[]>
    {
        
    }
}
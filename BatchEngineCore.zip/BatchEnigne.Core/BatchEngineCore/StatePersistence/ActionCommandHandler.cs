﻿using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core.StatePersistence
{
    internal class ActionCommandHandler: IHandler<Infrastructure.ActionCommand>
    {
        public void Handle(Infrastructure.ActionCommand message)
        {
            message.Action?.Invoke();
        }

        //public TResult Query<TResult>(Infrastructure.ActionCommand message)
        //{
        //    throw new System.NotImplementedException();
        //}

        public void Dispose()
        {
            
        }
    }
}
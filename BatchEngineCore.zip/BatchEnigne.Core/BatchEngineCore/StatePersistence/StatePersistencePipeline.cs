﻿using System.Threading;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.PipelineFilters;

namespace BatchEngine.Core.StatePersistence
{
    internal class StatePersistencePipeline: ReliablePipeline<Infrastructure.ActionCommand>
    {
        public StatePersistencePipeline(ILogger logger, CancellationToken token,
            IContextSwitchHandler contextSwitchHandler) : base(new ActionCommandHandler(), "StatePersistencePipeline", logger, 9, 500, token)
        {
            RegisterFeatureDecorator(new RetryAlertFeatureHandler<ActionCommand>(50000, 5000, logger, token, contextSwitchHandler));
        }
    }
}
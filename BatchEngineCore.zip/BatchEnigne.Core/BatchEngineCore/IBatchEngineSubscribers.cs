﻿using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Subscribers;

namespace BatchEngine.Core
{
    public interface IBatchEngineSubscribers
    {
        IEnumerable<IGroupSubscriber> GetGroupSubscribers();
        IEnumerable<IProcessSubscriber> GetProcessSubscribers();
    }

    public class BatchEngineSubscribers: IBatchEngineSubscribers
    {
        private readonly IReadOnlyList<IGroupSubscriber> _groupSubscribers; 
        private readonly IReadOnlyList<IProcessSubscriber> _processSubscribers; 

        public BatchEngineSubscribers(IResolver resolver)
        {
            _groupSubscribers = resolver.Resolve<IEnumerable<IGroupSubscriber>>().ToList();
            _processSubscribers = resolver.Resolve<IEnumerable<IProcessSubscriber>>().ToList();
        }

        public IEnumerable<IGroupSubscriber> GetGroupSubscribers()
        {
            return _groupSubscribers.Where(r=>r.IsActive).OrderBy(r=>r.Sequence);//.AsReadOnly();
        }

        public IEnumerable<IProcessSubscriber> GetProcessSubscribers()
        {
            return _processSubscribers.Where(r => r.IsActive).OrderBy(r=>r.Sequence);
        }
    }



}
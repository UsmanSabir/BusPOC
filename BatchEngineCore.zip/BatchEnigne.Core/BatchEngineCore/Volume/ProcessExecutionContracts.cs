﻿using System;
using System.Collections.Generic;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Messages;

namespace BatchEngine.Core
{
    public interface IProcessExecutionContext: IDashboardContextMessage
    {
        //todo: id, processId, correlationId, nodeId, 

        IProcessState ProcessState { get; }

        IProcessConfiguration Configuration { get; }
        DateTime ProcessingDate { get; }
        JobCriteria Criteria { get; }
        bool AddUpdateProcessData<T>(string key, T value);

        T GetProcessData<T>(string key);

        object GetProcessData(string key);


        bool SetTempData(string key, object value);
        T GetTempData<T>(string key);

        T GetSetTempData<T>(string key, Func<T> valueFactory);

        object GetTempData(string key);

        T GetSetResource<T>(string key, Func<T> valueFactory) where T : IDisposable;

        IGroupEntity Group { get; }

        int InvokeType { get; }

        //
        //IFrameworkLogger FrameworkLogger { get; }
    }
}

namespace BatchEngine.Core
{
    public interface IExecutionContextMessage:IMessage
    {
        //Guid CorrelationId { get; }
        ILogger Logger { get; }
    }

    public interface IDashboardContextMessage:IExecutionContextMessage
    {
        IDashboardService DashboardService { get; }
    }

    public interface IProcessFinalizedContext:IExecutionContextMessage
    {
        IProcessExecutionContext ExecutionContext { get; }
        bool HasExecuted { get; }
        void Resubmit(List<JobCriteria> criteria, int invokeType, string reason);
    }

    public interface IProcessExecutionContextWithVolume : IProcessExecutionContext
    {
        void SetVolumeGenerated();
    }

}
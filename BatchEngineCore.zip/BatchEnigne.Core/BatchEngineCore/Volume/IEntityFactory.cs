﻿using BatchEngine.Core.Groups;

namespace BatchEngine.Core
{
    public interface IEntityFactory
    {
        //T Create<T>(Action<T> initilizer=null);


        IReadWritableGroupEntity CreateGroupEntity();


        IReadWritableProcessState CreateProcessEntity();

    }
}
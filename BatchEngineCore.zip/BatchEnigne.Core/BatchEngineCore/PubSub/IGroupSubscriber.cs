﻿using BatchEngine.Core.Groups;

namespace BatchEngine.Core.Subscribers
{
    public interface IGroupSubscriber
    {
        int Sequence { get; }
        int GroupKey { get; }
        bool IsActive { get; }

        void OnGroupStarting(IGroupStartContext context);

        void OnGroupSubmitted(IGroupStartContext context);

        void OnGroupComplete(IGroupCompleteContext context);

        //void OnGroupStop(IGroupStoppedContext context);

        //void OnGroupResume(IGroupResumeContext context);
    }
}
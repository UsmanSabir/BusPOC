﻿using System;
using System.Xml.Serialization;
using BatchEngine.Core.Groups;
using BatchEngine.Core.CoreServices.Events;
using BatchEngine.Core.Messages;

namespace BatchEngine.Core
{
    public interface IBroadcastMessage:IMessage, ITinyMessage
    {
        
    }


    internal interface IProcessGroupRemovedMessage : IBroadcastMessage
    {
        SubmittedGroup Group { get; }
    }

    internal interface IWatchDogSyncComplete : IBroadcastMessage
    {
        bool HasError { get; }
        DateTime StartedOn { get; }
        DateTime CompletedOn { get; }
    }


    public interface IWatchDogMessage : IBroadcastMessage
    {

    }

    public interface IProcessInputIdleWatchDogMessage : IWatchDogMessage
    {
        long GroupId { get; }
        long ProcessId { get; }

        int ProcessKey { get; }
    }

    public interface IResumeGroupWatchDogMessage : IWatchDogMessage
    {
        long GroupId { get; }
    }

    public interface IProcessVolumeGeneratedWatchDogMessage : IWatchDogMessage
    {
        string ProcessId { get; }
    }

    public interface IProcessRemovedWatchDogMessage : IWatchDogMessage
    {
        long GroupId { get; }
        long ProcessId { get; }
    }

    class ProcessGroupRemovedMessage: IProcessGroupRemovedMessage
    {
        public ProcessGroupRemovedMessage(SubmittedGroup @group, object sender)
        {
            Group = @group;
            Sender = sender;
        }

        public SubmittedGroup Group { get; }

        [XmlIgnore]
        public object Sender { get; }
    }

    internal class ProcessInputIdleWatchDogMessage : IProcessInputIdleWatchDogMessage
    {
        public ProcessInputIdleWatchDogMessage()
        {
            
        }

        public ProcessInputIdleWatchDogMessage(long groupId, long processId, int processKey, object sender)
        {
            GroupId = groupId;
            ProcessId = processId;
            ProcessKey = processKey;
            Sender = sender;
        }

        public long GroupId { get; set; }
        public long ProcessId { get; set; }
        public int ProcessKey { get; set; }

        [XmlIgnore]
        public object Sender { get; set; }
    }

    class ProcessRemovedWatchDogMessage: IProcessRemovedWatchDogMessage
    {
        //public object Sender { get; }
        public long GroupId { get; set; }
        public long ProcessId { get; set; }

        [XmlIgnore]
        public object Sender { get; }
    }

    internal class TriggerProducerWatchDogMessage : IProcessVolumeGeneratedWatchDogMessage
    {
        [XmlIgnore]
        public object Sender { get; }

        public string ProcessId { get; set; }
    }

    internal class ProcessGroupAddedMessage : IBroadcastMessage
    {
        public long GroupId { get; set; }
        [XmlIgnore]
        public object Sender { get; }
    }

    public class ResumeGroupWatchDogMessage : IResumeGroupWatchDogMessage
    {
        
        [XmlIgnore]
        public object Sender { get; set; }

        public long GroupId { get; set; }
    }

    internal class WatchDogSyncComplete: IWatchDogSyncComplete
    {
        public WatchDogSyncComplete(object sender, DateTime startedOn, DateTime completedOn, bool hasError)
        {
            Sender = sender;
            StartedOn = startedOn;
            CompletedOn = completedOn;
            HasError = hasError;
        }

        [XmlIgnore]
        public object Sender { get; }

        public bool HasError { get; }
        public DateTime StartedOn { get; }
        public DateTime CompletedOn { get; }
    }
}
﻿using System.Collections.Generic;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Helper;

namespace BatchEngine.Core.Subscribers
{
    public abstract class GroupSubscriberBase:SafeDisposable, IGroupSubscriber
    {
        public int Sequence { get; protected set; } = 1000;
        public abstract int GroupKey { get; }
        public bool IsActive { get; set; } = true;

        public virtual void OnGroupStarting(IGroupStartContext context)
        {
            
        }

        public virtual void OnGroupSubmitted(IGroupStartContext context)
        {
            
        }

        public virtual void OnGroupComplete(IGroupCompleteContext context)
        {
            
        }
        
    }
}
﻿namespace BatchEngine.Core
{
    internal interface ITaskUnit<in T> : ITask<T, ITaskContext>
    {
        
    }

}

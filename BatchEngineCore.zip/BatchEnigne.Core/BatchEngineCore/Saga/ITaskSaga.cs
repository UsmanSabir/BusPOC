﻿using BatchEngine.Core.Handlers;

namespace BatchEngine.Core.Saga
{
    internal interface ITaskSaga<in T> : ITask<T, TaskContext>
    {
        
    }

}

﻿using System;

namespace BatchEngine.Core.Exceptions
{
    //donot retry on framework exception
    public class FrameworkException : ApplicationException
    {        
        public FrameworkException(string errMsg):base(errMsg)
        {
            
        }
        public FrameworkException(string errMsg, Exception innerException) : base(errMsg, innerException)
        {

        }
    }



    public class SagaStateException : FrameworkException
    {
        public SagaStateException(string errMsg):base(errMsg)
        {
            
        }
    }
}

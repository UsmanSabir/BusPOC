﻿using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core.Groups
{
    internal class GroupConsumer : WorkerProcess
    {
        //private readonly List<IGroupSubscriber> _groupSubscribers = new List<IGroupSubscriber>(); //todo

        public GroupConsumer(ILogger logger) : base("GroupConsumer", logger)
        {
        }


        internal override void OnStart()
        {
            //subscripe to groups


        }

        void OnGroupSubscriptionReceived(IGroupEntity group)
        {
            //var groupLogger = BatchLoggerFactory.GetGroupLogger(group.Id);
            //IGroupStartContext context=new GroupStartContext(group, groupLogger);

            //foreach (var groupSubscriber in _groupSubscribers)
            //{
            //    Robustness.Instance.SafeCall(() => { groupSubscriber.OnGroupStarting(context); });
            //}
        }

        internal override void OnStop()
        {
            //unsbscribe from groups
        }
    }
}
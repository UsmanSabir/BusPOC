﻿using BatchEngine.Core.CoreServices;

namespace BatchEngine.Core.Groups
{
    public interface IGroupEntity: ICompletableState
    {
        long Id { get; }
        int GroupKey { get; }
        bool IsManual { get; }
        bool IsResubmission { get; }
        string SubmittedBy { get; }
        string Criteria { get; }
        string State { get; }
        bool IsGenerated { get; }
        string Payload { get; }
        string NodeId { get; }
        string QueueName { get; }
        int? QueueSeq { get; }
        bool HasPriority { get; }
    }


    public interface IWritableGroupEntity : IWritableCompletableState
    {
        long Id { set; }
        int GroupKey { set; }
        bool IsManual { set; }
        bool IsResubmission { set; }
        string SubmittedBy { set; }
        string Criteria { set; }
        string State { set; }
        string NodeId { set; }
        bool IsGenerated { set; }
        string Payload { set; }

        string QueueName { set; }
        int? QueueSeq { set; }
        bool HasPriority { set; }
    }

    public interface IReadWritableGroupEntity : IGroupEntity, IWritableGroupEntity
    {
        new long Id { get; set; }
        new int GroupKey { get; set; }
        new bool IsManual { get; set; }
        new bool IsResubmission { get; set; }
        new string SubmittedBy { get; set; }
        new string Criteria { get; set; }
        new string State { get; set; }
        new bool IsFinished { get; set; }
        new bool IsStopped { get; set; }

        new bool IsGenerated { get; set; }
        new string Payload { get; set; }

        new string QueueName { get; set; }
        new int? QueueSeq { get; set; }
        new bool HasPriority { get; set; }

        new string NodeId { get; set; }
    }

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.JobScheduler;
using BatchEngine.Core.Serializers;
using BatchEngine.Core.Subscribers;

namespace BatchEngine.Core.Groups
{
    public interface IGroupStartContext
    {
        long Id { get; }
        int GroupKey { get; }
        int InvokeTypeId { get; }
        void StopGroup(string reason);
        string SubmittedBy { get; }
        ILogger Logger { get; }
    }

    public interface IGroupCompleteContext
    {
        long Id { get; }
        int GroupKey { get; }
        //bool IsResubmission { get; }

        bool IsResubmitted { get; }

        List<JobCriteria> Criteria { get; }

        void Resubmit(List<JobCriteria> criteria, int invokeTypeId, string reason);

        ILogger Logger { get; }
    }

    public interface IGroupStoppedContext
    {
        int Id { get; }
        int GroupKey { get; }
        string StopReason { get; }

        ILogger Logger { get; }
    }

    public interface IGroupResumeContext
    {
        int Id { get; }
        int GroupKey { get; }
        string SubmittedBy { get; }

        ILogger Logger { get; }
    }


    public class GroupStartContext : IGroupStartContext
    {
        private readonly IReadWritableGroupEntity _groupEntity;
        private readonly Bus _bus;
        public List<JobCriteria> MessageCriteria { get; }

        public GroupStartContext(IReadWritableGroupEntity @group, ILogger logger, List<JobCriteria> messageCriteria, Bus bus)
        {
            _groupEntity = @group;
            _bus = bus;
            MessageCriteria = messageCriteria;
            Logger = logger;

            Id = group.Id;
            GroupKey = group.GroupKey;
            InvokeTypeId = group.InvokeTypeId;
            SubmittedBy = group.SubmittedBy;
        }



        public long Id { get; }
        public int GroupKey { get; }

        public int InvokeTypeId { get; }

        public string SubmittedBy { get; }
        public ILogger Logger { get; }

        internal IGroupSubscriber CurrentSubscriber { get; set; }

        internal bool StopFlag { get; private set; }
        void IGroupStartContext.StopGroup(string reason)
        {
            StopFlag = true;

            if (CurrentSubscriber != null)
            {
                Logger.Info($"{CurrentSubscriber.GetType()} requested group stop");
            }

            var stopGroupMessage = new GroupMessage(GroupActions.Stop, _groupEntity, null, reason);
            _bus.HandleWatchDogMessage(stopGroupMessage);
        }

    }


    public interface IProcessEntity : ICompletableState
    {
        int Id { get; }
        int ProcessKey { get; }
        int GroupId { get; }


        bool IsManual { get; }
        bool IsResubmission { get; }
        string SubmittedBy { get; }


    }

    class SubmittedGroup
    {
        object _syncLock = new object();

        public SubmittedGroup(IReadWritableGroupEntity groupEntity, List<IReadWritableProcessState> processEntities)
        {
            GroupEntity = groupEntity;
            ProcessEntities = processEntities;
        }

        public IReadWritableGroupEntity GroupEntity { get; private set; }

        public List<IReadWritableProcessState> ProcessEntities { get; private set; }

        public IEnumerable<IReadWritableProcessState> GetNextProcesses(long? parentProcessId)
        {
            List<IReadWritableProcessState> groupProcesses;

            lock (_syncLock)
            {
                groupProcesses = ProcessEntities;

                
                int parentPrcsSeqId;

                if (parentProcessId != null)
                {
                    parentPrcsSeqId = groupProcesses.First(p => p.Id == parentProcessId.Value).GroupSeqId;
                }
                else
                {
                    parentPrcsSeqId = groupProcesses.Min(a => a.GroupSeqId);
                }

                var res = GetNextProcessesLocal(parentProcessId, parentPrcsSeqId);
                if (res.Any())
                {
                    return res;
                }
                
                var seqProcesses = groupProcesses.Where(p => p.GroupSeqId == parentPrcsSeqId).ToList();
                if (seqProcesses.All(p => p.IsFinished || p.IsStopped))
                {
                    //start next group seq
                    var groupSeqs = groupProcesses.Select(p => p.GroupSeqId).Distinct().OrderBy(seq => seq).ToList();

                    foreach (var groupSeq in groupSeqs.Where(s => s > parentPrcsSeqId))
                    {
                        res = GetNextProcessesLocal(null, groupSeq);
                        if (res.Any())
                            return res;
                    }
                }


                //no more processes, check for dependent processes by returning empty
                return Enumerable.Empty<IReadWritableProcessState>();



            }

            List<IReadWritableProcessState> GetNextProcessesLocal(long? parentId, int seqId)
            {
                //foreach (var groupSeq in groupSeqs)
                {
                    //var seqProcesses = groupProcesses.Where(p => p.GroupSeqId == seqId).ToList();

                    var nextProcess = groupProcesses.Where(p => p.GroupSeqId == seqId && p.ParentId == parentId && string.IsNullOrWhiteSpace(p.DependentIds)).ToList();

                    //if (nextProcess.Any())
                    return nextProcess;

                    ////no child process, check if groupSeq completed
                    //if (seqProcesses.All(p => p.GroupSeqId == groupSeq && (p.IsFinished || p.IsStopped)))
                    //{
                    //    //groupSeq completes, go for next seq
                    //}
                    //else
                    //{
                    //    //group seq has incomplete processes, either dependance or some other parallel branch. let them complete first and return empty list
                    //    return nextProcess;
                    //}
                }
            }
        }



        public IEnumerable<IReadWritableProcessState> GetCompletedParentHierarchy(long processId, bool includeSiblings)
        {
            List<IReadWritableProcessState> groupProcesses = ProcessEntities;

            var children = groupProcesses.Where(c => c.ParentId == processId);
            if (children.Any()) // children.Any(c => c.IsFinished == false))
            {
                //todo: do we need to check children as well
                return Enumerable.Empty<IReadWritableProcessState>(); //process has children , always start from leaf node
            }

            return GetCompletedParentHierarchyInternal(processId, includeSiblings);
        }

        IEnumerable<IReadWritableProcessState> GetCompletedParentHierarchyInternal(long processId, bool includeSiblings)
        {
            lock (_syncLock)
            {
                List<IReadWritableProcessState> groupProcesses = ProcessEntities;
                var process = groupProcesses.First(p => p.Id == processId);
                if (!process.IsFinished)
                {
                    yield break; //process itself not completed
                }

                yield return process;

                if (process.ParentId == null)
                {
                    yield break; //root process and completed
                }

                var parentId = process.ParentId.Value;
                //var parentProcess = groupProcesses.First(p => p.ParentId == parentId); //get parent of current node
                var siblingProcesses = groupProcesses.Where(p => p.ParentId == parentId && p.Id != processId).ToList(); //get siblings except itself
                var isNodeComplete = siblingProcesses.All(p => p.IsFinished); //check all siblings
                if (isNodeComplete)
                {
                    if (includeSiblings)
                    {
                        foreach (var siblingProcess in siblingProcesses) yield return siblingProcess;
                    }

                    foreach (var state in GetCompletedParentHierarchyInternal(parentId, includeSiblings)) yield return state;
                }


            }
        }

        public void UpdateProcessInstance(IReadWritableProcessState processState)
        {
            lock (_syncLock)
            {
                ProcessEntities.Remove(ProcessEntities.First(p => p.Id == processState.Id));
                ProcessEntities.Add(processState);
            }
        }

        public void Refresh(IStateManager stateManager)
        {
            lock (_syncLock)
            {
                GroupEntity = stateManager.GetGroupEntity(GroupEntity.Id);
                ProcessEntities = stateManager.GetSubmittedGroupProcesses(GroupEntity.Id).ToList();
            }
        }

        public bool CheckIfTreeNodeWithChildCompleted(IProcessState process)
        {
            lock (_syncLock)
            {
                bool res = process.IsFinished && ProcessEntities.Where(p => p.ParentId == process.Id)
                               .All(CheckIfTreeNodeWithChildCompleted);
                return res;
            }
        }

        public IEnumerable<IProcessState> GetTreeNodeWithChildren(IProcessState process)
        {
            lock (_syncLock)
            {
                yield return process;

                foreach (var state in ProcessEntities.Where(p => p.ParentId == process.Id))
                {
                    foreach (var child in GetTreeNodeWithChildren(state))
                    {
                        yield return child;
                    }
                }
            }
        }
    }

    class GroupCompleteContext : IGroupCompleteContext
    {
        private readonly IJobScheduler _scheduler;
        private readonly IGroupEntity _groupEntity;

        public GroupCompleteContext(long id, int groupKey, ILogger logger, IJobScheduler scheduler, IGroupEntity groupEntity)
        {
            var serializer = SerializersFactory.Instance.DefaultSerializer;
            _scheduler = scheduler;
            _groupEntity = groupEntity;
            Criteria = serializer.DeserializeFromString<List<JobCriteria>>(groupEntity.Criteria);
            Id = id;
            GroupKey = groupKey;
            //IsResubmission = isResubmission;
            InvokeTypeId = groupEntity.InvokeTypeId;
            Logger = logger;
        }

        public long Id { get; }
        public int GroupKey { get; }
        //public bool IsResubmission { get; }

        public int InvokeTypeId { get; }
        public List<JobCriteria> Criteria { get; }

        public void Resubmit(List<JobCriteria> criteria, int invokeTypeId, string reason)
        {
            var payload = _groupEntity.Payload;
            if (string.IsNullOrWhiteSpace(payload))
            {
                //group submission
                _scheduler.CreateJob(_groupEntity.GroupKey, criteria, "BPEM", invokeTypeId, _groupEntity.HasPriority);
            }
            else
            {
                var serializer = SerializersFactory.Instance.DefaultSerializer;
                var processKeys = serializer.DeserializeFromString<List<int>>(payload);
                _scheduler.CreateJob(_groupEntity.GroupKey, processKeys, criteria, "BPEM", invokeTypeId, _groupEntity.HasPriority);
            }

            IsResubmitted = true;

            //throw new System.NotImplementedException();
        }

        public bool IsResubmitted { get; set; }


        public ILogger Logger { get; }
    }
}
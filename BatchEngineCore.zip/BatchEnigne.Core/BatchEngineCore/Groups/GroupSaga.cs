﻿using BatchEngine.Core;

namespace BatchEngine.Core.Groups
{
    internal class GroupSaga
    {

        public void RegisterProcess(IBaseProcess process)
        {

        }

        public void RegisterProcessByKey(string key)
        {

        }

    }
}
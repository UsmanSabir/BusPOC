﻿namespace BatchEngine.Core
{
    public interface IContextSwitchHandler
    {
        void ContextSwitchStarting();
        void ContextSwitchCompleted();
    }
}
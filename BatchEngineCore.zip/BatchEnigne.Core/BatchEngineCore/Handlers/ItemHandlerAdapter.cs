﻿namespace BatchEngine.Core.Handlers
{
    internal class ItemHandlerAdapter
    {
        
    }
}

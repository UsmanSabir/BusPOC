﻿using BatchEngine.Core.CoreServices;
using BatchEngine.Core.PipelineFilters;

namespace BatchEngine.Core.Handlers
{
    internal class TaskProcessingPipeline:Pipeline<TaskMessage>
    {
        private readonly int _nodeThrottling = NodeSettings.Instance.Throttling; //todo

        public TaskProcessingPipeline(ILogger logger, ITaskExecutorsPool taskRepository) : base(new TaskHandler(taskRepository))
        {
            var throttlingFilter = new TasksThrottlingFilter(_nodeThrottling, logger);
            RegisterFeatureDecorator(throttlingFilter);
            if (_nodeThrottling <= 0)
            {
                throttlingFilter.Disable();
            }

        }
    }
}
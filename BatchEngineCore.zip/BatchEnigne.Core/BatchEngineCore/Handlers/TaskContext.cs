﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Serializers;
using BatchEngine.Core.StatePersistence;

namespace BatchEngine.Core.Handlers
{
    class TaskContext : SafeDisposable, ITaskContext
    {
        private readonly bool _isStateful;

        private ConcurrentDictionary<string, string> _stateDictionary=null;
        private readonly ConcurrentDictionary<string, object> _taskData;
        private readonly IStateManager _stateManager;
        private bool? _isLastAttempt;

        public TaskContext(bool isStateful, SafeDisposableActions onCompleteActions, IReadWritableTaskState state, IStateManager stateManager)
        {
            _isStateful = isStateful;
            OnCompleteActions = onCompleteActions;
            TaskStateWritable = state;
            _stateManager = stateManager;
            _taskData=new ConcurrentDictionary<string, object>();
        }

        public ILogger Logger { get; internal set; }
        public IDashboardService DashboardService { get; internal set; }

        protected override void Dispose(bool disposing)
        {
            try
            {
                OnCompleteActions?.Dispose();
                OnCompleteActions = null;

                _stateDictionary?.Clear();
                _taskData?.Clear();

                base.Dispose(disposing);
                
            }
            finally
            {
                Robustness.Instance.SafeCall(() => Transaction?.Rollback());
            }
        }

        internal IReadWritableTaskState TaskStateWritable { get; }

        public ITaskState State => TaskStateWritable;

        public string PrevState { get; internal set; }
        public string NextState { get; internal set; }
        public IProcessExecutionContext ProcessExecutionContext { get; internal set; }
        public ITransaction Transaction { get; internal set; }
        public CancellationToken CancellationToken { get; internal set; }
        public ResultStatus Result { get; set; }

        public bool IsDeferred { get; private set; } = false;

        public bool Defer()
        {
            IsDeferred = this.ReleaseTaskWithDeferFlag(_stateManager);
            return IsDeferred;
        }

        public int DeferredCount => State.DeferredCount;
        public bool IsRetry => State.FailedCount > 0;

        
        public bool IsLastAttempt
        {
            get
            {
                if (!_isLastAttempt.HasValue)
                    _isLastAttempt = GetIsLastAttemptValue();

                return _isLastAttempt.Value;
            }
        }

        bool GetIsLastAttemptValue()
        {
            var failedCount = State.FailedCount;
            int maxTries = 0;

            if (ProcessExecutionContext.Configuration.ProcessRetries.HasValue &&
                ProcessExecutionContext.Configuration.ProcessRetries.Value > 0)
            {
                if (ProcessExecutionContext.Configuration.TaskRetries.HasValue &&
                    ProcessExecutionContext.Configuration.TaskRetries.Value > 0)
                {
                    maxTries = ((ProcessExecutionContext.Configuration.TaskRetries.Value + 1) *
                                (ProcessExecutionContext.Configuration.ProcessRetries.Value + 1)) - 1;
                }
                else
                {
                    maxTries = ProcessExecutionContext.Configuration.ProcessRetries.Value;
                }
            }
            else
            {
                if (ProcessExecutionContext.Configuration.TaskRetries.HasValue &&
                    ProcessExecutionContext.Configuration.TaskRetries.Value > 0)
                {
                    maxTries = ProcessExecutionContext.Configuration.TaskRetries.Value;
                }
            }

            return maxTries <= failedCount; //ideally it should be equal for last attempt
        }

        internal SafeDisposableActions OnCompleteActions { get; private set; }


        internal void SetStates(ConcurrentDictionary<string, string> statesDictionary)
        {
            if(statesDictionary==null) 
                return;

            if (_stateDictionary == null)
            {
                _stateDictionary = statesDictionary;
            }
            else
            {
                foreach (var keyValuePair in statesDictionary)
                {
                    _stateDictionary.AddOrUpdate(keyValuePair.Key, keyValuePair.Value, (k, v) => keyValuePair.Value);
                }
            }


        }

        public void PreserveStateValue<T>(string key, T value) 
        {
            if (!_isStateful)
            {
#if DEBUG
                if (Debugger.IsAttached)
                {
                    throw new InvalidOperationException("Stateless process can't have state data");
                }
#endif
            }

            var serializer = SerializersFactory.Instance.GetSerializer<T>();
            var strVal = serializer.SerializeToString(value);
            var keyModified = $"{KeyConstants.TaskStatePrefix}{key}";


            if (_stateDictionary == null)
                _stateDictionary=new ConcurrentDictionary<string, string>();

            _stateDictionary.AddOrUpdate(keyModified, strVal, (ky, old) => strVal);

            List<KeyValuePair<string, string>> statList = new List<KeyValuePair<string, string>>();
            statList.Add(new KeyValuePair<string, string>(keyModified, strVal));
            _stateManager.SaveTaskStates(State.Id, State.ProcessId, statList);
        }

        public T GetLastStateValue<T>(string key)
        {
            if (!_isStateful)
            {
#if DEBUG
                if (Debugger.IsAttached)
                {
                    throw new InvalidOperationException("Stateless process can't have state data");
                }
#endif
            }

            var serializer = SerializersFactory.Instance.GetSerializer<T>();
            var keyModified = $"{KeyConstants.TaskStatePrefix}{key}";


            if (_stateDictionary != null && _stateDictionary.TryGetValue(keyModified, out string strVal))
            {
                if (!string.IsNullOrWhiteSpace(strVal))
                {
                    return serializer.DeserializeFromString<T>(strVal);
                }
            }

            return default;
        }

        public bool SetNextState(string next)
        {
            if (!_isStateful)
            {
#if DEBUG
                if (Debugger.IsAttached)
                {
                    throw new InvalidOperationException("Stateless process can't have state data");
                } 
#endif
            }
            PrevState = NextState;
            NextState = next;
            return true;
        }

        public void SetResult(ResultStatus result)
        {
            Result = result;
        }

        public void SetTaskTempData<T>(string key, T data)
        {
            _taskData.AddOrUpdate(key, data, (s, o) => data);
        }

        public T GetTaskTempData<T>(string key)
        {
            if (_taskData.TryGetValue(key, out object res))
            {
                var val = (T) res;
                return val;
            }
            return default;
        }

        public T GetOrAddTaskTempData<T>(string key, Func<T> valueFactory)
        {
            var res = _taskData.GetOrAdd(key, s => valueFactory());
            return (T) res;
        }

        public void IncrementFailedCount()
        {
            TaskStateWritable.FailedCount++;
            _isLastAttempt = null;
        }
    }
}

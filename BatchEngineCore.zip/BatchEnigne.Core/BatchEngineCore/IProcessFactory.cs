﻿namespace BatchEngine.Core
{
    //internal interface IProcessFactory
    //{
    //    IBaseProcess GetProcess(string processKey);

    //    ProcessConfiguration GetProcessConfiguration(int processKey);
    //}
}

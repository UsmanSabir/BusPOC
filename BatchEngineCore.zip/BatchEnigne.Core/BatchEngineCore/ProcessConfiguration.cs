﻿namespace BatchEngine.Core
{
    public interface IProcessConfiguration
    {
        int ProcessId { get; } //screenId

        int ProcessKey { get;  }

        int BatchSize { get; }

        int? ProcessTimeoutMins { get;  }

        int? TaskTimeout { get;  }

        int? ProcessRetries { get; }
        

        int? TaskRetries { get;  }

        int? RetryDelayMilli { get; }

        int MaxVolumeRetries { get; }
        int? QueueSize { get;  }

        int? ErrorThreshold { get; }

        bool IsActive { get; }

        string DaysYearTypeKey { get; }

        bool RollOverInd { get; }
        bool IsMonthEnd { get; }

        int CriteriaMatchDetId { get; } // Criteria MatchDetId 
    }
}

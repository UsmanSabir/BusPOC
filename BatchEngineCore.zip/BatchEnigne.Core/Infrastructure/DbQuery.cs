﻿using BatchEngine.Core.Messages;

namespace BatchEngine.Core.Infrastructure
{
    public class DbQuery: IQuery
    {
    }
}

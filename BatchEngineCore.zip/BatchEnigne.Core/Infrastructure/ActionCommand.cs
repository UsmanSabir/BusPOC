﻿using System;
using BatchEngine.Core.Messages;

namespace BatchEngine.Core.Infrastructure
{
    class ActionCommand : ICommand
    {
        public ActionCommand(Action action)
        {
            Action = action;
        }

        public Action Action { get; private set; }
    }

    public class DbAction:IMessage
    {
        public DbAction(DbActions action, Action command=null)
        {
            Action = action;
            Command = command;
        }

        public DbActions Action { get; private set; }

        public Action Command { get; private set; }
    }

    public enum DbActions
    {
        Opening,
        Opened,
        Error,
        Executing,
        Executed,
        Closed,
        Persist,
        Transaction
    }
}

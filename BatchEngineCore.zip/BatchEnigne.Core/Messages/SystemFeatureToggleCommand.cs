﻿using System;

namespace BatchEngine.Core.Messages
{
    public class SystemFeatureToggleCommand : ISystemCommand
    {
        public SystemFeatureToggleCommand(string pipeLineKey, Type featureType, bool enable)
        {
            PipeLineKey = pipeLineKey;
            FeatureHandlerType = featureType;
            Enable = enable;
        }

        public string PipeLineKey { get; private set; } // => nameof(ICommand);

        public Type FeatureHandlerType { get; private set; }
        public bool Enable { get; private set; }
    }

    public class SystemCommand : ISystemCommand
    {
        public SystemCommand(string pipeLineKey, Type featureType, bool enable)
        {
            PipeLineKey = pipeLineKey;
            FeatureHandlerType = featureType;
            Enable = enable;
        }

        public string PipeLineKey { get; private set; } // => nameof(ICommand);

        public Type FeatureHandlerType { get; private set; }
        public bool Enable { get; private set; }
    }
}

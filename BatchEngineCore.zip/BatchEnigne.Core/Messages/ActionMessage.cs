﻿namespace BatchEngine.Core.Messages
{
    // public class ActionCommand:ICommand
    //{
    //    public ActionCommand(Action action)
    //    {
    //        Action = action;
    //    }

    //    public Action Action { get; }
    //}
}

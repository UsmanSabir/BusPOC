﻿using System;

namespace BatchEngine.Core.Messages
{
    public interface ICommand: IMessage
    {
        Action Action { get; }
    }
}

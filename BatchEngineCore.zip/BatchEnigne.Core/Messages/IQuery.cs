﻿namespace BatchEngine.Core.Messages
{
    public interface IQuery : IMessage
    {

    }

    public interface IQuery<T> : IQuery
    {

    }

}

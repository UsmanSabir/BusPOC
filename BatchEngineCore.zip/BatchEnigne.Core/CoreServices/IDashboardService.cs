﻿namespace BatchEngine.Core.CoreServices
{
    public interface IDashboardService
    {
        void LogError(string error);
    }
}

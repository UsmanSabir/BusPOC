﻿namespace BatchEngine.Core.CoreServices
{
    public interface ICompletableState
    {
        bool IsFinished { get; }
        bool IsStopped { get; }
    }

    public interface IWritableCompletableState
    {
        bool IsFinished { set; }
        bool IsStopped { set; }
    }
}

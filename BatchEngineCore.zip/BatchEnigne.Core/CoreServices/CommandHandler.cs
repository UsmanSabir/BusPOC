﻿using BatchEngine.Core.Messages;

namespace BatchEngine.Core.CoreServices
{
    public class CommandHandler : IHandler<ICommand>
    {
        public void Handle(ICommand command)
        {
            command.Action();
        }

        public void Dispose()
        {
        }
    }
}

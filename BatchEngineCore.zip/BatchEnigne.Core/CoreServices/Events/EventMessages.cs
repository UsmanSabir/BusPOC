﻿namespace BatchEngine.Core.CoreServices.Events
{
    //class ProcessFinishMessage : GenericTinyMessage<string>
    //{
    //    public ProcessFinishMessage(object sender, string content) : base(sender, content)
    //    {
    //    }
    //}
}
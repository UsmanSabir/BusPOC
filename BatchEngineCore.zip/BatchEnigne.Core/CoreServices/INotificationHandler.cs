﻿using BatchEngine.Core.Messages;

namespace BatchEngine.Core.CoreServices
{
    public interface INotificationHandler<in TRequest> where TRequest : INotification
    {
        void Handle(TRequest notification);
    }
}

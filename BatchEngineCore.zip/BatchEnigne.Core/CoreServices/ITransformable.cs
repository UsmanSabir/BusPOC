﻿namespace BatchEngine.Core.CoreServices
{
    public interface ITransformable<out T>
    {
        T Transform();

        bool CanTransform();
    }
}

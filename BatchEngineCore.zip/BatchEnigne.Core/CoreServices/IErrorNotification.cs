﻿namespace BatchEngine.Core.CoreServices
{
    public interface IErrorNotification
    {
        void NotifyError(string error);
    }
}
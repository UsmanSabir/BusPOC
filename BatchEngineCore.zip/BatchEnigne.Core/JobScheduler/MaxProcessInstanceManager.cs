﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.CoreServices.Events;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.StatePersistence;

namespace BatchEngine.Core.JobScheduler
{
    internal class MaxProcessInstanceManager: IQueueProcessManager, IProcessCompleteListener
    {
        private readonly ProcessVolumePipeline _volumePipeline;

        private readonly IBatchLoggerFactory _loggerFactory;

        //readonly object _syncLock = new object();

        readonly ConcurrentDictionary<long, ProcessExecutionContext> _process = new ConcurrentDictionary<long, ProcessExecutionContext>();

        //readonly ConcurrentDictionary<long, (IReadWritableProcessState process, IReadWritableGroupEntity group, IProcessConfiguration config)> _process=
        //    new ConcurrentDictionary<long, (IReadWritableProcessState process, IReadWritableGroupEntity group, IProcessConfiguration config)>();


        //readonly List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> _queuedProcess =
        //        new List<(IReadWritableProcessState processes, IReadWritableGroupEntity groupDetailsGroupEntity)>();

        private readonly IFrameworkLogger _systemLogger;
        private readonly IContextSwitchHandler _contextSwitchHandler;
        //private IEventAggregator _eventAggregator;
        //private TinyMessageSubscriptionToken _subRem;
        private readonly Func<int, int, bool> _canSubmitPredicate;

        public MaxProcessInstanceManager(ProcessVolumePipeline volumePipeline, IBatchLoggerFactory loggerFactory,
            ICacheAside cacheAside,
            IProcessDataStorage storage, IResolver resolver, Func<int, int, bool> canSubmitPredicate)
        {
            _canSubmitPredicate = canSubmitPredicate;
            _contextSwitchHandler = resolver.Resolve<IContextSwitchHandler>();
            _volumePipeline = volumePipeline;
            _loggerFactory = loggerFactory;

            _systemLogger = loggerFactory.GetSystemLogger();

            var queSub = resolver.Resolve<QueManagerProcessSubscriber>();
            queSub.SetListener(this);
            //_eventAggregator = eventAggregator;
            //_subRem = eventAggregator.Subscribe<TextMessage>(ProcessRemoved, Constants.EventProcessFinished);
        }

        //private void ProcessRemoved(TextMessage obj)
        //{
        //    TrySubmitProcessForVolume();
        //}
        
        
        //public override int ProcessKey { get; } = 0;

        public void OnProcessFinalized(IProcessCompleteContext context)
        {
            if (!context.Configuration.MaxProcessInstance.HasValue ||
                context.Configuration.MaxProcessInstance.Value <= 0) return;

            if (_process.Count > 0)
            {
                var valueTuples = _process.Values.Where(s => s.ProcessState.ProcessId == context.Process.ProcessId)
                    .ToList();
                foreach (var valueTuple in valueTuples)
                {
                    if (!TrySubmitProcessForVolume(valueTuple))
                    {
                        break;
                    }
                }
            }
        }

        private bool TrySubmitProcessForVolume(ProcessExecutionContext context) // (IReadWritableProcessState process, IReadWritableGroupEntity group, IProcessConfiguration config) processTuple)
        {
            var readWritableProcessState = context.WritableProcessState;
            
            try
            {
                var isSubmitted = SubmitQueueProcessForVolume(context);//  readWritableProcessState, groupDetailsGroupEntity, config);
                if (isSubmitted)
                {
                    _process.TryRemove(context.ProcessState.Id, out _);
                }
                return isSubmitted;
            }
            catch (Exception e)
            {
                _systemLogger.Error("Error submitting Queued process Id {processId} for volume. {error}",
                    readWritableProcessState.Id, e);
            }

            return false;
        }

        readonly object _syncLock=new object();

        private bool SubmitQueueProcessForVolume(ProcessExecutionContext executionContext) // IReadWritableProcessState readWritableProcessState, IReadWritableGroupEntity groupDetailsGroupEntity, IProcessConfiguration configuration)
        {
            _contextSwitchHandler.ContextSwitchCompleted();

            var configuration = executionContext.Configuration;

            if (configuration.MaxProcessInstance.HasValue == false || configuration.MaxProcessInstance.Value == 0)
            {
                throw new ApplicationException($"Process Id {executionContext.ProcessState.Id} has null or 0 MaxProcessInstance value");
            }

            lock (_syncLock)
            {
                var canSubmit = _canSubmitPredicate(executionContext.ProcessState.ProcessId, configuration.MaxProcessInstance.Value);
                if (!canSubmit)
                {
                    return false;
                }

                {
                    //var p = readWritableProcessState;

                    //var volumeMessage = new ProcessExecutionContext(
                    //    _loggerFactory.GetProcessLogger(p), p, //.Id, p.ProcessId, p.CorrelationId
                    //    configuration, _storage, groupDetailsGroupEntity, _resolver, _processStateUpdateAction);

                    _volumePipeline.Invoke(executionContext);
                    return true;
                }
            }
        }

        protected void Dispose(bool disposing)
        {
            //if (!IsDisposed)
            {
                //_eventAggregator.Unsubscribe(_subRem);
                //lock (_syncLock)

                //_queuedProcess.Clear();
                _process?.Clear();
            }

            //base.Dispose(disposing);
        }

        public bool HandleQueueProcess(ProcessExecutionContext executionContext) // IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity, IProcessConfiguration configuration)
        {
            var submitted = SubmitQueueProcessForVolume(executionContext); //, groupDetailsGroupEntity, configuration);

            if (!submitted)
            {
                //lock (_syncLock)
                {
                    _process.AddOrUpdate(executionContext.ProcessState.Id,
                        id => executionContext, // (process, groupDetailsGroupEntity, configuration),
                        (l, oldTuple) => executionContext);// (process, groupDetailsGroupEntity, configuration));

                    //_queuedProcess.RemoveAll(a => a.process.Id == process.Id);//prevent duplicate
                    //_queuedProcess.Add((process, groupDetailsGroupEntity));
                }
            }
            else
            {
                //lock (_syncLock)
                {
                    _process.TryRemove(executionContext.ProcessState.Id, out _);
                    //_queuedProcess.RemoveAll(a => a.process.Id == process.Id);
                }
            }

            return true;
        }

        public void CheckPendingProcess()
        {
            if (_process.Count>0)
            {
                foreach (var processValue in _process.Values)
                {
                    TrySubmitProcessForVolume(processValue);
                }
            }
        }

        public void Dispose()
        {
            //_eventAggregator.Unsubscribe(_subRem);

            Dispose(true);
        }
    }
}
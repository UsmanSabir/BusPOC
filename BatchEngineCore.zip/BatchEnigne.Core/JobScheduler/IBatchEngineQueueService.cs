﻿using BatchEngine.Core;

namespace BatchEngine.Core.JobScheduler
{
    public interface IBatchEngineQueueService
    {
        int GetProcessSeqNoForQueue(string queueName, long refId, ITransaction transaction);
        bool IsQueueSeqReached(string queueName, int seqNumber, long refId);
        bool MarkQueueSeqFinish(string queueName, int seqNumber, ITransaction transaction);
    }
}
﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.StatePersistence;

namespace BatchEngine.Core.JobScheduler
{
    internal class DependentProcessExecutionManager: IDeferProcessExecutionManager, IProcessCompleteListener
    {
        private readonly ProcessVolumePipeline _volumePipeline;

        private readonly IBatchLoggerFactory _loggerFactory;

        //readonly object _syncLock = new object();

        readonly ConcurrentDictionary<long, (ProcessExecutionContext context, SubmittedGroup group)> _process = new ConcurrentDictionary<long, (ProcessExecutionContext context, SubmittedGroup group)>();

        //readonly ConcurrentDictionary<long, (IReadWritableProcessState process, IReadWritableGroupEntity group, IProcessConfiguration config)> _process=
        //    new ConcurrentDictionary<long, (IReadWritableProcessState process, IReadWritableGroupEntity group, IProcessConfiguration config)>();


        //readonly List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> _queuedProcess =
        //        new List<(IReadWritableProcessState processes, IReadWritableGroupEntity groupDetailsGroupEntity)>();

        private readonly IFrameworkLogger _systemLogger;
        private readonly IContextSwitchHandler _contextSwitchHandler;
        //private IEventAggregator _eventAggregator;
        //private TinyMessageSubscriptionToken _subRem;
        
        public DependentProcessExecutionManager(ProcessVolumePipeline volumePipeline, IBatchLoggerFactory loggerFactory,
            ICacheAside cacheAside,
            IProcessDataStorage storage, IResolver resolver)
        {
            _contextSwitchHandler = resolver.Resolve<IContextSwitchHandler>();
            _volumePipeline = volumePipeline;
            _loggerFactory = loggerFactory;

            _systemLogger = loggerFactory.GetSystemLogger();

            var queSub = resolver.Resolve<QueManagerProcessSubscriber>();
            queSub.SetListener(this);
            //_eventAggregator = eventAggregator;
            //_subRem = eventAggregator.Subscribe<TextMessage>(ProcessRemoved, Constants.EventProcessFinished);
        }

        //private void ProcessRemoved(TextMessage obj)
        //{
        //    TrySubmitProcessForVolume();
        //}
        
        
        //public override int ProcessKey { get; } = 0;

        public void OnProcessFinalized(IProcessCompleteContext context)
        {
            if (!context.Configuration.MaxProcessInstance.HasValue ||
                context.Configuration.MaxProcessInstance.Value <= 0) return;

            if (_process.Count > 0)
            {
                var valueTuples = _process.Values.Where(s => s.context.ProcessState.ProcessId == context.Process.ProcessId)
                    .ToList();
                foreach (var valueTuple in valueTuples)
                {
                    if (!TrySubmitProcessForVolume(valueTuple))
                    {
                        break;
                    }
                }
            }
        }

        private bool TrySubmitProcessForVolume((ProcessExecutionContext context, SubmittedGroup group) pair) // (IReadWritableProcessState process, IReadWritableGroupEntity group, IProcessConfiguration config) processTuple)
        {
            var context = pair.context;
            var readWritableProcessState = pair.context.WritableProcessState;
            
            try
            {
                var isSubmitted = SubmitQueueProcessForVolume(pair);//  readWritableProcessState, groupDetailsGroupEntity, config);
                if (isSubmitted)
                {
                    _process.TryRemove(context.ProcessState.Id, out _);
                }
                return isSubmitted;
            }
            catch (Exception e)
            {
                _systemLogger.Error("Error submitting Queued process Id {processId} for volume. {error}",
                    readWritableProcessState.Id, e);
            }

            return false;
        }

        readonly object _syncLock=new object();

        private bool SubmitQueueProcessForVolume((ProcessExecutionContext context, SubmittedGroup group) pair) // IReadWritableProcessState readWritableProcessState, IReadWritableGroupEntity groupDetailsGroupEntity, IProcessConfiguration configuration)
        {
            var executionContext = pair.context;
            var groupDetails = pair.group;

            _contextSwitchHandler.ContextSwitchCompleted();

            var processState = executionContext.ProcessState;

            if (string.IsNullOrWhiteSpace(processState.DependentIds))
            {
                throw new ApplicationException($"Process Id {executionContext.ProcessState.Id} has null or 0 MaxProcessInstance value");
            }

            lock (_syncLock)
            {
                var completedTree = groupDetails.GetCompletedParentHierarchy(executionContext.ProcessState.Id, false)
                    .Select(p => p.Id).ToList();
                List<IReadWritableProcessState> dependingProcessVolumeReq =
                    new List<IReadWritableProcessState>();



                if (completedTree.Any())
                {
                    foreach (var pid in completedTree)
                    {
                        var dependentProcess = groupDetails.ProcessEntities.Where(p =>
                            p.IsFinished == false && p.IsVolumeGenerated == false && p.IsStopped == false
                            && p.DependentIdsList.Contains(pid)).ToList();

                        foreach (var dependentPrcs in dependentProcess)
                        {
                            var isAllDependentCompleted = dependentPrcs.DependentIdsList.All(did =>
                            {
                                if (did == pid)
                                    return true; //dependent on current completed tree branch

                                var otherDepProcess =
                                    groupDetails.ProcessEntities.FirstOrDefault(pc => pc.Id == did);

                                if (otherDepProcess == null)
                                    return
                                        false; // dependent process not exist in process list. should execute at last through group health check method

                                //check full tree branch for completion
                                bool isTreeNodeWithChildCompleted =
                                    groupDetails.CheckIfTreeNodeWithChildCompleted(otherDepProcess);
                                return isTreeNodeWithChildCompleted;
                                //return otherDepProcess.IsFinished; //todo test thoroughly, possible to have non-existing id in dependentIds List?
                            });

                            if (isAllDependentCompleted)
                            {
                                dependingProcessVolumeReq.Add(dependentPrcs);
                            }
                        }
                    }
                }

                if (dependingProcessVolumeReq.Count > 0)
                {
                    //Logger.Info($"Submitting dependent process(es) on completion of pid {processId}, with Ids {string.Join(",", dependingProcessVolumeReq.Select(s => s.Id))}");
                    //SubmitVolumeRequest(dependingProcessVolumeReq, groupDetails.GroupEntity, groupDetails);
                    //skipGroupHealthCheck = true;
                }




                //var canSubmit = _canSubmitPredicate(executionContext.ProcessState.ProcessId, processState.MaxProcessInstance.Value);
                //if (!canSubmit)
                //{
                //    return false;
                //}

                {
                    //var p = readWritableProcessState;

                    //var volumeMessage = new ProcessExecutionContext(
                    //    _loggerFactory.GetProcessLogger(p), p, //.Id, p.ProcessId, p.CorrelationId
                    //    configuration, _storage, groupDetailsGroupEntity, _resolver, _processStateUpdateAction);

                    _volumePipeline.Invoke(executionContext);
                    return true;
                }
            }
        }

        protected void Dispose(bool disposing)
        {
            //if (!IsDisposed)
            {
                //_eventAggregator.Unsubscribe(_subRem);
                //lock (_syncLock)

                //_queuedProcess.Clear();
                _process?.Clear();
            }

            //base.Dispose(disposing);
        }

        public bool CanHandleProcess(ProcessExecutionContext context)
        {
            return !string.IsNullOrWhiteSpace(context.ProcessState.DependentIds);
        }

        public bool HandleQueueProcess(ProcessExecutionContext executionContext, SubmittedGroup @group) // IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity, IProcessConfiguration configuration)
        {
            var submitted = SubmitQueueProcessForVolume((executionContext, group)); //, groupDetailsGroupEntity, configuration);

            if (!submitted)
            {
                //lock (_syncLock)
                {
                    _process.AddOrUpdate(executionContext.ProcessState.Id,
                        id => (executionContext, group), // (process, groupDetailsGroupEntity, configuration),
                        (l, oldTuple) => (executionContext, group));// (process, groupDetailsGroupEntity, configuration));

                    //_queuedProcess.RemoveAll(a => a.process.Id == process.Id);//prevent duplicate
                    //_queuedProcess.Add((process, groupDetailsGroupEntity));
                }
            }
            else
            {
                //lock (_syncLock)
                {
                    _process.TryRemove(executionContext.ProcessState.Id, out _);
                    //_queuedProcess.RemoveAll(a => a.process.Id == process.Id);
                }
            }

            return true;
        }

        public void CheckPendingProcess()
        {
            if (_process.Count>0)
            {
                foreach (var processValue in _process.Values)
                {
                    TrySubmitProcessForVolume(processValue);
                }
            }
        }

        public void Dispose()
        {
            //_eventAggregator.Unsubscribe(_subRem);

            Dispose(true);
        }
    }
}
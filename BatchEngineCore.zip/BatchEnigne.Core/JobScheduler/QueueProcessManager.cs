﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core.Groups;
using BatchEngine.Core.StatePersistence;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.CoreServices.Events;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.Subscribers;

namespace BatchEngine.Core.JobScheduler
{
    internal interface IQueueProcessManager:IDisposable
    {
        bool HandleQueueProcess(ProcessExecutionContext executionContext); //IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity, IProcessConfiguration configuration);
        void CheckPendingProcess();
    }

    interface IProcessCompleteListener
    {
        void OnProcessFinalized(IProcessCompleteContext context);
    }

    class QueManagerProcessSubscriber: ProcessSubscriberBase
    {
        readonly List<WeakReference<IProcessCompleteListener>> _listeners 
            = new List<WeakReference<IProcessCompleteListener>>();

        readonly object _syncLock=new object();

        //private QueueProcessManager _queueProcessManager=null;

        public QueManagerProcessSubscriber()
        {
            
        }
        public override int ProcessId { get; } = 0;

        public override void OnProcessFinalized(IProcessCompleteContext context)
        {
            //_queueProcessManager?.OnProcessFinalized(context);
            WeakReference<IProcessCompleteListener>[] listeners;
            lock (_syncLock)
            {
                listeners = _listeners.ToArray();
            }
            foreach (var listener in listeners)
            {
                Robustness.Instance.SafeCall(() =>
                {
                    if (listener.TryGetTarget(out IProcessCompleteListener lstnr))
                    {
                        lstnr.OnProcessFinalized(context);
                    }
                    else
                    {
                        lock (_syncLock)
                        {
                            _listeners.Remove(listener);
                        }
                    }
                });
            }
        }


        public void SetListener(IProcessCompleteListener queueProcessManager)
        {
            //_queueProcessManager = queueProcessManager;
            lock (_syncLock)
            {
                _listeners.Add(new WeakReference<IProcessCompleteListener>(queueProcessManager));
            }
        }
    }

    internal class QueueProcessManager: IQueueProcessManager, IProcessCompleteListener
    {
        private readonly IResolver _resolver;
        private readonly IBatchEngineQueueService _batchEngineQueueService;

        private readonly ProcessVolumePipeline _volumePipeline;

        private readonly IBatchLoggerFactory _loggerFactory;

        private readonly ICacheAside _cacheAside;

        private readonly IProcessDataStorage _storage;

        //readonly object _syncLock = new object();

        //readonly ConcurrentDictionary<long, (IReadWritableProcessState process, IReadWritableGroupEntity group)> _process=
        //    new ConcurrentDictionary<long, (IReadWritableProcessState process, IReadWritableGroupEntity group)>();

        readonly ConcurrentDictionary<long, ProcessExecutionContext> _process = new ConcurrentDictionary<long, ProcessExecutionContext>();
        

        //readonly List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> _queuedProcess =
        //        new List<(IReadWritableProcessState processes, IReadWritableGroupEntity groupDetailsGroupEntity)>();

        private readonly IFrameworkLogger _systemLogger;
        private readonly IContextSwitchHandler _contextSwitchHandler;

        public QueueProcessManager(IBatchEngineQueueService batchEngineQueueService,
            ProcessVolumePipeline volumePipeline, IBatchLoggerFactory loggerFactory, ICacheAside cacheAside,
            IProcessDataStorage storage, IResolver resolver)
        {
            _resolver = resolver;
            _contextSwitchHandler = resolver.Resolve<IContextSwitchHandler>();
            _batchEngineQueueService = batchEngineQueueService;
            _volumePipeline = volumePipeline;
            _loggerFactory = loggerFactory;
            _cacheAside = cacheAside;
            _storage = storage;

            _systemLogger = loggerFactory.GetSystemLogger();

            var queSub = resolver.Resolve<QueManagerProcessSubscriber>();
            queSub.SetListener(this);
            //_eventAggregator = eventAggregator;
            //_subRem = eventAggregator.Subscribe<TextMessage>(ProcessRemoved, Constants.EventProcessFinished);
        }

        private void ProcessRemoved(TextMessage obj)
        {
            
        }
        
        
        //public override int ProcessKey { get; } = 0;

        public void OnProcessFinalized(IProcessCompleteContext context)
        {
            if (context.Process.QueueSeq.HasValue && context.Process.QueueSeq.Value > 0)
            TrySubmitProcessForVolume(context.Process.QueueName);
        }

        private void TrySubmitProcessForVolume(string queueName)
        {
            {
                //todo Queued process completed

                List<ProcessExecutionContext> list; //(IReadWritableProcessState process, IReadWritableGroupEntity group)

                //lock (_syncLock)
                {
                    //var src = _queuedProcess.AsEnumerable();
                    var src = _process.Values.AsEnumerable();
                    if (!string.IsNullOrWhiteSpace(queueName))
                        src = src.Where(r => r.ProcessState.QueueName == queueName);


                    list = src.ToList(); //get a copy in lock
                }


                {
                    //List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> process2remove =
                    //    new List<(IReadWritableProcessState, IReadWritableGroupEntity)>();
                    List<ProcessExecutionContext> process2remove = new List<ProcessExecutionContext>();


                    foreach (var pair in list)
                    {
                        var readWritableProcessState = pair.WritableProcessState;
                        
                        try
                        {
                            var isSubmitted = SubmitQueueProcessForVolume(pair); // readWritableProcessState, groupDetailsGroupEntity);
                            if (isSubmitted)
                            {
                                process2remove.Add(pair);
                            }
                        }
                        catch (Exception e)
                        {
                            _systemLogger.Error("Error submitting Queued process Id {processId} for volume. {error}",
                                readWritableProcessState.Id, e);
                        }
                    }

                    if (process2remove.Count > 0)
                    {
                        //lock (_syncLock)
                        {
                            foreach (var pair in process2remove)
                            {
                                //_queuedProcess.Remove(pair);
                                _process.TryRemove(pair.ProcessState.Id, out _);
                            }
                        }
                    }
                }
            }
        }

        private bool SubmitQueueProcessForVolume(ProcessExecutionContext context) //IReadWritableProcessState readWritableProcessState, IReadWritableGroupEntity groupDetailsGroupEntity)
        {
            _contextSwitchHandler.ContextSwitchCompleted();

            var readWritableProcessState = context.WritableProcessState;

            if (readWritableProcessState.QueueSeq.HasValue == false || readWritableProcessState.QueueSeq.Value == 0)
            {
                throw new ApplicationException($"Process Id {readWritableProcessState.Id} has null or 0 QueueSeq value");
            }

            var isQueueSeqReached = _batchEngineQueueService.IsQueueSeqReached(readWritableProcessState.QueueName,
                readWritableProcessState.QueueSeq.Value, readWritableProcessState.GroupId);

            if (isQueueSeqReached)
            {
                var p = readWritableProcessState;


                //var volumeMessage = new ProcessExecutionContext(
                //    _loggerFactory.GetProcessLogger(p), p, //.Id, p.ProcessId, p.CorrelationId
                //    _cacheAside.GetProcessConfiguration(p.ProcessId), _storage, groupDetailsGroupEntity, _resolver);

                _volumePipeline.Invoke(context);
                return true;
            }

            return false;
        }

        protected void Dispose(bool disposing)
        {
            //if (!IsDisposed)
            {
                //_eventAggregator.Unsubscribe(_subRem);
                //lock (_syncLock)

                //_queuedProcess.Clear();
                _process?.Clear();
            }

            //base.Dispose(disposing);
        }

        public bool HandleQueueProcess(ProcessExecutionContext context) // IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity, IProcessConfiguration configuration)
        {
            var submitted = SubmitQueueProcessForVolume(context); //.WritableProcessState, context.GroupEntity);
            var process = context.ProcessState;
            var groupDetailsGroupEntity = context.GroupEntity;

            if (!submitted)
            {
                //lock (_syncLock)
                {
                    _process.AddOrUpdate(process.Id, id => context, // (process, groupDetailsGroupEntity),
                        (l, oldTuple) => context// (process, groupDetailsGroupEntity)
                        );

                    //_queuedProcess.RemoveAll(a => a.process.Id == process.Id);//prevent duplicate
                    //_queuedProcess.Add((process, groupDetailsGroupEntity));
                }
            }
            else
            {
                //lock (_syncLock)
                {
                    _process.TryRemove(process.Id, out _);
                    //_queuedProcess.RemoveAll(a => a.process.Id == process.Id);
                }
            }

            return true;
        }

        public void CheckPendingProcess()
        {
            if (_process.Count>0)
            {
                TrySubmitProcessForVolume(null);
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
    }
}
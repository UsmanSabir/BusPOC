﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core.Groups;
using BatchEngine.Core.StatePersistence;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.CoreServices.Events;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.Subscribers;

namespace BatchEngine.Core.JobScheduler
{
    public interface IQueueProcessManager:IDisposable
    {
        void HandleQueueProcess(IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity);
        void CheckPendingProcess();
    }

    class QueManagerProcessSubscriber: ProcessSubscriberBase
    {
        private QueueProcessManager _queueProcessManager=null;

        public QueManagerProcessSubscriber()
        {
            
        }
        public override int ProcessId { get; } = 0;

        public override void OnProcessFinalized(IProcessCompleteContext context)
        {
            _queueProcessManager?.OnProcessFinalized(context);
        }


        public void SetListener(QueueProcessManager queueProcessManager)
        {
            _queueProcessManager = queueProcessManager;
        }
    }

    internal class QueueProcessManager: IQueueProcessManager
    {
        private readonly IResolver _resolver;
        private readonly IBatchEngineQueueService _batchEngineQueueService;

        private readonly ProcessVolumePipeline _volumePipeline;

        private readonly IBatchLoggerFactory _loggerFactory;

        private readonly ICacheAside _cacheAside;

        private readonly IProcessDataStorage _storage;
        
        //readonly object _syncLock = new object();

        readonly ConcurrentDictionary<long, (IReadWritableProcessState process, IReadWritableGroupEntity group)> _process=
            new ConcurrentDictionary<long, (IReadWritableProcessState process, IReadWritableGroupEntity group)>();

        //readonly List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> _queuedProcess =
        //        new List<(IReadWritableProcessState processes, IReadWritableGroupEntity groupDetailsGroupEntity)>();

        private readonly IFrameworkLogger _systemLogger;
        private IContextSwitchHandler _contextSwitchHandler;

        public QueueProcessManager(IBatchEngineQueueService batchEngineQueueService,
            ProcessVolumePipeline volumePipeline, IBatchLoggerFactory loggerFactory, ICacheAside cacheAside,
            IProcessDataStorage storage, IResolver resolver)
        {
            _resolver = resolver;
            _contextSwitchHandler = resolver.Resolve<IContextSwitchHandler>();
            _batchEngineQueueService = batchEngineQueueService;
            _volumePipeline = volumePipeline;
            _loggerFactory = loggerFactory;
            _cacheAside = cacheAside;
            _storage = storage;

            _systemLogger = loggerFactory.GetSystemLogger();

            var queSub = resolver.Resolve<QueManagerProcessSubscriber>();
            queSub.SetListener(this);
            //_eventAggregator = eventAggregator;
            //_subRem = eventAggregator.Subscribe<TextMessage>(ProcessRemoved, Constants.EventProcessFinished);
        }

        private void ProcessRemoved(TextMessage obj)
        {
            
        }
        
        
        //public override int ProcessKey { get; } = 0;

        public void OnProcessFinalized(IProcessCompleteContext context)
        {
            if (context.Process.QueueSeq.HasValue && context.Process.QueueSeq.Value > 0)
            TrySubmitProcessForVolume(context.Process.QueueName);
        }

        private void TrySubmitProcessForVolume(string queueName)
        {
            {
                //todo Queued process completed

                List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> list;

                //lock (_syncLock)
                {
                    //var src = _queuedProcess.AsEnumerable();
                    var src = _process.Values.AsEnumerable();
                    if (!string.IsNullOrWhiteSpace(queueName))
                        src = src.Where(r => r.process.QueueName == queueName);


                    list = src.ToList(); //get a copy in lock
                }


                {
                    List<(IReadWritableProcessState process, IReadWritableGroupEntity group)> process2remove =
                        new List<(IReadWritableProcessState, IReadWritableGroupEntity)>();

                    foreach (var pair in list)
                    {
                        var readWritableProcessState = pair.process;
                        var groupDetailsGroupEntity = pair.@group;

                        try
                        {
                            var isSubmitted = SubmitQueueProcessForVolume(readWritableProcessState, groupDetailsGroupEntity);
                            if (isSubmitted)
                            {
                                process2remove.Add(pair);
                            }
                        }
                        catch (Exception e)
                        {
                            _systemLogger.Error("Error submitting Queued process Id {processId} for volume. {error}",
                                readWritableProcessState.Id, e);
                        }
                    }

                    if (process2remove.Count > 0)
                    {
                        //lock (_syncLock)
                        {
                            foreach (var pair in process2remove)
                            {
                                //_queuedProcess.Remove(pair);
                                _process.TryRemove(pair.process.Id, out _);
                            }
                        }
                    }
                }
            }
        }

        private bool SubmitQueueProcessForVolume(IReadWritableProcessState readWritableProcessState,
            IReadWritableGroupEntity groupDetailsGroupEntity)
        {
            _contextSwitchHandler.ContextSwitchCompleted();

            if (readWritableProcessState.QueueSeq.HasValue == false || readWritableProcessState.QueueSeq.Value == 0)
            {
                throw new ApplicationException($"Process Id {readWritableProcessState.Id} has null or 0 QueueSeq value");
            }

            var isQueueSeqReached = _batchEngineQueueService.IsQueueSeqReached(readWritableProcessState.QueueName,
                readWritableProcessState.QueueSeq.Value, readWritableProcessState.GroupId);

            if (isQueueSeqReached)
            {
                var p = readWritableProcessState;


                var volumeMessage = new ProcessExecutionContext(
                    _loggerFactory.GetProcessLogger(p), p, //.Id, p.ProcessId, p.CorrelationId
                    _cacheAside.GetProcessConfiguration(p.ProcessId), _storage, groupDetailsGroupEntity, _resolver);

                _volumePipeline.Invoke(volumeMessage);
                return true;
            }

            return false;
        }

        protected void Dispose(bool disposing)
        {
            //if (!IsDisposed)
            {
                //_eventAggregator.Unsubscribe(_subRem);
                //lock (_syncLock)
                {
                    //_queuedProcess.Clear();
                    _process.Clear();
                    
                }
            }

            //base.Dispose(disposing);
        }

        public void HandleQueueProcess(IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity)
        {
            var submitted = SubmitQueueProcessForVolume(process, groupDetailsGroupEntity);

            if (!submitted)
            {
                //lock (_syncLock)
                {
                    _process.AddOrUpdate(process.Id, id => (process, groupDetailsGroupEntity),
                        (l, oldTuple) => (process, groupDetailsGroupEntity));

                    //_queuedProcess.RemoveAll(a => a.process.Id == process.Id);//prevent duplicate
                    //_queuedProcess.Add((process, groupDetailsGroupEntity));
                }
            }
            else
            {
                //lock (_syncLock)
                {
                    _process.TryRemove(process.Id, out _);
                    //_queuedProcess.RemoveAll(a => a.process.Id == process.Id);
                }
            }
        }

        public void CheckPendingProcess()
        {
            if (_process.Count>0)
            {
                TrySubmitProcessForVolume(null);
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
    }
}
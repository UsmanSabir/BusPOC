﻿using System;
using System.Collections.Generic;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.StatePersistence;

namespace BatchEngine.Core.JobScheduler
{
    internal class CompositeQueueProcessManager: IQueueProcessManager
    {
        private readonly List<IQueueProcessManager> _queueProcessManager;
        protected internal QueueProcessManager QueueProcessManager;
        protected internal MaxProcessInstanceManager MaxProcessInstanceManager;

        public CompositeQueueProcessManager(IResolver resolver, IProcessDataStorage storage,
            IBatchEngineQueueService batchEngineQueueService, ProcessVolumePipeline volumePipeline,
            IBatchLoggerFactory loggerFactory,
            ICacheAside cacheAside, Func<int, int, bool> canSubmitPredicate)
        {
            
            QueueProcessManager = new QueueProcessManager(batchEngineQueueService, volumePipeline, loggerFactory, cacheAside, storage,
                resolver);
            MaxProcessInstanceManager = new MaxProcessInstanceManager(volumePipeline, loggerFactory, cacheAside, storage, resolver, canSubmitPredicate);
            _queueProcessManager = new List<IQueueProcessManager>()
            {
                QueueProcessManager,
                MaxProcessInstanceManager
            };
        }

        public void Dispose()
        {
            foreach (var processManager in _queueProcessManager)
            {
                Robustness.Instance.SafeCall(() =>
                {
                    processManager.Dispose();
                });
            }
        }

        public bool HandleQueueProcess(ProcessExecutionContext executionContext) // IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity, IProcessConfiguration configuration)
        {
            var process = executionContext.ProcessState;

            if (process.QueueSeq.HasValue && process.QueueSeq.Value > 0)
            {
                QueueProcessManager.HandleQueueProcess(executionContext);
                return true;
                //var isQueueSeqReached = _batchEngineQueueService.IsQueueSeqReached(p.QueueName, p.QueueSeq.Value, p.GroupId);
                //if (!isQueueSeqReached)
                //{
                //    _systemLogger.Info("Process queue not reached for process Id {processId} and correlation Id {CorrelationId}", p.Id, p.CorrelationId);
                //    continue;
                //}
            }

            var processConfiguration = executionContext.Configuration;
            if (processConfiguration.MaxProcessInstance.HasValue &&
                processConfiguration.MaxProcessInstance.Value > 0)
            {
                //var maxInstances = processConfiguration.MaxProcessInstance.Value;
                MaxProcessInstanceManager.HandleQueueProcess(executionContext);
                return true;
            }

            return false;
        }

        public void CheckPendingProcess()
        {
            foreach (var processManager in _queueProcessManager)
            {
                Robustness.Instance.SafeCall(() =>
                {
                    processManager.CheckPendingProcess();
                });
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using BatchEngine.Core.Groups;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.StatePersistence;

namespace BatchEngine.Core.JobScheduler
{
    internal class CompositeDeferProcessExecutionManager: IDeferProcessExecutionManager
    {
        private readonly List<IDeferProcessExecutionManager> _queueProcessManager;
        protected internal DeferProcessExecutionManager DeferProcessExecutionManager;
        protected internal MaxProcessExecutionInstanceManager MaxProcessExecutionInstanceManager;
        protected internal DependentProcessExecutionManager DependentProcessExecutionManager;

        public CompositeDeferProcessExecutionManager(IResolver resolver, IProcessDataStorage storage,
            IBatchEngineQueueService batchEngineQueueService, ProcessVolumePipeline volumePipeline,
            IBatchLoggerFactory loggerFactory,
            ICacheAside cacheAside, Func<int, int, bool> canSubmitPredicate)
        {
            
            DeferProcessExecutionManager = new DeferProcessExecutionManager(batchEngineQueueService, volumePipeline, loggerFactory, cacheAside, storage,
                resolver);
            MaxProcessExecutionInstanceManager = new MaxProcessExecutionInstanceManager(volumePipeline, loggerFactory, cacheAside, storage, resolver, canSubmitPredicate);
            DependentProcessExecutionManager = new DependentProcessExecutionManager(volumePipeline, loggerFactory, cacheAside, storage, resolver);

            _queueProcessManager = new List<IDeferProcessExecutionManager>()
            {
                DeferProcessExecutionManager,
                MaxProcessExecutionInstanceManager,
                DependentProcessExecutionManager
            };
        }

        public void Dispose()
        {
            foreach (var processManager in _queueProcessManager)
            {
                Robustness.Instance.SafeCall(() =>
                {
                    processManager.Dispose();
                });
            }
        }

        public bool CanHandleProcess(ProcessExecutionContext context)
        {
            return true;//todo: what???
        }

        public bool HandleQueueProcess(ProcessExecutionContext executionContext, SubmittedGroup @group) // IReadWritableProcessState process, IReadWritableGroupEntity groupDetailsGroupEntity, IProcessConfiguration configuration)
        {
            var process = executionContext.ProcessState;

            if (DeferProcessExecutionManager.CanHandleProcess(executionContext)) // process.QueueSeq.HasValue && process.QueueSeq.Value > 0)
            {
                DeferProcessExecutionManager.HandleQueueProcess(executionContext, group);
                return true;
                //var isQueueSeqReached = _batchEngineQueueService.IsQueueSeqReached(p.QueueName, p.QueueSeq.Value, p.GroupId);
                //if (!isQueueSeqReached)
                //{
                //    _systemLogger.Info("Process queue not reached for process Id {processId} and correlation Id {CorrelationId}", p.Id, p.CorrelationId);
                //    continue;
                //}
            }

            //if (DependentProcessExecutionManager.CanHandleProcess(executionContext))
            //{
            //    DependentProcessExecutionManager.HandleQueueProcess(executionContext, group);
            //    return true;
            //}

            //var processConfiguration = executionContext.Configuration;
            if (MaxProcessExecutionInstanceManager.CanHandleProcess(executionContext)) // processConfiguration.MaxProcessInstance.HasValue && processConfiguration.MaxProcessInstance.Value > 0)
            {
                //var maxInstances = processConfiguration.MaxProcessInstance.Value;
                MaxProcessExecutionInstanceManager.HandleQueueProcess(executionContext, group);
                return true;
            }

            return false;
        }

        public void CheckPendingProcess()
        {
            foreach (var processManager in _queueProcessManager)
            {
                Robustness.Instance.SafeCall(() =>
                {
                    processManager.CheckPendingProcess();
                });
            }
        }
    }
}
﻿using System.Collections.Generic;
using BatchEngine.Core;

namespace BatchEngine.Core.JobScheduler
{
    public interface IJobScheduler
    {
        long CreateProcessJob(int processId, List<JobCriteria> criteria, string submittedBy, int invokeTypeId=1, bool hasPriority = false);
        
        long CreateJob(int groupId, List<JobCriteria> criteria, string submittedBy, int invokeTypeId=1, bool hasPriority=false);

        long CreateJob(List<int> processIds, List<JobCriteria> criteria, string submittedBy, int invokeTypeId = 1, bool hasPriority = false);

        long CreateJob(int groupId, List<int> processIds, List<JobCriteria> criteria, string submittedBy, int invokeTypeId = 1, bool hasPriority = false);

        long CreateQueueJob(List<int> processIds, List<JobCriteria> criteria, string queueName, string submittedBy, int invokeTypeId = 1, bool hasPriority = false);

        bool ResumeGroup(int groupId);
    }
}
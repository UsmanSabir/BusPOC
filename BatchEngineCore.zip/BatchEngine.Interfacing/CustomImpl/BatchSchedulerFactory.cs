﻿using BatchEngine.Core;
using BatchEngine.Core.JobScheduler;
using BatchEngine.Core.Serializers;
using NS.BatchEngine;
using NS.BatchEngine.Empty;
using NS.BatchEngine.Logs;
using NS.BatchEngine.PubSub.Database;

namespace BatchEngine.Interfacing
{
    public class BatchSchedulerFactory
    {
        public static IJobScheduler GetScheduler()
        {
            var batchLoggerFactory = new BatchLoggerFactory(new NLogFactory());

            IJobScheduler scheduler=new JobScheduler(new SerializersFactory(), new EmptyPubSubFactory(), batchLoggerFactory, new BatchEngineQueueService());
            //IJobScheduler scheduler = new JobScheduler(new SerializersFactory(), new DatabasePubSubFactory(batchLoggerFactory, null), batchLoggerFactory, new BatchEngineQueueService());
            return scheduler;
        }
    }
}
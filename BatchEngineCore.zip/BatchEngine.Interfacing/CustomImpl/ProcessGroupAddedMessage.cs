﻿namespace BatchEngine.Core
{
    public class ProcessGroupAddedMessage
    {
        public long GroupId { get; set; }
    }

    public class ResumeGroupWatchDogMessage
    {
        public long GroupId { get; set; }
    }

    
}
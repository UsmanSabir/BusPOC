﻿namespace BatchEngine.Core
{
    public interface IWatchDogMessage
    {

    }
}
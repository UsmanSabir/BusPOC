﻿using BatchEngine.Core.Groups;
using BatchEngine.Core;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;

namespace NS.BatchEngine
{
    public class EntityFactory: IEntityFactory
    {
        
        public IReadWritableGroupEntity CreateGroupEntity()
        {
            BatchGroupStateWrapper wrapper=new BatchGroupStateWrapper(new BatchGroupState());
            return wrapper;
        }

        public IReadWritableProcessState CreateProcessEntity()
        {
            var wrapper = new ProcessStateWrapper(new BatchProcessState());
            wrapper.Status= CompletionStatus.Pending;
            wrapper.Result= ResultStatus.Empty;
            return wrapper;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Helper;
using BatchEngine.Core.ProcessLocks;
using NS.BatchEngine.Db;
using NS.ORM;
using NS.ORM.UoW;

namespace NS.BatchEngine.Sql
{
    public class SqlDistributedLock: DistributedMutex
    {
        private readonly IContextSwitchHandler _contextSwitchHandler;
        //based on https://docs.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-getapplock-transact-sql?view=sql-server-2017

        private const string _sqlLockCommand = "sys.sp_GetAppLock";

        IUnitOfWork _uow;

        public SqlDistributedLock(string key, Func<CancellationToken, Task> taskToRunWhenLockAcquired,
            Action secondaryAction, IFrameworkLogger logger, IContextSwitchHandler contextSwitchHandler) 
            : base(key, taskToRunWhenLockAcquired, secondaryAction, logger)
        {
            _contextSwitchHandler = contextSwitchHandler;
        }
        
        private DbController GetDbController(IUnitOfWork uow = null)
        {
            return OrmFactory.GetDbController(uow);
        }

        protected override Task<string> AcquireLockAsync(string key, CancellationToken token)
        {
            _contextSwitchHandler.ContextSwitchCompleted();

            string lockKey = NodeSettings.Instance.LockKey;



            ReleaseLock(lockKey);
            
            if (AcquireDbLock(lockKey, out var isError)) return Task.FromResult(lockKey);

            ReleaseLock(lockKey);//close transaction / connection
            return Task.FromResult(string.Empty);
        }

        private bool AcquireDbLock(string lockKey, out bool isError)
        {
            isError = false;

            
            try
            {
                _uow = GetDbController().UsingUnitOfWork();
                var controller = _uow.Controller;

                var res = controller.ScalarFunctionCall<int>(
                    _sqlLockCommand, new Dictionary<string, object>()
                    {
                        {"Resource", lockKey},
                        {"LockMode", "Exclusive"}, //Shared,Update,Exclusive
                        {"LockOwner", "Transaction"},
                        {"LockTimeout", "100"}, // don't wait
                    }, false);

                Logger.Trace("SQLLock response received with value {lockId}", res);

                if (res == 0 || res == 1)
                {
                    //lock taken
                    //Value Result
                    //0   The lock was successfully granted synchronously.
                    //1   The lock was granted successfully after waiting for other incompatible locks to be released.
                    //- 1  The lock request timed out.
                    //-2  The lock request was canceled.
                    //-3  The lock request was chosen as a deadlock victim.
                    //-999    Indicates a parameter validation or other call error.
                    Logger.Info("SQLLock master lock taken with result value {lockId}", res);
                    {
                        return true;
                    }
                }

                //Console.WriteLine(res);
            }
            catch (Exception e)
            {
                isError = true;
                Logger.Error("Error while taking lock {error}", e);
            }

            return false;
        }

        protected override void ReleaseLock(string lockId)
        {
            _contextSwitchHandler.ContextSwitchCompleted();
            Robustness.Instance.SafeCall(() =>
            {
                _uow?.Dispose();
                _uow = null;
            });
        }

        protected override Task<bool> RenewLockAsync(string lockId, CancellationToken token)
        {
            _contextSwitchHandler.ContextSwitchCompleted();
            try
            {
                _uow.Controller.ExecuteSql("SELECT 'A'", null); //just ping query
                return Task.FromResult(true);
            }
            catch (Exception e)
            {
                Logger.Warn("Error while Renewing lock {error}", e);

                ReleaseLock(lockId);

                var key = NodeSettings.Instance.LockKey;
                if (AcquireDbLock(key, out var isError))
                    return Task.FromResult(true);
                else
                {
                    while (isError && token.IsCancellationRequested==false)
                    {
                        Task.Delay(2000, token).Wait(token); // wait 2 secs
                        _contextSwitchHandler.ContextSwitchCompleted();

                        if (token.IsCancellationRequested)
                            break;

                        if (AcquireDbLock(key, out isError)) return Task.FromResult(true);
                    }
                }

                return Task.FromResult(false);
            }
        }
    }
}
﻿using BatchEngine.Core;

namespace NS.BatchEngine
{
    public class Constant
    {
#if !Interfacing


        public static readonly string SQLCountFailedTasks =
            //$"SELECT COUNT(1) FROM BatchTaskState WITH(NOLOCK) WHERE CurrentState = '{ResultStatus.Error.Name}' AND ProcessId=@pid";
            $"SELECT COUNT(1) FROM BTCH_TASK_STAT WITH(NOLOCK) WHERE CURR_STAT = '{ResultStatus.Error.Name}' AND PRCS_ID = @pid";

        public static readonly string SQLRetryFailedTasks =
            //$"UPDATE BatchTaskState SET IsFinished = 0, NodeKey=NULL, CompletedOn=NULL, DeferredCount=0, CurrentState='{ResultStatus.Empty.Name}' WHERE CurrentState = 'Error' AND ProcessId=@0"; //todo what about start/complete date time, DeferredCount, IsStopped
            $"UPDATE BTCH_TASK_STAT SET IS_FNSH = 0, NODE_KEY = NULL, CMPL_ON = NULL, DFRD_CONT = 0, CURR_STAT ='{ResultStatus.Empty.Name}' WHERE CURR_STAT = 'Error' AND PRCS_ID = @0";

        public static readonly string SQLCountPendingTasks =
             // $"SELECT COUNT(1) FROM BatchTaskState WITH(NOLOCK) WHERE IsFinished = 0 AND IsStopped = 0 AND NodeKey IS NULL AND ProcessId=@pid"; //(CurrentState='' OR CurrentState IS NULL OR CurrentState='{ResultStatus.Empty.Name}') AND 
            "SELECT COUNT(1) FROM BTCH_TASK_STAT WITH(NOLOCK) WHERE IS_FNSH = 0 AND IS_STOP = 0 AND NODE_KEY IS NULL AND PRCS_ID=@pid";

        //public const string SQLReadDataQueue =
        //    @"SELECT TOP(1) * FROM BatchTaskState WITH(UPDLOCK, READPAST) WHERE IsFinished=0 AND IsStopped=0  ORDER BY ProcessId, DeferredCount";

        //        public static readonly string SQLReadDataQueue = string.Format(
        //            @"UPDATE BatchTaskState SET NodeKey='{0}', StartedOn = @0
        //OUTPUT Inserted.*
        //FROM (SELECT TOP 1 id FROM dbo.BatchTaskState WITH (NOLOCK) WHERE IsFinished = 0 AND IsStopped=0 AND NodeKey IS NULL ORDER  BY ProcessId, DeferredCount,Id) t
        //WHERE BatchTaskState.id = t.Id", NodeSettings.Instance.Name); //todo optimize with CTE


        #region Commit

        public static readonly string SQLReadDataQueue = string.Format(
//            @";WITH CTE AS
//(
//SELECT TOP 1 *
//FROM      dbo.BatchTaskState WITH (ROWLOCK, UPDLOCK, READPAST )
//WHERE     IsFinished = 0 AND IsStopped = 0 AND NodeKey IS NULL
//ORDER BY ProcessId,DeferredCount
//)

//UPDATE CTE 
//SET  NodeKey = '{0}' ,StartedOn = GETUTCDATE()
//OUTPUT Inserted.* "
@";WITH CTE AS
(
SELECT TOP 1 *
FROM      BTCH_TASK_STAT WITH (ROWLOCK, UPDLOCK, READPAST )
WHERE     IS_FNSH = 0 AND IS_STOP = 0 AND NODE_KEY IS NULL
ORDER BY PRCS_ID, DFRD_CONT
)

UPDATE CTE 
SET  NODE_KEY = '{0}' ,STRT_ON = GETUTCDATE()
OUTPUT Inserted.* 
", NodeSettings.Instance.Name); //todo optimize with CTE

        public static readonly string SQLReadDataPriorityQueue = string.Format(
//            @";WITH CTE AS
//(
//SELECT TOP 1 *
//FROM      dbo.BatchTaskState WITH (ROWLOCK, UPDLOCK, READPAST )
//WHERE     IsFinished = 0 AND IsStopped = 0 AND NodeKey IS NULL AND HasPriority=1
//ORDER BY ProcessId,DeferredCount
//)

//UPDATE CTE 
//SET  NodeKey = '{0}' ,StartedOn = GETUTCDATE()
//OUTPUT Inserted.*"
@";WITH CTE AS
(
SELECT TOP 1 *
FROM      BTCH_TASK_STAT WITH (ROWLOCK, UPDLOCK, READPAST )
WHERE     IS_FNSH = 0 AND IS_STOP = 0 AND NODE_KEY IS NULL AND HAS_PRTY=1
ORDER BY PRCS_ID, DFRD_CONT
)

UPDATE CTE 
SET  NODE_KEY = '{0}' ,STRT_ON = GETUTCDATE()
OUTPUT Inserted.* 
", NodeSettings.Instance.Name);

        #endregion


        #region Alternate (commented)

        //public static readonly string SQLReadDataQueue = string.Format(
        //    @"UPDATE  BatchTaskState
        //SET     NodeKey = '{0}' ,
        //        StartedOn = GETUTCDATE()
        //OUTPUT  Inserted.*
        //FROM    ( SELECT TOP 1
        //                    MIN(Id) id
        //          FROM      dbo.BatchTaskState WITH ( NOLOCK )
        //          WHERE     IsFinished = 0
        //                    AND IsStopped = 0
        //                    AND NodeKey IS NULL
        //          GROUP BY  DeferredCount
        //          ORDER BY  DeferredCount
        //        ) t
        //WHERE   BatchTaskState.Id = t.Id
        //AND NodeKey IS NULL", NodeSettings.Instance.Name); //todo optimize with CTE

        //public static readonly string SQLReadDataPriorityQueue = string.Format(
        //    @"UPDATE  BatchTaskState
        //SET     NodeKey = '{0}' ,
        //        StartedOn = GETUTCDATE()
        //OUTPUT  Inserted.*
        //FROM    ( SELECT TOP 1
        //                    MIN(Id) id
        //          FROM      dbo.BatchTaskState WITH ( NOLOCK )
        //          WHERE     IsFinished = 0
        //                    AND IsStopped = 0
        //                    AND NodeKey IS NULL
        //                    AND HasPriority = 1
        //          GROUP BY  DeferredCount
        //          ORDER BY  DeferredCount
        //        ) t
        //WHERE   BatchTaskState.Id = t.Id
        //AND NodeKey IS NULL", NodeSettings.Instance.Name);


        #endregion

        public const string SQLCheckPendingTasksExist =
 //           @"IF EXISTS(SELECT 1 FROM dbo.BatchTaskState WITH(NOLOCK) WHERE NodeKey IS NULL) 
 //SELECT 1
 //ELSE 
 //SELECT 0
 //";
        @"IF EXISTS(SELECT 1 FROM BTCH_TASK_STAT WITH(NOLOCK) WHERE NODE_KEY IS NULL) 
 SELECT 1
 ELSE 
 SELECT 0";

        public const string SQLUpdateTaskState =
            @"UPDATE BTCH_TASK_VALUE
	SET STAT_VAL = @2
WHERE TASK_ID = @0 AND STAT_KEY =@1;";

//        @"UPDATE dbo.BatchTaskValue
//	SET StateValue = @2
//WHERE TaskId = @0 AND StateKey=@1;";

        public const string SQLStopProcessTaskState =
//            @"UPDATE dbo.BatchTaskState
//  SET IsStopped=1,
//    UpdatedOn=@1,
//	CurrentState=@2,
//	NodeKey=@3
//WHERE ProcessId = @0 AND NodeKey IS NULL AND CurrentState=@4;";
            @"UPDATE BTCH_TASK_STAT
  SET IS_STOP =1,
    UPDT_ON =@1,
	CURR_STAT =@2,
	NODE_KEY =@3
WHERE PRCS_ID = @0 AND NODE_KEY IS NULL AND CURR_STAT =@4;";


        public const string SQLPing = "SELECT 'Ping'"; //"SELECT GETUTCDATE()";

        public const string SQLDeleteProcessVolume = "DELETE FROM BTCH_TASK_STAT WHERE PRCS_ID = @0"; // @"DELETE FROM dbo.BatchTaskState WHERE ProcessId = @0";


        public const string SQLResumeGroup =
            //"UPDATE BatchGroupState SET IsStopped = 0, NodeId = @1  WHERE Id = @0 AND IsStopped=1";
            "UPDATE BTCP_GRP_STAT SET IS_STOP = 0, NODE_ID = @1  WHERE BTCH_GRP_STAT_ID = @0 AND IS_STOP = 1";

        public static readonly string SQLResumeGroupProcesses =
            //$"UPDATE BatchProcessState SET IsStopped=0,CurrentState='{CompletionStatus.Pending.Name}', NodeId=@1  WHERE GroupId = @0 AND IsStopped=1"; //
            $"UPDATE BTCH_PRCS_STAT SET IS_STOP =0,CURR_STAT ='{CompletionStatus.Pending.Name}', NODE_ID =@1  WHERE GRP_ID = @0 AND IS_STOP=1";

        public static readonly string SQLResumeUpdateGetGroupStopper =
            //$"UPDATE BatchProcessState SET GroupStopper=0, ResultStatus='{ResultStatus.Empty.Name}', CurrentState='{CompletionStatus.Processing.Name}', RetryCount = 0,NodeId=@1    OUTPUT Inserted.Id WHERE GroupId = @0 AND GroupStopper=1";
            $"UPDATE BTCH_PRCS_STAT SET GRP_STOP_FLG =0, ResultStatus='{ResultStatus.Empty.Name}', CURR_STAT ='{CompletionStatus.Processing.Name}', RTRY_CONT = 0,NODE_ID =@1    OUTPUT Inserted.BTCH_PRCS_STAT_ID WHERE GRP_ID = @0 AND GRP_STOP_FLG =1";

        public const string SQLResumeGroupTask =
            //            @"UPDATE bt
            //SET IsStopped=0 
            //FROM 
            //BatchTaskState bt
            // JOIN BatchProcessState bp ON bp.Id=bt.ProcessId
            //WHERE bp.GroupId=@0 AND bt.IsStopped=1";
            @"UPDATE bt
SET IS_STOP=0 
FROM 
BTCH_TASK_STAT bt
 JOIN BTCH_PRCS_STAT bp ON bp.BTCH_PRCS_STAT_ID=bt.PRCS_ID
WHERE bp.GRP_ID =@0 AND bt.IS_STOP =1";

        public static readonly string SQLResumeResetStopperErroredTasks =
            $"UPDATE BTCH_TASK_STAT SET IS_FNSH = 0, NODE_KEY =NULL, CMPL_ON =NULL, DFRD_CONT =0, CURR_STAT ='{ResultStatus.Empty.Name}'  WHERE CURR_STAT = 'Error' AND PRCS_ID =@0"; //$"UPDATE BatchTaskState SET IsFinished = 0, NodeKey=NULL, CompletedOn=NULL, DeferredCount=0, CurrentState='{ResultStatus.Empty.Name}'  WHERE CurrentState = 'Error' AND ProcessId=@0";

        public const string SQLDeleteDbPubSubHistory = @"DELETE FROM BTCH_CMND WHERE PBLS_TIME < @0"; // @"DELETE FROM dbo.BatchCommands WHERE PublishedTime < @0";
#endif

        public const string SQLAddProcessToQueue =
            @"DECLARE @maxSeq INT;  
SELECT  @maxSeq = MAX(QUEU_SEQ) + 1
FROM    BTCH_QUEU WITH ( XLOCK )
WHERE   QUEU_NME = @0;

INSERT  INTO BTCH_QUEU( QUEU_NME , QUEU_SEQ,  REF_ID )
        SELECT  @0 , ISNULL(@maxSeq, 1) , @1;

SELECT ISNULL(@maxSeq, 1);";
            
//            @"
//DECLARE @maxSeq INT;  
//SELECT  @maxSeq = MAX(QueueSeq) + 1
//FROM    BatchQueue WITH ( XLOCK )
//WHERE   QueueName = @0;

//INSERT  INTO dbo.BatchQueue( QueueName , QueueSeq , RefId )
//        SELECT  @0 , ISNULL(@maxSeq, 1) , @1;

//SELECT ISNULL(@maxSeq, 1);
//";

        public const string SQLMarkQueueFinished = @"UPDATE BTCH_QUEU
SET IS_FNSH = 1
WHERE QUEU_NME=@0 AND QUEU_SEQ=@1";


//        @"UPDATE BatchQueue
//SET IsFinished = 1
//WHERE QueueName=@0 AND QueueSeq=@1
//";

    }
}
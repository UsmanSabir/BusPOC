﻿using System.Collections.Generic;
using BatchEngine.Core;
using NS.BaseModels;
using NS.ORM;
using NS.ORM.UoW;

namespace NS.BatchEngine.Db
{
    public class OrmFactory
    {
        public static EntityContextExt<T> GetEntityContext<T>(IList<T> entities = null) where T : BaseModel, new()
        {
            EntityContextExt<T> contextExt;
            contextExt = string.IsNullOrWhiteSpace(NodeSettings.Instance.ConnectionString) ? EntityContextExt.Create<T>(entities)
                : EntityContextExt.Create<T>(entities, NodeSettings.Instance.ConnectionString);
            return contextExt;
        }

        public static DbController GetDbController(IUnitOfWork uow = null)
        {
            if (uow != null) return DbController.Create(uow);

            if (string.IsNullOrWhiteSpace(NodeSettings.Instance.ConnectionString))
            {
                return DbController.Create();
            }
            else
            {
                return DbController.Create(NodeSettings.Instance.ConnectionString);
            }
        }
    }
}
﻿using System.Runtime.Remoting.Messaging;
using NS.Utilities.Context;

namespace NS.BatchEngine
{
    public class ContextHost
    {
        private const string key = "BatchEngineNodeConext";

        public static Context NodeContext
        {
            get;
            set;
        }

        public static Context NodeCallContext
        {
            get => (Context)CallContext.LogicalGetData(key);
            set => CallContext.LogicalSetData(key, value);
        }

        public static void SetAppContext()
        {
            LogContext.ContextToLog = NodeCallContext ?? NodeContext;
        }
        public static void SetAppContext(Context context)
        {
            NodeCallContext = context;
            LogContext.ContextToLog = NodeCallContext ?? NodeContext;
        }

        public static void SetNodeCallContext()
        {
            NodeCallContext = NodeContext;
        }


        public static Context GetCurrentContext()
        {
            return NodeCallContext ?? NodeContext;
        }
    }
}
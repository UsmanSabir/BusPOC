﻿using System;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Subscribers;
using NS.BatchEngine.Logs;

namespace NS.BatchEngine.Listeners
{
    public class LogContextTaskListener:ITaskListener
    {
        private readonly ILogger _logger;

        public LogContextTaskListener(ILoggerFactory logger)
        {
            _logger = logger.CreateLogger();
        }

        public void BeforeExecute(ITaskContext taskContext)
        {
            int refId;

            if (!int.TryParse(taskContext.State.Payload, out refId))
            {
                _logger.Warn($"LogContext Payload is not int. Initializing refId with taskId taskContext.State.Id. Original Payload: '{taskContext.State.Payload}'");
                try
                {
                    refId = (int)taskContext.State.Id;
                }
                catch (Exception e)
                {
                    _logger.Warn($"Error setting RefId in Task LogContext. Reverting to 0. {e.Message}");
                    refId = 0;
                }
            }
            
            var contextToLog = ContextHost.GetCurrentContext().Copy(taskContext.ProcessExecutionContext.ProcessingDate, refId);
            contextToLog.ProcessQueueId = (int) taskContext.State.ProcessId;//backward compatibility
            contextToLog.ProcessId = taskContext.ProcessExecutionContext.Configuration.ProcessId;
            contextToLog.ContextId = taskContext.ProcessExecutionContext.ProcessState.CorrelationId;
            try
            {
                contextToLog.TaskId = (int) taskContext.State.Id;
            }
            catch (Exception e)
            {
                _logger.Warn($"Error setting TaskId in Task LogContext. Reverting to 0. {e.Message}");
                contextToLog.TaskId = 0;
            }
            //contextToLog.Status
            //contextToLog.TaskStatus
            ContextHost.SetAppContext(contextToLog);
            //LogContext.ContextToLog = contextToLog; 
        }

        public void AfterExecute(ITaskContext taskContext)
        {
            
        }

        public string Name { get; } = nameof(LogContextTaskListener);
    }

    public class LogContextProcessListener : ProcessSubscriberBase //IProcessSubscriber
    {
        private readonly ILogger _logger;

        public LogContextProcessListener(ILoggerFactory logger)
        {
            _logger = logger.CreateLogger();
        }

       
        //public string Name { get; } = nameof(LogContextTaskListener);
        public override int ProcessId { get; } = 0;
        public override bool CanExecute(IProcessExecutionContext context)
        {
            //todo: check if can execute i.e. is month-end or day-end
            if (context.Configuration.IsMonthEnd)
            {
                
            }

            return true;
        }


        public override void BeforeVolumeGenerating(IProcessExecutionContext context)
        {
            var contextToLog = ContextHost.NodeContext.Copy(context.ProcessingDate, (int)context.ProcessState.Id);
            contextToLog.ProcessQueueId = (int)context.ProcessState.Id;//backward compatibility
            contextToLog.ProcessId = context.Configuration.ProcessId;
            contextToLog.TaskId = 0;
            contextToLog.ContextId = context.ProcessState.CorrelationId;
            //contextToLog.Status
            //contextToLog.TaskStatus
            ContextHost.SetAppContext(contextToLog);
        }

        public override void ProcessStarting(IProcessExecutionContext context)
        {
            var contextToLog = ContextHost.NodeContext.Copy(context.ProcessingDate, (int)context.ProcessState.Id);
            contextToLog.ProcessQueueId = (int)context.ProcessState.Id;//backward compatibility
            contextToLog.ProcessId = context.Configuration.ProcessId;
            contextToLog.ContextId = context.ProcessState.CorrelationId;
            contextToLog.TaskId = 0;
            //contextToLog.Status
            //contextToLog.TaskStatus
            ContextHost.SetAppContext(contextToLog);
        }
    }
}
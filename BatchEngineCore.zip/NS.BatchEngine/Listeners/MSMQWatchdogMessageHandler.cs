﻿using BatchEngine.Core.Process;

namespace NS.BatchEngine.Listeners
{
    public class MSMQWatchdogMessageHandler:IPrimarySecondaryObserver
    {
        private bool _isPrimary = false;

        public void OnPrimary()
        {
            _isPrimary = true;
        }

        public void OnSecondary()
        {
            _isPrimary = false;
        }

        void OnMessageArrived()
        {
            if (_isPrimary)
            {

            }
        }
    }
}
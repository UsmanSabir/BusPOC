﻿using BatchEngine.Core;

namespace NS.BatchEngine.Listeners
{
    public class LogContextSwitchHandler: IContextSwitchHandler
    {
        public void ContextSwitchStarting()
        {
            ContextHost.SetAppContext();
        }

        public void ContextSwitchCompleted()
        {
            ContextHost.SetAppContext();
        }
    }
}
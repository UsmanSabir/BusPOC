﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using NS.BatchEngine.Empty;

namespace NS.BatchEngine.PubSub.Database
{
    public class DatabasePubSubFactory: IPubSubFactory
    {
        private readonly string _connectionString;

        readonly object _lock=new object();
        //private UdpPortSubscriber _portSubscriber;
        protected const string PubChannel = "BPEMChannel";
        private readonly IFrameworkLogger _systemLogger;
#if !Interfacing
        readonly List<VirtualSubscriber> _activeSubscribers = new List<VirtualSubscriber>();
        private DatabaseListener _dbListener;
#endif
        public DatabasePubSubFactory(IBatchLoggerFactory logger, string connectionString)
        {
            _connectionString = connectionString;
            _systemLogger = logger.GetSystemLogger();
            //_portSubscriber=new UdpPortSubscriber(_ip, port, _systemLogger, OnMessageReceived);
            //_dbListener=new DatabaseListener(_systemLogger, OnMessageReceived);
        }
#if !Interfacing

        private void OnMessageReceived(string channel, string type, string message)
        {
            IEnumerable<VirtualSubscriber> subscribers;
            lock (_lock)
            {
                subscribers = _activeSubscribers.Where(ch=>ch.Channel==channel).ToList();
            }
            foreach (var subscriber in subscribers)
            {
                subscriber.OnMessageReceived(type, message);
            }
        }
        
#endif
        public IDistributedMessagePublisher GetPublisher(CancellationToken token, ILogger logger, string channelName = null)
        {
            if (nameof(IWatchDogMessage).Equals(channelName))
            {
                return new DatabasePublisher(channelName, logger, _connectionString);
            }
            else
            {
                return new EmptyPub();
            }
            
        }

        public IDistributedMessageSubscriber GetSubscriber(CancellationToken token, ILogger logger, string channelName = null)
        {

#if !Interfacing
            var ch = channelName ?? PubChannel;

            
            VirtualSubscriber virtualSubscriber = new VirtualSubscriber((s) =>
            {
                lock (_lock)
                {
                    _activeSubscribers.Remove(s);
                    _systemLogger.Trace("DB PubSub channel {channel} removed", s.Channel);
                    if (_activeSubscribers.Count == 0)
                    {
                        _dbListener.Dispose();
                        _dbListener = null;
                        _systemLogger.Info("DB PubSub listener closed due to empty subscribers");
                    }
                }
            }, ch);

            lock (_lock)
            {
                _activeSubscribers.Add(virtualSubscriber);
                
                if (_dbListener == null)
                {
                    _dbListener=new DatabaseListener(_systemLogger, OnMessageReceived, _connectionString);
                    _dbListener.Start(token);//todo
                }
            }
            
            return virtualSubscriber;
#else
            return null;
#endif

        }
    }
}
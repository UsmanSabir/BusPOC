﻿using System;
using System.Net;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Helper;
using BatchEngine.Models.Entities;
using NS.ORM;

namespace NS.BatchEngine.PubSub.Database
{
    public class DatabasePublisher:IDistributedMessagePublisher
    {
        private readonly JsonSerializer _serializer;
        protected const string PubChannel = "BPEMChannel";
        private readonly string _customChannel;
        private readonly ILogger _logger;
        private readonly string _connectionString;

        public DatabasePublisher(string channel, ILogger logger, string connectionString)
        {
            _customChannel = channel;
            _logger = logger;
            _connectionString = connectionString;
            _serializer = new JsonSerializer();
        }
        public void Dispose()
        {
            
        }

        public void PublishMessage(string message, string type)
        {
            Robustness.Instance.SafeCall(() =>
            {
                EntityContextExt<BatchEngineCommand> ext;
                if(string.IsNullOrWhiteSpace(_connectionString))
                    ext = EntityContextExt.Create<BatchEngineCommand>();
                else
                    ext = EntityContextExt.Create<BatchEngineCommand>(_connectionString);

                var command = ext.CreateNew();
                command.CHANNEL = _customChannel;
                command.COMMAND = message;
                command.TYPE = type;
#if Interfacing
                command.PUBLISHEDBYNODE = Dns.GetHostName();
#else
                command.PUBLISHEDBYNODE = NodeSettings.Instance.Name;
#endif

                command.PUBLISHEDTIME = DateTime.UtcNow;
                ext.Persist();
            }, _logger);
        }

        public void PublishMessage<T>(T message)
        {
            var json = _serializer.SerializeToString(message);
            var type = message.GetType().Name;
            PublishMessage(json, type);
        }
    }
}
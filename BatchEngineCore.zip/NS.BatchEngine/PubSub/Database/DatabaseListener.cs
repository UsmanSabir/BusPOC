﻿using System;
using System.Configuration;
using System.Linq;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Helper;
using BatchEngine.Models.Entities;
using NS.ORM;

namespace NS.BatchEngine.PubSub.Database
{
    public class DatabaseListener:RepeatingProcess
    {
        DateTime _lastSync= DateTime.UtcNow;// SQLDeleteDbPubSubHistory
        readonly TimeSpan _deleteInterval = TimeSpan.FromMinutes(30);
        DateTime _lastDelete = new DateTime(1901, 1, 1);

        private readonly Action<string, string, string> _onMessageReceived;
        private readonly string _connectionString;

        public DatabaseListener(ILogger logger, Action<string, string, string> onMessageReceived, string connectionString) : base("DbCommandListener", logger)
        {
            _onMessageReceived = onMessageReceived;
            _connectionString = connectionString;

            var interval = ConfigurationManager.AppSettings["DbCommandPollIntervalSecs"] ?? "5";
            int pollInterval = 5; //sec
            if (!string.IsNullOrWhiteSpace(interval))
            {
                int.TryParse(interval, out pollInterval);
            }

            if (pollInterval <= 0 || pollInterval > 999)
                pollInterval = 5;

            base.Interval= TimeSpan.FromSeconds(pollInterval);
        }

        internal override void PerformIteration()
        {
            CheckPendingCommands();
        }

        void CheckPendingCommands()
        {
            EntityContextExt<BatchEngineCommand> ext;
            Robustness.Instance.SafeCall(() =>
            {
                if (string.IsNullOrWhiteSpace(_connectionString))
                    ext = EntityContextExt.Create<BatchEngineCommand>();
                else
                    ext = EntityContextExt.Create<BatchEngineCommand>(_connectionString);


                ext.Read(r => r.PUBLISHEDTIME > _lastSync); //r.ISHANDLEDBYMASTER == false); //r.PUBLISHEDTIME >= _lastSync && 
                _lastSync = DateTime.UtcNow;

                if (ext.Entity.Count > 0)
                {
                    foreach (var command in ext.Entity.OrderBy(r => r.PUBLISHEDTIME))
                    {
                        Robustness.Instance.SafeCall(() =>
                        {
                            _onMessageReceived?.Invoke(command.CHANNEL, command.TYPE, command.COMMAND);
                            if (NodeSettings.Instance.IsPrimary)
                            {
                                command.ISHANDLEDBYMASTER = true;
                                command.HANDLERNODEID = NodeSettings.Instance.Name;
                            }

                        }, Logger);
                    }

                    Robustness.Instance.SafeCall(() => { ext.Persist(); }, Logger);

                }

            });

            if (DateTime.UtcNow - _lastDelete > _deleteInterval)
            {
                Robustness.Instance.SafeCall(() =>
                {
                    _lastDelete = DateTime.UtcNow;

                    DbController dbController;

                    if (string.IsNullOrWhiteSpace(_connectionString))
                    {
                        dbController = DbController.Create();
                    }
                    else
                    {
                        dbController = DbController.Create(_connectionString);
                    }

                    dbController.ExecuteNonQuery(Constant.SQLDeleteDbPubSubHistory, DateTime.UtcNow.AddHours(-1));

                });
                
            }

            //var command = ext.CreateNew();
            //command.CHANNEL = _customChannel;
            //command.COMMAND = message;
            //command.TYPE = type;
            //command.PUBLISHEDBYNODE = NodeSettings.Instance.Name;
            //command.PUBLISHEDTIME = DateTime.UtcNow;
        }


    }
}
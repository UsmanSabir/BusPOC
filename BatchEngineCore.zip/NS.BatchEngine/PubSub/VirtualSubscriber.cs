﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using BatchEngine.Core;
using BatchEngine.Core.Helper;
using NS.BatchEngine.Redis;

namespace NS.BatchEngine.PubSub
{
    class VirtualSubscriber : IDistributedMessageSubscriber
    {
        private readonly RedisSerializer _serializer=new RedisSerializer();
        readonly ConcurrentBag<KeyValuePair<string, Action<string>>> _subscriptions = new ConcurrentBag<KeyValuePair<string, Action<string>>>();
        private readonly Action<VirtualSubscriber> _action;
        private readonly string _channel;

        public VirtualSubscriber(Action<VirtualSubscriber> action, string channel)
        {
            this._action = action;
            _channel = channel;
        }

        internal string Channel
        {
            get { return _channel; }
        }

        public void Dispose()
        {
            _action?.Invoke(this);
        }

        public void Subscribe(string message, Action<string> action)
        {
            _subscriptions.Add(new KeyValuePair<string, Action<string>>(message, action));
        }

        public void Subscribe<T>(Action<T> action)
        {
            if (action == null)
                return;

            void ActString(string s)
            {
                var item = _serializer.DeserializeFromString<T>(s);

                //WeakAction w=new WeakAction(action);//todo, do we need to store weak reference
                action(item);
            }

            var typeName = typeof(T).Name;

            Subscribe(typeName, ActString); 
        }

        internal void OnMessageReceived(string type, string message)
        {
            //var type = msgParts[2];
            //3 and 4 reserved
            var packet = message; // msgParts[5];

            //var isWatchDogMsg = type == nameof(IWatchDogMessage);
            foreach (var pair in _subscriptions)
            {
                if (type == pair.Key)
                {
                    Robustness.Instance.SafeCall(() =>
                    {
                        pair.Value.Invoke(packet); //BeginInvoke(packet, null, null);
                    });
                }
            }
        }
        
    }
}
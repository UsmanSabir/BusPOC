﻿using BatchEngine.Core;
using NS.ServiceModel;

namespace NS.BatchEngine.ServiceChannels
{
    public static class ProcessResourceExt
    {
        public static ProxyClient<T> GetService<T>(this IProcessExecutionContext context, bool preferLocalInstance=false) //where T:IDisposable
        {
            var result = context.GetSetResource($"R_{typeof(T).Name}", () =>
            {
                ProxyClient<T> proxy = new ProxyClient<T>(preferLocalInstance);
                return proxy;
            });

            return result;
        }

        public static ProxyClient<T> GetService<T>(this ITaskContext context, bool preferLocalInstance=false)
        {
            var result = context.ProcessExecutionContext.GetService<T>(preferLocalInstance);
            return result;
        }

        static void test()
        {

            
        }
    }
}
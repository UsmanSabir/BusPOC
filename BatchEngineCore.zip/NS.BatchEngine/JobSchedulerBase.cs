﻿using System;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.JobScheduler;
using BatchEngine.Core.Serializers;
using BatchEngine.Models.Entities;
using NS.BaseModels;
using NS.ORM;

namespace NS.BatchEngine
{
    internal abstract class JobSchedulerBase
    {
        private readonly IBatchEngineQueueService _batchEngineQueueService;
        private readonly ISerializer _ser;
        protected internal IFrameworkLogger SystemLogger;

        protected JobSchedulerBase(ISerializersFactory factory, IBatchLoggerFactory loggerFactory, 
            IBatchEngineQueueService batchEngineQueueService)
        {
            _batchEngineQueueService = batchEngineQueueService;
            SystemLogger = loggerFactory.GetSystemLogger();
            
            //_ser = SerializersFactory.Instance.GetSerializer<List<JobCriteria>>();
            //JsonSerializer serializer=new JsonSerializer();
            _ser = factory.GetSerializer(typeof(JobCriteria));
        }

        public long CreateProcessJob(int processId, List<JobCriteria> criteria, string submittedBy, int invokeTypeId, bool hasPriority = false)
        {
            return CreateJob(new List<int>() {processId}, criteria, submittedBy, invokeTypeId, hasPriority);
        }

        public long CreateJob(int groupId, List<JobCriteria> criteria, string submittedBy, int invokeTypeId, bool hasPriority)
        {
            BatchGroupState group=new BatchGroupState()
            //BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(@group)
            {
                GRP_KEY = groupId,
                CRIT = _ser.SerializeToString(criteria),
                IS_GENR = false,
                IS_STOP = false,
                IS_FNSH = false,
                INVK_TYPE_ID = invokeTypeId,
                SBMT_BY = submittedBy,
                //State = CompletionStatus.Pending.Name,
                CURR_STAT= CompletionStatus.Pending.Name,
                //ISMANUAL = isResubmission || criteria.First().IsManual,
                HAS_PRTY = hasPriority
            };

            var ext = EntityContextExt.Create(new[] {@group});
            ext.Persist();

            Publish(group.BTCH_GRP_STAT_ID);

            return @group.BTCH_GRP_STAT_ID;
        }

        public long CreateJob(int groupId, List<int> processIds, List<JobCriteria> criteria, string submittedBy, int invokeTypeId, bool hasPriority = false)
        {
            BatchGroupState group = new BatchGroupState()
            //BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(@group)
            {
                GRP_KEY = groupId,
                PAY_LOAD = _ser.SerializeToString(processIds),
                CRIT = _ser.SerializeToString(criteria),
                IS_GENR = false,
                IS_STOP = false,
                //ISRESUBMISSION = isResubmission,
                INVK_TYPE_ID = invokeTypeId,
                IS_FNSH = false,
                SBMT_BY = submittedBy,
                //State = CompletionStatus.Pending.Name,
                CURR_STAT = CompletionStatus.Pending.Name,
                //ISMANUAL = isResubmission || criteria.First().IsManual,
                HAS_PRTY = hasPriority
            };

            var ext = EntityContextExt.Create(new[] { @group });
            ext.Persist();

            Publish(group.BTCH_GRP_STAT_ID);

            return group.BTCH_GRP_STAT_ID;
        }

        public long CreateJob(List<int> processIds, List<JobCriteria> criteria, string submittedBy, int invokeTypeId, bool hasPriority)
        {
            BatchGroupState group = new BatchGroupState()
            //BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(@group)
            {
                PAY_LOAD = _ser.SerializeToString(processIds),
                CRIT = _ser.SerializeToString(criteria),
                IS_GENR = false,
                IS_STOP = false,
                INVK_TYPE_ID = invokeTypeId,
                IS_FNSH = false,
                SBMT_BY = submittedBy,
                //State = CompletionStatus.Pending.Name,
                CURR_STAT = CompletionStatus.Pending.Name,
                //ISMANUAL = isResubmission || criteria.First().IsManual,
                HAS_PRTY = hasPriority
            };
            
            var ext = EntityContextExt.Create(new[] { @group });
            ext.Persist();

            Publish(group.BTCH_GRP_STAT_ID);

            return group.BTCH_GRP_STAT_ID;
        }

        public long CreateQueueJob(List<int> processIds, List<JobCriteria> criteria, string queueName, string submittedBy, int invokeTypeId, bool hasPriority)
        {
            if (processIds==null || processIds.Count==0)
                throw new ArgumentNullException(nameof(processIds));

            if (string.IsNullOrWhiteSpace(queueName))
                throw new ArgumentNullException(nameof(queueName));

            BatchGroupState group = new BatchGroupState()
            //BatchGroupStateWrapper groupEntity = new BatchGroupStateWrapper(@group)
            {
                PAY_LOAD = _ser.SerializeToString(processIds),
                CRIT = _ser.SerializeToString(criteria),
                IS_GENR = false,
                IS_STOP = false,
                INVK_TYPE_ID = invokeTypeId,
                IS_FNSH = false,
                SBMT_BY = submittedBy,
                //State = CompletionStatus.Pending.Name,
                CURR_STAT = CompletionStatus.Pending.Name,
                //ISMANUAL = isResubmission || criteria.First().IsManual,
                QUEU_NME = queueName,
                HAS_PRTY = hasPriority
            };

            using (var unitOfWorkManager = new DataQueueManager())
            {
                //unitOfWorkManager.QueuePersist(new List<BatchGroupState>{ group });
                unitOfWorkManager.QueueCommand(uow =>
                {
                    var ext = EntityContextExt.Create(new[] { @group }).UsingUnitOfWork(uow);
                    ext.Persist();

                    var queueSeq = _batchEngineQueueService.GetProcessSeqNoForQueue(queueName, @group.BTCH_GRP_STAT_ID, new TransactionWrapper(uow));
                    @group.QUEU_SEQ = queueSeq;
                    @group.State = EntityState.DataModified; //trigger update command
                    ext.Persist();
                });

                unitOfWorkManager.Commit();
            }

            //var ext = EntityContextExt.Create(new[] { group });
            //using (var unitOfWork = ext.InitiateUnitOfWork())
            //{
            //    ext.Persist();

            //    var queueSeq = _batchEngineQueueService.GetProcessSeqNoForQueue(queueName,@group.ID, new TransactionWrapper(unitOfWork));
            //    group.QUEUESEQ = queueSeq;
            //    ext.Persist();

            //    unitOfWork.Save();
            //}
            

            Publish(group.BTCH_GRP_STAT_ID);

            return group.BTCH_GRP_STAT_ID;
        }

        protected abstract void Publish(long groupId);

        
    }
}
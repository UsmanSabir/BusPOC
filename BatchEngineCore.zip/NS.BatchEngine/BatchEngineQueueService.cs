﻿using System;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core;
using BatchEngine.Core.JobScheduler;
using BatchEngine.Models.Entities;
using NS.ORM;
using NS.ORM.UoW;

namespace NS.BatchEngine
{
    public class BatchEngineQueueService : IBatchEngineQueueService
    {
        public int GetProcessSeqNoForQueue(string queueName, long refId, ITransaction transaction)
        {
            //var contextExt = EntityContextExt.Create<BatchEngineQueue>().UsingUnitOfWork(transaction as IUnitOfWork);
            var controller = DbController.Create((IUnitOfWork) transaction.TransactionObject);
            var quieId = controller.GetCustomItem<int>(Constant.SQLAddProcessToQueue, queueName, refId);
            return quieId;
        }

        public bool IsQueueSeqReached(string queueName, int seqNumber, long refId)
        {
            var previousQueue = GetPreviousQueue(queueName, seqNumber); //previousQueue //BatchEngineQueue.GetPreviousQueue(queueName, seqNumber); //previousQueue
            if (previousQueue==null || previousQueue.Count==0)
            {
                return true;
            }

            return previousQueue.First().IS_FNSH;

            //int lastSeq = seqNumber - 1;
            //var ext = EntityContextExt.Create<BatchEngineQueue>();
            //ext.Read(s => s.QUEUENAME == queueName && s.QUEUESEQ == lastSeq);
            //if (ext.Entity.Count == 0)
            //    return true; //no previous items in queue

            //return ext.Entity.First().ISFINISHED;
        }

        public List<BatchEngineQueue> GetPreviousQueue(
            String queName, int queSeq)
        {
            EntityContextExt<BatchEngineQueue> c = EntityContextExt.Create<BatchEngineQueue>();
            c.ReadEntityByKey(new Dictionary<string, object>()
                {
                    { "queName" , queName },
                    { "queSeq" , queSeq },
                }, nameof(GetPreviousQueue)
            );
            //if (fillChilds)
            //    c.FillChilds();
            return c.Entity;
        }

        public bool MarkQueueSeqFinish(string queueName, int seqNumber, ITransaction transaction)
        {
            var controller = DbController.Create((IUnitOfWork) transaction.TransactionObject);
            var rowsEffected = controller.ExecuteNonQuery(Constant.SQLMarkQueueFinished, queueName, seqNumber);
            return rowsEffected > 0;
        }
    }
}
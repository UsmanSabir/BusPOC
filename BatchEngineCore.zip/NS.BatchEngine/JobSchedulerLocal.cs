﻿using System;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices.Events;
using BatchEngine.Core.JobScheduler;
using BatchEngine.Core.Serializers;

namespace NS.BatchEngine
{
    internal class JobSchedulerLocal:JobSchedulerBase
    {
        private readonly IEventAggregator _eventAggregator;
        
        public JobSchedulerLocal(ISerializersFactory factory, IBatchLoggerFactory loggerFactory, 
            IBatchEngineQueueService batchEngineQueueService, IEventAggregator eventAggregator)
            : base(factory, loggerFactory, batchEngineQueueService)
        {
            _eventAggregator = eventAggregator;
        }

        protected override void Publish(long groupId)
        {
            try
            {
                _eventAggregator.PublishAsync(this, Constants.EventProcessGroupAdded, groupId.ToString());
            }
            catch (Exception e)
            {
                SystemLogger.Error("Failed to publish ProcessGroupAddedMessage for groupId {groupId} having error {error}", groupId, e);
            }
        }
    }
}
﻿namespace NS.BatchEngine.Redis
{
    public class RedisManagerPool
    {
        
    }
}
﻿using System;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.Helper;

namespace NS.BatchEngine.Logs
{
    public class BatchEngineLoggerFactory : IBatchLoggerFactory
    {
        public BatchEngineLoggerFactory(ILoggerFactory instance)
        {
            Instance = instance;
        }

        ILoggerFactory Instance { get; set; } 

        public IFrameworkLogger GetSystemLogger()
        {
            // return new FrameworkLogger(CreateLogger("System")); 
            return new FrameworkLogger(new CorrelationStringLogger("System", CreateLogger("System")));// 
        }

        public ILogger GetTaskLogger(ITaskState taskState, Guid correlationId)
        {
#if !DEBUG
            var processContext = ContextHost.GetCurrentContext().Copy();

            int refId;

            if (!int.TryParse(taskState.Payload, out refId))
            {
                try
                {
                    refId = (int)taskState.Id;
                }
                catch (Exception e)
                {
                    //_logger.Warn($"Error setting RefId in Task LogContext. Reverting to 0. {e.Message}");
                    refId = 0;
                }
            }
            processContext.ProcessId = taskState.ProcessId;
            Robustness.Instance.SafeCall(() => { processContext.ReferenceId = refId; });
            processContext.ContextId = correlationId;


            return new ProcessLogger(processContext, taskState);

#else
            return new CorrelationLogger(correlationId, CreateLogger());
            //, $"TaskId {taskId}, ProcessId {processId}, correlationId {correlationId} =>");
#endif
        }

        public ILogger GetGroupLogger(long groupId, int groupKey)
        {
            //return new PrependedLogger(CreateLogger(), $"GroupId {groupId}, GroupKey {groupKey} =>");
            return new CorrelationStringLogger(groupId.ToString(), CreateLogger());
        }

        public ILogger GetProcessLogger(IProcessState state) //long processId, long processKey, Guid correlationId)
        {
#if !DEBUG
            var processContext = ContextHost.GetCurrentContext().Copy();

            processContext.ProcessId = state.Id;
            Robustness.Instance.SafeCall(() =>
            {
                processContext.ReferenceId = (int?)state.Id;
            });
            processContext.ContextId = state.CorrelationId;

            return new ProcessLogger(processContext, state);

#else
            return new PrependedLogger(CreateLogger(), $"ProcessId {state.Id}, ProcessKey {state.ProcessId}, correlationId {state.CorrelationId}  =>");

            //return new CorrelationLogger(correlationId, CreateLogger());
#endif


        }

        public ILogger CreateLogger(string name = null)
        {
            return Instance.CreateLogger(name);
        }
    }
}
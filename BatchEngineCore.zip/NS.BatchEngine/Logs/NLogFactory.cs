﻿using BatchEngine.Core;
using NLog;
using ILogger = BatchEngine.Core.CoreServices.ILogger;


namespace NS.BatchEngine.Logs
{
    public class NLogFactory: ILoggerFactory
    {
        
        public static Logger Create(string name="logger")
        {
            var logger = LogManager.GetLogger(name);
            return logger;
        }

        public ILogger CreateLogger(string name = "logger")
        {
            //var logger = LogManager.GetLogger(name);
            return new NLogWrapper();
            //return logger;
        }
    }
}
﻿using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using NS.Configurations.Helper;
using NS.ExceptionHandling;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using NS.Utilities.Helper;
using System;
using System.Configuration;
using System.Linq.Expressions;

namespace NS.BatchProcessing.Business.Helpers
{
    public class TaskLogger : ILogger
    {

        // public static string MsgExecuteBatch = "Execution started for <<process:#ProcessId#;processqueue:#ProcessQueueId#;Batch:#BatchId#>>.";
        //public static string MsgExecuteBatch = "Execution started for <<process no:{0};with processqueue no:{1};and Batch no:{2}>>.";
        #region Messages

        public static string MsgExecuteBatch = "Execution started for Batch no:{2} , <<process no:{0} with processqueue no:{1};>>.";
        public static string MsgGenerateBatch = "Batch generation started for <<process no:{0};with processqueue no:{1}>>.";
        public static string MsgProcessCannotExecute = "Process No: {0} could not be executed on non-working day.";
        public static string MsgProcessCanExecuteOnMonthEnd = "Process No: {0} can only be executed on month end.";
        public static string MsgProcExecuted = "Execution completed for <<process no:{0};with processqueue no:{1}>>.";
        public static string MsgProcIhExport = "Export started uisng integration hub with MsgFlowType no:{0} for <<process no:{1};with processqueue no:{2}>>.";
        public static string MsgProcIhExportEnd = "Export End uisng integration hub for <<process no:{0};with processqueue no:{1}>>.";
        public static string MsgProcIhExportEndWithError = "Export is not successfull uisng integration hub for <<process no:{0};with processqueue no:{1}>>.";
        public static string MsgSaveBatch = "Batch saved for  Batch no:{2} ,<<process no:{0};with processqueue no:{1};>>.";
        public static string MsgSaveTaskItem = "TaskItem saved for taskitem no:{3} , <<process no:{0};with processqueue no:{1} , Batch no:{2} and refId:{4}>>. ";
        public static string MsgSaveListOfTaskItem = "TaskItem saved for taskitem no:{2} , <<process no:{0};with processqueue no:{1}>>. ";
        public static string MsgExecutingTaskItem = "TaskItem executing for taskitem:{3} , <<process no:{0};with processqueue no:{1} , Batch:{2} and refId:{4}>>. ";
        public static string MsgExecutingTaskItemNotStarted = "TaskItem execution not started against taskitem:{3} due to PreStartTaskExecution for <<process no:{0};with processqueue no:{1}, Batch:{2} and refId:{4}>>. ";
        public static string MsgMaxConfiguredBatches = "<<Process no:{0};with processqueue no:{1};and Batch no:{2}>> cannot be executed due to limit of max configured Batch per instance:{3}.";
        public static string MsgWorkflowPreConfigError = "<<Process no:{0};with processqueue no:{1};and Batch no:{2}>> cannot be executed due to pre start configured workflow not working successfully.";
        public static string MsgProcessValidationsError = "<<Process no:{0};with processqueue no:{1}>> cannot be processed due to validation errors";
        public static string MsgProcessCompleted = "<<Process no:{0};with processqueue no:{1}>> completed successfully.";
        public static string MsgProcessError = "<<Process no:{0};with processqueue no:{1}>> has all records with error status.";
        public static string MsgProcessStarted = "<<Process no:{0};with processqueue no:{1}>> started for processing.";
        public static string MsgProcessCompletedWithError = "<<Process no:{0};with processqueue no:{1}>> completed with errors.";
        public static string MsgConcatInfo = "<<process no:{0} , processqueue no:{1} , Batch no:{2} , taskitem:{3} , and refId:{4}>>.";
        public static string MsgTaskCompletedSuccesfully = "TaskItem executed successfully for taskitem:{3} , <<process no:{0};with processqueue no:{1}, Batch:{2} and refId:{4}>>.";
        public static string MsgTaskCompletedWithError = "TaskItem executed with error for taskitem:{3} , <<process no:{0};with processqueue no:{1} ,Batch:{2} and refId:{4}>>.";
        public static string MsgBatchTimeout = "<<Batch no:{0};with processqueue no:{1}>> is timed out.";
        public static string MsgProcessTimeout = "<<Process no:{0};with processqueue no:{1}>> is timed out.";
        public static string MsgProcessRetry = "<<Process no:{0};with processqueue no:{1}>> is reset for retry#{2}.";
        public static string MsgBatchRetry = "<<Batch no:{0};with processqueue no:{1}>> is reset for retry#{2}.";

        public static string MsgBatchCompletedSuccesfully = "Batch executed successfully for Batch no:{2} , <<process no:{0}; with processqueue no:{1};>>.";
        public static string MsgBatchCompletedWithError = "Batch executed with error for Batch no:{2} , <<process no:{0};with processqueue no:{1} >>.";
        public static string BatchItemCompletedSuccesfully = "Batch Item executed successfully for Batch no:{2} , <<process no:{0}; with processqueue no:{1};>>.";
        public static string BatchItemCompletedWithError = "Batch Item executed with error for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string ApplicationNumberNullError = "Error: Application Number is null for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string ApplicationNumberLengthError = "Error: Application Number length is greater than 22 for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string ContractNumberNullError = "Error: Contract Number is null for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string StatusNullError = "Error: Status is null for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string ProperStatusError = "Error: Status is not Settled or Irregular for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string ResultSetNullError = "Error: Contract Number does not exist for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string ContractNotActiveError = "Error: Contract is not active for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string ChecklistNullError = "Error: Contract Number does not exist for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string ChecklistStatusKeyError = "Error: Chcklist status key is verified or waived against approve when pending for Import Item Id: {2}, Batch Item no:{0} , <<Batch no:{1} >>.";
        public static string DayEndCompletionTimeMsg = "Dayend process started at {0} and completed at {1}. It took {2} minutes for day end to complete."; 
        #endregion

        #region Private Memebers
        private readonly string _machineIp;
        Context _context;
        ITaskState _state;

        public TaskLogger(Context context, ITaskState state)
        {
            _machineIp = GetMachineIpOrName();
            _context = context;
            _state = state;
        }

        private string GetMachineIpOrName()
        {
            try
            {
                return IpAddress.GetLocalIpAddress();

                // return ConfigurationManager.AppSettings["NodeAddress"];
                // return ConfigUtility.GetIPv4Address();
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
                DisplayExceptionAtConsole(ex);
            }
            return Environment.MachineName;

        }
        #endregion


        /// <summary>
        /// Log
        /// </summary>
        /// <param name="customMessage"></param>
        /// <param name="context"></param>
        /// <param name="status"></param>
        /// <param name="retryCount"></param>
        /// <param name="referenceId"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="timeOutInd"></param>
        /// <param name="logLevel"></param>
        public void Log(string customMessage, Context context, string status, int? retryCount, int? referenceId, DateTime? startDate, DateTime? endDate, bool? timeOutInd = false, NSLogLevel logLevel = NSLogLevel.Info)
        {

            context.CustomMessage = customMessage;

            context.LogLevel = logLevel;
            context.ReferenceId = referenceId;
            //to:do check to use other field for nodeid and subtenantid
            context.ServerIp = _machineIp + ":" + NodeSettings.Instance.Name + "_" + context.SubTenantId;
            context.StatusKey = status;
            context.RetryCount = retryCount.HasValue ? retryCount.Value : 0;
            context.ProcessStartDate = startDate;
            context.ProcessEndDate = endDate;
            context.TimeOutInd = timeOutInd.HasValue ? timeOutInd.Value : false;

            //LogContext.ContextToLog = Context;
            //LogContext.ContextToLog.ContextId = Context.ContextId;

            ExceptionHandler.Log(context);

            context.SubTenantId = NodeSettings.Instance.SubTenantId;

            //BatchProcessing.Helpers.ProcessHelper.SetSubtenantIdFromConfig(context); //todo, remove when fixed from NS team , first team calling log change the SubtenantID,

            context.CustomMessage = string.Empty;

        }
        public void LogMessage(string customMessage, Context context,NSLogLevel logLevel = NSLogLevel.Info)
        {

            context.CustomMessage = customMessage;

            context.LogLevel = logLevel;
            //to:do check to use other field for nodeid and subtenantid
            context.ServerIp = _machineIp + ":" + NodeSettings.Instance.Name + "_" + context.SubTenantId;
                        

            //LogContext.ContextToLog = Context;
            //LogContext.ContextToLog.ContextId = Context.ContextId;

            ExceptionHandler.Log(context);
            context.SubTenantId = NodeSettings.Instance.SubTenantId;

            //BatchProcessing.Helpers.ProcessHelper.SetSubtenantIdFromConfig(context); //todo, remove when fixed from NS team , first team calling log change the SubtenantID,

            context.CustomMessage = string.Empty;

        }

        ///// <summary>
        ///// GetApplicationMessage
        ///// </summary>
        ///// <param name="msgCode"></param>
        ///// <param name="parameters"></param>
        ///// <returns></returns>
        //public static string GetApplicationMessage(string msgCode, params Expression<Func<string, string>>[] parameters)
        //{
        //    return ApplicationMessages.GetMessageString(msgCode, parameters);

        //}

        /// <summary>
        /// DisplayExceptionAtConsole
        /// </summary>
        /// <param name="ex"></param>
        public void DisplayExceptionAtConsole(Exception ex)
        {
            if (Environment.UserInteractive)
                Console.WriteLine("Exception occured while processing:" + ex.Message);
        }

        public void Debug(string msg)
        {
            Log(msg, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn);
        }

        public void Trace(string message, params object[] args)
        {
            Log(message, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn,false,NSLogLevel.Trace);
        }

        public void Info(string info, params object[] args)
        {
            Log(info, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn);
        }

        public void Warn(string warn, params object[] args)
        {
            Log(warn, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn, false, NSLogLevel.Warn);
        }

        public void Warn(string message, Exception e, params object[] args)
        {
            Log(message + " StackTrace: " + e.StackTrace, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn, false, NSLogLevel.Trace);
        }

        public void Error(string error)
        {
            Log(error, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn, false, NSLogLevel.Error);
        }

        public void Error(string error, params object[] args)
        {
            Log(error, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn, false, NSLogLevel.Error);
        }

        public void Error(string error, Exception exception, params object[] args)
        {
            Log(error + " StackTrace: " + exception.StackTrace, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn, false, NSLogLevel.Error);
        }

        public void Fatal(string error, params object[] args)
        {
            Log(error, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn, false, NSLogLevel.Fatal);
        }

        public void Fatal(string error, Exception exception, params object[] args)
        {
            Log(error + " StackTrace: " + exception, _context, _state.Status.Name, _state.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn, false, NSLogLevel.Fatal);
        }
    }
}

﻿using System;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using NS.ExceptionHandling;
using NS.Utilities.Context;
using NS.Utilities.Enums;
using NS.Utilities.Helper;

namespace NS.BatchEngine.Logs
{
    public class ProcessLogger : ILogger
    {


        #region Private Memebers
        private readonly string _machineIp;
        readonly Context _context;
        readonly IProcessState _state;
        ITaskState _taskState;

        public ProcessLogger(Context context, IProcessState state)
        {
            _machineIp = GetMachineIpOrName();
            _context = context;
            _state = state;
        }

        public ProcessLogger(Context context, ITaskState taskState)
        {
            _machineIp = GetMachineIpOrName();
            _context = context;
            _taskState = taskState;
        }


        private string GetMachineIpOrName()
        {
            try
            {
                return IpAddress.GetLocalIpAddress();

                // return ConfigurationManager.AppSettings["NodeAddress"];
                // return ConfigUtility.GetIPv4Address();
            }
            catch (Exception ex)
            {
                ExceptionHandler.HandleException(ex, ExceptionHandlingPolicy.LogOnlyPolicy);
                DisplayExceptionAtConsole(ex);
            }
            return Environment.MachineName;

        }
        #endregion


        /// <summary>
        /// Log
        /// </summary>
        /// <param name="customMessage"></param>
        /// <param name="context"></param>
        /// <param name="status"></param>
        /// <param name="retryCount"></param>
        /// <param name="referenceId"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="timeOutInd"></param>
        /// <param name="logLevel"></param>
        public void Log(string customMessage, Context context, string status, int? retryCount, long? referenceId, DateTime? startDate, DateTime? endDate, bool? timeOutInd = false, NSLogLevel logLevel = NSLogLevel.Info)
        {

            context.CustomMessage = customMessage;

            
            //int refId=0;
            //if (referenceId != null && !int.TryParse(referenceId.ToString(), out refId))
            //    refId = 0;

            context.LogLevel = logLevel;
            //context.ReferenceId = refId;
            //to:do check to use other field for nodeid and subtenantid
            context.ServerIp = _machineIp + ":" + NodeSettings.Instance.Name + "_" + context.SubTenantId;
            context.StatusKey = status;
            context.RetryCount = retryCount.HasValue ? retryCount.Value : 0;
            context.ProcessStartDate = startDate;
            context.ProcessEndDate = endDate;
            context.TimeOutInd = timeOutInd.HasValue ? timeOutInd.Value : false;

            //LogContext.ContextToLog = Context;
            //LogContext.ContextToLog.ContextId = Context.ContextId;

#if DEBUG
            Console.WriteLine(customMessage);
#else
            ExceptionHandler.Log(context);
            
#endif
            context.SubTenantId = NodeSettings.Instance.SubTenantId;

            //BatchProcessing.Helpers.ProcessHelper.SetSubtenantIdFromConfig(context); //todo, remove when fixed from NS team , first team calling log change the SubtenantID,

            context.CustomMessage = string.Empty;

        }
        public void LogMessage(string customMessage, Context context,NSLogLevel logLevel = NSLogLevel.Info)
        {

            context.CustomMessage = customMessage;

            context.LogLevel = logLevel;
            //to:do check to use other field for nodeid and subtenantid
            context.ServerIp = _machineIp + ":" + NodeSettings.Instance.Name + "_" + context.SubTenantId;
                        

            //LogContext.ContextToLog = Context;
            //LogContext.ContextToLog.ContextId = Context.ContextId;

            ExceptionHandler.Log(context);
            context.SubTenantId = NodeSettings.Instance.SubTenantId;

            //BatchProcessing.Helpers.ProcessHelper.SetSubtenantIdFromConfig(context); //todo, remove when fixed from NS team , first team calling log change the SubtenantID,

            context.CustomMessage = string.Empty;

        }

        ///// <summary>
        ///// GetApplicationMessage
        ///// </summary>
        ///// <param name="msgCode"></param>
        ///// <param name="parameters"></param>
        ///// <returns></returns>
        //public static string GetApplicationMessage(string msgCode, params Expression<Func<string, string>>[] parameters)
        //{
        //    return ApplicationMessages.GetMessageString(msgCode, parameters);

        //}

        /// <summary>
        /// DisplayExceptionAtConsole
        /// </summary>
        /// <param name="ex"></param>
        public void DisplayExceptionAtConsole(Exception ex)
        {
            if (Environment.UserInteractive)
                Console.WriteLine("Exception occured while processing:" + ex.Message);
        }

        public void Debug(string msg)
        {
            Log(msg, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime);
        }

        public void Trace(string message, params object[] args)
        {
            Log(message, _context, _state?.Status.Name??_taskState.CurrentState, _state?.RetryCount??_taskState.FailedCount, _state?.Id ??_taskState?.Id, _state?.StartTime??_taskState?.StartedOn, _state?.CompleteTime??_taskState?.CompletedOn, false,NSLogLevel.Info);
            //Log(message, _context, _state.Status.Name, _taskState.FailedCount, int.Parse(_state.Payload), _state.StartedOn, _state.CompletedOn, false, NSLogLevel.Trace);
        }

        public void Info(string info, params object[] args)
        {
            //Log(info, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime);
            Log(info, _context, _state?.Status.Name ?? _taskState.CurrentState, _state?.RetryCount ?? _taskState.FailedCount, _state?.Id ?? _taskState?.Id, _state?.StartTime ?? _taskState?.StartedOn, _state?.CompleteTime ?? _taskState?.CompletedOn, false, NSLogLevel.Info);

        }

        public void Warn(string warn, params object[] args)
        {
            //Log(warn, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime, false, NSLogLevel.Warn);
            Log(warn, _context, _state?.Status.Name ?? _taskState.CurrentState, _state?.RetryCount ?? _taskState.FailedCount, _state?.Id ?? _taskState?.Id, _state?.StartTime ?? _taskState?.StartedOn, _state?.CompleteTime ?? _taskState?.CompletedOn, false, NSLogLevel.Warn);
        }

        public void Warn(string message, Exception e, params object[] args)
        {
            //Log(message + " StackTrace: " + e.StackTrace, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime, false, NSLogLevel.Warn);
            Log(message + " StackTrace: " + e.StackTrace, _context, _state?.Status.Name ?? _taskState.CurrentState, _state?.RetryCount ?? _taskState.FailedCount, _state?.Id ?? _taskState?.Id, _state?.StartTime ?? _taskState?.StartedOn, _state?.CompleteTime ?? _taskState?.CompletedOn, false, NSLogLevel.Warn);
        }

        public void Error(string error)
        {
            //Log(error, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime, false, NSLogLevel.Error);
            Log(error, _context, _state?.Status.Name ?? _taskState.CurrentState, _state?.RetryCount ?? _taskState.FailedCount, _state?.Id ?? _taskState?.Id, _state?.StartTime ?? _taskState?.StartedOn, _state?.CompleteTime ?? _taskState?.CompletedOn, false, NSLogLevel.Error);
        }

        public void Error(string error, params object[] args)
        {
            //Log(error, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime, false, NSLogLevel.Error);
            Log(error, _context, _state?.Status.Name ?? _taskState.CurrentState, _state?.RetryCount ?? _taskState.FailedCount, _state?.Id ?? _taskState?.Id, _state?.StartTime ?? _taskState?.StartedOn, _state?.CompleteTime ?? _taskState?.CompletedOn, false, NSLogLevel.Error);
        }

        public void Error(string error, Exception exception, params object[] args)
        {
            //Log(error + " StackTrace: " + exception.StackTrace, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime, false, NSLogLevel.Error);
            Log(error + " StackTrace: " + exception.StackTrace, _context, _state?.Status.Name ?? _taskState.CurrentState, _state?.RetryCount ?? _taskState.FailedCount, _state?.Id ?? _taskState?.Id, _state?.StartTime ?? _taskState?.StartedOn, _state?.CompleteTime ?? _taskState?.CompletedOn, false, NSLogLevel.Error);
        }

        public void Fatal(string error, params object[] args)
        {
            //Log(error, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime, false, NSLogLevel.Fatal);
            Log(error , _context, _state?.Status.Name ?? _taskState.CurrentState, _state?.RetryCount ?? _taskState.FailedCount, _state?.Id ?? _taskState?.Id, _state?.StartTime ?? _taskState?.StartedOn, _state?.CompleteTime ?? _taskState?.CompletedOn, false, NSLogLevel.Fatal);
        }

        public void Fatal(string error, Exception exception, params object[] args)
        {
            //Log(error + " StackTrace: " + exception.StackTrace, _context, _state.Status.Name, _state.RetryCount, (int)_state.Id, _state.StartTime, _state.CompleteTime, false, NSLogLevel.Error);
            Log(error + " StackTrace: " + exception.StackTrace, _context, _state?.Status.Name ?? _taskState.CurrentState, _state?.RetryCount ?? _taskState.FailedCount, _state?.Id ?? _taskState?.Id, _state?.StartTime ?? _taskState?.StartedOn, _state?.CompleteTime ?? _taskState?.CompletedOn, false, NSLogLevel.Fatal);
        }
    }
}


/* This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using BatchEngine.Core.Groups;
using BatchEngine.Models.Entities;

namespace BatchEngine.Models.BusStateWrapper
{

    ///BatchGroupState
    public class BatchGroupStateWrapper : IReadWritableGroupEntity
    {
        public BatchGroupState _state;

        public BatchGroupStateWrapper(BatchGroupState state)
        {
            _state = state;
        }

        public bool IsFinished
        {
            get => _state.IS_FNSH;
            set => _state.IS_FNSH= value;
        }

        public bool IsStopped
        {
            get => _state.IS_STOP;
            set => _state.IS_STOP = value;
        }

        public long Id
        {
            get => _state.BTCH_GRP_STAT_ID;
            set => Id = _state.BTCH_GRP_STAT_ID;
        }

        public int GroupKey
        {
            get => _state.GRP_KEY;
            set => _state.GRP_KEY = value;
        }

        public int InvokeTypeId
        {
            get => _state.INVK_TYPE_ID;
            set => _state.INVK_TYPE_ID = value;
        }
        
        public string SubmittedBy
        {
            get => _state.SBMT_BY;
            set => _state.SBMT_BY = value;
        }

        public string Criteria
        {
            get => _state.CRIT;
            set => _state.CRIT = value;
        }

        public string State
        {
            get => _state.CURR_STAT;
            set => _state.CURR_STAT = value;
        }

        public bool IsGenerated
        {
            get => _state.IS_GENR;
            set => _state.IS_GENR = value;
        }

        public string Payload
        {
            get => _state.PAY_LOAD;
            set => _state.PAY_LOAD = value;
        }

        public string NodeId
        {
            get => _state.NODE_ID;
            set => _state.NODE_ID = value;
        }

        public string QueueName
        {
            get => _state.QUEU_NME;
            set => _state.QUEU_NME = value;
        }

        public int? QueueSeq
        {
            get => _state.QUEU_SEQ;
            set => _state.QUEU_SEQ = value;
        }

        public bool HasPriority
        {
            get => _state.HAS_PRTY;
            set => _state.HAS_PRTY = value;
        }
    }


#pragma warning restore CS1591

}
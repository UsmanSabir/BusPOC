﻿
using BatchEngine.Core;

namespace BatchEngine.Models.BusStateWrapper
{
    public class ProcessConfigurationWrapper:IProcessConfiguration
    {
        private readonly Entities.ProcessConfiguration _state;

        public ProcessConfigurationWrapper(Entities.ProcessConfiguration state)
        {
            _state = state;
        }

        public int ProcessId
        {
            get => _state.PRCS_ID; // screen_code
        }

        public int ProcessKey
        {
            get => _state.PRCS_KEY;
            set => _state.PRCS_KEY=value;
        }

        public int MaxDegreeOfParallelism
        {
            get => _state.MAX_DOP;
            //set => throw new System.NotImplementedException();
        }

        public int? ProcessTimeoutMins
        {
            get => _state.PRCS_TIME_OUT_MINT;
            //set => throw new System.NotImplementedException();
        }

        public int? TaskTimeout
        {
            get => _state.TASK_TIME_OUT;
            //set => throw new System.NotImplementedException();
        }

        public int? ProcessRetries
        {
            get => _state.PRCS_RETR;
            //set => throw new System.NotImplementedException();
        }

        public int? MaxProcessInstance { get => _state.MAX_PRCS_INST; }

        public int? TaskRetries
        {
            get => _state.TASK_RETR;
            //set => throw new System.NotImplementedException();
        }

        public int? RetryDelayMilli
        {
            get => _state.RTRY_DELY_MILI;
            //set => throw new System.NotImplementedException();
        }

        public int MaxVolumeRetries
        {
            get => _state.MAX_VOLM_RETR;
            //set => throw new System.NotImplementedException();
        }

        public int? QueueSize
        {
            get => _state.QUEU_SIZE;
            //set => throw new System.NotImplementedException();
        }

        public int? ErrorThreshold
        {
            get => _state.EROR_TRHD;
        }

        public bool IsActive
        {
            get => _state.ACT_IND;

        }

        public string DaysYearTypeKey
        {
            get => _state.DAYS_YEAR_TYPE_KEY;
        }

        public bool RollOverInd
        {
            get => _state.ROLL_OVER_EXEC_IND;
        }
        public bool IsMonthEnd
        {
            get => _state.IS_MNTH_END;
        }

        public int CriteriaMatchDetId
        {
            get => _state.CRIT_MTCH_DTE_ID;
        }
    }
}
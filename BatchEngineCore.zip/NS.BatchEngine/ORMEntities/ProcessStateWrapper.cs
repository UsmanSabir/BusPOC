﻿using System;
using System.Collections.Generic;
using System.Linq;
using BatchEngine.Core;
using BatchEngine.Models.Entities;


namespace BatchEngine.Models.BusStateWrapper
{
    public class ProcessStateWrapper: IReadWritableProcessState
    {
        internal readonly BatchProcessState State;

        public ProcessStateWrapper(BatchProcessState state)
        {
            State = state;
        }

        public long Id
        {
            get => State.BTCH_PRCS_STAT_ID;
            set => State.BTCH_PRCS_STAT_ID = value;
        }

        public Guid CorrelationId
        {
            get => State.CRLT_ID;
            set => State.CRLT_ID=value;
        }

        public DateTime? UpdatedOn
        {
            get => State.UPDT_ON;
            set => State.UPDT_ON=value;
        }

        public CompletionStatus Status
        {
            get => CompletionStatus.FromName(State.CURR_STAT);
            set => State.CURR_STAT= value.Name;
        }

        public int RetryCount
        {
            get => State.RTRY_CONT;
            set => State.RTRY_CONT=value;
        }

        public int CompanyId
        {
            get => State.CMPY_ID;
            set => State.CMPY_ID=value;
        }

        public int BranchId
        {
            get => State.BRCH_ID;
            set => State.BRCH_ID=value;
        }

        public int SubTenantId
        {
            get => State.SUB_TNNT_ID;
            set => State.SUB_TNNT_ID=value;
        }

        public DateTime ProcessingDate
        {
            get => State.PRCG_DTE;
            set => State.PRCG_DTE=value;
        }

        public int ProcessId
        {
            get => State.PRCS_ID;
            set => State.PRCS_ID=value;
        }

        public bool IsVolumeGenerated
        {
            get => State.IS_VOLM_GENR;
            set => State.IS_VOLM_GENR =value;
        }

        public long? ParentId
        {
            get => State.PRNT_ID;
            set => State.PRNT_ID=value;
        }

        public long GroupId
        {
            get => State.GRP_ID;
            set => State.GRP_ID = value;
        }


        public bool IsFinished
        {
            get => State.IS_FNSH;
            set => State.IS_FNSH=value;
        }

        public bool IsStopped
        {
            get => State.IS_STOP;
            set => State.IS_STOP=value;
        }

        public string Criteria
        {
            get => State.CRIT;
            set => State.CRIT=value;
        }

        public DateTime? StartTime
        {
            get => State.STRT_TIME;
            set => State.STRT_TIME=value;
        }

        public DateTime? CompleteTime
        {
            get => State.CMPL_TIME;
            set => State.CMPL_TIME=value;
        }

        public DateTime? GenerationCompleteTime
        {
            get => State.GENR_CMPL_TIME;
            set => State.GENR_CMPL_TIME=value;
        }

        public ResultStatus Result
        {
            get => ResultStatus.FromName(State.RSLT_STS);
            set => State.RSLT_STS=value.Name;
        }

        public int GroupSeqId
        {
            get => State.GRP_SEQ_ID;
            set => State.GRP_SEQ_ID = value;
        }

        public bool HasVolume
        {
            get => State.HAS_VOLM;
            set => State.HAS_VOLM = value;
        }

        public bool? GroupStopper
        {
            get => State.GRP_STOP_FLG;
            set => State.GRP_STOP_FLG = value;
        }

        public string DependentIds
        {
            get => State.DPDT_PRCS_ID;
            set => State.DPDT_PRCS_ID = value;
        }

        public string QueueName
        {
            get => State.QUEU_NME;
            set => State.QUEU_NME = value;
        }

        public int? QueueSeq
        {
            get => State.QUEU_SEQ;
            set => State.QUEU_SEQ = value;
        }

        public bool HasPriority
        {
            get => State.HAS_PRTY;
            set => State.HAS_PRTY = value;
        }

        public string NodeId
        {
            get => State.NODE_ID;
            set => State.NODE_ID = value;
        }

        private List<long> _dependentIdsList = null;
        public List<long> DependentIdsList
        {
            get
            {
                if (_dependentIdsList == null)
                {
                    _dependentIdsList = new List<long>();
                    if (!string.IsNullOrWhiteSpace(DependentIds))
                    {
                        foreach (var s in DependentIds.Split(new[] {","}, StringSplitOptions.RemoveEmptyEntries))
                        {
                            if (long.TryParse(s, out long id))
                            {
                                _dependentIdsList.Add(id);
                            }
                        }
                    }
                }

                return _dependentIdsList;
            }
        }
    }
}
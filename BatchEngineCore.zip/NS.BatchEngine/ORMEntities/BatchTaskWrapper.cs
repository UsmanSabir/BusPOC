﻿using System;
using BatchEngine.Models.Entities;
using IReadWritableTaskState = BatchEngine.Core.IReadWritableTaskState;
using ResultStatus = BatchEngine.Core.ResultStatus;

namespace BatchEngine.Models.BusStateWrapper
{
    public class BatchTaskWrapper: Core.IReadWritableTaskState
    {
        internal readonly BatchTaskState State;

        public BatchTaskWrapper(BatchTaskState state)
        {
            State = state;
        }

        public bool IsFinished 
        {
            get => State.IS_FNSH;
            set => State.IS_FNSH=value;
        }

        public bool IsStopped 
        {
            get => State.IS_STOP;
            set => State.IS_STOP = value;
        }

        public long Id 
        {
            get => State.BTCH_TASK_STAT_ID;
            set => State.BTCH_TASK_STAT_ID = value;
        }

        public long ProcessId 
        {
            get => State.PRCS_ID;
            set => State.PRCS_ID = value;
        }

        public string Payload 
        {
            get => State.PAY_LOAD;
            set => State.PAY_LOAD = value;
        }

        public DateTime? UpdatedOn
        {
            get => State.UPDT_ON;
            set => State.UPDT_ON = value;
        }

        public ResultStatus Status 
        {
            get => ResultStatus.FromName(State.CURR_STAT);
            set => State.CURR_STAT = value.Name;
        }

        public string CurrentState
        {
            get => State.CURR_STAT;
            set => State.CURR_STAT = value;
        }

        public int FailedCount
        {
            get => State.FALD_CONT;
            set => State.FALD_CONT = value;
        }

        public int DeferredCount 
        {
            get => State.DFRD_CONT;
            set => State.DFRD_CONT = value;
        }

        public string NodeKey 
        {
            get => State.NODE_KEY;
            set => State.NODE_KEY = value;
        }

        public DateTime? StartedOn
        {
            get => State.STRT_ON;
            set => State.STRT_ON = value;
        }

        public DateTime? CompletedOn
        {
            get => State.CMPL_ON;
            set => State.CMPL_ON=value;
        }
    }
}
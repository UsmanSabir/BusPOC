﻿//using System;
//using Memcached.ClientLibrary;
//using NS.Configurations.Models;

//namespace NS.BatchEngine.MemCachedImpl
//{
//    public sealed class MemCached// : ICache
//    {
//        #region Private Members

//        private readonly MemcachedClient _mc;

//        #endregion

//        #region Private Methods
//        /// <summary>
//        /// Initializes the memcached client's socket pool according to 
//        /// the configuration in web.config.
//        /// </summary>
//        /// <param name="serverlist">list of memcached servers</param>
//        ///<remarks>
//        /// <para>[MKB] 1/04/2016  1.0 Method Created</para>
//        /// </remarks>
//        private void InitSocketPool(string[] serverlist)
//        {
//            SockIOPool pool = SockIOPool.GetInstance();
//            Array.Sort(serverlist);
//            pool.SetServers(serverlist);
//            pool.InitConnections = AppsrSettings.McInitConnections;
//            pool.MinConnections = AppsrSettings.McMinConnections;
//            pool.MaxConnections = AppsrSettings.McMaxConnections;
//            pool.SocketConnectTimeout = AppsrSettings.McSocketConnectTimeout;
//            pool.SocketTimeout = AppsrSettings.McSocketTimeout;
//            pool.MaintenanceSleep = AppsrSettings.McMaintenanceSleep;
//            pool.Failover = AppsrSettings.McFailover;
//            pool.Nagle = AppsrSettings.McNagle;
//            pool.HashingAlgorithm = HashingAlgorithm.NewCompatibleHash;

//            pool.Initialize();
//        }

//        private TResult GetorSet<TResult>(string key, Func<TResult> cacheLoader, DateTime expiry)
//        {
//            var item = _mc.Get<TResult>(key);

//            if (item == null)
//            {
//                lock (typeof(TResult))
//                {
//                    item = _mc.Get<TResult>(key); //Re-verification. May be any other thread has loaded it.
//                    if (item == null)
//                    {
//                        item = cacheLoader();
//                        if (item != null)
//                        {
//                            if (_mc.Set(key, item, expiry))
//                            {
//                            }
//                        }
//                    }
//                }
//            }

//            return item;
//        }

//        #endregion

//        #region Constructor
//        /// <summary>
//        /// Initializes an instance of MemCached Class. The lifecycle of the instance is
//        /// managed by Unity.
//        /// </summary>
//        /// <param name="name">Cache name.</param>
//        ///<remarks>
//        /// <para>[MKB] 01/04/2016  1.0 Method Created</para>
//        /// </remarks>
//        public MemCached(string name, string connection)
//        {
//            CacheName = name;
//            string[] serverlist = connection.Split(','); //AppsrSettings.McServers.Split(',');
//            // initialize the pool for memcache servers
//            InitSocketPool(serverlist);

//            // get client instance
//            _mc = new MemcachedClient
//            {
//                EnableCompression = AppsrSettings.McEnableCompression
//            };
//        }
//        #endregion

//        #region Public Properties
//        /// <summary>
//        /// Gets or sets cache name.
//        /// </summary>
//        /// <remarks>
//        /// <para>[MKB] 01/04/2016  1.0 Property Created</para>
//        /// </remarks>
//        public string CacheName { get; set; }

//        #endregion

//        #region Public Methods

//        /// <summary>
//        /// Gets or sets an entry in cache.
//        /// </summary>
//        /// <typeparam name="TResult">Type of cache item.</typeparam>
//        /// <param name="key">The unique identifier string for the cache entry.</param>
//        /// <param name="cacheLoader">The method to be used to get the data of the cache entry in case of
//        /// cache miss. The retrieved data will be stored in cache against the provided key.</param>
//        /// <param name="expiry">Expiry for the cache item.</param>
//        /// <param name="isKeyMultitenant">Indicates if the key for the entry is different accross 
//        /// subtenants.</param>
//        /// <returns>Desired item either retrieved from cache or the CacheLoader method.</returns>
//        /// <remarks>
//        /// <para> [MKB] 21/03/2017 1.0 Method declaration added.</para>        
//        /// </remarks>
//        public TResult Get<TResult>(string key, Func<TResult> cacheLoader, DateTime expiry, bool isKeyMultitenant = true)
//        {
//            key = KeyHelper.GetKey(key, isKeyMultitenant);
//            return GetorSet(key, cacheLoader, expiry);
//        }
//        /// <inheritdoc />
//        /// <remarks>
//        /// <para> [MKB] 07/04/2016 1.0 Method created.</para>
//        /// <para> [MKB] 04/05/2016 1.0 Comments added.</para>
//        /// </remarks>
//        public TResult Get<TResult>(string key, Func<TResult> cacheLoader, int expiryDays, bool isKeyMultitenant = true)
//        {
//            key = KeyHelper.GetKey(key, isKeyMultitenant);
//            return GetorSet(key, cacheLoader, DateTime.Now.AddDays(expiryDays));
//        }
//        /// <summary>
//        /// Gets or sets an entry in cache.
//        /// </summary>
//        /// <typeparam name="TResult">Type of cache item.</typeparam>
//        /// <param name="key">The unique identifier string for the cache entry.</param>
//        /// <param name="cacheLoader">The method to be used to get the data of the cache entry in case of
//        /// cache miss. The retrieved data will be stored in cache against the provided key.</param>
//        /// <param name="isKeyMultitenant">Indicates if the key for the entry is different accross 
//        /// subtenants.</param>
//        /// <returns>Desired item either retrieved from cache or from the CacheLoader method.</returns>
//        /// <remarks>
//        /// <para> [MKB] 03/06/2016 1.0 Method added.</para>
//        /// </remarks>
//        public TResult Get<TResult>(string key, Func<TResult> cacheLoader, bool isKeyMultitenant = true)
//        {
//            key = KeyHelper.GetKey(key, isKeyMultitenant);
//            return GetorSet(key, cacheLoader, DateTime.MaxValue);
//        }
//        /// <inheritdoc/>
//        /// <remarks>
//        /// <para> [MKB] 07/04/2016 1.0 Method created.</para>
//        /// <para> [MKB] 04/05/2016 1.0 Comments added.</para>
//        /// </remarks>
//        public bool RemoveCache(string key, bool isKeyMultitenant = true)
//        {
//            key = KeyHelper.GetKey(key, isKeyMultitenant);
//            if (_mc.Delete(key))
//            {
//                return true;
//            }
//            return false;
//        }


//        /// <inheritdoc/>
//        /// <remarks>
//        /// <para> [MKB] 07/04/2016 1.0 Method created.</para>
//        /// <para> [MKB] 04/05/2016 1.0 Comments added.</para>
//        /// </remarks>
//        public T Get<T>(string key, bool isKeyMultitenant = true)
//        {
//            key = KeyHelper.GetKey(key, isKeyMultitenant);
//            return _mc.Get<T>(key);
//        }
//        /// <inheritdoc/>
//        /// <remarks>
//        /// <para> [MKB] 07/04/2016 1.0 Method created.</para>
//        /// <para> [MKB] 04/05/2016 1.0 Comments added.</para>
//        /// </remarks>
//        public bool Set<T>(string key, T item, bool isKeyMultitenant = true)
//        {
//            key = KeyHelper.GetKey(key, isKeyMultitenant);
//            if (_mc.Set(key, item))
//            {
//                return true;
//            }
//            return false;
//        }
//        /// <summary>
//        /// Inserts an entry into the cache by using a key and a value.
//        /// </summary>
//        /// <typeparam name="T">Type of data of cache entry.</typeparam>
//        /// <param name="key">A unique identifier for the cache entry to insert.</param>
//        /// <param name="item">The data for the cache entry.</param>
//        /// <param name="expiryDays">number of days after which the item will be evicted from cache.
//        /// 0 in case the item is never to expire.</param>
//        /// <param name="isKeyMultitenant">Indicates if the key for the entry is different accross 
//        /// subtenants.</param>
//        /// <returns>True in case of successful insertion otherwise false.</returns>
//        /// <remarks>
//        /// <para> [MKB] 03/06/2016 1.0 Method added.</para>
//        /// </remarks>
//        public bool Set<T>(string key, T item, int expiryDays, bool isKeyMultitenant = true)
//        {
//            key = KeyHelper.GetKey(key, isKeyMultitenant);
//            DateTime expiry = DateTime.Now.AddDays(expiryDays);
//            if (_mc.Set(key, item, expiry))
//            {
//                return true;
//            }
//            return false;
//        }

//        /// <summary>
//        /// Inserts an entry into the cache by using a key and a value.
//        /// </summary>
//        /// <typeparam name="T">Type of data of cache entry.</typeparam>
//        /// <param name="key">A unique identifier for the cache entry to insert.</param>
//        /// <param name="item">The data for the cache entry.</param>
//        /// <param name="expiry">Expiry for the cache item.</param>
//        /// <param name="isKeyMultitenant">Indicates if the key for the entry is different accross 
//        /// subtenants.</param>
//        /// <returns>True in case of successful insertion otherwise false.</returns>
//        /// <remarks>
//        /// <para> [MKB] 03/06/2016 1.0 Method declaration added.</para>
//        /// </remarks>
//        public bool Set<T>(string key, T item, DateTime expiry, bool isKeyMultitenant = true)
//        {
//            key = KeyHelper.GetKey(key, isKeyMultitenant);
//            if (_mc.Set(key, item, expiry))
//            {
//                return true;
//            }
//            return false;
//        }
//        #endregion
//    }
//}
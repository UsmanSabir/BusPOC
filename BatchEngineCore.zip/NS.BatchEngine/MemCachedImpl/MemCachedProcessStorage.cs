﻿//using System;
//using System.Diagnostics;
//using BatchEngine.Core.BatchEngineCore;
//using BatchEngine.Core.Infrastructure;

//namespace NS.BatchEngine.MemCachedImpl
//{
//    public class MemCachedProcessStorage: IProcessDataStorage
//    {
//        private MemCached _memCacheClient;
//        private readonly string _name;

//        private readonly string _connection;
//        //private readonly ISerializer _serializer;

//        public MemCachedProcessStorage(string name, string connection) //, ISerializer serializer
//        {
//            _name = name;
//            _connection = connection;
//            //_serializer = serializer;

//            CreateClient();
//        }

//        string GetHashKey(string processId)
//        {
//            return $"{_name}_process_{processId}";
//        }
        
//        public void AddOrUpdateProcessData<T>(long processStateId, string key, T value, TimeSpan expireIn)
//        {
//            var k = GetHashKey(processStateId.ToString());

//            k = $"{k}_{key}";
//            //var s = _serializer.SerializeToString(value);
//            if (expireIn == default(TimeSpan))
//                expireIn = TimeSpan.FromHours(6);

//            _memCacheClient.Set(k, value, DateTime.Now.Add(expireIn));
//        }

//        public T GetProcessData<T>(long processStateId, string key)
//        {
//            var k = GetHashKey(processStateId.ToString());
//            k = $"{k}_{key}";
//            T val = _memCacheClient.Get<T>(k);
//            //if (string.IsNullOrWhiteSpace(redisValue))
//            //    return default(T);

//            //var item = _serializer.DeserializeFromString<T>(redisValue);
//            ////var item = _memCacheClient.HashGet<T>(k, key);
//            return  val;
//        }

//        public void CleanProcessData(string processId)
//        {
//            //var k = GetHashKey(processId);
            
//            //_db.KeyDelete(k);
//            //_memCacheClient.Remove(k);
//            //_memCacheClient.HashDelete(k)
//        }

//        public bool IsHealthy()
//        {
//            try
//            {
//                var key = $"{NodeSettings.Instance.Name}_{Process.GetCurrentProcess()?.Id??1}";
//                var value = _memCacheClient.Get<string>(key, ()=> "Ping");
//                _memCacheClient.RemoveCache(key);
//                return true;
//            }
//            catch (Exception e)
//            {
//                return false;
//            }
//        }

//        private void CreateClient()
//        {
//            _memCacheClient = new MemCached(_name, _connection);
//        }

        
//        public void RefreshIfNotHealth()
//        {
//            if (!IsHealthy())
//            {
//                CreateClient();
//            }
//        }
//    }
//}
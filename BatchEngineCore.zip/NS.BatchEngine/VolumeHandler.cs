﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;
using BatchEngine.Core.StatePersistence;
using BatchEngine.Core.Helper;
using BatchEngine.Core.Infrastructure;
using BatchEngine.Core.Serializers;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using NS.BaseModels;
using NS.BatchEngine.Db;
using NS.ORM;
using NS.ORM.UoW;

namespace NS.BatchEngine
{
    class VolumeHandler: IVolumeHandler
    {
        private readonly IResolver _resolver;
        private readonly ISerializersFactory _serializersFactory;

        public VolumeHandler(IResolver resolver)
        {
            _resolver = resolver;
            _serializersFactory = SerializersFactory.Instance;
            _systemLogger = resolver.Resolve<IBatchLoggerFactory>().GetSystemLogger();
        }

        EntityContextExt<T> GetEntityContext<T>(IList<T> entities = null) where T : BaseModel, new()
        {
            return OrmFactory.GetEntityContext(entities);
        }

        private DbController GetDbController(IUnitOfWork uow = null)
        {
            return OrmFactory.GetDbController(uow);
        }

        public void Handle<T>(IEnumerable<T> volume, IProcessExecutionContextWithVolume processContext, CancellationToken token)
        {
            if (volume==null)
            {
                processContext.Logger.Info("No volume returned");
                return;
            }

            bool hasVolume = false;
            var serializer = _serializersFactory.GetSerializer<T>();
            int currentCount = 0;
            int batchSize = 100;

            IUnitOfWork uow = null;
            EntityContextExt<BatchTaskState> ext=null;

            try
            {
                Bus.HandleDbCommand(new DbAction(DbActions.Transaction, () => //create transaction in Db Bus pipeline
                {
                    var isolationLevel = IsolationLevel.Snapshot;

                    Retry:

                    try
                    {
                        ext = GetEntityContext<BatchTaskState>();
                        uow = ext.InitiateUnitOfWork(isolationLevel);
                        var controller = GetDbController(uow);
                        var volumeDeletedCount = controller.ExecuteNonQuery(Constant.SQLDeleteProcessVolume,
                            processContext.ProcessState.Id);
                        if (volumeDeletedCount > 0)
                        {
                            processContext.Logger.Warn($"Existing volume {volumeDeletedCount} deleting");
                        }
                    }
                    catch (Exception e) when (e.Message.Contains("snapshot isolation is not allowed in this database"))
                    {
                        uow?.Dispose();
                        uow = null;
                        ext?.Dispose();
                        if (isolationLevel != IsolationLevel.Snapshot)
                            throw;

                        isolationLevel = IsolationLevel.ReadCommitted;
                        processContext.Logger.Warn("Snapshot isolation is not allowed in this database. Switching to ReadCommitted.");
                        goto Retry;
                    }
                }));


                //using (var unitOfWork = ) //IsolationLevel.Snapshot //todo check isolation level with db team, is it enabled by default
                {
                    foreach (var v in volume)
                    {
                        var payLoad = serializer.SerializeToString(v);
                        var state = ext.CreateNew();

                        state.PAYLOAD = payLoad;
                        state.PROCESSID = processContext.ProcessState.Id;
                        state.CURRENTSTATE = ResultStatus.Empty.Name;
                        state.HASPRIORITY = processContext.ProcessState.HasPriority;

                        currentCount++;
                        if (currentCount >= batchSize)
                        {
                            token.ThrowIfCancellationRequested();

                            hasVolume = true;
                            ext.Persist();
                            currentCount = 0;
                            ext.Entity.Clear(); //remove persisted items
                        }
                    }

                    if (ext.Entity?.Count > 0)
                    {
                        token.ThrowIfCancellationRequested();
                        hasVolume = true;
                        ext.Persist();
                    }

                    uow.Save();
                }
            }
            finally
            {
                uow?.Dispose();
            }

            if(hasVolume)
                processContext.SetVolumeGenerated();

        }

        private Bus _bus;
        private IFrameworkLogger _systemLogger;

        protected Bus Bus
        {
            get { return _bus ?? (_bus = _resolver.Resolve<Bus>()); }
        }

        public IReadWritableTaskState GetNextTaskWithTransaction(out ITransaction transaction)
        {
            return NextTaskWithTransactionLocal(out transaction, false);
        }

        private IReadWritableTaskState NextTaskWithTransactionLocal(out ITransaction transaction, bool isPriority)
        {
            IUnitOfWork unitOfWork = null;
            transaction = null;
            int tries = 0;
            ITransaction trans = null;
            BatchTaskWrapper batchTaskWrapper = null;

            Retry:

            tries++;
            try
            {
                Bus.HandleDbCommand(new DbAction(DbActions.Transaction, () =>
                {
                    short attempt = 1;
                    var ext = GetEntityContext<BatchTaskState>();
                    unitOfWork = ext.InitiateUnitOfWork();
                    try
                    {
                        do
                        {
                            ext.ReadWithSql(isPriority ? Constant.SQLReadDataPriorityQueue : Constant.SQLReadDataQueue,
                                DateTime.UtcNow);
                            if (ext.Entity?.Count > 0)
                            {
                                trans = new TransactionWrapper(unitOfWork); //todo what if db connection lost
                                var batchTaskState = ext.Entity.Single();
                                if (batchTaskState.NODEKEY!=NodeSettings.Instance.Name) //todo remove in production
                                {
                                    _systemLogger.Fatal("{taskId} received with invalid nodeId {nodeId} instead of {originalNodeId}", batchTaskState.ID, batchTaskState.NODEKEY, NodeSettings.Instance.Name);
                                }
                                batchTaskWrapper = new BatchTaskWrapper(batchTaskState);
                            }
                            else
                            {
                                attempt++; //in multi-node mode, there is possibility of no-row, attempt again
                                //return null;
                                unitOfWork?.Dispose(); //release transaction
                            }
                        } while (attempt <= 2);
                    }
                    catch (Exception)
                    {
                        unitOfWork?.Dispose();
                        throw;
                    }
                }));
                transaction = trans;
                return batchTaskWrapper;
            }
            catch (Exception)
            {
                unitOfWork?.Dispose();
                if (tries < 3)
                    goto Retry;

                //throw;
                return null;
            }
        }

        public IReadWritableTaskState GetPriorityNextTaskWithTransaction(out ITransaction transaction)
        {
            return NextTaskWithTransactionLocal(out transaction, true);

            #region Commented

            //IUnitOfWork unitOfWork = null;
            //transaction = null;
            //int tries = 0;
            //ITransaction trans = null;
            //BatchTaskWrapper batchTaskWrapper = null;

            //Retry:

            //tries++;
            //try
            //{
            //    Bus.HandleDbCommand(new DbAction(DbActions.Transaction, () =>
            //    {
            //        var ext = GetEntityContext<BatchTaskState>();
            //        unitOfWork = ext.InitiateUnitOfWork();

            //        try
            //        {
            //            ext.ReadWithSql(Constant.SQLReadDataPriorityQueue, DateTime.UtcNow);
            //            if (ext.Entity?.Count > 0)
            //            {
            //                trans = new TransactionWrapper(unitOfWork); //todo what if db connection lost
            //                batchTaskWrapper = new BatchTaskWrapper(ext.Entity.Single());
            //            }
            //            else
            //            {
            //                unitOfWork?.Dispose();//release transaction
            //                //return null;
            //            }
            //        }
            //        catch (Exception)
            //        {
            //            unitOfWork?.Dispose();
            //            throw;
            //        }

            //    }));
            //    transaction = trans;
            //    return batchTaskWrapper;

            //}
            //catch (Exception)
            //{
            //    unitOfWork?.Dispose();
            //    if (tries < 3)
            //        goto Retry;

            //    //throw;
            //    return null;

            //}

            #endregion

        }
    }
}
﻿using System.Threading;
using BatchEngine.Core;
using BatchEngine.Core.CoreServices;

namespace NS.BatchEngine.Empty
{
    public class EmptyPubSubFactory: IPubSubFactory
    {
        
        public EmptyPubSubFactory()
        {
            
        }
        public IDistributedMessagePublisher GetPublisher(CancellationToken token, ILogger logger,
            string channelName = null)
        {
            return new EmptyPub();
        }

        public IDistributedMessageSubscriber GetSubscriber(CancellationToken token, ILogger logger,
            string channelName = null)
        {
            return new EmptySub();
        }
    }
}
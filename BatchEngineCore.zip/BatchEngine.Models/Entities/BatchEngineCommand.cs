
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchCommands
	public partial class BatchEngineCommand : BaseModel
	{
		
				private Int32 _id;
				private String _channel;
				private String _type;
				private String _command;
				private String _parameter;
				private String _publishedbynode;
				private DateTime _publishedtime;
				private Boolean _ishandledbymaster;
				private String _handlernodeid;
		
		//public BatchEngineCommand BatchEngineCommand { get { return this; } } //Self reference property

		
		public Int32 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public String CHANNEL
		{
			get { return _channel; }
			set
			{
				CheckSetProperty(ref _channel, value);
			}
		}

		
		public String TYPE
		{
			get { return _type; }
			set
			{
				CheckSetProperty(ref _type, value);
			}
		}

		
		public String COMMAND
		{
			get { return _command; }
			set
			{
				CheckSetProperty(ref _command, value);
			}
		}

		
		public String PARAMETER
		{
			get { return _parameter; }
			set
			{
				CheckSetProperty(ref _parameter, value);
			}
		}

		
		public String PUBLISHEDBYNODE
		{
			get { return _publishedbynode; }
			set
			{
				CheckSetProperty(ref _publishedbynode, value);
			}
		}

		
		public DateTime PUBLISHEDTIME
		{
			get { return _publishedtime; }
			set
			{
				CheckSetProperty(ref _publishedtime, value);
			}
		}

		
		public Boolean ISHANDLEDBYMASTER
		{
			get { return _ishandledbymaster; }
			set
			{
				CheckSetProperty(ref _ishandledbymaster, value);
			}
		}

		
		public String HANDLERNODEID
		{
			get { return _handlernodeid; }
			set
			{
				CheckSetProperty(ref _handlernodeid, value);
			}
		}

		

		
	}

		public class BatchEngineCommandValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "CHANNEL", "TYPE", "COMMAND", "PUBLISHEDBYNODE", "PUBLISHEDTIME", "ISHANDLEDBYMASTER",  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		    ["CHANNEL"] = 500
		  , ["TYPE"] = 500
		  , ["COMMAND"] = 500
		  , ["PARAMETER"] = 50
		  , ["PUBLISHEDBYNODE"] = 150
		    , ["HANDLERNODEID"] = 150
		 
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
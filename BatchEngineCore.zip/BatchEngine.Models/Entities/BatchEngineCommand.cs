
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchCommands
	public partial class BatchEngineCommand : BaseModel
	{
		
				private Int32 _btch_cmnd_id;
				private String _chnl;
				private String _type;
				private String _cmnd;
				private String _parm;
				private String _pbls_by_node;
				private DateTime _pbls_time;
				private Boolean _is_hndl_by_mstr;
				private String _hndl_node_id;
				private String _insr_by;
				private String _updt_by;
				private DateTime _insr_dte;
				private DateTime _updt_dte;
		
		//public BatchEngineCommand BatchEngineCommand { get { return this; } } //Self reference property

		
		public Int32 BTCH_CMND_ID
		{
			get { return _btch_cmnd_id; }
			set
			{
				CheckSetProperty(ref _btch_cmnd_id, value);
			}
		}

		
		public String CHNL
		{
			get { return _chnl; }
			set
			{
				CheckSetProperty(ref _chnl, value);
			}
		}

		
		public String TYPE
		{
			get { return _type; }
			set
			{
				CheckSetProperty(ref _type, value);
			}
		}

		
		public String CMND
		{
			get { return _cmnd; }
			set
			{
				CheckSetProperty(ref _cmnd, value);
			}
		}

		
		public String PARM
		{
			get { return _parm; }
			set
			{
				CheckSetProperty(ref _parm, value);
			}
		}

		
		public String PBLS_BY_NODE
		{
			get { return _pbls_by_node; }
			set
			{
				CheckSetProperty(ref _pbls_by_node, value);
			}
		}

		
		public DateTime PBLS_TIME
		{
			get { return _pbls_time; }
			set
			{
				CheckSetProperty(ref _pbls_time, value);
			}
		}

		
		public Boolean IS_HNDL_BY_MSTR
		{
			get { return _is_hndl_by_mstr; }
			set
			{
				CheckSetProperty(ref _is_hndl_by_mstr, value);
			}
		}

		
		public String HNDL_NODE_ID
		{
			get { return _hndl_node_id; }
			set
			{
				CheckSetProperty(ref _hndl_node_id, value);
			}
		}

		
		public String INSR_BY
		{
			get { return _insr_by; }
			set
			{
				CheckSetProperty(ref _insr_by, value);
			}
		}

		
		public String UPDT_BY
		{
			get { return _updt_by; }
			set
			{
				CheckSetProperty(ref _updt_by, value);
			}
		}

		
		public DateTime INSR_DTE
		{
			get { return _insr_dte; }
			set
			{
				CheckSetProperty(ref _insr_dte, value);
			}
		}

		
		public DateTime UPDT_DTE
		{
			get { return _updt_dte; }
			set
			{
				CheckSetProperty(ref _updt_dte, value);
			}
		}

		

		
	}

		public class BatchEngineCommandValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "BTCH_CMND_ID", "CHNL", "TYPE", "CMND", "PARM", "PBLS_BY_NODE", "PBLS_TIME", "IS_HNDL_BY_MSTR", "HNDL_NODE_ID", "INSR_BY", "UPDT_BY", "INSR_DTE", "UPDT_DTE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		    ["CHNL"] = 500
		  , ["TYPE"] = 500
		  , ["CMND"] = 500
		  , ["PARM"] = 50
		  , ["PBLS_BY_NODE"] = 150
		    , ["HNDL_NODE_ID"] = 150
		  , ["INSR_BY"] = 20
		  , ["UPDT_BY"] = 20
		   
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
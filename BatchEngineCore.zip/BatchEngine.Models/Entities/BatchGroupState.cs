
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchGroupState
	public partial class BatchGroupState : BaseModel
	{
		
				private Int64 _id;
				private Int32 _groupkey;
				private String _submittedby;
				private Int32 _invoketypeid;
				private String _criteria;
				private Boolean _isfinished;
				private Boolean _isstopped;
				private String _currentstate;
				private String _payload;
				private Boolean _isgenerated;
				private String _queuename;
				private Int32? _queueseq;
				private Boolean _haspriority;
				private String _nodeid;
		
		//public BatchGroupState BatchGroupState { get { return this; } } //Self reference property

		
		public Int64 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Int32 GROUPKEY
		{
			get { return _groupkey; }
			set
			{
				CheckSetProperty(ref _groupkey, value);
			}
		}

		
		public String SUBMITTEDBY
		{
			get { return _submittedby; }
			set
			{
				CheckSetProperty(ref _submittedby, value);
			}
		}

		
		public Int32 INVOKETYPEID
		{
			get { return _invoketypeid; }
			set
			{
				CheckSetProperty(ref _invoketypeid, value);
			}
		}

		
		public String CRITERIA
		{
			get { return _criteria; }
			set
			{
				CheckSetProperty(ref _criteria, value);
			}
		}

		
		public Boolean ISFINISHED
		{
			get { return _isfinished; }
			set
			{
				CheckSetProperty(ref _isfinished, value);
			}
		}

		
		public Boolean ISSTOPPED
		{
			get { return _isstopped; }
			set
			{
				CheckSetProperty(ref _isstopped, value);
			}
		}

		
		public String CURRENTSTATE
		{
			get { return _currentstate; }
			set
			{
				CheckSetProperty(ref _currentstate, value);
			}
		}

		
		public String PAYLOAD
		{
			get { return _payload; }
			set
			{
				CheckSetProperty(ref _payload, value);
			}
		}

		
		public Boolean ISGENERATED
		{
			get { return _isgenerated; }
			set
			{
				CheckSetProperty(ref _isgenerated, value);
			}
		}

		
		public String QUEUENAME
		{
			get { return _queuename; }
			set
			{
				CheckSetProperty(ref _queuename, value);
			}
		}

		
		public Int32? QUEUESEQ
		{
			get { return _queueseq; }
			set
			{
				CheckSetProperty(ref _queueseq, value);
			}
		}

		
		public Boolean HASPRIORITY
		{
			get { return _haspriority; }
			set
			{
				CheckSetProperty(ref _haspriority, value);
			}
		}

		
		public String NODEID
		{
			get { return _nodeid; }
			set
			{
				CheckSetProperty(ref _nodeid, value);
			}
		}

		

		
	}

		public class BatchGroupStateValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "GROUPKEY", "SUBMITTEDBY", "INVOKETYPEID", "CRITERIA", "ISFINISHED", "ISSTOPPED", "CURRENTSTATE", "ISGENERATED", "HASPRIORITY",  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		     ["SUBMITTEDBY"] = 250
		   , ["CRITERIA"] = 2147483647
		    , ["CURRENTSTATE"] = 50
		  , ["PAYLOAD"] = 2147483647
		   , ["QUEUENAME"] = 50
		    , ["NODEID"] = 250
		 
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
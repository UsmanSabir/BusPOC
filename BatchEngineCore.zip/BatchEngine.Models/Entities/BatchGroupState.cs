
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchGroupState
	public partial class BatchGroupState : BaseModel
	{
		
				private Int64 _btch_grp_stat_id;
				private Int32 _grp_key;
				private String _sbmt_by;
				private String _crit;
				private Boolean _is_fnsh;
				private Boolean _is_stop;
				private String _curr_stat;
				private String _pay_load;
				private Boolean _is_genr;
				private String _queu_nme;
				private Int32? _queu_seq;
				private Boolean _has_prty;
				private String _node_id;
				private Int32 _invk_type_id;
				private String _insr_by;
				private String _updt_by;
				private DateTime _insr_dte;
				private DateTime _updt_dte;
		
		//public BatchGroupState BatchGroupState { get { return this; } } //Self reference property

		
		public Int64 BTCH_GRP_STAT_ID
		{
			get { return _btch_grp_stat_id; }
			set
			{
				CheckSetProperty(ref _btch_grp_stat_id, value);
			}
		}

		
		public Int32 GRP_KEY
		{
			get { return _grp_key; }
			set
			{
				CheckSetProperty(ref _grp_key, value);
			}
		}

		
		public String SBMT_BY
		{
			get { return _sbmt_by; }
			set
			{
				CheckSetProperty(ref _sbmt_by, value);
			}
		}

		
		public String CRIT
		{
			get { return _crit; }
			set
			{
				CheckSetProperty(ref _crit, value);
			}
		}

		
		public Boolean IS_FNSH
		{
			get { return _is_fnsh; }
			set
			{
				CheckSetProperty(ref _is_fnsh, value);
			}
		}

		
		public Boolean IS_STOP
		{
			get { return _is_stop; }
			set
			{
				CheckSetProperty(ref _is_stop, value);
			}
		}

		
		public String CURR_STAT
		{
			get { return _curr_stat; }
			set
			{
				CheckSetProperty(ref _curr_stat, value);
			}
		}

		
		public String PAY_LOAD
		{
			get { return _pay_load; }
			set
			{
				CheckSetProperty(ref _pay_load, value);
			}
		}

		
		public Boolean IS_GENR
		{
			get { return _is_genr; }
			set
			{
				CheckSetProperty(ref _is_genr, value);
			}
		}

		
		public String QUEU_NME
		{
			get { return _queu_nme; }
			set
			{
				CheckSetProperty(ref _queu_nme, value);
			}
		}

		
		public Int32? QUEU_SEQ
		{
			get { return _queu_seq; }
			set
			{
				CheckSetProperty(ref _queu_seq, value);
			}
		}

		
		public Boolean HAS_PRTY
		{
			get { return _has_prty; }
			set
			{
				CheckSetProperty(ref _has_prty, value);
			}
		}

		
		public String NODE_ID
		{
			get { return _node_id; }
			set
			{
				CheckSetProperty(ref _node_id, value);
			}
		}

		
		public Int32 INVK_TYPE_ID
		{
			get { return _invk_type_id; }
			set
			{
				CheckSetProperty(ref _invk_type_id, value);
			}
		}

		
		public String INSR_BY
		{
			get { return _insr_by; }
			set
			{
				CheckSetProperty(ref _insr_by, value);
			}
		}

		
		public String UPDT_BY
		{
			get { return _updt_by; }
			set
			{
				CheckSetProperty(ref _updt_by, value);
			}
		}

		
		public DateTime INSR_DTE
		{
			get { return _insr_dte; }
			set
			{
				CheckSetProperty(ref _insr_dte, value);
			}
		}

		
		public DateTime UPDT_DTE
		{
			get { return _updt_dte; }
			set
			{
				CheckSetProperty(ref _updt_dte, value);
			}
		}

		

		
	}

		public class BatchGroupStateValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "BTCH_GRP_STAT_ID", "GRP_KEY", "SBMT_BY", "CRIT", "IS_FNSH", "IS_STOP", "CURR_STAT", "IS_GENR", "HAS_PRTY", "INVK_TYPE_ID", "INSR_BY", "UPDT_BY", "INSR_DTE", "UPDT_DTE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		     ["SBMT_BY"] = 250
		  , ["CRIT"] = 2147483647
		    , ["CURR_STAT"] = 50
		  , ["PAY_LOAD"] = 2147483647
		   , ["QUEU_NME"] = 50
		    , ["NODE_ID"] = 250
		   , ["INSR_BY"] = 20
		  , ["UPDT_BY"] = 20
		   
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
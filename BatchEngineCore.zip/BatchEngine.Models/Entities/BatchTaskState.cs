
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchTaskState
	public partial class BatchTaskState : BaseModel
	{
		
				private Int64 _btch_task_stat_id;
				private Int64 _prcs_id;
				private String _pay_load;
				private DateTime? _updt_on;
				private String _curr_stat;
				private Int32 _fnsh_cnt;
				private Int32 _fald_cont;
				private Int32 _dfrd_cont;
				private String _node_key;
				private Boolean _is_fnsh;
				private Boolean _is_stop;
				private DateTime? _strt_on;
				private Boolean _has_prty;
				private DateTime? _cmpl_on;
				private String _insr_by;
				private String _updt_by;
				private DateTime _insr_dte;
				private DateTime _updt_dte;
		
		//public BatchTaskState BatchTaskState { get { return this; } } //Self reference property

		
		public Int64 BTCH_TASK_STAT_ID
		{
			get { return _btch_task_stat_id; }
			set
			{
				CheckSetProperty(ref _btch_task_stat_id, value);
			}
		}

		
		public Int64 PRCS_ID
		{
			get { return _prcs_id; }
			set
			{
				CheckSetProperty(ref _prcs_id, value);
			}
		}

		
		public String PAY_LOAD
		{
			get { return _pay_load; }
			set
			{
				CheckSetProperty(ref _pay_load, value);
			}
		}

		
		public DateTime? UPDT_ON
		{
			get { return _updt_on; }
			set
			{
				CheckSetProperty(ref _updt_on, value);
			}
		}

		
		public String CURR_STAT
		{
			get { return _curr_stat; }
			set
			{
				CheckSetProperty(ref _curr_stat, value);
			}
		}

		
		public Int32 FNSH_CNT
		{
			get { return _fnsh_cnt; }
			set
			{
				CheckSetProperty(ref _fnsh_cnt, value);
			}
		}

		
		public Int32 FALD_CONT
		{
			get { return _fald_cont; }
			set
			{
				CheckSetProperty(ref _fald_cont, value);
			}
		}

		
		public Int32 DFRD_CONT
		{
			get { return _dfrd_cont; }
			set
			{
				CheckSetProperty(ref _dfrd_cont, value);
			}
		}

		
		public String NODE_KEY
		{
			get { return _node_key; }
			set
			{
				CheckSetProperty(ref _node_key, value);
			}
		}

		
		public Boolean IS_FNSH
		{
			get { return _is_fnsh; }
			set
			{
				CheckSetProperty(ref _is_fnsh, value);
			}
		}

		
		public Boolean IS_STOP
		{
			get { return _is_stop; }
			set
			{
				CheckSetProperty(ref _is_stop, value);
			}
		}

		
		public DateTime? STRT_ON
		{
			get { return _strt_on; }
			set
			{
				CheckSetProperty(ref _strt_on, value);
			}
		}

		
		public Boolean HAS_PRTY
		{
			get { return _has_prty; }
			set
			{
				CheckSetProperty(ref _has_prty, value);
			}
		}

		
		public DateTime? CMPL_ON
		{
			get { return _cmpl_on; }
			set
			{
				CheckSetProperty(ref _cmpl_on, value);
			}
		}

		
		public String INSR_BY
		{
			get { return _insr_by; }
			set
			{
				CheckSetProperty(ref _insr_by, value);
			}
		}

		
		public String UPDT_BY
		{
			get { return _updt_by; }
			set
			{
				CheckSetProperty(ref _updt_by, value);
			}
		}

		
		public DateTime INSR_DTE
		{
			get { return _insr_dte; }
			set
			{
				CheckSetProperty(ref _insr_dte, value);
			}
		}

		
		public DateTime UPDT_DTE
		{
			get { return _updt_dte; }
			set
			{
				CheckSetProperty(ref _updt_dte, value);
			}
		}

		

		
	}

		public class BatchTaskStateValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "BTCH_TASK_STAT_ID", "PRCS_ID", "PAY_LOAD", "CURR_STAT", "FNSH_CNT", "FALD_CONT", "DFRD_CONT", "IS_FNSH", "IS_STOP", "HAS_PRTY", "INSR_BY", "UPDT_BY", "INSR_DTE", "UPDT_DTE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		     ["PAY_LOAD"] = 500
		   , ["CURR_STAT"] = 50
		     , ["NODE_KEY"] = 250
		       , ["INSR_BY"] = 20
		  , ["UPDT_BY"] = 20
		   
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace

/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessConfig
	public partial class ProcessConfiguration : BaseModel
	{
		
				private Int32 _id;
				private Int32 _processid;
				private Int32 _processkey;
				private Int32 _batchsize;
				private Int32? _processtimeoutmins;
				private Int32? _tasktimeout;
				private Int32? _processretries;
				private Int32? _taskretries;
				private Int32? _retrydelaymilli;
				private Int32 _maxvolumeretries;
				private Int32? _queuesize;
				private Int32? _errorthreshold;
				private String _days_year_type_key;
				private Boolean _act_ind;
				private Boolean _roll_over_exec_ind;
				private Boolean _ismonthend;
				private Int32 _crit_mtch_dte_id;
		
		//public ProcessConfiguration ProcessConfiguration { get { return this; } } //Self reference property

		
		public Int32 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Int32 PROCESSID
		{
			get { return _processid; }
			set
			{
				CheckSetProperty(ref _processid, value);
			}
		}

		
		public Int32 PROCESSKEY
		{
			get { return _processkey; }
			set
			{
				CheckSetProperty(ref _processkey, value);
			}
		}

		
		public Int32 BATCHSIZE
		{
			get { return _batchsize; }
			set
			{
				CheckSetProperty(ref _batchsize, value);
			}
		}

		
		public Int32? PROCESSTIMEOUTMINS
		{
			get { return _processtimeoutmins; }
			set
			{
				CheckSetProperty(ref _processtimeoutmins, value);
			}
		}

		
		public Int32? TASKTIMEOUT
		{
			get { return _tasktimeout; }
			set
			{
				CheckSetProperty(ref _tasktimeout, value);
			}
		}

		
		public Int32? PROCESSRETRIES
		{
			get { return _processretries; }
			set
			{
				CheckSetProperty(ref _processretries, value);
			}
		}

		
		public Int32? TASKRETRIES
		{
			get { return _taskretries; }
			set
			{
				CheckSetProperty(ref _taskretries, value);
			}
		}

		
		public Int32? RETRYDELAYMILLI
		{
			get { return _retrydelaymilli; }
			set
			{
				CheckSetProperty(ref _retrydelaymilli, value);
			}
		}

		
		public Int32 MAXVOLUMERETRIES
		{
			get { return _maxvolumeretries; }
			set
			{
				CheckSetProperty(ref _maxvolumeretries, value);
			}
		}

		
		public Int32? QUEUESIZE
		{
			get { return _queuesize; }
			set
			{
				CheckSetProperty(ref _queuesize, value);
			}
		}

		
		public Int32? ERRORTHRESHOLD
		{
			get { return _errorthreshold; }
			set
			{
				CheckSetProperty(ref _errorthreshold, value);
			}
		}

		
		public String DAYS_YEAR_TYPE_KEY
		{
			get { return _days_year_type_key; }
			set
			{
				CheckSetProperty(ref _days_year_type_key, value);
			}
		}

		
		public Boolean ACT_IND
		{
			get { return _act_ind; }
			set
			{
				CheckSetProperty(ref _act_ind, value);
			}
		}

		
		public Boolean ROLL_OVER_EXEC_IND
		{
			get { return _roll_over_exec_ind; }
			set
			{
				CheckSetProperty(ref _roll_over_exec_ind, value);
			}
		}

		
		public Boolean ISMONTHEND
		{
			get { return _ismonthend; }
			set
			{
				CheckSetProperty(ref _ismonthend, value);
			}
		}

		
		public Int32 CRIT_MTCH_DTE_ID
		{
			get { return _crit_mtch_dte_id; }
			set
			{
				CheckSetProperty(ref _crit_mtch_dte_id, value);
			}
		}

		

		
	}

		public class ProcessConfigurationValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "PROCESSID", "PROCESSKEY", "BATCHSIZE", "MAXVOLUMERETRIES", "ACT_IND", "ROLL_OVER_EXEC_IND", "ISMONTHEND", "CRIT_MTCH_DTE_ID"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		               ["DAYS_YEAR_TYPE_KEY"] = 25
		     
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
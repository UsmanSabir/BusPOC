
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessConfig
	public partial class ProcessConfiguration : BaseModel
	{
		
				private Int32 _btch_prcs_conf_id;
				private Int32 _prcs_id;
				private Int32 _prcs_key;
				private Int32 _max_dop;
				private Int32? _prcs_time_out_mint;
				private Int32? _task_time_out;
				private Int32? _prcs_retr;
				private Int32? _max_prcs_inst;
				private Int32? _task_retr;
				private Int32? _rtry_dely_mili;
				private Int32 _max_volm_retr;
				private Int32? _queu_size;
				private Int32? _eror_trhd;
				private String _days_year_type_key;
				private Boolean _act_ind;
				private Boolean _roll_over_exec_ind;
				private Boolean _is_mnth_end;
				private Int32 _crit_mtch_dte_id;
				private String _insr_by;
				private String _updt_by;
				private DateTime _insr_dte;
				private DateTime _updt_dte;
		
		//public ProcessConfiguration ProcessConfiguration { get { return this; } } //Self reference property

		
		public Int32 BTCH_PRCS_CONF_ID
		{
			get { return _btch_prcs_conf_id; }
			set
			{
				CheckSetProperty(ref _btch_prcs_conf_id, value);
			}
		}

		
		public Int32 PRCS_ID
		{
			get { return _prcs_id; }
			set
			{
				CheckSetProperty(ref _prcs_id, value);
			}
		}

		
		public Int32 PRCS_KEY
		{
			get { return _prcs_key; }
			set
			{
				CheckSetProperty(ref _prcs_key, value);
			}
		}

		
		public Int32 MAX_DOP
		{
			get { return _max_dop; }
			set
			{
				CheckSetProperty(ref _max_dop, value);
			}
		}

		
		public Int32? PRCS_TIME_OUT_MINT
		{
			get { return _prcs_time_out_mint; }
			set
			{
				CheckSetProperty(ref _prcs_time_out_mint, value);
			}
		}

		
		public Int32? TASK_TIME_OUT
		{
			get { return _task_time_out; }
			set
			{
				CheckSetProperty(ref _task_time_out, value);
			}
		}

		
		public Int32? PRCS_RETR
		{
			get { return _prcs_retr; }
			set
			{
				CheckSetProperty(ref _prcs_retr, value);
			}
		}

		
		public Int32? MAX_PRCS_INST
		{
			get { return _max_prcs_inst; }
			set
			{
				CheckSetProperty(ref _max_prcs_inst, value);
			}
		}

		
		public Int32? TASK_RETR
		{
			get { return _task_retr; }
			set
			{
				CheckSetProperty(ref _task_retr, value);
			}
		}

		
		public Int32? RTRY_DELY_MILI
		{
			get { return _rtry_dely_mili; }
			set
			{
				CheckSetProperty(ref _rtry_dely_mili, value);
			}
		}

		
		public Int32 MAX_VOLM_RETR
		{
			get { return _max_volm_retr; }
			set
			{
				CheckSetProperty(ref _max_volm_retr, value);
			}
		}

		
		public Int32? QUEU_SIZE
		{
			get { return _queu_size; }
			set
			{
				CheckSetProperty(ref _queu_size, value);
			}
		}

		
		public Int32? EROR_TRHD
		{
			get { return _eror_trhd; }
			set
			{
				CheckSetProperty(ref _eror_trhd, value);
			}
		}

		
		public String DAYS_YEAR_TYPE_KEY
		{
			get { return _days_year_type_key; }
			set
			{
				CheckSetProperty(ref _days_year_type_key, value);
			}
		}

		
		public Boolean ACT_IND
		{
			get { return _act_ind; }
			set
			{
				CheckSetProperty(ref _act_ind, value);
			}
		}

		
		public Boolean ROLL_OVER_EXEC_IND
		{
			get { return _roll_over_exec_ind; }
			set
			{
				CheckSetProperty(ref _roll_over_exec_ind, value);
			}
		}

		
		public Boolean IS_MNTH_END
		{
			get { return _is_mnth_end; }
			set
			{
				CheckSetProperty(ref _is_mnth_end, value);
			}
		}

		
		public Int32 CRIT_MTCH_DTE_ID
		{
			get { return _crit_mtch_dte_id; }
			set
			{
				CheckSetProperty(ref _crit_mtch_dte_id, value);
			}
		}

		
		public String INSR_BY
		{
			get { return _insr_by; }
			set
			{
				CheckSetProperty(ref _insr_by, value);
			}
		}

		
		public String UPDT_BY
		{
			get { return _updt_by; }
			set
			{
				CheckSetProperty(ref _updt_by, value);
			}
		}

		
		public DateTime INSR_DTE
		{
			get { return _insr_dte; }
			set
			{
				CheckSetProperty(ref _insr_dte, value);
			}
		}

		
		public DateTime UPDT_DTE
		{
			get { return _updt_dte; }
			set
			{
				CheckSetProperty(ref _updt_dte, value);
			}
		}

		

		
	}

		public class ProcessConfigurationValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "BTCH_PRCS_CONF_ID", "PRCS_ID", "PRCS_KEY", "MAX_DOP", "MAX_VOLM_RETR", "ACT_IND", "ROLL_OVER_EXEC_IND", "IS_MNTH_END", "CRIT_MTCH_DTE_ID", "INSR_BY", "UPDT_BY", "INSR_DTE", "UPDT_DTE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		                ["DAYS_YEAR_TYPE_KEY"] = 25
		      , ["INSR_BY"] = 20
		  , ["UPDT_BY"] = 20
		   
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
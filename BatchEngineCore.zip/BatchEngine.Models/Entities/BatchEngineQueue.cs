
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchQueue
	public partial class BatchEngineQueue : BaseModel
	{
		
				private Int32 _btch_queu_id;
				private String _queu_nme;
				private Int32? _queu_seq;
				private Int64 _ref_id;
				private Boolean _is_fnsh;
				private String _insr_by;
				private String _updt_by;
				private DateTime _insr_dte;
				private DateTime _updt_dte;
		
		//public BatchEngineQueue BatchEngineQueue { get { return this; } } //Self reference property

		
		public Int32 BTCH_QUEU_ID
		{
			get { return _btch_queu_id; }
			set
			{
				CheckSetProperty(ref _btch_queu_id, value);
			}
		}

		
		public String QUEU_NME
		{
			get { return _queu_nme; }
			set
			{
				CheckSetProperty(ref _queu_nme, value);
			}
		}

		
		public Int32? QUEU_SEQ
		{
			get { return _queu_seq; }
			set
			{
				CheckSetProperty(ref _queu_seq, value);
			}
		}

		
		public Int64 REF_ID
		{
			get { return _ref_id; }
			set
			{
				CheckSetProperty(ref _ref_id, value);
			}
		}

		
		public Boolean IS_FNSH
		{
			get { return _is_fnsh; }
			set
			{
				CheckSetProperty(ref _is_fnsh, value);
			}
		}

		
		public String INSR_BY
		{
			get { return _insr_by; }
			set
			{
				CheckSetProperty(ref _insr_by, value);
			}
		}

		
		public String UPDT_BY
		{
			get { return _updt_by; }
			set
			{
				CheckSetProperty(ref _updt_by, value);
			}
		}

		
		public DateTime INSR_DTE
		{
			get { return _insr_dte; }
			set
			{
				CheckSetProperty(ref _insr_dte, value);
			}
		}

		
		public DateTime UPDT_DTE
		{
			get { return _updt_dte; }
			set
			{
				CheckSetProperty(ref _updt_dte, value);
			}
		}

		

		
	}

		public class BatchEngineQueueValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "BTCH_QUEU_ID", "QUEU_NME", "REF_ID", "IS_FNSH", "INSR_BY", "UPDT_BY", "INSR_DTE", "UPDT_DTE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		    ["QUEU_NME"] = 50
		     , ["INSR_BY"] = 20
		  , ["UPDT_BY"] = 20
		   
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
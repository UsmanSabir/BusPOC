
/* This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
using NS.ORM;


namespace BatchEngine.Models.Entities
{

	///BatchProcessGroupDetail
	public partial class BatchProcessGroupDetail 

	{

	public static List<BatchProcessGroupDetail> Read(
		int? depth=null
	)
	{
		
		return Read(null, depth);
		
	}

	public static List<BatchProcessGroupDetail> Read(Dictionary<string, object> parameters, int? depth = null)
        {
            EntityContextExt<BatchProcessGroupDetail> c = EntityContextExt.Create<BatchProcessGroupDetail>();
            c.Read(parameters, depth);
            return c.Entity;
        }


		

		public static List<BatchProcessGroupDetail> GetActiveGroupProcess(
Int64 groupKey)
{
			EntityContextExt<BatchProcessGroupDetail> c = EntityContextExt.Create<BatchProcessGroupDetail>();
            c.ReadEntityByKey(new Dictionary<string, object>()
            {
				{ "groupKey" , groupKey }, 
            }
);
			//if (fillChilds)
            //    c.FillChilds();
            return c.Entity;
			}
		
		public static List<BatchProcessGroupDetail> GetActiveGroupProcess(
Int64 groupKey, string cs)
{
			EntityContextExt<BatchProcessGroupDetail> c = EntityContextExt.Create<BatchProcessGroupDetail>(cs); //cs = connection string
            c.ReadEntityByKey(new Dictionary<string, object>()
            {
				{ "groupKey" , groupKey }, 
            }
);
			//if (fillChilds)
            //    c.FillChilds();
            return c.Entity;
			}
		

		public static void Persist(IList<BatchProcessGroupDetail> entity)
    {
        EntityContextExt<BatchProcessGroupDetail> c = EntityContextExt.Create(entity);
        c.Persist();
    }
		
	

	}
	

#pragma warning restore CS1591

}
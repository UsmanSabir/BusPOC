
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessGroupMaster
	public partial class BatchProcessGroupMaster : BaseModel
	{
		
				private Int32 _grp_key;
				private String _nme;
				private String _insr_by;
				private String _updt_by;
				private DateTime _insr_dte;
				private DateTime _updt_dte;
		
		//public BatchProcessGroupMaster BatchProcessGroupMaster { get { return this; } } //Self reference property

		
		public Int32 GRP_KEY
		{
			get { return _grp_key; }
			set
			{
				CheckSetProperty(ref _grp_key, value);
			}
		}

		
		public String NME
		{
			get { return _nme; }
			set
			{
				CheckSetProperty(ref _nme, value);
			}
		}

		
		public String INSR_BY
		{
			get { return _insr_by; }
			set
			{
				CheckSetProperty(ref _insr_by, value);
			}
		}

		
		public String UPDT_BY
		{
			get { return _updt_by; }
			set
			{
				CheckSetProperty(ref _updt_by, value);
			}
		}

		
		public DateTime INSR_DTE
		{
			get { return _insr_dte; }
			set
			{
				CheckSetProperty(ref _insr_dte, value);
			}
		}

		
		public DateTime UPDT_DTE
		{
			get { return _updt_dte; }
			set
			{
				CheckSetProperty(ref _updt_dte, value);
			}
		}

		

		
	}

		public class BatchProcessGroupMasterValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "GRP_KEY", "INSR_BY", "UPDT_BY", "INSR_DTE", "UPDT_DTE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		    ["NME"] = 100
		  , ["INSR_BY"] = 20
		  , ["UPDT_BY"] = 20
		   
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
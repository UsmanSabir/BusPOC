
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessState
	public partial class BatchProcessState : BaseModel
	{
		
				private Int64 _btch_prcs_stat_id;
				private Guid _crlt_id;
				private DateTime? _updt_on;
				private Int32 _rtry_cont;
				private Int32 _cmpy_id;
				private Int32 _brch_id;
				private DateTime _prcg_dte;
				private Int32 _prcs_id;
				private Boolean _is_volm_genr;
				private Boolean _has_volm;
				private Int64? _prnt_id;
				private String _dpdt_prcs_id;
				private Int64 _grp_id;
				private Boolean _is_fnsh;
				private Boolean _is_stop;
				private String _crit;
				private DateTime? _strt_time;
				private String _curr_stat;
				private Int32 _sub_tnnt_id;
				private DateTime? _cmpl_time;
				private DateTime? _genr_cmpl_time;
				private String _rslt_sts;
				private Int32 _grp_seq_id;
				private Boolean? _grp_stop_flg;
				private String _queu_nme;
				private Int32? _queu_seq;
				private Boolean _has_prty;
				private String _node_id;
				private String _insr_by;
				private String _updt_by;
				private DateTime _insr_dte;
				private DateTime _updt_dte;
		
		//public BatchProcessState BatchProcessState { get { return this; } } //Self reference property

		
		public Int64 BTCH_PRCS_STAT_ID
		{
			get { return _btch_prcs_stat_id; }
			set
			{
				CheckSetProperty(ref _btch_prcs_stat_id, value);
			}
		}

		
		public Guid CRLT_ID
		{
			get { return _crlt_id; }
			set
			{
				CheckSetProperty(ref _crlt_id, value);
			}
		}

		
		public DateTime? UPDT_ON
		{
			get { return _updt_on; }
			set
			{
				CheckSetProperty(ref _updt_on, value);
			}
		}

		
		public Int32 RTRY_CONT
		{
			get { return _rtry_cont; }
			set
			{
				CheckSetProperty(ref _rtry_cont, value);
			}
		}

		
		public Int32 CMPY_ID
		{
			get { return _cmpy_id; }
			set
			{
				CheckSetProperty(ref _cmpy_id, value);
			}
		}

		
		public Int32 BRCH_ID
		{
			get { return _brch_id; }
			set
			{
				CheckSetProperty(ref _brch_id, value);
			}
		}

		
		public DateTime PRCG_DTE
		{
			get { return _prcg_dte; }
			set
			{
				CheckSetProperty(ref _prcg_dte, value);
			}
		}

		
		public Int32 PRCS_ID
		{
			get { return _prcs_id; }
			set
			{
				CheckSetProperty(ref _prcs_id, value);
			}
		}

		
		public Boolean IS_VOLM_GENR
		{
			get { return _is_volm_genr; }
			set
			{
				CheckSetProperty(ref _is_volm_genr, value);
			}
		}

		
		public Boolean HAS_VOLM
		{
			get { return _has_volm; }
			set
			{
				CheckSetProperty(ref _has_volm, value);
			}
		}

		
		public Int64? PRNT_ID
		{
			get { return _prnt_id; }
			set
			{
				CheckSetProperty(ref _prnt_id, value);
			}
		}

		
		public String DPDT_PRCS_ID
		{
			get { return _dpdt_prcs_id; }
			set
			{
				CheckSetProperty(ref _dpdt_prcs_id, value);
			}
		}

		
		public Int64 GRP_ID
		{
			get { return _grp_id; }
			set
			{
				CheckSetProperty(ref _grp_id, value);
			}
		}

		
		public Boolean IS_FNSH
		{
			get { return _is_fnsh; }
			set
			{
				CheckSetProperty(ref _is_fnsh, value);
			}
		}

		
		public Boolean IS_STOP
		{
			get { return _is_stop; }
			set
			{
				CheckSetProperty(ref _is_stop, value);
			}
		}

		
		public String CRIT
		{
			get { return _crit; }
			set
			{
				CheckSetProperty(ref _crit, value);
			}
		}

		
		public DateTime? STRT_TIME
		{
			get { return _strt_time; }
			set
			{
				CheckSetProperty(ref _strt_time, value);
			}
		}

		
		public String CURR_STAT
		{
			get { return _curr_stat; }
			set
			{
				CheckSetProperty(ref _curr_stat, value);
			}
		}

		
		public Int32 SUB_TNNT_ID
		{
			get { return _sub_tnnt_id; }
			set
			{
				CheckSetProperty(ref _sub_tnnt_id, value);
			}
		}

		
		public DateTime? CMPL_TIME
		{
			get { return _cmpl_time; }
			set
			{
				CheckSetProperty(ref _cmpl_time, value);
			}
		}

		
		public DateTime? GENR_CMPL_TIME
		{
			get { return _genr_cmpl_time; }
			set
			{
				CheckSetProperty(ref _genr_cmpl_time, value);
			}
		}

		
		public String RSLT_STS
		{
			get { return _rslt_sts; }
			set
			{
				CheckSetProperty(ref _rslt_sts, value);
			}
		}

		
		public Int32 GRP_SEQ_ID
		{
			get { return _grp_seq_id; }
			set
			{
				CheckSetProperty(ref _grp_seq_id, value);
			}
		}

		
		public Boolean? GRP_STOP_FLG
		{
			get { return _grp_stop_flg; }
			set
			{
				CheckSetProperty(ref _grp_stop_flg, value);
			}
		}

		
		public String QUEU_NME
		{
			get { return _queu_nme; }
			set
			{
				CheckSetProperty(ref _queu_nme, value);
			}
		}

		
		public Int32? QUEU_SEQ
		{
			get { return _queu_seq; }
			set
			{
				CheckSetProperty(ref _queu_seq, value);
			}
		}

		
		public Boolean HAS_PRTY
		{
			get { return _has_prty; }
			set
			{
				CheckSetProperty(ref _has_prty, value);
			}
		}

		
		public String NODE_ID
		{
			get { return _node_id; }
			set
			{
				CheckSetProperty(ref _node_id, value);
			}
		}

		
		public String INSR_BY
		{
			get { return _insr_by; }
			set
			{
				CheckSetProperty(ref _insr_by, value);
			}
		}

		
		public String UPDT_BY
		{
			get { return _updt_by; }
			set
			{
				CheckSetProperty(ref _updt_by, value);
			}
		}

		
		public DateTime INSR_DTE
		{
			get { return _insr_dte; }
			set
			{
				CheckSetProperty(ref _insr_dte, value);
			}
		}

		
		public DateTime UPDT_DTE
		{
			get { return _updt_dte; }
			set
			{
				CheckSetProperty(ref _updt_dte, value);
			}
		}

		

		
	}

		public class BatchProcessStateValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "BTCH_PRCS_STAT_ID", "CRLT_ID", "RTRY_CONT", "CMPY_ID", "BRCH_ID", "PRCG_DTE", "PRCS_ID", "IS_VOLM_GENR", "HAS_VOLM", "GRP_ID", "IS_FNSH", "IS_STOP", "CRIT", "CURR_STAT", "SUB_TNNT_ID", "RSLT_STS", "GRP_SEQ_ID", "HAS_PRTY", "INSR_BY", "UPDT_BY", "INSR_DTE", "UPDT_DTE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		              ["DPDT_PRCS_ID"] = 500
		     , ["CRIT"] = 4000
		   , ["CURR_STAT"] = 50
		     , ["RSLT_STS"] = 50
		    , ["QUEU_NME"] = 50
		    , ["NODE_ID"] = 250
		  , ["INSR_BY"] = 20
		  , ["UPDT_BY"] = 20
		   
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
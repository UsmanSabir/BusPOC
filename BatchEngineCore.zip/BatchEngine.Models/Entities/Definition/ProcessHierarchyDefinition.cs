 
 
 
 

/*  This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
	Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
using NS.Utilities;
using NS.ORM.Definitions;
using NS.ORM.Definitions.Classes;

using BatchEngine.Models.Entities;


namespace BatchEngine.Models.Entities.Definition
{
	public class ProcessHierarchyDefinition : BaseDefination
	{

	
 

		//constructor ctor
		public ProcessHierarchyDefinition(): base()
        {
			DefinitionVersion = 3;

			ParameterNames = new List<string>()
		    {
					    };
					 
		 
		  //==========Start secondarySqlColl=============


		  
		  //=========End secondarySqlColl=============

			//store type relation (i.e. join and where clause)



			// ===== Ver 2 ======

			//better performance with "OrdinalIgnoreCase" in string key comparison. ref http://stackoverflow.com/a/7145953 
			AggregateChildsV2 = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
			{
					};


			ChildRelations = new Dictionary<string, Tuple<RelationDetails, Func<ProcessHierarchy, IList<object>>, Action<List<ProcessHierarchy>, List<BaseModel>>>>()			
			{
			};


		} //end ctor
		
		internal Dictionary<string, Tuple<RelationDetails, Func<ProcessHierarchy, IList<object>>, Action<List<ProcessHierarchy>, List<BaseModel>>>> ChildRelations { get; set; }

		public override bool HasIdentity { get; protected set; } = true;
		
		public override string IdentityColumn { get; protected set; } = "BTCH_PRCS_GRP_DET_ID";        
        
		public override string RootName => string.Empty;//TODO

        public override bool HasChilds { get; } = false ;

        public override string SelectQuery { get; protected set; } = @"SELECT BTCH_PRCS_GRP_DET_ID , GRP_KEY , PRCS_ID , PRNT_PRCS_ID , DPDT_PRCS_ID , ACT_IND  FROM BTCH_PRCS_GRP_DET  ";

        public override bool Updatable { get; protected set; } = false;
        
		public override string UpdateTableName { get; protected set; } = @"BTCH_PRCS_GRP_DET";
	
		public override string CountQuery { get; protected set; } = @"SELECT COUNT(*) FROM    BTCH_PRCS_GRP_DET  {0}";

		public override string OrderBy { get; set; } = @"" ;

		public override string Where { get; protected set; } = @""; 

		public override string GroupBy { get; set; } = @""; 

		public override string Having { get; set; } =  @"";

				
		public override void IdInjector<T>(T item, int id)
        {

		
		var t = item as ProcessHierarchy;
            if (t != null)
            {
				t.BTCH_PRCS_GRP_DET_ID = id;     


       
			}
		
            
        }

		public override void UpdateChildIds<T>(T item)
        {

		
		var t = item as ProcessHierarchy;
            if (t != null)
            {
				var id = t.BTCH_PRCS_GRP_DET_ID;

       
			}
		
            
        }

		
		
public override IEnumerable<string> GetInsertIgnoreList<T>(T entity)
        {
            //Nested Iterators
            //nameof(entity.State)
            foreach (var i in base.GetInsertIgnoreList(entity)) yield return i;

            //example usage
            
             
						yield return nameof(ProcessHierarchy.BTCH_PRCS_GRP_DET_ID);
						yield return nameof(ProcessHierarchy.GRP_KEY);
						yield return nameof(ProcessHierarchy.PRCS_ID);
						yield return nameof(ProcessHierarchy.PRNT_PRCS_ID);
						yield return nameof(ProcessHierarchy.DPDT_PRCS_ID);
						yield return nameof(ProcessHierarchy.ACT_IND);
			
						
        }

		public override IEnumerable<string> GetClrMapping()
        {
				return base.GetClrMapping();
           
			
			
        }

		public override SerializableDictionary<string,object> GetIds(BaseModel model)
	    {
	        var t = model as ProcessHierarchy;
	        if (t != null)
	        {

	            var lst = new SerializableDictionary<string,object>();

								lst.Add(nameof(t.BTCH_PRCS_GRP_DET_ID), t.BTCH_PRCS_GRP_DET_ID); 
						
	            
	            
	            return lst;
	        }

	        return base.GetIds(model);
	    }

		 public override Tuple<string, IList<object>> GetChildSqlWithParamsV2(BaseModel parent, Type entityChild,
            string propertyName, string aggregateName, Action<List<BaseModel>> postAction = null)
         {
            var target = parent as ProcessHierarchy;
            if (target == null)
                throw new ArgumentNullException(nameof(parent));


            var type = entityChild;//.GetType();
            var def = type.ToDefination();
            Tuple<RelationDetails, Func<ProcessHierarchy, IList<object>>, Action<List<ProcessHierarchy>, List<BaseModel>>> relationTuple=null;
			
            string sql = string.Empty;
            IList<object> ids = null;
            

            string aggrName = aggregateName;
            if (string.IsNullOrWhiteSpace(aggrName))
            {
                relationTuple = ChildRelations.Values.FirstOrDefault(f => f.Item1.ChildType == type && f.Item1.PropertyName.Equals(propertyName));//?.Item1.AggregateName;
            }

            if (relationTuple!=null || ChildRelations.TryGetValue(propertyName + aggrName, out relationTuple))
            {
                DbBatch batch = new DbBatch();
                int i = 0;
                var rel = relationTuple.Item1;

                //HACK: entityId is fixed(empty string)
                var s = def.GetSelectBatchV2(rel.AggregateName, batch,
                    rel.Join,
                                        string.Format(rel.CustomWhere, string.Join(" and ", GetUpdateWhereV2().Select(p => (string.IsNullOrEmpty(rel.Join) ? string.Empty :/*in case of join, append table name with each column name in where clause*/ UpdateTableName + ".") + p + "= @" + i++).ToArray()))
                        //, postAction
                        //, list => { ChildProcessor<Product>(parent, list);}
                        , 1, 1, null, null
                        );


                sql = batch.GetQueries().FirstOrDefault().Key;
                ids = relationTuple.Item2(target);
            }

            

            return Tuple.Create(sql, ids);
        }


		private List<BaseModel> ProcessResult(IModelReader reader, DbBatch batch, EntityHost<ProcessHierarchy> entityHost, Action<List<BaseModel>> postResultAction)
        {
            var ret = reader.GetWithDefination<ProcessHierarchy>(this);
            entityHost?.SetHostedItems(ret);

            ProcessChildBatches(batch, ret);

            var r = new List<BaseModel>(ret);
            postResultAction?.Invoke(r); //r);

            return r;
        }
		public override void ProcessChildBatches<T>(DbBatch batch, List<T> ret)
        {
            if (ret.Count > 0)
            {
                foreach (var childBatch in batch.Successor)
                {
                    childBatch.ProcessInitilizer(ret, childs => { ChildProcessor(ret, childs); });
                }
            }
        }
		public override void ChildProcessor<T>(List<T> parentItems, List<BaseModel> childs)
        {
            var items = parentItems.Cast<ProcessHierarchy>().ToList();
            var itemsCount = items.Count;
            if (itemsCount==0)
            {
                return;
            }

            if (childs.Count > 0)
            {
                
					    }
        }
		public override void CustomMapper<T>(T item, IDbReader row)
        {
            var target = item as ProcessHierarchy;
            if (target == null) return;

								target.BTCH_PRCS_GRP_DET_ID = row.GetInt32("BTCH_PRCS_GRP_DET_ID");

			
								target.GRP_KEY = row.GetInt32("GRP_KEY");

			
								target.PRCS_ID = row.GetInt32("PRCS_ID");

			
								target.PRNT_PRCS_ID = (Int32?) row.GetValue("PRNT_PRCS_ID");
	
			
								target.DPDT_PRCS_ID = row.GetString("DPDT_PRCS_ID");

			
								target.ACT_IND = row.GetInt32("ACT_IND");

			
			
		}

		public override IEnumerable<string> GetUpdateWhere<T>(T entity)
        {
            var target = entity as ProcessHierarchy;
            if (target == null)
                throw new ArgumentNullException(nameof(entity) + " is null.");
									yield return nameof(target.BTCH_PRCS_GRP_DET_ID); 
						
            
        }

		public IEnumerable<string> GetUpdateWhereV2()
        {
								yield return nameof(ProcessHierarchy.BTCH_PRCS_GRP_DET_ID); 
			            
        }

		public override IEnumerable<IEnumerable<BaseModel>> GetChildsColl(IEnumerable<BaseModel> items)
        {
            var target = items as IEnumerable<ProcessHierarchy>;
	    foreach (var child in base.GetChildsColl(items))
            {
                yield return child;
            }
        }

		public override IEnumerable<BaseModel> GetChilds(BaseModel item)
        {
            var target = item as ProcessHierarchy;
	    foreach (var baseModel in base.GetChilds(item))
            {
                yield return baseModel;
            }
        }

		public override IEnumerable<BaseModel> AcceptChildCollections(BaseModel item) 
        {
		var target = item as ProcessHierarchy;
	    foreach (var baseModel in base.GetChilds(item))
            {
                yield return baseModel;
            }

            
            
        }
						
		public override DbBatch GetSelectBatchV2(string aggregateId, DbBatch batch, string strJoin, string strWhere, int? depth, int level, Action<List<BaseModel>> postAction, Func<Type, string, string, string, bool> shouldAppendChild)
        {
            if (depth.HasValue && depth.Value < level)
                return batch;          

            if (batch == null)
                batch = new DbBatch();

            //var sql = string.Format(SelectQuery, column, vals);
            var sbQuery = new StringBuilder();
            sbQuery.Append(" " + SelectQuery);

            if(!string.IsNullOrEmpty(strJoin))
            {
                sbQuery.AppendLine(strJoin);
            }
            var whereClause = strWhere;
            bool customWhere = true;
            if(string.IsNullOrEmpty(whereClause))
            {
                whereClause = Where;//string.IsNullOrWhiteSpace(Where)?" 1=1 ":Where;
                customWhere = false;
            }

			if (whereClause.Trim().Equals("1=1"))
                whereClause = string.Empty;
            else if (!string.IsNullOrWhiteSpace(whereClause))
                sbQuery.Append(" WHERE " + whereClause);

			if (!string.IsNullOrEmpty(GroupBy))
            {
                sbQuery.Append(" Group BY " + GroupBy);
            }
			if (!string.IsNullOrEmpty(Having))
            {
                sbQuery.Append(" HAVING " + Having);
            }
            if (!string.IsNullOrEmpty(OrderBy))
            {
                sbQuery.Append(" ORDER BY " + OrderBy);
            }

            var entityHost = new EntityHost<ProcessHierarchy>();
            
            batch.AddQuery(sbQuery.ToString(), (reader, dbBatch) => ProcessResult(reader, dbBatch, entityHost, postAction));
            sbQuery.Clear();
            
            //TODO: for childs, either use 1-direct column that exist in child table, 2-use sub query with in syntax, 3-use join if relation have multiple columns
            //if  customWhere==true, if subquery with "in" supported then use relation column in sub-query else use joins
            //if customWhere==false, if child table have same column then use/pass it for where clause, else sub-query with "in" if supported or use joins

            var nextLevel = level + 1;

            if (depth.HasValue && depth.Value < nextLevel)
                return batch;
                

		    List<string> entityChilds;
            if (AggregateChildsV2.TryGetValue(aggregateId, out entityChilds))
            {
                foreach (var entityChild in entityChilds)
                {
					Tuple<RelationDetails, Func<ProcessHierarchy, IList<object>>, Action<List<ProcessHierarchy>, List<BaseModel>>> relationTuple;

                    if (ChildRelations.TryGetValue(entityChild, out relationTuple))
                    {	
						var rel = relationTuple.Item1;					
						bool appendInd = shouldAppendChild?.Invoke(relationTuple.Item1.ChildType, nameof(ProcessHierarchy), aggregateId, rel.PropertyName) ?? true;						
                        if(appendInd)
                        {
							var def = rel.ChildType.ToDefination();						
							string @where = string.Empty;
                            var @join = string.Empty;

                            if (!rel.UseParentWhere) //in-case UseParentWhere==true then use entity's "where" clause defined with parameter name matching parent parameter name. so keep it empty string, child will append its 'where'
                            {
                                if (!string.IsNullOrWhiteSpace(strJoin))
                                {
                                    if (string.IsNullOrWhiteSpace(rel.Join))
                                    {
                                        //single column join
                                        @join = rel.ConditionalJoin + strJoin;
                                    }
                                    else
                                    {
                                        //multi column join
                                        @join = rel.Join + strJoin;
                                    }

                                    @where = whereClause;
                                }
                                else
                                {
                                    if (string.IsNullOrWhiteSpace(rel.Join))
                                    {
                                        //no joins
                                        if (customWhere)
                                            @where = string.Format(rel.CustomWhere, string.IsNullOrWhiteSpace(whereClause) ? "1=1" : whereClause);
                                        else
                                            @where = rel.Where;
                                    }
                                    else
                                    {
                                        //join just started
                                        @join = rel.Join;
                                        @where = whereClause;
                                    }

                                    
                                }

         //                       if (string.IsNullOrWhiteSpace(rel.Join))
         //                       {
         //                           if (customWhere)
         //                               @where = string.Format(rel.CustomWhere, string.IsNullOrWhiteSpace(whereClause) ? "1=1" : whereClause);
         //                           else
         //                               @where = rel.Where;
         //                       }
         //                       else
         //                       {
         //                           //have join with parent                                    
									//@where = whereClause; // in this case, this child relation already has join with its parent, so we can use parent's where clause to optimize query


         //                           //else if (customWhere) // orm has passed a custom "where" clause
         //                           //    @where = whereClause; // in this case, this child relation already has join with its parent, so we can use parent's where clause to optimize query
         //                           //else
         //                           //    @where = rel.Where; //we are in join here, can we use entity's own where clause here?
         //                       }
                            }

                            var s = def.GetSelectBatchV2(aggregateId, batch, @join,
                                    @where
                                    , depth, nextLevel, list => relationTuple.Item3(entityHost.Items, list),
                                    shouldAppendChild);
						}
                    }
                }            
	        }
			            
            //var baseSqls = base.GetSelectBatchV2(aggregateId, batch, strJoin, strWhere, depth, level, postAction, shouldAppendChild);
            return batch;
        }

		public override DbBatch FillChilds(IEnumerable<BaseModel> items, string aggregateId, DbBatch batch, int? depth, int level, Func<Type, string, string, string, bool> shouldAppendChild)
        {
		 if (depth.HasValue && depth.Value < level)
                return batch;

            if (batch == null)
                batch = new DbBatch();

            string whereClause = string.Empty;

            StringBuilder sb=new StringBuilder();

			var cast = items.Cast<ProcessHierarchy>().ToList();

						var p1 = cast.Select(r=> r.BTCH_PRCS_GRP_DET_ID).ToList();
			string pName1 = nameof(ProcessHierarchy.BTCH_PRCS_GRP_DET_ID);
						sb.Append($"{pName1} in(@{pName1}) ");
				
				batch.AddParam(pName1, p1);				
			
			whereClause = sb.ToString();

			bool customWhere = true;
            
            var nextLevel = level + 1;

            if (depth.HasValue && depth.Value < nextLevel)
                return batch;

            List<string> entityChilds;
			if (AggregateChildsV2.TryGetValue(aggregateId, out entityChilds))
            {
                foreach (var entityChild in entityChilds)
                {
					Tuple<RelationDetails, Func<ProcessHierarchy, IList<object>>, Action<List<ProcessHierarchy>, List<BaseModel>>> relationTuple;

                    if (ChildRelations.TryGetValue(entityChild, out relationTuple))
                    {	
						var rel = relationTuple.Item1;					
						bool appendInd = shouldAppendChild?.Invoke(relationTuple.Item1.ChildType, nameof(ProcessHierarchy), aggregateId, rel.PropertyName) ?? true;						
                        if(appendInd)
                        {
							
							var def = rel.ChildType.ToDefination();
							
							var s = def.GetSelectBatchV2(aggregateId, batch, rel.Join,
							customWhere ? string.Format(rel.CustomWhere, string.IsNullOrWhiteSpace(whereClause) ? "1=1" : whereClause) : rel.Where
							, depth, nextLevel, list =>  relationTuple.Item3(cast, list) , shouldAppendChild);							
						}
                    }
                }            
	        }
			return batch;

		}

		/// <summary>
        /// Checks if entity exists in specified entity graph.
        /// </summary>
        /// <param name="entityId">The entity graph key to search.</param>
        /// <param name="type">The entity type to search.</param>
        /// <returns>True, if entity found in specifed entity graph.</returns>
        /// <remarks>
        /// <para>[US] 19/08/2016  1.0 Method created.</para>
        /// </remarks>
        public override bool HaveType(string entityId, Type type)
        {
            //return false;

            if (AggregateChildsV2 == null || AggregateChildsV2.ContainsKey(entityId) == false)
            {
                return false;
            }

            var types = AggregateChildsV2[entityId];


            var haveType =
                ChildRelations.Where(t => types.Any(ty => ty.Equals(t.Key))).Any(a => a.Value.Item1.ChildType == type);
            return haveType;
            
        }


	}//end class

#pragma warning restore

}//end ns
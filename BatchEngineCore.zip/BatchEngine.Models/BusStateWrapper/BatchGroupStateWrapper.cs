
/* This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using BatchEngine.Core.Groups;
using BatchEngine.Models.Entities;

namespace BatchEngine.Models.BusStateWrapper
{

	///BatchGroupState
	public class BatchGroupStateWrapper : IReadWritableGroupEntity
    {
	    public BatchGroupState _state;

	    public BatchGroupStateWrapper(BatchGroupState state)
	    {
	        _state = state;
	    }

        public bool IsFinished
        {
            get => _state.ISFINISHED;
            set => _state.ISFINISHED=value;
        }

        public bool IsStopped
        {
            get => _state.ISSTOPPED;
            set => _state.ISSTOPPED=value;
        }

        public long Id
        {
            get => _state.ID;
            set => Id = _state.ID;
        }

        public int GroupKey
        {
            get => _state.GROUPKEY;
            set => _state.GROUPKEY=value;
        }

        public bool IsManual
        {
            get => _state.ISMANUAL;
            set => _state.ISMANUAL=value;
        }

        public bool IsResubmission
        {
            get => _state.ISRESUBMISSION;
            set => _state.ISRESUBMISSION=value;
        }

        public string SubmittedBy
        {
            get => _state.SUBMITTEDBY;
            set => _state.SUBMITTEDBY=value;
        }

        public string Criteria
        {
            get => _state.CRITERIA;
            set => _state.CRITERIA=value;
        }

        public string State
        {
            get => _state.CURRENTSTATE;
            set => _state.CURRENTSTATE = value;
        }

        public bool IsGenerated
        {
            get => _state.ISGENERATED;
            set => _state.ISGENERATED = value;
        }

        public string Payload
        {
            get => _state.PAYLOAD;
            set => _state.PAYLOAD = value;
        }

        public string NodeId
        {
            get => _state.NODEID;
            set => _state.NODEID = value;
        }

        public string QueueName
        {
            get => _state.QUEUENAME;
            set => _state.QUEUENAME = value;
        }

        public int? QueueSeq
        {
            get => _state.QUEUESEQ;
            set => _state.QUEUESEQ = value;
        }

        public bool HasPriority
        {
            get => _state.HASPRIORITY;
            set => _state.HASPRIORITY = value;
        }
    }
	

#pragma warning restore CS1591

}
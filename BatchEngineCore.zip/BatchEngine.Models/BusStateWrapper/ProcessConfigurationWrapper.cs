﻿
using BatchEngine.Core;

namespace BatchEngine.Models.BusStateWrapper
{
    public class ProcessConfigurationWrapper:IProcessConfiguration
    {
        private readonly Entities.ProcessConfiguration _state;

        public ProcessConfigurationWrapper(Entities.ProcessConfiguration state)
        {
            _state = state;
        }

        public int ProcessId
        {
            get => _state.PROCESSID; // screen_code
        }

        public int ProcessKey
        {
            get => _state.PROCESSKEY;
            set => _state.PROCESSKEY=value;
        }

        public int BatchSize
        {
            get => _state.BATCHSIZE;
            //set => throw new System.NotImplementedException();
        }

        public int? ProcessTimeoutMins
        {
            get => _state.PROCESSTIMEOUTMINS;
            //set => throw new System.NotImplementedException();
        }

        public int? TaskTimeout
        {
            get => _state.TASKTIMEOUT;
            //set => throw new System.NotImplementedException();
        }

        public int? ProcessRetries
        {
            get => _state.PROCESSRETRIES;
            //set => throw new System.NotImplementedException();
        }

        public int? TaskRetries
        {
            get => _state.TASKRETRIES;
            //set => throw new System.NotImplementedException();
        }

        public int? RetryDelayMilli
        {
            get => _state.RETRYDELAYMILLI;
            //set => throw new System.NotImplementedException();
        }

        public int MaxVolumeRetries
        {
            get => _state.MAXVOLUMERETRIES;
            //set => throw new System.NotImplementedException();
        }

        public int? QueueSize
        {
            get => _state.QUEUESIZE;
            //set => throw new System.NotImplementedException();
        }

        public int? ErrorThreshold
        {
            get => _state.ERRORTHRESHOLD;
        }

        public bool IsActive
        {
            get => _state.ACT_IND;

        }

        public string DaysYearTypeKey
        {
            get => _state.DAYS_YEAR_TYPE_KEY;
        }

        public bool RollOverInd
        {
            get => _state.ROLL_OVER_EXEC_IND;
        }
        public bool IsMonthEnd
        {
            get => _state.ISMONTHEND;
        }
    }
}
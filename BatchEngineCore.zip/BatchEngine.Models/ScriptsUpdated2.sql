﻿
CREATE TABLE [dbo].[BatchGroupState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[GroupKey] [int] NOT NULL,
	[SubmittedBy] [varchar](250) NOT NULL,
	[IsManual] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsManual]  DEFAULT ((1)),
	[IsResubmission] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsResubmission]  DEFAULT ((0)),
	[Criteria] [varchar](250) NOT NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsStopped]  DEFAULT ((0)),
	[CurrentState] [varchar](50) NOT NULL,
	[Payload] [varchar](max) NULL,
	[IsGenerated] [bit] NOT NULL CONSTRAINT [DF_BatchGroupState_IsGenerated]  DEFAULT ((0)),
 CONSTRAINT [PK_BatchGroupState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessConfig]    Script Date: 1/17/2019 11:05:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchProcessConfig](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProcessId] [int] NOT NULL,
	[ProcessKey] [int] NOT NULL,
	[BatchSize] [int] NOT NULL,
	[ProcessTimeoutMins] [int] NULL,
	[TaskTimeout] [int] NULL,
	[ProcessRetries] [int] NULL,
	[TaskRetries] [int] NULL,
	[RetryDelayMilli] [int] NULL,
	[MaxVolumeRetries] [int] NOT NULL CONSTRAINT [DF_BatchProcessConfig_MaxVolumeRetries]  DEFAULT ((3)),
	[QueueSize] [int] NULL,
	[ErrorThreshold] [int] NULL,
	[DAYS_YEAR_TYPE_KEY] [varchar](25) NULL,
	[ACT_IND] [bit] NOT NULL CONSTRAINT [DF_BatchProcessConfig_ACT_IND]  DEFAULT ((1)),
	[ROLL_OVER_EXEC_IND] [bit] NOT NULL CONSTRAINT [DF_BatchProcessConfig_ROLL_OVER_EXEC_IND]  DEFAULT ((1)),
	[IsMonthEnd] [bit] NOT NULL CONSTRAINT [DF_BatchProcessConfig_IsMonthEnd]  DEFAULT ((0)),
 CONSTRAINT [PK_BatchProcessConfig] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessGroupDetail]    Script Date: 1/17/2019 11:05:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchProcessGroupDetail](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[GroupKey] [int] NOT NULL,
	[ProcessId] [int] NOT NULL,
	[ParentProcessId] [int] NULL,
	[DependentProcessIds] [varchar](500) NULL,
	[ACT_IND] [bit] NOT NULL CONSTRAINT [DF_BatchProcessGroupDetail_ACT_IND]  DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessGroupMaster]    Script Date: 1/17/2019 11:05:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchProcessGroupMaster](
	[GroupKey] [int] IDENTITY(1,1) NOT NULL,
	[NME] [varchar](100) NULL,
	[insr_by] [varchar](20) NULL,
	[insr_DTE] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[GroupKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessState]    Script Date: 1/17/2019 11:05:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchProcessState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CorrelationId] [uniqueidentifier] NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[RetryCount] [int] NOT NULL CONSTRAINT [DF_BatchProcessState_RetryCount]  DEFAULT ((0)),
	[CompanyId] [int] NOT NULL,
	[BranchId] [int] NOT NULL,
	[ProcessingDate] [datetime] NOT NULL,
	[ProcessId] [int] NOT NULL,
	[IsVolumeGenerated] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsVolumeGenerated]  DEFAULT ((0)),
	[HasVolume] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_HasVolume]  DEFAULT ((0)),
	[ParentId] [bigint] NULL,
	[DependentProcessIds] [varchar](500) NULL,
	[GroupId] [bigint] NOT NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsStopped]  DEFAULT ((0)),
	[Criteria] [nvarchar](500) NOT NULL,
	[StartTime] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[SubTenantId] [int] NOT NULL,
	[CompleteTime] [datetime] NULL,
	[GenerationCompleteTime] [datetime] NULL,
	[ResultStatus] [varchar](50) NOT NULL CONSTRAINT [DF_BatchProcessState_ResultStatus]  DEFAULT ('Pending'),
	[GroupSeqId] [int] NOT NULL,
	[GroupStopper] [bit] NULL,
 CONSTRAINT [PK_BatchProcessState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchTaskState]    Script Date: 1/17/2019 11:05:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
CREATE TABLE [dbo].[BatchTaskState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[Payload] [varchar](500) NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[FailedCount] [int] NOT NULL CONSTRAINT [DF_BatchTask_FailedCount]  DEFAULT ((0)),
	[DeferredCount] [int] NOT NULL CONSTRAINT [DF_BatchTask_DeferredCount]  DEFAULT ((0)),
	[NodeKey] [varchar](250) NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchTask_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchTaskState_IsStopped]  DEFAULT ((0)),
	[StartedOn] [datetime] NULL,
	[CompletedOn] [datetime] NULL,
 CONSTRAINT [PK_BatchTaskState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchTaskValue]    Script Date: 1/17/2019 11:05:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchTaskValue](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TaskId] [bigint] NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[StateKey] [varchar](250) NOT NULL,
	[StateValue] [varchar](500) NULL,
 CONSTRAINT [PK_BatchTaskValue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
ALTER TABLE [dbo].[BatchProcessGroupDetail]  WITH CHECK ADD  CONSTRAINT [FK_ProcessGroups] FOREIGN KEY([GroupKey])
REFERENCES [dbo].[BatchProcessGroupMaster] ([GroupKey])
GO
ALTER TABLE [dbo].[BatchProcessGroupDetail] CHECK CONSTRAINT [FK_ProcessGroups]
GO

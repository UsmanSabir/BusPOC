﻿
/****** Object:  Table [dbo].[BatchGroupState]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[BatchGroupState](
	[Id] [BIGINT] IDENTITY(1,1) NOT NULL,
	[GroupKey] [INT] NOT NULL,
	[SubmittedBy] [VARCHAR](250) NOT NULL,
	[Criteria] [VARCHAR](MAX) NOT NULL,
	[IsFinished] [BIT] NOT NULL,
	[IsStopped] [BIT] NOT NULL,
	[CurrentState] [VARCHAR](50) NOT NULL,
	[Payload] [VARCHAR](MAX) NULL,
	[IsGenerated] [BIT] NOT NULL,
	[QueueName] [VARCHAR](50) NULL,
	[QueueSeq] [INT] NULL,
	[HasPriority] [BIT] NOT NULL,
	[NodeId] [VARCHAR](250) NULL,
	[InvokeTypeId] [INT] NOT NULL,
 CONSTRAINT [PK_BatchGroupState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessConfig]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[BatchProcessConfig](
	[Id] [INT] IDENTITY(1,1) NOT NULL,
	[ProcessId] [INT] NOT NULL,
	[ProcessKey] [INT] NOT NULL,
	[BatchSize] [INT] NOT NULL,
	[ProcessTimeoutMins] [INT] NULL,
	[TaskTimeout] [INT] NULL,
	[ProcessRetries] [INT] NULL,
	[TaskRetries] [INT] NULL,
	[RetryDelayMilli] [INT] NULL,
	[MaxVolumeRetries] [INT] NOT NULL CONSTRAINT [DF_BatchProcessConfig_MaxVolumeRetries]  DEFAULT ((3)),
	[QueueSize] [INT] NULL,
	[ErrorThreshold] [INT] NULL,
	[DAYS_YEAR_TYPE_KEY] [VARCHAR](25) NULL,
	[ACT_IND] [BIT] NOT NULL CONSTRAINT [DF_BatchProcessConfig_ACT_IND]  DEFAULT ((1)),
	[ROLL_OVER_EXEC_IND] [BIT] NOT NULL CONSTRAINT [DF_BatchProcessConfig_ROLL_OVER_EXEC_IND]  DEFAULT ((1)),
	[IsMonthEnd] [BIT] NOT NULL CONSTRAINT [DF_BatchProcessConfig_IsMonthEnd]  DEFAULT ((0)),
	[CRIT_MTCH_DTE_ID] [INT] NOT NULL CONSTRAINT [DF_BatchProcessConfig_CRIT_MTCH_DTE_ID]  DEFAULT ((1)),
 CONSTRAINT [PK_BatchProcessConfig] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessGroupDetail]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchProcessGroupDetail](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[GroupKey] [int] NOT NULL,
	[ProcessId] [int] NOT NULL,
	[ParentProcessId] [int] NULL,
	[DependentProcessIds] [varchar](500) NULL,
	[ACT_IND] [bit] NOT NULL CONSTRAINT [DF_BatchProcessGroupDetail_ACT_IND]  DEFAULT ((1)),
	[CanInvokeIndependent] [bit] NOT NULL CONSTRAINT [DF_BatchProcessGroupDetail_CanInvokeIndependent]  DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessGroupMaster]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchProcessGroupMaster](
	[GroupKey] [int] IDENTITY(1,1) NOT NULL,
	[NME] [varchar](100) NULL,
	[insr_by] [varchar](20) NULL,
	[insr_DTE] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[GroupKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchProcessState]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchProcessState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CorrelationId] [uniqueidentifier] NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[RetryCount] [int] NOT NULL CONSTRAINT [DF_BatchProcessState_RetryCount]  DEFAULT ((0)),
	[CompanyId] [int] NOT NULL,
	[BranchId] [int] NOT NULL,
	[ProcessingDate] [datetime] NOT NULL,
	[ProcessId] [int] NOT NULL,
	[IsVolumeGenerated] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsVolumeGenerated]  DEFAULT ((0)),
	[HasVolume] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_HasVolume]  DEFAULT ((0)),
	[ParentId] [bigint] NULL,
	[DependentProcessIds] [varchar](500) NULL,
	[GroupId] [bigint] NOT NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_IsStopped]  DEFAULT ((0)),
	[Criteria] [nvarchar](4000) NOT NULL,
	[StartTime] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[SubTenantId] [int] NOT NULL,
	[CompleteTime] [datetime] NULL,
	[GenerationCompleteTime] [datetime] NULL,
	[ResultStatus] [varchar](50) NOT NULL CONSTRAINT [DF_BatchProcessState_ResultStatus]  DEFAULT ('Pending'),
	[GroupSeqId] [int] NOT NULL,
	[GroupStopper] [bit] NULL,
	[QueueName] [varchar](50) NULL,
	[QueueSeq] [int] NULL,
	[HasPriority] [bit] NOT NULL CONSTRAINT [DF_BatchProcessState_HasPriority]  DEFAULT ((0)),
	[NodeId] [varchar](250) NULL,
 CONSTRAINT [PK_BatchProcessState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchQueue]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchQueue](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[QueueName] [varchar](50) NOT NULL,
	[QueueSeq] [int] NOT NULL,
	[RefId] [bigint] NOT NULL,
	[IsFinished] [bit] NOT NULL,
 CONSTRAINT [PK_BatchQueue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchTaskState]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
CREATE TABLE [dbo].[BatchTaskState](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[Payload] [varchar](500) NOT NULL,
	[UpdatedOn] [datetime] NULL,
	[CurrentState] [varchar](50) NOT NULL,
	[FailedCount] [int] NOT NULL CONSTRAINT [DF_BatchTask_FailedCount]  DEFAULT ((0)),
	[DeferredCount] [int] NOT NULL CONSTRAINT [DF_BatchTask_DeferredCount]  DEFAULT ((0)),
	[NodeKey] [varchar](250) NULL,
	[IsFinished] [bit] NOT NULL CONSTRAINT [DF_BatchTask_IsFinished]  DEFAULT ((0)),
	[IsStopped] [bit] NOT NULL CONSTRAINT [DF_BatchTaskState_IsStopped]  DEFAULT ((0)),
	[StartedOn] [datetime] NULL,
	[CompletedOn] [datetime] NULL,
	[HasPriority] [bit] NOT NULL CONSTRAINT [DF_BatchTaskState_HasPriority]  DEFAULT ((0)),
 CONSTRAINT [PK_BatchTaskState] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchTaskValue]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchTaskValue](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TaskId] [bigint] NOT NULL,
	[ProcessId] [bigint] NOT NULL,
	[StateKey] [varchar](250) NOT NULL,
	[StateValue] [varchar](500) NULL,
 CONSTRAINT [PK_BatchTaskValue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

CREATE TABLE [dbo].[BatchCommands](
	[Id] [INT] IDENTITY(1,1) NOT NULL,
	[Channel] [VARCHAR](500) NOT NULL,
	[Type] [VARCHAR](500) NOT NULL,
	[Command] [VARCHAR](500) NOT NULL,
	[Parameter] [VARCHAR](50) NULL,
	[PublishedByNode] [VARCHAR](150) NOT NULL,
	[PublishedTime] [DATETIME] NOT NULL CONSTRAINT [DF_BatchCommands_PublishedTime]  DEFAULT (GETUTCDATE()),
	[IsHandledByMaster] [BIT] NOT NULL CONSTRAINT [DF_BatchCommands_IsHandledByMaster]  DEFAULT ((0)),
	[HandlerNodeId] [VARCHAR](150) NULL,
 CONSTRAINT [PK_BatchCommands] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


/****** Object:  Table [dbo].[QUEUE]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QUEUE](
	[QUEUEID] [int] IDENTITY(1,1) NOT NULL,
	[SOMEACTION] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[QUEUEID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Student]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Student](
	[Id] [int] NULL,
	[FirstName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[StudentSubject]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[StudentSubject](
	[Id] [int] NULL,
	[SubjectId] [int] NULL,
	[StudentId] [int] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[subject]    Script Date: 2/1/2019 2:00:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[subject](
	[Id] [int] NULL,
	[SubjectName] [nvarchar](50) NULL
) ON [PRIMARY]

GO
/****** Object:  Index [IDX_BatchTaskState_NodeKey_IsFinished]    Script Date: 2/1/2019 2:00:57 PM ******/
CREATE NONCLUSTERED INDEX [IDX_BatchTaskState_NodeKey_IsFinished] ON [dbo].[BatchTaskState]
(
	[NodeKey] ASC,
	[IsFinished] ASC
)
INCLUDE ( 	[Id]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IDX_BATCHTASKVALUE_TID_SKEY]    Script Date: 2/1/2019 2:00:57 PM ******/
CREATE NONCLUSTERED INDEX [IDX_BATCHTASKVALUE_TID_SKEY] ON [dbo].[BatchTaskValue]
(
	[TaskId] ASC,
	[StateKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BatchQueue] ADD  CONSTRAINT [DF_BatchQueue_IsFinished]  DEFAULT ((0)) FOR [IsFinished]
GO
ALTER TABLE [dbo].[BatchProcessGroupDetail]  WITH CHECK ADD  CONSTRAINT [FK_ProcessGroups] FOREIGN KEY([GroupKey])
REFERENCES [dbo].[BatchProcessGroupMaster] ([GroupKey])
GO
ALTER TABLE [dbo].[BatchProcessGroupDetail] CHECK CONSTRAINT [FK_ProcessGroups]
GO
ALTER DATABASE [TestDB] SET  READ_WRITE 
GO

SET IDENTITY_INSERT [dbo].[BatchProcessGroupMaster] ON 

GO
INSERT [dbo].[BatchProcessGroupMaster] ([GroupKey], [NME], [insr_by], [insr_DTE]) VALUES (2, N'DayEnd', N'Usman', CAST(N'2019-01-08 00:00:00.000' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[BatchProcessGroupMaster] OFF
GO
SET IDENTITY_INSERT [dbo].[BatchProcessGroupDetail] ON 

GO
INSERT [dbo].[BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND], [CanInvokeIndependent]) VALUES (1, 2, 1, NULL, NULL, 1, 1)
GO
INSERT [dbo].[BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND], [CanInvokeIndependent]) VALUES (2, 2, 2, 1, NULL, 1, 1)
GO
INSERT [dbo].[BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND], [CanInvokeIndependent]) VALUES (3, 2, 3, 2, NULL, 1, 1)
GO
INSERT [dbo].[BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND], [CanInvokeIndependent]) VALUES (5, 2, 4, 3, NULL, 1, 1)
GO
INSERT [dbo].[BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND], [CanInvokeIndependent]) VALUES (6, 2, 5, 1, N'2', 1, 1)
GO
INSERT [dbo].[BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND], [CanInvokeIndependent]) VALUES (7, 2, 6, 5, NULL, 1, 1)
GO
INSERT [dbo].[BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND], [CanInvokeIndependent]) VALUES (8, 2, 7, 4, NULL, 1, 1)
GO
INSERT [dbo].[BatchProcessGroupDetail] ([Id], [GroupKey], [ProcessId], [ParentProcessId], [DependentProcessIds], [ACT_IND], [CanInvokeIndependent]) VALUES (9, 2, 9, 7, NULL, 0, 1)
GO
SET IDENTITY_INSERT [dbo].[BatchProcessGroupDetail] OFF
GO
SET IDENTITY_INSERT [dbo].[BatchProcessConfig] ON 

GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (1, 1, 5301, 10, 500, 3, 1, NULL, 500, 3, 0, 5, NULL, 1, 1, 0)
GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (2, 2, 5301, 10, 500, 3, 0, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (3, 3, 5301, 10, 500, 3, 0, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (4, 4, 5301, 10, 500, 3, 0, NULL, 500, 3, 0, 1, NULL, 1, 1, 0)
GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (5, 5, 5301, 10, 500, 3, 0, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (6, 6, 5301, 10, 500, 3, 1, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (7, 7, 5301, 10, 500, 3, 1, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (8, 8, 5301, 10, 500, 3, 1, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
INSERT [dbo].[BatchProcessConfig] ([Id], [ProcessId], [ProcessKey], [BatchSize], [ProcessTimeoutMins], [TaskTimeout], [ProcessRetries], [TaskRetries], [RetryDelayMilli], [MaxVolumeRetries], [QueueSize], [ErrorThreshold], [DAYS_YEAR_TYPE_KEY], [ACT_IND], [ROLL_OVER_EXEC_IND], [IsMonthEnd]) VALUES (9, 9, 5301, 10, 500, 3, 1, NULL, 500, 3, 0, NULL, NULL, 1, 1, 0)
GO
SET IDENTITY_INSERT [dbo].[BatchProcessConfig] OFF
GO

IF EXISTS (SELECT 1 FROM SYS.indexes WHERE name = 'IDX_BatchTaskState_NodeKey_IsFinished' AND  OBJECT_NAME ( OBJECT_ID) ='BatchTaskState')
DROP INDEX IDX_BatchTaskState_NodeKey_IsFinished ON BatchTaskState
GO

CREATE INDEX IDX_BatchTaskState_NodeKey_IsFinished ON  BatchTaskState(NodeKey,IsFinished,IsStopped,ProcessId,DeferredCount) 
INCLUDE (id, HasPriority) WITH FILLFACTOR = 80 --ON NFS_INDEX
GO


--ALTER DATABASE TestDb2 SET ALLOW_SNAPSHOT_ISOLATION ON  

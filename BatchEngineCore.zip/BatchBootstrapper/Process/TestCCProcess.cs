﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using BatchEngine.Core;
using NS.BatchEngine.Logs;
using NS.ORM;
using NS.Utilities.Context;


namespace BatchBootstrapper.Process
{
    public class TestCCProcess: StatelessProcess<int> //StatefulProcess<int>, IHaveSupportingData
    {
        public override IEnumerable<int> GetVolume(IProcessExecutionContext processContext)
        {
            //throw new InvalidOperationException();
            //var baseContext = LogContext.ContextToLog.GetCurrentLogContext();

            return Enumerable.Range(1, 1000);
            //return null;
            //return Enumerable.Empty<int>();
        }

        public override int ProcessKey => 5301;
        
        
        public void InitializeSupportingData(IProcessExecutionContext context)
        {
            //context.AddUpdateProcessData("test_w", "Hello Cached World");
            //context.AddUpdateProcessData("test_w", "Hello Cached World- updated");
            //context.AddUpdateProcessData("test2_w", "I am back");
        }

        public override void ProcessStarting(IProcessExecutionContext processContext)
        {
            base.ProcessStarting(processContext);

            //var workflowService = processContext.GetService<IWorkflowEngineService>();
        }
#if DEBUG
        static ConcurrentDictionary<long, object> _processedColl = new ConcurrentDictionary<long, object>();
#endif
        //private int count = 0;
        public override void Execute(int id, ITaskContext context)
        {

#if DEBUG
            var cid = context.State.Id;
            if (_processedColl.ContainsKey(cid)) // TryAdd(id, id))
            {
                System.Diagnostics.Debugger.Break();
            }
            else {
                if (!_processedColl.TryAdd(cid, cid))
    {
 }
 }
#endif
            //LogContext.ContextToLog.GetBaseContext()
            //Interlocked.Increment(ref count);
            context.Logger.Info("First step");

            //var lastStateValue = context.GetLastStateValue<int?>("p");
            //if (lastStateValue == null)
            //{
            //    context.PreserveStateValue("p", 2);
            //    throw new Exception("test");
            //}


            //var ddPrm = context.ProcessExecutionContext.GetSetTempData<object>("DDParam", ReadFromDb);

            //var processData = context.ProcessExecutionContext.GetProcessData<string>("test_w");
            //context.Logger.Info($"Data read from store= {processData}");

            
            //if (id % 5 == 0 && context.DeferredCount < 30)
            //{
            //    context.Logger.Info("Going to defer");
            //    var isDeferred = context.Defer();
            //    if (isDeferred)
            //    {
            //        context.Logger.Info($"Task deferred {context.State.DeferredCount}");
            //        return;
            //    }
            //    else
            //    {
            //        context.Logger.Warn($"Task deferred Failed {context.State.DeferredCount}");
            //    }
            //}
            //if (!context.IsRetry)
                //for (int i = 0; i < 6; i++)
                //{
                //    Thread.Sleep(50);
                //}

            //if (!context.IsRetry)
            //    throw new NotImplementedException();

            //Thread.Sleep(800);

            //Interlocked.Decrement(ref count);

            try
            {
                using (var controller = DbController.Create())
                {
                    var rows = controller.ExecuteNonQuery($@"INSERT INTO [dbo].[TempTable]([RefId],[Val]) VALUES({context.State.Id},'{DateTime.Now.ToString()}')");
                    if (rows <= 0)
                    {
                        Debugger.Break();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }


            if (context.State.Id % 10 == 0)
                context.SetResult(ResultStatus.Invalid);

        }

        private object ReadFromDb()
        {
            return null;
        }

        public override void ProcessCompleted(IProcessExecutionContext processContext)
        {
            base.ProcessCompleted(processContext);
        }

        public override void ProcessFinalizer(IProcessFinalizedContext context)
        {
            //processContext.SetVolumeGenerated();
            context.Logger.Info($"Completed: {context.HasExecuted}");
            //context.Resubmit(new List<JobCriteria>(){ context.ExecutionContext.Criteria}, "Test");
            //processFinalizerContext.Resubmit();

            base.ProcessFinalizer(context);
        }

        public override void OnRetry(IProcessRetryContext processContext)
        {
            processContext.Logger.Info("OnRetry");
            base.OnRetry(processContext);
        }

        public override void ProcessStopped(IProcessStoppedContext stoppedContext)
        {
            stoppedContext.Logger.Info("OnRetry");
            base.ProcessStopped(stoppedContext);
        }

        //public override void InitializeStates()
        //{
        //    DefineState("Execute", Execute);
        //}
    }
}
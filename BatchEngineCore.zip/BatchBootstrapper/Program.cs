﻿using System;
using System.Collections.Generic;
using System.Configuration;
using BatchEngine.Core;
using BatchEngine.Core.JobScheduler;
using NS.BatchEngine;
using NS.Utilities.Context;

namespace BatchBootstrapper
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ready");
            InitCfg();

            //var redisConnection = "10.39.100.27";// "localhost";// "172.31.15.19";
            //var cacheServer = "10.39.100.46";// "localhost";// "172.31.15.19";
            //var cacheServer = "10.39.100.27"; // "localhost";// "172.31.15.19";
            var cacheServer = "localhost";// "172.31.15.19";

            //var cacheServer = "172.31.15.19";
            //var serializer = Bootstrap.GetSerializer();

            //IProcessDataStorage storage=new RedisProcessStorage(NodeSettings.Instance.Name, redisConnection, serializer);

            //IPubSubFactory factory= new RedisPubSubFactory(redisConnection);
            //IDistributedMutexFactory mutexFactory=new DistributedMutexFactory(redisConnection);

            var nodeId = ConfigurationManager.AppSettings["NodeId"] ?? "Node";
            var container = Bootstrap.Initialize(1, nodeId, null, true, 0, cacheServer);


            BatchEngineService service = container.Resolve<BatchEngineService>(); // new BatchEngineService(new StatePersistenceService(), new EntityFactory());
            var jobScheduler = container.Resolve<IJobScheduler>();
            try
            {
                var c = LogContext.ContextToLog;
                Console.WriteLine(c.SubTenantId);

                service.Start();

                //IJobScheduler jobScheduler=new JobSchedulerInternal();

                //service.SubmitSingleProcess<TestDDProcess>(new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 }, false);
                //service.SubmitSingleProcess<TestCCProcess>(new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 }, false);
                //service.SubmitSingleProcess<TestCCProcess>(new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 }, false);

                //jobScheduler.CreateJob(2, new List<JobCriteria>() { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } }, "System");

                //jobScheduler.CreateJob(new List<int>() { 2 }, new List<JobCriteria>() { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } }, "System");
                jobScheduler.CreateJob(2, new List<int>() { 1,2 }, new List<JobCriteria>() { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } }, "System");

                //jobScheduler.CreateQueueJob(new List<int>(){2}, new List<JobCriteria>()
                //    { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } },
                //    "Fin", "Manual");
                //jobScheduler.CreateQueueJob(new List<int>() { 2 }, new List<JobCriteria>()
                //        { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } },
                //    "Fin", "Manual");
                //jobScheduler.CreateJob(new List<int>() { 4 }, new List<JobCriteria>() { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } }, "System");
                //jobScheduler.CreateJob(new List<int>() { 3 }, new List<JobCriteria>() { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } }, "System", true);

                //jobScheduler.CreateQueueJob(new List<int>() { 2 }, new List<JobCriteria>()
                //        { new JobCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 } },
                //"NonFin", "Manual");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            Console.WriteLine("Done");
            Console.ReadLine();
            service.Stop();

            Console.WriteLine("Stopped <enter> to exit");
            Console.ReadLine();

        }

        static void InitCfg()
        {
            try
            {
                //var t1 = Task.Run(() =>
                //{
                //    using (var acquireLock =
                //        new InProcessLockFactory().AcquireLock($"Group_1", -1))
                //    {
                //        Console.WriteLine(DateTime.Now + "T1 entered");
                //        Thread.Sleep(5000);
                //        Console.WriteLine(DateTime.Now + "T1 leave");
                //    }
                //});

                //var t2 = Task.Run(() =>
                //{
                //    using (var acquireLock =
                //        new InProcessLockFactory().AcquireLock($"Group_1", -1))
                //    {
                //        Console.WriteLine(DateTime.Now + "T2 entered");
                //        Thread.Sleep(5000);
                //        Console.WriteLine(DateTime.Now + "T2 leave");
                //    }
                //});
                //var t3 = Task.Run(() =>
                //{
                //    using (var acquireLock =
                //        new InProcessLockFactory().AcquireLock($"Group_1", -1))
                //    {
                //        Console.WriteLine(DateTime.Now + "T3 entered");
                //        Thread.Sleep(5000);
                //        Console.WriteLine(DateTime.Now + "T3 left");
                //    }
                //});

                //Task.WaitAll(t1, t2, t3);
                //NS.Configurations.Manager.ConfigurationManager.GetInstance().InitializeConfigAndServices();

                //NS.Configurations.Manager.ConfigurationManager.GetInstance().RegisterNode();

                ////ExceptionHandler.SetLogsDatabase(BpemSettings.LogsDatabase);
                ////_ibatchProcessServiceClient = _ibatchProcessServiceClient ?? GetBatchProcessServiceInstance();

                ////AppName = ConfigurationManager.AppSettings["AppCode"];
                ////SessionData = ProcessHelper.GetSessionId(AppName);
                ////LogServiceUrls();
                ////Configurations.Manager.ConfigurationManager.GetInstance().RegisterNode();

                ////if (int.Parse(ConfigurationManager.AppSettings["ENABLE_SESSION_VALIDATION"]) == 1 && SessionData == null)
                ////    throw new Exception("User session for batch process not available at login.");
                ////else if (int.Parse(ConfigurationManager.AppSettings["ENABLE_SESSION_VALIDATION"]) == 0)
                ////    SessionData = null;

            }
            catch (Exception)
            {
               // ExceptionHandler.HandleException(exception, ExceptionHandlingPolicy.LogOnlyPolicy);
            }
        }
    }
}

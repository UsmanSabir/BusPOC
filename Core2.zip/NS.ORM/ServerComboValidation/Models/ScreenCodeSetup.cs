
/* /m
   This file is generated from NFS ORM VS Extension v2.0.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace NS.ORM.ServerComboValidation.Models
{

    ///CM_SCRN_CODE
    public partial class ScreenCodeSetupValidateComboPoco : BaseModel
#if !RICHCLIENT
        , IConcurrentModel
#endif
    {

        private Int32 _scrn_id;
        private String _nme;
        private String _extr_code;
        private String _asmb_nme;
        private String _nme_spce;
        private String _dscr;
        private String _appl_key;
        private String _mdul_key;
        private Boolean _bpm_scrn_ind;
        private Boolean _act_ind;
        private Boolean _sys_ind;
        private String _insr_by;
        private String _updt_by;
        private DateTime _insr_dte;
        private DateTime _updt_dte;
        private String _sts_key;
        private Int32? _ref_id;
        private String _scrn_tabl_nme;
        private String _scrn_key_coln;
        private String _enty_nme;

        //public ScreenCodeSetupValidateComboPoco ScreenCodeSetupValidateComboPoco { get { return this; } } //Self reference property


        public Int32 SCRN_ID
        {
            get { return _scrn_id; }
            set
            {
                CheckSetProperty(ref _scrn_id, value);
            }
        }


        public String NME
        {
            get { return _nme; }
            set
            {
                CheckSetProperty(ref _nme, value);
            }
        }


        public String EXTR_CODE
        {
            get { return _extr_code; }
            set
            {
                CheckSetProperty(ref _extr_code, value);
            }
        }


        public String ASMB_NME
        {
            get { return _asmb_nme; }
            set
            {
                CheckSetProperty(ref _asmb_nme, value);
            }
        }


        public String NME_SPCE
        {
            get { return _nme_spce; }
            set
            {
                CheckSetProperty(ref _nme_spce, value);
            }
        }


        public String DSCR
        {
            get { return _dscr; }
            set
            {
                CheckSetProperty(ref _dscr, value);
            }
        }


        public String APPL_KEY
        {
            get { return _appl_key; }
            set
            {
                CheckSetProperty(ref _appl_key, value);
            }
        }


        public String MDUL_KEY
        {
            get { return _mdul_key; }
            set
            {
                CheckSetProperty(ref _mdul_key, value);
            }
        }


        public Boolean BPM_SCRN_IND
        {
            get { return _bpm_scrn_ind; }
            set
            {
                CheckSetProperty(ref _bpm_scrn_ind, value);
            }
        }


        public Boolean ACT_IND
        {
            get { return _act_ind; }
            set
            {
                CheckSetProperty(ref _act_ind, value);
            }
        }


        public Boolean SYS_IND
        {
            get { return _sys_ind; }
            set
            {
                CheckSetProperty(ref _sys_ind, value);
            }
        }


        public String INSR_BY
        {
            get { return _insr_by; }
            set
            {
                CheckSetProperty(ref _insr_by, value);
            }
        }


        public String UPDT_BY
        {
            get { return _updt_by; }
            set
            {
                CheckSetProperty(ref _updt_by, value);
            }
        }


        public DateTime INSR_DTE
        {
            get { return _insr_dte; }
            set
            {
                CheckSetProperty(ref _insr_dte, value);
            }
        }


        public DateTime UPDT_DTE
        {
            get { return _updt_dte; }
            set
            {
                CheckSetProperty(ref _updt_dte, value);
            }
        }


        public String STS_KEY
        {
            get { return _sts_key; }
            set
            {
                CheckSetProperty(ref _sts_key, value);
            }
        }


        public Int32? REF_ID
        {
            get { return _ref_id; }
            set
            {
                CheckSetProperty(ref _ref_id, value);
            }
        }


        public String SCRN_TABL_NME
        {
            get { return _scrn_tabl_nme; }
            set
            {
                CheckSetProperty(ref _scrn_tabl_nme, value);
            }
        }


        public String SCRN_KEY_COLN
        {
            get { return _scrn_key_coln; }
            set
            {
                CheckSetProperty(ref _scrn_key_coln, value);
            }
        }


        public String ENTY_NME
        {
            get { return _enty_nme; }
            set
            {
                CheckSetProperty(ref _enty_nme, value);
            }
        }




    }

    public class ScreenCodeSetupValidateComboPocoValidator : BaseValidation
    {


        public override List<string> MandatoryFields { get; protected set; }
            = new List<string>() { "SCRN_ID", "NME", "BPM_SCRN_IND", "ACT_IND", "SYS_IND", "INSR_BY", "INSR_DTE", "UPDT_DTE", };

        public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
        {
            ["NME"] = 100
          ,
            ["EXTR_CODE"] = 10
          ,
            ["ASMB_NME"] = 100
          ,
            ["NME_SPCE"] = 300
          ,
            ["DSCR"] = 500
          ,
            ["APPL_KEY"] = 5
          ,
            ["MDUL_KEY"] = 15
             ,
            ["INSR_BY"] = 20
          ,
            ["UPDT_BY"] = 20
            ,
            ["STS_KEY"] = 10
           ,
            ["SCRN_TABL_NME"] = 30
          ,
            ["SCRN_KEY_COLN"] = 30
          ,
            ["ENTY_NME"] = 100

        };




    }//end validator class

#pragma warning restore CS1591

}//end namespace
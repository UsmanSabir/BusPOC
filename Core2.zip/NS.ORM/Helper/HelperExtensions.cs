﻿using System;
using System.Linq;
using System.Linq.Expressions;
using NS.BaseModels;
using NS.ORM.Definitions.Classes;
using NS.ORM.FluentData;

namespace NS.ORM.Helper
{
    /// <summary>
    /// BaseModel extension for lazy loading children 
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public static class HelperExtensions
    {

        /// <summary>
        /// This method wraps entity into server EntityContext
        /// </summary>
        /// <typeparam name="T">Any entity/POCO inherited from BaseModel</typeparam>
        /// <param name="entity">The entity object.</param>
        /// <returns>ServerEntityContext of type T</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static EntityContextExt<T> ToController<T>(this T entity) where T:BaseModel, new()
        {
            return EntityContextExt<T>.Create(new[] {entity});
        }

        /// <summary>
        /// Explicit Loading of child collection
        /// </summary>
        /// <typeparam name="T">Parent info or entity</typeparam>
        /// <typeparam name="TProperty">Child info</typeparam>
        /// <param name="entity">Parent info/entity object</param>
        /// <param name="propertyExpression">Property expression that need to be loaded. e.g. p=>p.SaleOrderDetails</param>
        /// <param name="entityContext">Server EntityContext object that contains database connection information. Can be null if using default configuration based connection string</param>
        /// <param name="aggregateName">Aggregate name</param>
        /// <returns>Parent entity with child embeded</returns>
        /// <example>
        /// <code>
        /// entity.Read&lt;Product, SalesOrderDetail&gt;(p=>p.SalesOrderDetails, serverController);
        /// entity.Read&lt;Product, SalesOrderDetail&gt;(p=>p.SalesOrderDetails);
        /// </code>
        /// </example>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static T Read<T, TProperty>(this T entity, Expression<Func<T, object>> propertyExpression, EntityContextExt<T> entityContext = null, string aggregateName=null) 
            where T : BaseModel, new() where TProperty : BaseModel
        {
            var def = entity.GetType().ToDefination();
            var parser = new PropertyExpressionParser<T>(entity, propertyExpression);
            var prop = parser.Property;
            var type = ReflectionHelper.GetGenericSafeType(prop);

            //var sqlWithParams = def.GetChildSqlWithParams(entity, type, null);
            var sqlWithParams = def.GetChildSqlWithParamsV2(entity, type , prop.Name, aggregateName);

            using (
                var dbController = entityContext != null
                    ? entityContext.GetController() //it will get connection string from provided server EntityContext
                    : DbController.Create()
                )
            {
                var list = dbController.GetChildsList<T,TProperty>(sqlWithParams.Item1, sqlWithParams.Item2.ToArray()).ToList();
                if(prop.PropertyType.IsGenericType)
                    prop.SetValue(entity, list);//assign list
                else
                    prop.SetValue(entity, list.FirstOrDefault());//assign single model. Ideally query should return single value only
                //def.ChildProcessor<T>(new List<T>() { entity }, list);
            }


            return entity;
        }



    }
}
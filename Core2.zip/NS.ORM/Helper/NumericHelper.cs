﻿using System;
using System.Numerics;

namespace NS.ORM.Helper
{
    /// <summary>
    /// Helper class for checking if an object is numeric
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public static class NumericHelper
    {
        /// <summary>
        /// Checks if a value is an integer
        /// </summary>
        /// <param name="value">The value to check</param>
        /// <returns>True if the specified value is ineteger</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static bool IsInteger(this ValueType value)
        {
            return (value is SByte || value is Int16 || value is Int32
                    || value is Int64 || value is Byte || value is UInt16
                    || value is UInt32 || value is UInt64
                    || value is BigInteger);
        }

        /// <summary>
        /// Checks if a value is floating point
        /// </summary>
        /// <param name="value">The value to check</param>
        /// <returns>True if the specified value is floating point</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static bool IsFloat(this ValueType value)
        {
            return (value is float | value is double | value is Decimal);
        }

        /// <summary>
        /// Checks if the value is numeric
        /// </summary>
        /// <param name="value"></param>
        /// <returns>True if the value is numeric</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static bool IsNumeric(this ValueType value)
        {
            if (!(value is Byte ||
                    value is Int16 ||
                    value is Int32 ||
                    value is Int64 ||
                    value is SByte ||
                    value is UInt16 ||
                    value is UInt32 ||
                    value is UInt64 ||
                    value is BigInteger ||
                    value is Decimal ||
                    value is Double ||
                    value is Single))
                return false;
            else
                return true;
        }
    }
}
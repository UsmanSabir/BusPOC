﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using NS.BaseModels;
using NS.Validation;

// ReSharper disable All

namespace NS.ORM.Helper
{
    // ReSharper disable once InconsistentNaming

    /// <summary>
    /// Builds query from linq expression
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// <para>Reference link: https://msdn.microsoft.com/library/bb546158(v=vs.110).aspx</para>
    /// </remarks>
    internal sealed class QueryTranslator : ExpressionVisitor
    {
        private StringBuilder _sb;
        private List<KeyValuePair<string, object>> _sqlParams;
        //HACK: removed redundant field initializer
        //private int _prmCounter = 0;
        private int _prmCounter;
        private string _orderBy = string.Empty;
        private string _paramName = string.Empty;
        //HACK: removed redundant field initializer
        //private int? _skip = null;
        private int? _skip;

        //HACK: removed redundant field initializer
        //private int? _take = null;
        private int? _take;

        private string _whereClause = string.Empty;
        private Type _type;
        private BaseValidation _validator;

        public int? Skip
        {
            get
            {
                return _skip;
            }
        }

        public int? Take
        {
            get
            {
                return _take;
            }
        }

        public string OrderBy
        {
            get
            {
                return _orderBy;
            }
        }

        public string WhereClause
        {
            get
            {
                return _whereClause;
            }
        }

        public List<KeyValuePair<string, object>> SqlParams
        {
            get { return _sqlParams; }
        }

        //public Tuple<string, List<KeyValuePair<string, object>>> Translate(Expression expression,
        //    bool digDeepExpression = false)
        //{
        //    return Translate<object>(expression, digDeepExpression);
        //}
        public Tuple<string, List<KeyValuePair<string, object>>> Translate<T>(Expression expression, bool digDeepExpression = false)
        {
            this._type = typeof(T);
            if(_type!=typeof(object))
                this._validator = ValidationCollections.Instance.GetModelValidation(_type);

            _sb = new StringBuilder();
            _sqlParams = new List<KeyValuePair<string, object>>();
            //_prmCounter = 0;
            var expr = expression;
            if (digDeepExpression)
                expr = Evaluator.PartialEval(expr);

            Visit(expr);
            _whereClause = _sb.ToString();
            var tpl = Tuple.Create(_whereClause, _sqlParams);
            return tpl;// _whereClause;
        }

        private static Expression StripQuotes(Expression e)
        {
            while (e.NodeType == ExpressionType.Quote)
            {
                e = ((UnaryExpression)e).Operand;
            }
            return e;
        }

        //private Boolean insideContains = false;

        //more help from msdn https://msdn.microsoft.com/library/bb546158(v=vs.110).aspx
        protected override Expression VisitMethodCall(MethodCallExpression m)
        {
            if (m.Method.DeclaringType == typeof(Queryable) && m.Method.Name == "Where")
            {
                Visit(m.Arguments[0]);
                LambdaExpression lambda = (LambdaExpression)StripQuotes(m.Arguments[1]);
                Visit(lambda.Body);
                return m;
            }
            else if (m.Method.Name == "Take")
            {
                if (ParseTakeExpression(m))
                {
                    Expression nextExpression = m.Arguments[0];
                    return Visit(nextExpression);
                }
            }
            else if (m.Method.Name == "Skip")
            {
                if (ParseSkipExpression(m))
                {
                    Expression nextExpression = m.Arguments[0];
                    return Visit(nextExpression);
                }
            }
            else if (m.Method.Name == "OrderBy")
            {
                if (ParseOrderByExpression(m, "ASC"))
                {
                    Expression nextExpression = m.Arguments[0];
                    return Visit(nextExpression);
                }
            }
            else if (m.Method.Name == "OrderByDescending")
            {
                if (ParseOrderByExpression(m, "DESC"))
                {
                    Expression nextExpression = m.Arguments[0];
                    return Visit(nextExpression);
                }
            }
            else if (m.Method.Name == "Contains")
            {
                if (m.Method.DeclaringType == typeof(string))
                {
                    var valueExpression = m.Arguments[0];

                    Visit(m.Object);
                    _sb.AppendFormat(" LIKE '%'+ ");


                    Visit(valueExpression);
                    _sb.AppendFormat("+'%'");

                    return m;
                }
                //List Contains
                //else if (m.Method.DeclaringType == typeof(ICollection<>))
                //{

                //}
                //Expression valuesExpression = null;

                //if (m.Method.DeclaringType == typeof(Enumerable))
                //{
                //    //if (ExpressionTreeHelpers.IsSpecificMemberExpression(m.Arguments[1], typeof(Place), "Name") ||
                //    //ExpressionTreeHelpers.IsSpecificMemberExpression(m.Arguments[1], typeof(Place), "State"))
                //    {
                //        valuesExpression = m.Arguments[0];
                //    }
                //}
                //else if (m.Method.DeclaringType == typeof(IList<string>))
                //{
                //    valuesExpression = m.Arguments[0];
                //}
                //else if (m.Method.DeclaringType == typeof(IList<int>))
                //{
                //    //if (ExpressionTreeHelpers.IsSpecificMemberExpression(m.Arguments[0], typeof(Place), "Name") ||
                //    //ExpressionTreeHelpers.IsSpecificMemberExpression(m.Arguments[0], typeof(Place), "State"))
                //    {
                //        valuesExpression = m.Object;
                //    }
                //}

                //else if (m.Method.DeclaringType == typeof(ICollection<string>))
                //{
                //    valuesExpression = m.Arguments[0];
                //}
                //else if (m.Method.DeclaringType == typeof(ICollection<int>))
                //{
                //    //if (ExpressionTreeHelpers.IsSpecificMemberExpression(m.Arguments[0], typeof(Place), "Name") ||
                //    //ExpressionTreeHelpers.IsSpecificMemberExpression(m.Arguments[0], typeof(Place), "State"))
                //    {
                //        valuesExpression = m.Object;
                //    }
                //}

                //var list = m.Object;      // The list being searched
                //object listValue;

                #region Get Parse List(commented)

                //if(list==null)
                //    throw new NotSupportedException(string.Format("The method '{0}' is not supported", m.Method.Name));

                //if (list.NodeType == ExpressionType.Constant)
                //    // from constant value
                //    listValue = ((ConstantExpression)list).Value;
                //else
                //{
                //    // from constant value property/field
                //    var listMember = list as MemberExpression;
                //    if (listMember == null) throw new NotSupportedException(
                //        $"The method '{m.Method.Name}' is not supported");
                //    var listOwner = listMember?.Expression as ConstantExpression;
                //    if (listOwner == null) throw new NotSupportedException(
                //        $"The method '{m.Method.Name}' is not supported");
                //    var listProperty = listMember?.Member as PropertyInfo;
                //    listValue = listProperty != null ? listProperty.GetValue(listOwner.Value) : ((FieldInfo)listMember.Member).GetValue(listOwner.Value);
                //}
                //var listItems = listValue as System.Collections.IEnumerable;
                //if (listItems == null)
                //{
                //    throw new NotSupportedException($"The method '{m.Method.Name}' is not supported");
                //}

                   
                #endregion

                var target = m.Arguments[0];

                Visit(target);
                _sb.Append(" in("); //dont add space in "in(" bcoz of data parameter parser limitation

                Visit(m.Object);
                _sb.Append(") ");//dont add space in ")" bcoz of data parameter parser limitation

                //if (listItems == null) return false;

                //if (valuesExpression == null || valuesExpression.NodeType != ExpressionType.Constant)
                //    throw new Exception("Could not find the location values.");

                //ConstantExpression ce = (ConstantExpression)valuesExpression;

                //IEnumerable<string> placeStrings = ce.Value as IEnumerable<string>;
                //var placeStrings2 = ce.Value as IEnumerable<int>;
                // Add each string in the collection to the list of locations to obtain data about. 
                //foreach (string place in placeStrings)
                //    locations.Add(place);

                return m;

            }
            //else if (m.Method.DeclaringType == typeof(String) && m.Method.Name == "Contains")
            //{
            //    var valueExpression = m.Arguments[0];

            //    Visit(m.Object);
            //    _sb.AppendFormat(" LIKE '%'+ ");


            //    Visit(valueExpression);
            //    _sb.AppendFormat("+'%'");

            //    return m;

            //}
            else if (m.Method.DeclaringType == typeof(String) && m.Method.Name == "StartsWith")
            {
                var valueExpression = m.Arguments[0];

                Visit(m.Object);
                _sb.AppendFormat(" LIKE ");


                Visit(valueExpression);
                _sb.AppendFormat("+'%'");

                return m;

            }
            else if (m.Method.DeclaringType == typeof(String) && m.Method.Name == "EndsWith")
            {

                var valueExpression = m.Arguments[0];

                Visit(m.Object);
                _sb.AppendFormat(" LIKE '%'+");


                Visit(valueExpression);
                _sb.AppendFormat("");

                return m;

            }



            throw new NotSupportedException($"The method '{m.Method.Name}' is not supported");
        }

        protected override Expression VisitUnary(UnaryExpression u)
        {
            switch (u.NodeType)
            {
                case ExpressionType.Not:
                    _sb.Append(" NOT ");
                    Visit(u.Operand);
                    break;
                case ExpressionType.Convert:
                    Visit(u.Operand);
                    break;
                default:
                    throw new NotSupportedException(string.Format("The unary operator '{0}' is not supported", u.NodeType));
            }
            return u;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="b"></param>
        /// <returns></returns>
        protected override Expression VisitBinary(BinaryExpression b)
        {
            _sb.Append("(");
            Visit(b.Left);

            switch (b.NodeType)
            {
                case ExpressionType.And:
                    _sb.Append(" AND ");
                    break;

                case ExpressionType.AndAlso:
                    _sb.Append(" AND ");
                    break;

                case ExpressionType.Or:
                    _sb.Append(" OR ");
                    break;

                case ExpressionType.OrElse:
                    _sb.Append(" OR ");
                    break;

                case ExpressionType.Equal:
                    if (IsNullConstant(b.Right))
                    {
                        _sb.Append(" IS NULL ");
                    }
                    else
                    {
                        _sb.Append(" = ");
                    }
                    break;

                case ExpressionType.NotEqual:
                    if (IsNullConstant(b.Right))
                    {
                        _sb.Append(" IS NOT NULL ");
                    }
                    else
                    {
                        _sb.Append(" <> ");
                    }
                    break;

                case ExpressionType.LessThan:
                    _sb.Append(" < ");
                    break;

                case ExpressionType.LessThanOrEqual:
                    _sb.Append(" <= ");
                    break;

                case ExpressionType.GreaterThan:
                    _sb.Append(" > ");
                    break;

                case ExpressionType.GreaterThanOrEqual:
                    _sb.Append(" >= ");
                    break;

                default:
                    throw new NotSupportedException(string.Format("The binary operator '{0}' is not supported", b.NodeType));

            }

            Visit(b.Right);
            _sb.Append(")");
            return b;
        }

        int GetNextParam()
        {
            return _prmCounter++;
        }

        string GetNextParamString()
        {
            string s;
            if (!string.IsNullOrEmpty(_paramName))
            {
                if (_sqlParams.Exists(p => p.Key == _paramName)) s = string.Concat(_paramName, GetNextParam().ToString());
                else s = _paramName;
            }
            else s = GetNextParam().ToString();
            return s;
        }

        protected override Expression VisitConstant(ConstantExpression c)
        {
            IQueryable q = c.Value as IQueryable;

            if (q == null && c.Value == null)
            {
                //var s = GetNextParamString();
                //_sb.Append("@" + s); //sb.Append("NULL");
                //_sqlParams.Add(new KeyValuePair<string, object>(s, DBNull.Value));

                //Do nothing, NULL is already set in sql
            }
            else if (q == null)
            {
                var s = GetNextParamString();
                _sqlParams.Add(new KeyValuePair<string, object>(s, c.Value));
                _sb.Append("@" + s);
                switch (Type.GetTypeCode(c.Value.GetType()))
                {
                    //case TypeCode.Boolean:
                    //    //sb.Append(s); //sb.Append(((bool)c.Value) ? 1 : 0);
                    //    break;

                    //case TypeCode.String:
                    //    sb.Append("@" + _prmCounter++); //
                    //    //sb.Append("'");
                    //    //sb.Append(c.Value);
                    //    //sb.Append("'");
                    //    break;

                    //case TypeCode.DateTime:
                    //    sb.Append("@" + _prmCounter++); //
                    //    //sb.Append("'");
                    //    //sb.Append(c.Value);
                    //    //sb.Append("'");
                    //    break;

                    case TypeCode.Object:
                        if (c.Value.GetType() != typeof(List<int>) && c.Value.GetType() != typeof(List<string>))
                            throw new NotSupportedException(string.Format("The constant for '{0}' is not supported",
                                c.Value));

                        break;

                        //default:
                        //    //sb.Append("@" + _prmCounter++); //sb.Append(c.Value);
                        //    break;
                }
            }

            return c;
        }

        public Func<string,string> MemberTableNameFactory { get; set; }

        internal int ParameterCounter
        {
            get { return _prmCounter; }
            set { _prmCounter = value; }
        }

        protected override Expression VisitMember(MemberExpression m)
        {
            if (m.Expression != null && m.Expression.NodeType == ExpressionType.Parameter)
            {
#if DEBUG
                //var memberTypes = m.Member.DeclaringType;
                //var def = memberTypes.ToDefination();

                //Console.WriteLine(def.UpdateTableName);
#endif

                //_sb.Append("{0}" + m.Member.Name); //property name

                //TODO: get table name of property "m.Member.Name" from validator class and append in where clause with property name
                var name = m.Member.Name;
                string tableName=string.Empty;
                if (MemberTableNameFactory != null)
                {
                    tableName = MemberTableNameFactory.Invoke(name);
                }
                else
                {
                    _validator?.ColumnTable?.TryGetValue(name, out tableName);
                }
                _paramName = name;
                if (!string.IsNullOrWhiteSpace(tableName))
                {
                    name = $"{tableName}.{name}";
                }

                _sb.Append(name); //property name
                //Debug.WriteLine(name);

                return m;
            }
            else if (m.NodeType == ExpressionType.MemberAccess)
            {
                var listProperty = m.Member as PropertyInfo;
                
                //listValue = listProperty != null ? listProperty.GetValue(listOwner.Value) : ((FieldInfo)listMember.Member).GetValue(listOwner.Value);

                LambdaExpression lambda = Expression.Lambda(m);
                Delegate fn = lambda.Compile();
                var val = fn.DynamicInvoke(null);
                //return Expression.Constant(, e.Type);

                ////probably some object's property getter expression, compile and call getter
                //var objectMember = Expression.Convert(m, typeof(object));
                //var getterLambda = Expression.Lambda<Func<object>>(objectMember);
                //var getter = getterLambda.Compile();

                //var val = getter(); //here we get value
                var s = GetNextParamString();
                _sb.Append("@" + s);
                _sqlParams.Add(new KeyValuePair<string, object>(s, val ?? DBNull.Value)); //pass DBNull in case of null
                return m;
            }

            //hmmm... be carefull while passing expression arguments
            throw new NotSupportedException(string.Format("The member '{0}' is not supported", m.Member.Name));
        }

        internal static string GetValueFromExpression(Expression expression)
        {
            if (expression.NodeType == ExpressionType.Constant)
                return (string)(((ConstantExpression)expression).Value);
            else
                throw new InvalidOperationException(
                    String.Format(CultureInfo.CurrentCulture,
                    "The expression type {0} is not supported to obtain a value.",
                    expression.NodeType));
        }

        protected bool IsNullConstant(Expression exp)
        {
            return (exp.NodeType == ExpressionType.Constant && ((ConstantExpression)exp).Value == null);
        }

        private bool ParseOrderByExpression(MethodCallExpression expression, string order)
        {
            UnaryExpression unary = (UnaryExpression)expression.Arguments[1];
            LambdaExpression lambdaExpression = (LambdaExpression)unary.Operand;

            lambdaExpression = (LambdaExpression)Evaluator.PartialEval(lambdaExpression);

            MemberExpression body = lambdaExpression.Body as MemberExpression;
            if (body != null)
            {
                if (string.IsNullOrEmpty(_orderBy))
                {
                    _orderBy = string.Format("{0} {1}", body.Member.Name, order);
                }
                else
                {
                    _orderBy = string.Format("{0}, {1} {2}", _orderBy, body.Member.Name, order);
                }

                return true;
            }

            return false;
        }

        private bool ParseTakeExpression(MethodCallExpression expression)
        {
            ConstantExpression sizeExpression = (ConstantExpression)expression.Arguments[1];

            int size;
            if (int.TryParse(sizeExpression.Value.ToString(), out size))
            {
                _take = size;
                return true;
            }

            return false;
        }

        private bool ParseSkipExpression(MethodCallExpression expression)
        {
            ConstantExpression sizeExpression = (ConstantExpression)expression.Arguments[1];

            int size;
            if (int.TryParse(sizeExpression.Value.ToString(), out size))
            {
                _skip = size;
                return true;
            }

            return false;
        }

        internal static BinaryExpression GetBinaryExpression(Expression expression)
        {
            if (expression is BinaryExpression)
                return expression as BinaryExpression;

            throw new ArgumentException("Binary expression expected");
        }

        internal static MemberExpression GetMemberExpression(Expression expression)
        {
            switch (expression.NodeType)
            {
                case ExpressionType.MemberAccess:
                    return expression as MemberExpression;
                case ExpressionType.Convert:
                    return GetMemberExpression((expression as UnaryExpression).Operand);
            }

            throw new ArgumentException("Member expression expected");
        }

        internal static string GetColumnName(Expression expression)
        {
            var member = GetMemberExpression(expression);
            return member.Member.Name;
        }
    }
}
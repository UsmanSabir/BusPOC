﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using NS.BaseModels;
using NS.ORM.Definitions;
using NS.ORM.Definitions.Classes;
using NS.ORM.FluentData;
using NS.ORM.FluentData.Command;
using NS.ORM.Helper;
using NS.ORM.UoW;
using NS.Utilities;
using NS.Utilities.Context;
using IDbCommand = NS.ORM.FluentData.Command.IDbCommand;
using System.Data.SqlClient;
using IsolationLevel = NS.ORM.UoW.IsolationLevel;

namespace NS.ORM
{
    /// <summary>
    /// Performs database operations
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public class DbController : IDisposable
    {
        #region Static
        /// <summary>
        /// Creates instance of DbController
        /// </summary>
        /// <param name="uow">IUnitOfWork object</param>
        /// <returns>DbController</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static DbController Create(IUnitOfWork uow = null)
        {
            var dbController = uow != null ? new DbController(uow) : new DbController();

            dbController = InitController(dbController);
            //any future thing
            return dbController;
        }

        /// <summary>
        /// Creates instance of DbController
        /// </summary>
        /// <param name="uow">IUnitOfWork object</param>
        /// <param name="commandTimeOut">IUnitOfWork object</param>
        /// <returns>DbController</returns>
        /// <remarks>
        /// <para>[WB] 29/03/2018  1.0 Method created.</para>
        /// </remarks>
        public static DbController Create(int commandTimeOut, IUnitOfWork uow = null)
        {
            var dbController = uow != null ? new DbController(uow) : new DbController(commandTimeOut);

            dbController = InitController(dbController);
            //any future thing
            return dbController;
        }

        internal static DbController Create(string connectionString, IDbProvider provider)
        {
            var dbController = new DbController(connectionString, provider);

            dbController = InitController(dbController);
            //any future thing
            return dbController;
        }

        /// <summary>
        /// Creates DbController instance with provided connection string
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="providerName"></param>
        /// <returns></returns>
        public static DbController Create(string connectionString, string providerName = "System.Data.SqlClient")
        {
            var dbController = new DbController(connectionString, providerName);
            dbController = InitController(dbController);
            //any future thing
            return dbController;
        }

        /// <summary>
        /// Creates DbController instance with provided connection string
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="providerName"></param>
        /// <param name="commandTimeOut"></param>
        /// <returns></returns>
        public static DbController Create(int commandTimeOut, string connectionString, string providerName = "System.Data.SqlClient")
        {
            DbController dbController;
            dbController = new DbController(commandTimeOut, connectionString, providerName);
            dbController = InitController(dbController);
            //any future thing
            return dbController;
        }

        static DbController InitController(DbController controller)
        {
            //hook events. e.g.
            //controller.Inserting_EventHandler += model => {/* any check or operation or auditing etc */ };
            controller.HookEvents();
            return controller;
        }

        #endregion

        #region Fields

        private IUnitOfWork _uow;
        private IDbContext _dbContext;
        private bool _ignoreEntityConstraints;
        private List<Action> _postCommitActions;
        private List<Action> _rollbackActions;
        private bool _isDisposed = false;

        //        private const string transSql = @"if object_id('tempdb..#tt_audt_trck') is not null
        //begin
        //update #tt_audt_trck
        //set trck_id='{0}'
        //end
        //else
        //begin
        //select '{0}' trck_id into #tt_audt_trck
        //end
        //";
        const string wrapQuery = @"{0}
  order by {1}
OFFSET {2} ROWS
FETCH NEXT {3} ROWS ONLY
";


        //            @"select * from (select res.*, row_number() over (order by {1}) rnk
        //from ({0}) res) res1
        //  where res1.rnk >({2}) and res1.rnk <= {3}
        //";

        #endregion

        #region DbController Events

        /// <summary>
        /// Action to execute before inserting to database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<BaseModel> Inserting;

        /// <summary>
        /// Action to execute after data inserted into database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<BaseModel> Inserted;

        /// <summary>
        /// Action to execute before updating data in database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<BaseModel> Updating;

        /// <summary>
        /// Action to execute after updating data in database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<BaseModel> Updated;


        /// <summary>
        /// Action to execute before deleting data in database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<BaseModel> Deleting;

        /// <summary>
        /// Action to execute after deleting data in database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<BaseModel> Deleted;

        /// <summary>
        /// Action to execute before selecting data from database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<Type> Selecting;

        /// <summary>
        /// Action to execute after selecting data from database.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<IEnumerable<BaseModel>> Selected;

        /// <summary>
        /// Action to execute before selecting an entity.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<Type> EntitySelecting;

        /// <summary>
        /// Action to execute after selecting an entity.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Event created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public event Action<IEnumerable<BaseModel>> EntitySelected;

        /// <summary>
        /// Action to execute after Generating an Id on poco insertion.
        /// </summary>
        /// <remarks>
        /// <para>[MU] 21/09/2016  1.0 Event created.</para>        
        /// </remarks>
        public Action<BaseModel, int> IdGenerated;

        /// <summary>
        /// Inserting Event handler. See <see cref="Inserting"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnInserting(BaseModel obj)
        {
            Inserting?.Invoke(obj);
        }

        /// <summary>
        /// Inserted Event handler. See <see cref="Inserted"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnInserted(BaseModel obj)
        {
            Inserted?.Invoke(obj);
        }

        /// <summary>
        /// Updating Event handler. See <see cref="Updating"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnUpdating(BaseModel obj)
        {
            Updating?.Invoke(obj);
        }

        /// <summary>
        /// Updated Event handler. See <see cref="Updated"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnUpdated(BaseModel obj)
        {
            Updated?.Invoke(obj);
        }

        /// <summary>
        /// Deleting Event handler. See <see cref="Deleting"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnDeleting(BaseModel obj)
        {
            Deleting?.Invoke(obj);
        }

        /// <summary>
        /// Deleted Event handler. See <see cref="Deleted"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnDeleted(BaseModel obj)
        {
            Deleted?.Invoke(obj);
        }

        /// <summary>
        /// Selecting Event handler. See <see cref="Selecting"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnSelecting(Type obj)
        {
            Selecting?.Invoke(obj);
        }

        //HACK: remvoed unused method
        //private void OnSelected(BaseModel obj)
        //{
        //    Selected?.Invoke(new[] {obj});
        //}

        /// <summary>
        /// Selected Event handler. See <see cref="Selected"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnSelected(IEnumerable<BaseModel> obj)
        {
            Selected?.Invoke(obj);
        }

        /// <summary>
        /// EntitySelecting Event handler. See <see cref="EntitySelecting"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnEntitySelecting(Type obj)
        {
            EntitySelecting?.Invoke(obj);
        }

        /// <summary>
        /// EntitySelected Event handler. See <see cref="EntitySelected"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 29/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected virtual void OnEntitySelected(IEnumerable<BaseModel> obj)
        {
            EntitySelected?.Invoke(obj);
        }

        /// <summary>
        /// IdGenerated Event handler. See <see cref="IdGenerated"/>
        /// </summary>
        /// <param name="obj">The entity object.</param>
        /// <param name="id">The id of object.</param>
        /// <remarks>
        /// <para>[MU] 21/09/2016  1.0 Method created.</para> 
        /// </remarks>
        protected virtual void OnIdGenerated(BaseModel obj, int id)
        {
            IdGenerated?.Invoke(obj, id);
        }
        #endregion

        #region ctor

        private DbController()
        {
            _dbContext = new DbContext().ConnectionStringName("BusinessDatabase"); //,new SqlServerProvider());            
            //_context = new NSDbContext();
        }

        private DbController(int commandTimeOut)
        {
            _dbContext = new DbContext().ConnectionStringName("BusinessDatabase").CommandTimeout(commandTimeOut); //,new SqlServerProvider());
        }

        private DbController(IUnitOfWork uow)
        {
            _uow = uow;
            //_context = uow.Controller._context;

        }

        private DbController(string connectionString, IDbProvider provider)
        {
            //_context = new NSDbContext(connectionString, provider);
            _dbContext = new DbContext().ConnectionString(connectionString,
            provider);
        }

        private DbController(string connectionString, string providerName)
        {
            _dbContext = new DbContext().ConnectionString(connectionString, null, providerName);
            //_context = new NSDbContext(connectionString, providerName);
        }

        private DbController(int commandTimeOut, string connectionString, string providerName)
        {
            _dbContext = new DbContext().ConnectionString(connectionString, null, providerName).CommandTimeout(commandTimeOut);
        }

        public DbController EnableQueryPlanOptimization(bool avoidRecompile = false)
        {
            EnableQueryPlanOptimizationFlag = true;
            EnableQueryPlanOptimizationAvoidRecompile = avoidRecompile;

            return this;
        }
        #endregion

        #region Public Properties

        /// <summary>
        /// A delegate to decide, should child entity be included in aggregate filling. Func Arguments are "Type entityChild, string entityParent, string aggregateId"
        /// </summary>
        public Func<Type, string, string, string, bool> EntityScopeFunc { get; set; }


        /// <summary>
        /// A delegate to decide, should child use the provided identity type or not 
        /// </summary>
        public Func<Type, bool> SequenceScopeFunc { get; set; }

        /// <summary>
        /// EnableQueryPlanOptimizationFlag
        /// </summary>
        public bool EnableQueryPlanOptimizationFlag { get; set; }

        /// <summary>
        /// EnableSeconderyOptimizationRecompile
        /// </summary>
        public bool EnableQueryPlanOptimizationAvoidRecompile { get; set; }

        bool UseQeuryPlanRecompile => !EnableQueryPlanOptimizationAvoidRecompile;

        #endregion

        #region Paged

        /// <summary>
        /// Read Paged result from Database
        /// </summary>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <param name="definition">Entity Definition</param>
        /// <param name="expression">Filter Expression</param>
        /// <param name="take">Take/Fetch rows</param>
        /// <param name="skip">Skip/Offset rows</param>
        /// <param name="orderBy">Order by column</param>
        /// <returns>Paged result</returns>
        internal List<T> ReadPage<T>(BaseDefination definition, Expression<Func<T, bool>> expression, int take, int skip,
   string orderBy) where T : BaseModel
        {
            var translator = new QueryTranslator();
            var tuple = translator.Translate<T>(expression);
            string whereClause = tuple.Item1;
            var prms = tuple.Item2;
            //var validator = ValidationCollections.Instance.GetModelValidation(typeof(T));
            //var validator = typeof(T).ToValidator();
            //validator.ColumnTable?.Keys.Where(k=>k.Equals())
            //var tab = typeof(T).ToDefination().UpdateTableName;
            //whereClause = string.Format(whereClause, string.IsNullOrWhiteSpace(tab) ? string.Empty : tab+ ".");

            return ReadPage<T>(definition, take, skip, whereClause, orderBy, prms.Select(s => s.Key).ToList(), prms.Select(s => s.Value).ToArray());
        }

        /// <summary>
        /// Read Paged result from Database with External Paramteres
        /// </summary>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <param name="definition">Entity Definition</param>
        /// <param name="expression">Filter Expression</param>
        /// <param name="externalParameters">External Paramters</param>
        /// <param name="take">Take/Fetch rows</param>
        /// <param name="skip">Skip/Offset rows</param>
        /// <param name="orderBy">Order by column</param>
        /// <returns>Paged result</returns>
        internal List<T> ReadPage<T>(BaseDefination definition, Expression<Func<T, bool>> expression, List<KeyValuePair<string, object>> externalParameters, int take, int skip,
            string orderBy) where T : BaseModel
        {
            var translator = new QueryTranslator();
            var tuple = translator.Translate<T>(expression);
            string whereClause = tuple.Item1;
            var prms = tuple.Item2;
            if (externalParameters != null && externalParameters.Any()) prms.AddRange(externalParameters);
            return ReadPage<T>(definition, take, skip, whereClause, orderBy, prms.Select(s => s.Key).ToList(), prms.Select(s => s.Value).ToArray());
        }

        /// <summary>
        /// Read Paged result from Database
        /// </summary>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <param name="definition">Entity Definition</param>
        /// <param name="criteria">Filter criteria, A 'where' clause</param>
        /// <param name="parameters">Named/Value parameters dictionary used in 'where' clause</param>
        /// <param name="take">Take/Fetch rows</param>
        /// <param name="skip">Skip/Offset rows</param>
        /// <param name="orderBy">Order by column</param>
        /// <returns>Paged result</returns>
        internal List<T> ReadPage<T>(BaseDefination definition, string criteria, Dictionary<string, object> parameters, int take, int skip,
   string orderBy) where T : BaseModel
        {
            string whereClause = criteria;
            var prms = parameters;
            //var tab = typeof(T).ToDefination().UpdateTableName;
            //whereClause = string.Format(whereClause, string.IsNullOrWhiteSpace(tab) ? string.Empty : tab+ ".");

            return ReadPage<T>(definition, take, skip, whereClause, orderBy, prms?.Select(s => s.Key).ToList(), prms?.Select(s => s.Value).ToArray());
        }

        /// <summary>
        /// Read Paged result from Database
        /// </summary>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <param name="definition">Entity Definition</param>
        /// <param name="take">Take/Fetch rows</param>
        /// <param name="skip">Skip/Offset rows</param>
        /// <param name="orderBy">Order by column</param>
        /// <param name="ids">id parameter values defined in entity designer</param>
        /// <returns>Paged result</returns>
        internal List<T> ReadPage<T>(BaseDefination definition, int take, int skip,
            // string where, 
            string orderBy, params object[] ids) where T : BaseModel
        {
            string where = string.Empty;
            if (ids != null && ids.Length > 0)
                where = definition.Where;

            return ReadPage<T>(definition, take, skip, where, orderBy, definition.ParameterNames, ids);
        }

        /// <summary>
        /// Read Paged result from Database
        /// </summary>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <param name="definition">Entity Definition</param>
        /// <param name="take">Take/Fetch rows</param>
        /// <param name="skip">Skip/Offset rows</param>
        /// <param name="where">Where clause</param>
        /// <param name="orderBy">Order by column</param>
        /// <param name="parameterNames">Parameter names</param>
        /// <param name="ids">id parameter values defined in entity designer</param>
        /// <returns>Paged result</returns>
        internal List<T> ReadPage<T>(BaseDefination definition, int take, int skip,
            string where,
            string orderBy, List<string> parameterNames, params object[] ids) where T : BaseModel
        {
            var orderByCol = string.IsNullOrEmpty(orderBy)
                ? "1" //definition.IdentityColumn
                : orderBy;
            if (string.IsNullOrWhiteSpace(orderByCol))
                throw new ArgumentException(nameof(orderByCol), nameof(orderByCol) + " is null.");

            var sqlBuilder = new StringBuilder();

            sqlBuilder.AppendLine(definition.SelectQuery);

            if (!string.IsNullOrWhiteSpace(where))
            {
                //_defination.ParameterNames
                sqlBuilder.AppendLine($" WHERE {@where}");
            }

            if (!string.IsNullOrWhiteSpace(definition.GroupBy))
            {
                sqlBuilder.AppendLine($" GROUP BY {@definition.GroupBy}");
            }

            if (!string.IsNullOrWhiteSpace(definition.Having))
            {
                sqlBuilder.AppendLine($" HAVING {@definition.Having}");
            }
            //var wre = string.IsNullOrWhiteSpace(where) ? _defination.Where : where;
            //var wre = _defination.Where ;

            var pagingSql = WrapPagingSql(sqlBuilder.ToString(), orderByCol, skip, take);
            if (EnableQueryPlanOptimizationFlag)
            {
                var sqlOptimization =
                    _dbContext.Data.FluentDataProvider.ApplySqlOptimization(pagingSql, parameterNames?.ToArray(), ids,
                        EnableQueryPlanOptimizationAvoidRecompile);
                pagingSql = sqlOptimization.Item1;
                ids = sqlOptimization.Item2?.Select(s => s.Value).ToArray();
                parameterNames = sqlOptimization.Item2?.Select(s => s.Name).ToList();
            }
            if (ids != null && ids.Length > 0)
            {
                //_defination.ParameterNames
                //parameterNames = _defination.ParameterNames;

                return GetEntityWithCustomSql<T>(pagingSql, parameterNames, ids);
            }
            else
            {
                return GetEntityWithCustomSql<T>(pagingSql);
            }
        }

        string WrapPagingSql(string sql, string orderBy, int skip, int take)
        {
            //TODO: Check / Replace 'Order By' clause
            //if (sql.LastIndexOf("order by", StringComparison.OrdinalIgnoreCase) > 0)
            //{

            //}
            var pagedSql = string.Format(wrapQuery, sql, orderBy, skip, take);
            return pagedSql;
        }

        /// <summary>
        /// Read Paged result from Database
        /// </summary>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <param name="sql">sql query</param>
        /// <param name="namedParameters">Parameter names</param>
        /// <param name="take">Take/Fetch rows</param>
        /// <param name="skip">Skip/Offset rows</param>
        /// <param name="orderBy">Order by column</param>
        /// <returns>Paged result</returns>
        /// <remarks>
        /// <para>[MU] 27/02/2017  1.0 Method created.</para>
        /// </remarks>
        public IList<T> GetCustomListWithPage<T>(string sql, SerializableDictionary<string, object> namedParameters, int take, int skip,
           string orderBy)
        {

            var orderByCol = string.IsNullOrEmpty(orderBy)
               ? "1" //definition.IdentityColumn
               : orderBy;

            //var r = _dbContext.Sql(sql, parameters).QueryMany<T>();
            var pagingSql = WrapPagingSql(sql, orderByCol, skip, take);
            var query = _dbContext.Sql(pagingSql);

            var nms = namedParameters.Keys.ToList();

            for (var i = 0; i < namedParameters.Count; i++)
            {
                query = query.Parameter(nms[i], namedParameters[nms[i]]);
            }

            var r = query.QueryMany<T>();

            return r;
            //if (namedParameters != null && namedParameters.Count > 0)
            //{
            //    return GetEntityWithCustomSql<T>(pagingSql, namedParameters?.Select(s => s.Key).ToList(), namedParameters?.Select(s => s.Value).ToArray());
            //}
            //else
            //{
            //    return GetEntityWithCustomSql<T>(pagingSql);
            //}

        }

        /// <summary>
        /// Read Paged result from Database
        /// </summary>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <param name="sql">sql query</param>
        /// <param name="namedParameters">Parameter names</param>
        /// <param name="take">Take/Fetch rows</param>
        /// <param name="skip">Skip/Offset rows</param>
        /// <param name="orderBy">Order by column</param>
        /// <returns>Paged result</returns>
        /// <remarks>
        /// <para>[MU] 21/03/2017  1.0 Method created.</para>
        /// <para>[WB] 14/03/2018  1.0 Method updated(Reset States).</para>
        /// </remarks>
        public IList<T> GetCustomListWithPageUsingType<T>(string sql, SerializableDictionary<string, object> namedParameters, int take, int skip, string orderBy)
            where T : BaseModel
        {

            var orderByCol = string.IsNullOrEmpty(orderBy)
               ? "1" //definition.IdentityColumn
               : orderBy;

            //var r = _dbContext.Sql(sql, parameters).QueryMany<T>();
            var pagingSql = WrapPagingSql(sql, orderByCol, skip, take);
            var query = _dbContext.Sql(pagingSql);

            var nms = namedParameters.Keys.ToList();

            for (var i = 0; i < namedParameters.Count; i++)
            {
                query = query.Parameter(nms[i], namedParameters[nms[i]]);
            }

            var def = typeof(T).ToDefination();

            var r = query.QueryMany<T>(def.CustomMapper);

            SetState(r);

            return r;
            //if (namedParameters != null && namedParameters.Count > 0)
            //{
            //    return GetEntityWithCustomSql<T>(pagingSql, namedParameters?.Select(s => s.Key).ToList(), namedParameters?.Select(s => s.Value).ToArray());
            //}
            //else
            //{
            //    return GetEntityWithCustomSql<T>(pagingSql);
            //}

        }

        #endregion

        #region Unit of Work

        /// <summary>
        /// Set isolation level on transaction
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <returns></returns>
        public DbController UsingIsolationLevel(IsolationLevel isolationLevel)
        {
            _dbContext = _dbContext.IsolationLevel(isolationLevel);
            return this;
        }

        /// <summary>
        /// Enables unit of work and starts db transaction
        /// </summary>
        /// <returns>
        /// Instance of IUnitOfWork
        /// </returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public IUnitOfWork UsingUnitOfWork(Action saveAction = null, Action rollbackAction = null)
        {
            if (_uow != null)
            {
                throw new InvalidOperationException("A unit of work is already in use");
            }

            _dbContext = _dbContext.UseTransaction(true);

#if !SKIPF
            Context callContext = LogContext.ContextToLog;
            if (callContext != null)
            {
                var trackingId = callContext.SessionId + "_" + callContext.ContextId + "_" + callContext.LoginId;

                //Dictionary<string, object> dic=new Dictionary<string, object>();
                //dic.Add("ContextId", trackingId);
                //var res = SpCallSingle<object>(SpTransTempName, dic);

                //_dbContext.Data.AdoNetProvider.CreateConnection()

                var tSql = _dbContext.Data.FluentDataProvider.TempTableQuery;
                if (!string.IsNullOrEmpty(tSql))
                {
                    var sql = string.Format(tSql, trackingId);
                    _dbContext.Sql(sql).Execute();
                }
            }
            
#endif
            _uow = new UnitOfWork(this, SaveAction, RollbackAction);
            _postCommitActions = new List<Action>();
            _rollbackActions = new List<Action>();
            _postCommitActions.Add(saveAction);
            _rollbackActions.Add(rollbackAction);
            return _uow;
        }

        /// <summary>
        /// EnableSharedConnection
        /// </summary>
        /// <exception cref="InvalidOperationException"></exception>
        public void EnableSharedConnection()
        {
            if (_uow != null)
            {
                throw new InvalidOperationException("A unit of work is already in use");
            }

            _dbContext = _dbContext.UseSharedConnection(true);

            Context callContext = LogContext.ContextToLog;
            if (callContext != null)
            {
                var trackingId = callContext.SessionId + "_" + callContext.ContextId + "_" + callContext.LoginId;

                //Dictionary<string, object> dic=new Dictionary<string, object>();
                //dic.Add("ContextId", trackingId);
                //var res = SpCallSingle<object>(SpTransTempName, dic);

                //_dbContext.Data.AdoNetProvider.CreateConnection()

                var tSql = _dbContext.Data.FluentDataProvider.TempTableQuery;
                if (!string.IsNullOrEmpty(tSql))
                {
                    var sql = string.Format(tSql, trackingId);
                    _dbContext.Sql(sql).Execute();
                }
            }
        }


        IUnitOfWork InitUnitOfWorkIfNot()
        {
            if (_uow == null)
                return UsingUnitOfWork();

            return null;
        }

        /// <summary>
        /// Add action in post commit actions list
        /// </summary>
        /// <param name="action"></param>
        public void OnSaveAction(Action action)
        {
            _postCommitActions?.Add(action);
        }

        /// <summary>
        /// Add action in rollback actions list
        /// </summary>
        /// <param name="action"></param>
        public void OnRollbackAction(Action action)
        {
            _rollbackActions?.Add(action);
        }

        void SaveAction()
        {
            _dbContext.Commit();

            _dbContext.UseTransaction(false);

            _postCommitActions?.ForEach(a =>
            {
                try
                {
                    a?.Invoke();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                    //what to do with exception
                    throw;
                }
            });
            _postCommitActions?.Clear();
            _postCommitActions = null;
            _rollbackActions?.Clear();
            _rollbackActions = null;

            _uow = null;
        }

        void RollbackAction()
        {
            _dbContext.Rollback();
            _dbContext.UseTransaction(false);
            _rollbackActions?.ForEach(a =>
            {
                try
                {
                    a?.Invoke();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                    //what to do with exception
                    throw;
                }
            });
            _uow = null;

            _postCommitActions?.Clear();
            _postCommitActions = null;
            _rollbackActions?.Clear();
            _rollbackActions = null;

        }

        #endregion

        #region Entity Getters
        //public T Get<T>(params object[] ids)
        //    where T : BaseModel
        //{
        //    var type = typeof(T);
        //    OnSelecting(type);

        //    var defination = type.ToDefination();
        //    T result = null;

        //    var query = _context.Context.Sql(defination.CompiledSelectSql)
        //        //TODO: attach where clause
        //        .Parameters(ids);
        //    //var query = _context.Context.Select<T>(defination.Fields)
        //    //    .From(defination.TableName)
        //    //    .Where(defination.Where)
        //    //    .Parameters(ids); //@0


        //    if (defination.UseManualMapping)
        //    {
        //        #region Alternate (commented)

        //        //Func<IDbReader, T> m = reader =>
        //        //{
        //        //    var obj = Activator.CreateInstance<T>();
        //        //    defination.CustomMapper(obj, reader);
        //        //    return obj;
        //        //};

        //        //result = query.QueryComplexSingle(m); 

        //        #endregion

        //        result = query.QuerySingle<T>(defination.ManualMapping<T>);
        //    }
        //    else
        //    {
        //        result = query.QuerySingle<T>(defination.CustomMapper<T>);
        //    }

        //    //result?.Commit(EntityState.NotModified); //set entity state to not modified on db read
        //    if (result != null)
        //    {
        //        SetState(result);
        //    }
        //    OnSelected(result);

        //    return result;
        //}

        /// <summary>
        /// Gets entity object using stored procedure
        /// </summary>
        /// <typeparam name="T">The type of entity</typeparam>
        /// <param name="spName">Stored Procedure Name</param>
        /// <param name="ids">Values of stored procedure parameters</param>
        /// <returns>Entity object. Instance of type T.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public T GetProc<T>(string spName, params object[] ids)
            where T : BaseModel
        {
            T result;
            var defination = typeof(T).ToDefination();

            //HACK: replace with actual procedure name, may be retrieved from definition
            var query = _dbContext
                .Sql(spName)
                .CommandType(DbCommandTypes.StoredProcedure)
                .Parameters(ids);

            // ReSharper disable once ConvertIfStatementToConditionalTernaryExpression
            if (defination.UseManualMapping)
            {
                #region Alternate (commented)

                //Func<IDbReader, T> m = reader =>
                //{
                //    var obj = Activator.CreateInstance<T>();
                //    defination.CustomMapper(obj, reader);
                //    return obj;
                //};

                //result = query.QueryComplexSingle(m); 

                #endregion

                result = query.QuerySingle<T>(defination.ManualMapping);
            }
            else
            {
                result = query.QuerySingle<T>(defination.CustomMapper);
            }

            //result?.Commit(EntityState.NotModified); //set entity state to not modified on db read
            if (result != null)
            {
                SetStateObj(result);
            }
            return result;
        }

        /// <summary>
        /// Gets enumeration of entity objects using stored procedure
        /// </summary>
        /// <typeparam name="T">The type of entity</typeparam>
        /// <param name="spName">Stored Procedure Name</param>
        /// <param name="ids">Values of stored procedure parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public IEnumerable<T> GetListProc<T>(string spName, params object[] ids)
            where T : BaseModel
        {
            List<T> result;
            var defination = typeof(T).ToDefination();

            //HACK: replace with actual procedure name, may be retrieved from definition
            var query = _dbContext
                .Sql(spName)
                .CommandType(DbCommandTypes.StoredProcedure)
                .Parameters(ids);

            // ReSharper disable once ConvertIfStatementToConditionalTernaryExpression
            if (defination.UseManualMapping)
            {
                #region Alternate (commented)

                //Func<IDbReader, T> m = reader =>
                //{
                //    var obj = Activator.CreateInstance<T>();
                //    defination.CustomMapper(obj, reader);
                //    return obj;
                //};

                //result = query.QueryComplexSingle(m); 

                #endregion

                result = query.QueryMany<T>(defination.ManualMapping);
            }
            else
            {
                result = query.QueryMany<T>(defination.CustomMapper);
            }

            //result?.Commit(EntityState.NotModified); //set entity state to not modified on db read
            if (result != null)
            {
                SetState(result);
            }
            return result;
        }

        //public IEnumerable<T> GetList<T>(params object[] ids)
        //    where T : BaseModel
        //{
        //    var type = typeof(T);
        //    OnSelecting(type);

        //    var defination = type.ToDefination();

        //    //var sql = defination.SelectQuery + " WHERE " + defination.Where;
        //    var sql = defination.CompiledSelectSql;

        //    var result = GetListInternal<T>(sql, defination, ids);

        //    OnSelected(result);

        //    return result;
        //}

        /// <summary>
        /// Gets entity children using specified query and parameters
        /// </summary>
        /// <typeparam name="TParent">The type of entity</typeparam>
        /// <typeparam name="T">The type of child entity</typeparam>
        /// <param name="sql">Sql query</param>
        /// <param name="ids">Values of query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public IEnumerable<T> GetChildsList<TParent, T>(string sql, params object[] ids)
            where T : BaseModel
            where TParent : BaseModel
        {
            var parentType = typeof(TParent);
            var childType = typeof(T);

            OnSelecting(parentType);

            var parentDefination = parentType.ToDefination();
            var childDefinition = childType.ToDefination();


            var result = GetChildsListInternal<T>(sql, parentDefination, childDefinition, ids);

            OnSelected(result);

            return result;
        }

        // ReSharper disable once UnusedParameter.Local
        //TODO: remove parentDefination if not used
        List<T> GetChildsListInternal<T>(string sql, BaseDefination parentDefination, BaseDefination childDefinition, params object[] ids)
            where T : BaseModel
        {
            //TODO ids length and prms count should be same
            //var prms = parentDefination.ParameterNames;

            OnSqlStatementGenerated(sql, ids);

            var result = new List<T>();
            var query = _dbContext
                .Sql(sql)
                .Parameters(ids); //@0

            //for (var i = 0; i < prms.Count; i++)
            //{
            //    query = query.Parameter(prms[i], ids[i]);
            //}


            if (childDefinition.UseManualMapping)
            {
                #region Alternate (commented)

                //Action<IList<T>, IDbReader> m = (list, row) =>
                //{
                //    var obj = Activator.CreateInstance<T>();
                //    defination.CustomMapper(obj, row);
                //    list.Add(obj);
                //};

                //query.QueryComplexMany(result, m); 

                #endregion

                result = query.QueryMany<T>(childDefinition.ManualMapping);
            }
            else
                result.AddRange(query.QueryMany<T>(childDefinition.CustomMapper));

            //result?.ForEach(r=>r.Commit(EntityState.NotModified)); //set entity state to not modified on db read

            SetState(result);

            return result;
        }

        /// <summary>
        /// Read entity list based on custom query
        /// </summary>
        /// <param name="sql">sql query</param>
        /// <param name="ids">parameter values based on numeric (0,1) sequence</param>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <returns>List of entities</returns>
        /// <remarks>
        /// <para>[US] 30/03/2016  1.0 Method created.</para>
        /// </remarks>
        public List<T> GetEntityWithCustomSql<T>(string sql, params object[] ids)
            where T : BaseModel
        {

            var entityDefinition = typeof(T).ToDefination();

            OnSqlStatementGenerated(sql, ids);

            var result = new List<T>();
            var query = (_dbContext??_uow.Controller._dbContext)
                .Sql(sql)
                .Parameters(ids); //@0

            //for (var i = 0; i < prms.Count; i++)
            //{
            //    query = query.Parameter(prms[i], ids[i]);
            //}


            if (entityDefinition.UseManualMapping)
            {
                #region Alternate (commented)

                //Action<IList<T>, IDbReader> m = (list, row) =>
                //{
                //    var obj = Activator.CreateInstance<T>();
                //    defination.CustomMapper(obj, row);
                //    list.Add(obj);
                //};

                //query.QueryComplexMany(result, m); 

                #endregion

                result = query.QueryMany<T>(entityDefinition.ManualMapping);
            }
            else
                result.AddRange(query.QueryMany<T>(entityDefinition.CustomMapper));

            //result?.ForEach(r=>r.Commit(EntityState.NotModified)); //set entity state to not modified on db read

            SetState(result);

            return result;
        }

        /// <summary>
        /// Read entity list based on custom query
        /// </summary>
        /// <param name="sql">sql query</param>
        /// <param name="prmNames">parameter names </param>
        /// <param name="ids">parameter values based on numeric (0,1) sequence</param>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <returns>List of entities</returns>
        /// <remarks>
        /// <para>[US] 30/03/2016  1.0 Method created.</para>
        /// </remarks>
        public List<T> GetEntityWithCustomSql<T>(string sql, List<string> prmNames, params object[] ids)
           where T : BaseModel
        {

            var entityDefinition = typeof(T).ToDefination();

            OnSqlStatementGenerated(sql, ids);

            var result = new List<T>();
            var query = _dbContext
                .Sql(sql);


            for (var i = 0; i < prmNames.Count; i++)
            {
                query = query.Parameter(prmNames[i], ids[i]);
            }


            if (entityDefinition.UseManualMapping)
            {
                #region Alternate (commented)

                //Action<IList<T>, IDbReader> m = (list, row) =>
                //{
                //    var obj = Activator.CreateInstance<T>();
                //    defination.CustomMapper(obj, row);
                //    list.Add(obj);
                //};

                //query.QueryComplexMany(result, m); 

                #endregion

                result = query.QueryMany<T>(entityDefinition.ManualMapping);
            }
            else
                result.AddRange(query.QueryMany<T>(entityDefinition.CustomMapper));

            //result?.ForEach(r=>r.Commit(EntityState.NotModified)); //set entity state to not modified on db read

            SetState(result);

            return result;
        }

        /// <summary>
        /// Read entity list based on custom query
        /// </summary>
        /// <param name="sql">sql query</param>
        /// <param name="args">arguments</param>
        /// <typeparam name="T">Entity Type</typeparam>
        /// <returns>List of entities</returns>
        /// <remarks>
        /// <para>[US] 05/08/2016  1.0 Method created.</para>
        /// </remarks>
        public List<T> GetEntityWithSql<T>(string sql, Dictionary<string, object> args)//List<string> prmNames, params object[] ids)
           where T : BaseModel
        {

            var entityDefinition = typeof(T).ToDefination();
            List<DbParamInfo> parameters = null;

            if (EnableQueryPlanOptimizationFlag)
            {
                if (args != null && args.Count>0)
                {
                    var sqlOptimization =
                        _dbContext.Data.FluentDataProvider.ApplySqlOptimization(sql, args.Select(s=>s.Key).ToArray(), args.Select(s=>s.Value).ToArray(), EnableQueryPlanOptimizationAvoidRecompile);
                    sql = sqlOptimization.Item1;
                    
                    parameters = sqlOptimization.Item2;
                }
            }

            OnSqlStatementGenerated(sql, args?.Values);
            var query = _dbContext
                .Sql(sql);

            var result = new List<T>();

            if (EnableQueryPlanOptimizationFlag)
            {
                parameters?.ForEach(p =>
                {
                    query = query.Parameter(p.Name, p.Value, p.DbType);
                });
            }
            else
            {
                if (args != null)
                {
                    foreach (var pair in args)
                    {
                        query = query.Parameter(pair.Key, pair.Value);
                    }
                }
            }

            if (entityDefinition.UseManualMapping)
            {
                #region Alternate (commented)

                //Action<IList<T>, IDbReader> m = (list, row) =>
                //{
                //    var obj = Activator.CreateInstance<T>();
                //    defination.CustomMapper(obj, row);
                //    list.Add(obj);
                //};

                //query.QueryComplexMany(result, m); 

                #endregion

                result = query.QueryMany<T>(entityDefinition.ManualMapping);
            }
            else
                result.AddRange(query.QueryMany<T>(entityDefinition.CustomMapper));

            //result?.ForEach(r=>r.Commit(EntityState.NotModified)); //set entity state to not modified on db read

            SetState(result);

            return result;
        }

        /// <summary>
        /// Execute Sql in Database, In case of Update Query Append Tracking fields before executing
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sql"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public dynamic ExecuteSql(string sql, Dictionary<string, object> args)
        {
            var unitOfWork = InitUnitOfWorkIfNot();
            try {
                if (IsUpdatedQuery(sql))
                {
                    string literal_1 = TrackingFieldNames.UpdtDte;
                    string literal_2 = TrackingFieldNames.UpdtBy;
                    var updateAppendedClause = string.Empty;
                    if (args == null) args = new Dictionary<string, object>();

                    var paramCounter = 1;
                    var isUnique = true;
                    if (!sql.ToLower(System.Globalization.CultureInfo.InvariantCulture).Contains(literal_1))
                    {
                        var literal = literal_1;
                        do
                        {
                            if (args.ContainsKey(literal) || args.ContainsKey(literal.ToUpper(System.Globalization.CultureInfo.InvariantCulture)))
                            {
                                literal += paramCounter++;
                            }
                            else isUnique = false;
                        } while (isUnique);
                        updateAppendedClause += $", {literal_1}=@{literal} ";
                        args.Add(literal, SystemDateTime.UtcNow);
                    }
                    if (!sql.ToLower(System.Globalization.CultureInfo.InvariantCulture).Contains(literal_2))
                    {
                        Context context = LogContext.ContextToLog;

                        var literal = literal_2;
                        do
                        {
                            if (args.ContainsKey(literal) || args.ContainsKey(literal.ToUpper(System.Globalization.CultureInfo.InvariantCulture)))
                            {
                                literal += paramCounter++;
                            }
                            else isUnique = false;
                        } while (isUnique);
                        updateAppendedClause += $", {literal_2}=@{literal} ";
                        args.Add(literal, context.UserName);
                    }

                    var appendedIndex = sql.ToLower(System.Globalization.CultureInfo.InvariantCulture).IndexOf("where");


                    if (appendedIndex == 0) appendedIndex = sql.Length;
                    sql = sql.Insert(appendedIndex, updateAppendedClause);

                }

                OnSqlStatementGenerated(sql, null);

                var query = _dbContext
                    .Sql(sql);


                if (args != null)
                {
                    foreach (var pair in args)
                    {
                        query = query.Parameter(pair.Key, pair.Value);
                    }
                }

                var retvel = query.QueryMany<dynamic>();

                unitOfWork?.Save();
                return retvel;
            }
            finally
            {
                unitOfWork?.Dispose();
            }
        }

        /// <summary>
        /// Get entity list based on sql key name provided in designer
        /// </summary>
        /// <param name="key">Query name</param>
        /// <param name="args">Arguments/Parameters if any</param>
        /// <typeparam name="T">Entity type</typeparam>
        /// <returns>List of entity</returns>
        /// <exception cref="KeyNotFoundException"></exception>
        public List<T> GetEntityByKey<T>(string key, Dictionary<string, object> args = null)
           where T : BaseModel
        {

            var entityDefinition = typeof(T).ToDefination();

            var sql = string.Empty;
            entityDefinition?.SqlCollection?.TryGetValue(key, out sql);
            if (string.IsNullOrWhiteSpace(sql))
            {
                throw new KeyNotFoundException($"{key} key not found or empty sql statment");
            }

            return GetEntityWithSql<T>(sql, args);
        }

        /// <summary>
        /// Execute Stored Procedure
        /// </summary>
        /// <typeparam name="T">The type of entity object. i.e. dynamic</typeparam>
        /// <param name="spName">SP name</param>
        /// <param name="namedParameters">Names and Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 17/03/2016  1.0 Method created.</para>
        /// </remarks>
        public List<T> SpCallForEntity<T>(string spName, Dictionary<string, object> namedParameters)
            where T : BaseModel
        {
            var def = typeof(T).ToDefination();
            List<T> list = null;
            SpCallInternal(spName, namedParameters, command =>
            {
                if (def.UseManualMapping)
                {
                    list = command.QueryMany<T>(def.ManualMapping);
                }
                else
                {
                    list = command.QueryMany<T>(def.CustomMapper);
                }

            });
            SetState(list);
            return list;
        }


        /// <summary>
        /// Execute Stored Procedure
        /// </summary>
        /// <typeparam name="T">The type of entity object. i.e. dynamic</typeparam>
        /// <param name="spName">SP name</param>
        /// <param name="namedParameters">Names and Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 17/03/2016  1.0 Method created.</para>
        /// </remarks>
        public List<T> SpCall<T>(string spName, Dictionary<string, object> namedParameters)
        {
            List<T> list = null;
            SpCallInternal(spName, namedParameters, command =>
            {
                list = command.QueryMany<T>();
            });
            return list;
        }

        void SpCallInternal(string spName, Dictionary<string, object> namedParameters, Action<IDbCommand> cmdAction)
        {
            var unitOfWork = InitUnitOfWorkIfNot();
            try
            {
                //var r = _dbContext.Sql(sql, parameters).QueryMany<T>();
                var query = _dbContext
                    .Sql(spName)
                    .CommandType(DbCommandTypes.StoredProcedure); //@0

                if (namedParameters != null)
                {
                    var nms = namedParameters.Keys.ToList();

                    for (var i = 0; i < namedParameters.Count; i++)
                    {
                        query = query.Parameter(nms[i], namedParameters[nms[i]]);
                    }
                }

                //var r = query.QueryMany<T>();
                cmdAction?.Invoke(query);

                unitOfWork?.Save();

            }
            //catch (Exception ex)
            //{

            //}
            finally
            {
                unitOfWork?.Dispose();
            }
        }

        /// <summary>
        /// Execute Stored Procedure
        /// </summary>
        /// <typeparam name="T">The type of entity object. i.e. dynamic</typeparam>
        /// <param name="spName">SP name</param>
        /// <param name="namedParameters">Names and Values of the query parameters</param>
        /// <returns>object</returns>
        /// <remarks>
        /// <para>[US] 17/03/2016  1.0 Method created.</para>
        /// </remarks>
        public T SpCallSingle<T>(string spName, Dictionary<string, object> namedParameters)
        {
            T item = default(T);
            SpCallInternal(spName, namedParameters, command =>
            {
                item = command.QuerySingle<T>();
            });
            return item;
        }

        /// <summary>
        /// Execute Scalar Function
        /// </summary>
        /// <param name="funcName">Function name</param>
        /// <param name="namedParameters">Names and Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 25/05/2016  1.0 Method created.</para>
        /// </remarks>
        [Obsolete("Caution: Works with Sql Server Only. Oracle not supported for now")]
        public string ScalarFunctionCall(string funcName, Dictionary<string, object> namedParameters)
        {
            var uow = InitUnitOfWorkIfNot();
            try
            {
                var jn = string.Join(",", namedParameters.Select(aa => "@" + aa.Key));

                const string outputParameterName = "res";
                var sql = string.Format("exec {0} = dbo." + funcName + $" {jn} ", _dbContext.Data.FluentDataProvider.GetParameterName(outputParameterName));

                var query = _dbContext
                    .Sql(sql)
                    ;//.CommandType(DbCommandTypes.StoredProcedure); //@0


                var nms = namedParameters.Keys.ToList();

                for (var i = 0; i < namedParameters.Count; i++)
                {
                    query = query.Parameter(nms[i], namedParameters[nms[i]]);
                }
                query.ParameterOut(outputParameterName, DataTypes.String, int.MaxValue);


                query.Execute();
                var res = query.ParameterValue<string>(outputParameterName);

                uow?.Save();
                return res;// new[] {res.ToString()};
            }
            finally
            {
                uow?.Dispose();
            }
        }

        /// <summary>
        /// Reads custom entities of any type
        /// </summary>
        /// <typeparam name="T">The type of entity object. i.e. dynamic</typeparam>
        /// <param name="sql">Sql query</param>
        /// <param name="namedParameters">Names and Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 17/03/2016  1.0 Method created.</para>
        /// </remarks>
        public IList<T> GetCustomList<T>(string sql, SerializableDictionary<string, object> namedParameters)
        {
            //var r = _dbContext.Sql(sql, parameters).QueryMany<T>();
            var query = _dbContext
                .Sql(sql); //@0

            var nms = namedParameters.Keys.ToList();

            for (var i = 0; i < namedParameters.Count; i++)
            {
                query = query.Parameter(nms[i], namedParameters[nms[i]]);
            }

            var r = query.QueryMany<T>();

            return r;
        }

        /// <summary>
        /// Reads custom entities of any type
        /// </summary>
        /// <typeparam name="T">The type of entity object. i.e. dynamic</typeparam>
        /// <param name="sql">Sql query</param>
        /// <param name="parameters">Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 17/03/2016  1.0 Method created.</para>
        /// </remarks>
        public IList<T> GetCustomList<T>(string sql, params object[] parameters)
        {
            if (_uow != null)
            {
                return _uow.Controller._dbContext.Sql(sql, parameters).QueryMany<T>();
            }
            else
            {
                return _dbContext.Sql(sql, parameters).QueryMany<T>();
            }
        }

        /// <summary>
        /// Read single item by query
        /// </summary>
        /// <param name="sql">sql query</param>
        /// <param name="parameters">query parameters</param>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T GetCustomItem<T>(string sql, params object[] parameters)
        {
            if (_uow != null)
            {
                return _uow.Controller._dbContext.Sql(sql, parameters).QuerySingle<T>();
            }
            else
            {
                return _dbContext.Sql(sql, parameters).QuerySingle<T>();
            }

        }

        #endregion

        #region ReadEntityGraph
        /// <summary>
        /// Reads entity object with all children
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="ids">Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(params object[] ids)
            where T : BaseModel
        {
            return ReadEntityGraph<T>(string.Empty, null, ids);
        }

        /// <summary>
        /// Reads entity object and its children upto specified depth
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="depth">Number of levels to process in entity hierarchy</param>
        /// <param name="ids">Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(int depth, params object[] ids)
            where T : BaseModel
        {
            return ReadEntityGraph<T>(string.Empty, depth, ids);
        }

        /// <summary>
        /// Reads entity object
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="where">Custom where clause</param>
        /// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="ids">Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(string where, int? depth, params object[] ids)
            where T : BaseModel
        {
            var type = typeof(T);
            var defination = type.ToDefination();

            return ReadEntityGraph<T>(where, depth, defination.ParameterNames, ids);
        }

        /// <summary>
        /// Reads entity object
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="where">Custom where clause</param>
        /// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="prmNames">List of parameter names</param>
        /// <param name="ids">Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(string where, int? depth, IList<string> prmNames, params object[] ids)
            //params object[] ids)// 
            where T : BaseModel
        {
            return ReadEntityGraph<T>(null, where, depth, prmNames, ids);
        }

        ///// <summary>
        ///// Reads entity object
        ///// </summary>
        ///// <typeparam name="T">The type of entity object</typeparam>
        ///// <param name="aggregateId">Aggregate Id. Pass null if need to take from definition file</param>
        ///// <param name="where">Custom where clause</param>
        ///// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        ///// <param name="prmNames">List of parameter names</param>
        ///// <param name="ids">Values of the query parameters</param>
        ///// <returns>Enumeration of entity objects</returns>
        ///// <remarks>
        ///// <para>[US] 23/02/2016  1.0 Method created.</para>
        ///// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        ///// <para>[US] 15/08/2016  1.1 Added "aggregateId" parameter.</para>
        ///// </remarks>
        ////public List<T> ReadEntityGraph<T>(string aggregateId, string where, int? depth, IList<string> prmNames,
        ////    params object[] ids) //params object[] ids)// 
        ////    where T : BaseModel
        ////{
        ////    return ReadEntityGraph<T>(aggregateId, null, where, depth, prmNames, ids);
        ////}

        /// <summary>
        /// Reads entity object
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="aggregateId">Aggregate Id. Pass null if need to take from definition file</param>
        /// <param name="where">Custom where clause</param>
        /// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="prmNames">List of parameter names</param>
        /// <param name="ids">Values of the query parameters</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// <para>[US] 15/08/2016  1.1 Added "aggregateId" parameter.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(string aggregateId, string where, int? depth, IList<string> prmNames, params object[] ids)//params object[] ids)// 
            where T : BaseModel
        {
            //For oracle https://msdn.microsoft.com/en-us/library/haa3afyz(v=vs.110).aspx

            var type = typeof(T);

            OnEntitySelecting(type);

            var definition = type.ToDefination();
            //BaseDefination defination = new ProductDefinationNext(); //ProductModelDefinitionNext();
            var aggrId = aggregateId ?? definition.EntityId;

            var rootBatch = definition.GetSelectBatchV2(aggrId, null, String.Empty, where, depth, 1, null, EntityScopeFunc);
            List<T> target = null;
            bool targetInitilized = false;

            foreach (var batch in rootBatch.GetNextBatch())
            {

                var seqs = batch.GetQueries();
                if (seqs.Count == 0)
                    throw new InvalidOperationException("No query returned for type : " + type.FullName);


                if (_dbContext.IsMultiResultSqlSupported)
                {
                    var names = prmNames;// as IList<string> ?? prmNames.ToList();
                    using (var cmd = _dbContext.MultiResultSql)
                    {
                        var sb = new StringBuilder();
                        foreach (var s in seqs)
                        {
                            var sqlEntity = s.Key;
                            if (EnableQueryPlanOptimizationFlag && UseQeuryPlanRecompile)
                            {
                                var sqlOptimization =
                                    _dbContext.Data.FluentDataProvider.ApplySqlOptimization(sqlEntity, null, null, EnableQueryPlanOptimizationAvoidRecompile);
                                sqlEntity = sqlOptimization.Item1;
                            }

                            sb.AppendLine(sqlEntity + ";");
                        }

                        var sql = sb.ToString();

                        if (EnableQueryPlanOptimizationFlag)
                        {
                            if (UseQeuryPlanRecompile==false) //use parameter variables and not recompilation
                            {
                                var sqlOptimization =
                                    _dbContext.Data.FluentDataProvider.ApplySqlOptimization(sql, names?.ToArray(), ids, EnableQueryPlanOptimizationAvoidRecompile);
                                sql = sqlOptimization.Item1;
                                var prms = sqlOptimization.Item2;
                                prms?.ForEach(p => cmd.Parameter(p.Name, p.Value, p.DbType));

                                if (batch.ParameterList != null)
                                {
                                    sqlOptimization =
                                        _dbContext.Data.FluentDataProvider.ApplySqlOptimization(sql,
                                            batch.ParameterList.Select(s => s.Key).ToArray(),
                                            batch.ParameterList.Select(s => s.Value).ToArray(), EnableQueryPlanOptimizationAvoidRecompile);

                                    sql = sqlOptimization.Item1;
                                    prms = sqlOptimization.Item2;
                                    prms?.ForEach(p => cmd.Parameter(p.Name, p.Value, p.DbType));
                                }
                            }
                        }

                        OnSqlStatementGenerated(sql, ids);

                        var command = cmd.Sql(sql);

                            //.Parameters(ids);

                            //foreach (var idKv in ids)
                            //{
                            //    command.Parameter(idKv.Key, idKv.Value);
                            //}


                        if (!EnableQueryPlanOptimizationFlag || UseQeuryPlanRecompile) //either optimization disabled or option recompile is used
                        {
                            if (ids != null && ids.Length > 0)
                            {
                                for (var i = 0; i < ids.Length; i++)
                                {
                                    command = command.Parameter(names[i], ids[i],
                                        definition.NStringsColl.Contains(names[i])
                                            ? DataTypes.String
                                            : DataTypes.Object);
                                }
                            }

                            if (batch.ParameterList != null)
                                foreach (var pair in batch.ParameterList)
                                {
                                    command = command.Parameter(pair.Key, pair.Value);

                                }
                        }

                        var modelReader = new ModelReader(command);

                            foreach (var seq in seqs)
                            {
                                var res = seq.Value(modelReader, batch);
                                SetState(res); // as List<BaseModel>??res.ToList());
                                if (!targetInitilized)
                                {
                                    target = res.Cast<T>().ToList();
                                    targetInitilized = true;
                                }
                            }
                        }
                    }
                else
                {

                    var modelReader = new ModelReader(_dbContext, batch, ids, OnSqlStatementGenerated);

                    //var modelReader = new ModelReader(command);

                    foreach (var seq in seqs)
                    {
                        var res = seq.Value(modelReader, batch);
                        //SetState(res.ToArray());
                        SetState(res);// as List<BaseModel>??res.ToList());
                        if (!targetInitilized)
                        {
                            target = res.Cast<T>().ToList();
                            targetInitilized = true;
                        }
                    }

                }
            }

            OnEntitySelected(target);
            return target;

        }

        /// <summary>
        /// Reads entity object
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="expression">Expression that will be used as where clause</param>
        /// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="digDeepExpression">Digs down deeper in the expression to parse inline function call and evaluate them. if true, it will parse expressions with functions in it but will take extra CPU cycles and will have performance impact</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(Expression<Func<T, bool>> expression, int? depth = null,
            bool digDeepExpression = false)
            where T : BaseModel
        {
            return ReadEntityGraph(expression, null, null, depth, digDeepExpression);
        }

        /// <summary>
        /// Reads entity object
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="expression">Expression that will be used as where clause</param>
        /// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="digDeepExpression">Digs down deeper in the expression to parse inline function call and evaluate them. if true, it will parse expressions with functions in it but will take extra CPU cycles and will have performance impact</param>
        /// <param name="memberTableNameFactory"></param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(Expression<Func<T, bool>> expression, int? depth = null,
            bool digDeepExpression = false, Func<string, string> memberTableNameFactory = null)
            where T : BaseModel
        {
            return ReadEntityGraph(expression, null, null, depth, digDeepExpression, memberTableNameFactory);
        }

        /// <summary>
        /// Reads entity object
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="expression">Expression that will be used as where clause</param>
        /// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="memberTableNameFactory"></param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(Expression<Func<T, bool>> expression, int? depth = null
            , Func<string, string> memberTableNameFactory = null)
            where T : BaseModel
        {
            return ReadEntityGraph(expression, null, null, depth, false, memberTableNameFactory);
        }

        /// <summary>
        /// Reads entity object
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="expression">Expression that will be used as where clause</param>
        /// <param name="externalParameters"></param>
        /// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="memberTableNameFactory"></param>
        /// <param name="aggregateId"></param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(Expression<Func<T, bool>> expression, string aggregateId, 
            List<KeyValuePair<string, object>> externalParameters, int? depth = null, Func<string, string> memberTableNameFactory = null)
            where T : BaseModel
        {
            return ReadEntityGraph(expression, aggregateId, externalParameters, depth, false, memberTableNameFactory);
        }


        /// <summary>
        /// Reads entity object
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="expression">Expression that will be used as where clause</param>
        /// <param name="aggregateId">Aggregate Id to take entity hierarchy from</param>
        /// <param name="depth">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="digDeepExpression">Digs down deeper in the expression to parse inline function call and evaluate them. if true, it will parse expressions with functions in it but will take extra CPU cycles and will have performance impact</param>
        /// <param name="externalParameters">Number of levels to process in entity hierarchy. Null for reading all children. Default is null.</param>
        /// <param name="memberTableNameFactory">column table alias provider factory</param>
        /// <returns>Enumeration of entity objects</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> ReadEntityGraph<T>(Expression<Func<T, bool>> expression, string aggregateId, List<KeyValuePair<string, object>> externalParameters, 
            int? depth = null, bool digDeepExpression = false, Func<string, string> memberTableNameFactory = null)
            where T : BaseModel
        {

            var translator = new QueryTranslator();
            translator.MemberTableNameFactory = memberTableNameFactory;
            var tuple = translator.Translate<T>(expression, digDeepExpression);
            string whereClause = tuple.Item1;
            var prms = tuple.Item2;
            if (externalParameters != null && externalParameters.Any()) prms.AddRange(externalParameters);

            //var tab = typeof(T).ToDefination().UpdateTableName;
            //whereClause = string.Format(whereClause, string.IsNullOrWhiteSpace(tab)?string.Empty:tab+ ".");

            var result = ReadEntityGraph<T>(aggregateId, whereClause, depth, prms.Select(s => s.Key).ToList(), prms.Select(s => s.Value).ToArray());
            return result;
        }

        /// <summary>
        /// Fill Childs of aggregate items
        /// </summary>
        /// <param name="items"></param>
        /// <param name="depth"></param>
        /// <param name="aggregateId"></param>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException"></exception>
        public List<T> FillChilds<T>(List<T> items, int? depth = null, string aggregateId = null)
            where T : BaseModel
        {
            var type = typeof(T);

            var definition = type.ToDefination();

            var aggrId = aggregateId ?? definition.EntityId;

            var rootBatch = definition.FillChilds(items, aggrId, null, depth, 1, EntityScopeFunc);

            //bool targetInitilized = false;

            foreach (var batch in rootBatch.GetNextBatch())
            {

                var seqs = batch.GetQueries();
                if (seqs.Count == 0)
                    throw new InvalidOperationException("No query returned for type : " + type.FullName);


                if (_dbContext.IsMultiResultSqlSupported)
                {

                    using (var cmd = _dbContext.MultiResultSql)
                    {
                        var sb = new StringBuilder();
                        foreach (var s in seqs)
                        {
                            sb.AppendLine(s.Key + ";");
                        }
                        var sql = sb.ToString();

                        OnSqlStatementGenerated(sql, batch.ParameterList?.Values);

                        var command = cmd.Sql(sql);

                        if (batch.ParameterList != null)
                            foreach (var pair in batch.ParameterList)
                            {
                                command = command.Parameter(pair.Key, pair.Value);
                            }


                        var modelReader = new ModelReader(command);

                        foreach (var seq in seqs)
                        {
                            var res = seq.Value(modelReader, batch);
                            SetState(res);// as List<BaseModel> ?? res.ToList());
                        }
                    }
                }
                else
                {

                    var modelReader = new ModelReader(_dbContext, batch, null, OnSqlStatementGenerated);

                    foreach (var seq in seqs)
                    {
                        var res = seq.Value(modelReader, batch);
                        SetState(res);// as List<BaseModel> ?? res.ToList());
                    }

                }
            }

            return items;

        }



        #region Old ReadGraph (commented)
        //public IEnumerable<T> ReadEntityGraph<T>(params object[] ids)
        //    where T : ModelDefination
        //{
        //    //For oracle https://msdn.microsoft.com/en-us/library/haa3afyz(v=vs.110).aspx

        //    var defination = typeof(T).ToModelDefination();

        //    if (!defination.HasChilds)
        //    {
        //        //return GetChildsList<T, ModelDefination>(defination, ids);
        //    }

        //    //using (defination.WithContext(this))
        //    {

        //        List<T> target = null;
        //        using (var cmd = _dbContext.MultiResultSql)
        //        {

        //            StringBuilder sb = new StringBuilder();
        //            var multiSql = defination.GetSelectSqlForColumn(defination.KeyColumn, ids.Select(ToDbParamValue).ToArray()).ToList();
        //            foreach (string s in multiSql)
        //            {
        //                sb.AppendLine(s);
        //            }

        //            var command = cmd.Sql(sb.ToString());

        //            //using (defination.WithCommand(command))
        //            {
        //                if (defination.UseManualMapping)
        //                {
        //                    //target = command.QueryMany<T>(defination.ManualMapping<T>);
        //                }
        //                else
        //                {
        //                    // target = command.QueryMany<T>(defination.CustomMapper<T>);
        //                }


        //                using (var modelReader = new ModelReader(cmd))
        //                {
        //                    //defination.SatisfyModel(target, command, this);
        //                    //defination.SatisfyModel(target, modelReader);
        //                }
        //            }

        //        }
        //        return target;
        //    }

        //} 
        #endregion

        #endregion

        #region Entity Count
        /// <summary>
        /// Counts number of entities
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <returns>Number of entities</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public long CountAll<T>(Dictionary<string, object> parameters = null) where T : BaseModel
        {
            var definition = typeof(T).ToDefination();
            string query = string.Format(definition.CountQuery, string.Empty); //$"SELECT COUNT(*) FROM {defination.UpdateTableName} ";
            IDbCommand command = null;

            if (EnableQueryPlanOptimizationFlag)
            {
                var sqlOptimization =
                    _dbContext.Data.FluentDataProvider.ApplySqlOptimization(query, parameters?.Select(s => s.Key).ToArray(), parameters?.Select(s => s.Value).ToArray(),
                        EnableQueryPlanOptimizationAvoidRecompile);
                query = sqlOptimization.Item1;
                command = _dbContext.Sql(query);

                sqlOptimization.Item2?.ForEach(p => command = command.Parameter(p.Name, p.Value, p.DbType));
            }
            else
            {
                command = _dbContext.Sql(query);

                if (parameters != null)
                {
                    foreach (var pair in parameters)
                    {
                        command = command.Parameter(pair.Key, pair.Value);
                    }
                }
            }

            return command.QuerySingle<long>();
        }

        /// <summary>
        /// Counts number of entities
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="where">Custom where clause. Default is null.</param>
        /// <param name="parameters">Named parameters</param>
        /// <returns>Number of entities</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public long Count<T>(string where = null, Dictionary<string, object> parameters = null) where T : BaseModel
        {
            var definition = typeof(T).ToDefination();
            
            if (!string.IsNullOrEmpty(where))
                where = " WHERE " + where;

            var sbQuery = new StringBuilder();
            sbQuery.Append(string.Format(definition.CountQuery, where));


            if (definition.DefinitionVersion < 2)
                sbQuery.Append(where);

            var sql = sbQuery.ToString();
            IDbCommand command=null;

            if (EnableQueryPlanOptimizationFlag)
            {
                var sqlOptimization =
                    _dbContext.Data.FluentDataProvider.ApplySqlOptimization(sql, parameters?.Select(s=>s.Key).ToArray(), parameters?.Select(s=>s.Value).ToArray(),
                        EnableQueryPlanOptimizationAvoidRecompile);
                sql = sqlOptimization.Item1;
                command = _dbContext.Sql(sql);

                sqlOptimization.Item2?.ForEach(p=>command=command.Parameter(p.Name, p.Value, p.DbType));
                OnSqlStatementGenerated(sql, sqlOptimization.Item2?.Select(s=>s.Value));
            }
            else
            {
                //without query plan optimization
                command = _dbContext.Sql(sql);
                if (parameters != null)
                {
                    foreach (var pair in parameters)
                    {
                        command = command.Parameter(pair.Key, pair.Value);
                    }
                }
                OnSqlStatementGenerated(sql, parameters?.Values);
            }
            

            return command
                //.Parameters(ids)
                .QuerySingle<long>();
        }

        /// <summary>
        /// Count number of entities.
        /// </summary>
        /// <param name="sql">Sql Count Query</param>        
        /// <param name="parameters">Named Parameters</param>
        /// <returns></returns>
        /// <para>[MU] 06/03/2017  1.0 Method created.</para>        
        public long Count(string sql, Dictionary<string, object> parameters = null)
        {
            IDbCommand command = null;

            if (EnableQueryPlanOptimizationFlag)
            {
                var sqlOptimization =
                    _dbContext.Data.FluentDataProvider.ApplySqlOptimization(sql, parameters?.Select(s => s.Key).ToArray(), parameters?.Select(s => s.Value).ToArray(),
                        EnableQueryPlanOptimizationAvoidRecompile);
                sql = sqlOptimization.Item1;

                command = _dbContext.Sql(sql);
                sqlOptimization.Item2?.ForEach(p => command = command.Parameter(p.Name, p.Value, p.DbType));
                OnSqlStatementGenerated(sql, sqlOptimization.Item2?.Select(s => s.Value));
            }
            else
            {
                command = _dbContext.Sql(sql);
                if (parameters != null)
                {
                    foreach (var pair in parameters)
                    {
                        command = command.Parameter(pair.Key, pair.Value);
                    }
                }
                OnSqlStatementGenerated(sql, parameters?.Values);
            }

            return command
                //.Parameters(ids)
                .QuerySingle<long>();
        }

        #endregion

        #region Persist

        //        public T Update<T, TDefination>(T item, TDefination defination)
        //            where TDefination : BaseDefination
        //            where T : BaseModel
        //        {
        //            int rowsAffected = _dbContext
        //                .Update<T>(defination.TableName, item)
        //                .AutoMap(defination.GetInsertIgnoreList(item).ToArray())
        //                .Where(defination.KeyColumn, defination.GetId(item))
        //                .Execute();

        //#if DEBUG
        //            if (rowsAffected <= 0)
        //                throw new OperationCanceledException("no row effected");
        //#endif
        //            return item;
        //        }

        T Insert<T, TDefination>(T item, TDefination defination, InsertIdentityType useIdentityType, bool extendedSkipList)
            where TDefination : BaseDefination
            where T : BaseModel
        {
            object val = null;
            OnInserting(item);
            if (useIdentityType == InsertIdentityType.UseSequence)
            {
                val = item.GetType().GetProperty(defination.IdentityColumn)?.GetValue(item, null);
                if (val != null && (int)val == 0)
                {
                    // Get Sequence Table Name from Defination File
                    var colmVal = GetNextSequence(defination.UpdateTableName);
                    // We cane set Sequence either by using Reflection or by setting sql Parameter 
                    item.GetType().GetProperty(defination.IdentityColumn)?.SetValue(item, colmVal, null);
                    val = colmVal;
                }
            }
            var ignoringList = defination.GetInsertIgnoreList(item).ToList();
            //if (extendedSkipList)
            //    ignoringList.AddRange(defination.GetInsertIgnoreListExtented());

            if (useIdentityType == InsertIdentityType.SkipIdentity || useIdentityType == InsertIdentityType.UseSequence) ignoringList.Remove(defination.IdentityColumn);
            var res = _dbContext
                .Insert(defination.UpdateTableName, item, useIdentityType == InsertIdentityType.SkipIdentity)
                .AutoMap(ignoringList.ToArray());
            //defination.KeyColumn, nameof(item.State), nameof(item.ModifiedFields));
            var t = new List<string>();
            if (defination.HasIdentity)
            {
                var ret = 0;
                if (useIdentityType == InsertIdentityType.UseSequence)
                {
                    res.Execute();
                    if (val != null) ret = (int)val;
                }
                else
                    ret = res.ExecuteReturnLastId<int>(defination.IdentityColumn);
                defination.IdInjector(item, ret);
                OnIdGenerated(item, ret);
            }
            else
            {
                // ReSharper disable once UnusedVariable
                //It (ret) is being used in Debug mode
                var ret = res.Execute();
#if DEBUG
                //Debug.Assert(ret<=0);

                if (ret <= 0 && _ignoreEntityConstraints == false)
                    throw new OperationCanceledException("no row effected");

#endif
            }

            OnInserted(item);

            return item;
        }


        T Update<T, TDefination>(T item, TDefination defination, Action trackingFieldHandler, bool extendedSkipList)
            where T : BaseModel
            where TDefination : BaseDefination
        {

            OnUpdating(item);

            //var defination = typeof(T).ToDefination();
            if (!defination.Updatable)
            {
                if (_ignoreEntityConstraints == false)
                    throw new InvalidOperationException("entity is not updatable.");
                else
                    return item;
            }

            string tblName = defination.UpdateTableName;
            int rowsAffected;
#if DEBUG
            rowsAffected = 0;
#endif
            if (defination.UpdateMethod == UpdateMethod.DeleteThenInsert)
            {
                //TODO: impl will be added later
                //rowsAffected = 1;
            }
            else
            {
                var concurrenyModel = item as IConcurrentModel;
                DateTime? cnrtDate = null;
                if (concurrenyModel != null)
                {
                    cnrtDate = concurrenyModel.UPDT_DTE;
                }
                if (!extendedSkipList)
                    trackingFieldHandler();

                var ignoringList = defination.GetInsertIgnoreList(item).ToList();
                //if (extendedSkipList)
                //    ignoringList.AddRange(defination.GetInsertIgnoreListExtented());

                var updateQueryBuilder = _dbContext
                    .Update(tblName, item)
                    .AutoMap(ignoringList.ToArray());

                //HACK: Method1 - using reflection
                var idVals = defination.GetIds(item);
                // ReSharper disable once LoopCanBeConvertedToQuery
                foreach (var pair in idVals)// defination.GetUpdateWhere(item))
                {
                    updateQueryBuilder = updateQueryBuilder.Where(pair.Key, pair.Value ?? DBNull.Value);
                    //, ReflectionHelper.GetPropertyValue(item, fieldName));
                }


                if (concurrenyModel != null)
                {
                    updateQueryBuilder = updateQueryBuilder.Where(nameof(concurrenyModel.UPDT_DTE),
                        cnrtDate.Value);
                }


                //HACK: Method2 - using compiled methods
                //foreach (var kp in defination.GetParamList(item))
                //{
                //    updateQueryBuilder = updateQueryBuilder.Where(kp.Key, kp.Value(item));
                //}

                rowsAffected = updateQueryBuilder.Execute();

                if (rowsAffected <= 0 && concurrenyModel != null)
                {
                    throw new DBConcurrencyException("Concurrency issue: no row updated : " + item.GetType().Name + " (" + string.Join(",", idVals.Select(i => i.Key + ":" + i.Value.ToString())) + ")");
                }

                //rowsAffected = _dbContext
                //            .Update<T>(tblName, item)
                //            .AutoMap(defination.GetInsertIgnoreList(item).ToArray())
                //            .Where(defination.KeyColumn, defination.GetId(item))
                //    //.Where("ProductModelId", 33)
                //    //.Where("Color", "Red")
                //            .Execute();

                if (rowsAffected <= 0)
                    //throw new OperationCanceledException((concurrenyModel!=null? "Concurrency issue: ":string.Empty ) + "no row updated : " + item.GetType().Name + " (" + idVals.Select(i => i.Key + ":" + i.Value.ToString()) + ")");
                    throw new OperationCanceledException("no row updated : " + item.GetType().Name + " (" + string.Join(",", idVals.Select(i => i.Key + ":" + i.Value.ToString())) + ")");

            }

#if DEBUG
            if (rowsAffected <= 0 && _ignoreEntityConstraints == false)
                throw new OperationCanceledException("no row updated");
#endif



            OnUpdated(item);

            return item;
        }


        // ReSharper disable once UnusedTypeParameter
        int Delete<T>(BaseDefination defination, SerializableDictionary<string, object> ids)
            where T : BaseModel
        {

            //OnDeleting(); called through Persist method
            var qry = _dbContext
                .Delete(defination.UpdateTableName);
            // ReSharper disable once LoopCanBeConvertedToQuery
            foreach (var pair in ids)
            {
                qry = qry.Where(pair.Key, pair.Value ?? DBNull.Value);
            }

            int rowsAffected = qry.Execute();

#if DEBUG
            if (rowsAffected <= 0 && _ignoreEntityConstraints == false)
                throw new OperationCanceledException("no row deleted");
#endif
            //if (rowsAffected <= 0)
            //    throw new OperationCanceledException("no row deleted");

            return rowsAffected;
        }


        /// <summary>
        /// Saves changes in enity object to database.
        /// </summary>
        /// <typeparam name="T">The type of entity object</typeparam>
        /// <param name="item">The entity object to persist</param>
        /// <param name="useIdentityType">Determine whether identity insert or not</param>
        /// <param name="extendedSkipList">Use Extended Skip List</param>
        /// <param name="passIdentityType">Determine whether identity Type pass to Childs or childs use Default Identity Type (Scope Identity)</param>
        /// <returns>The entity object</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual T Persist<T>(T item, InsertIdentityType useIdentityType, bool extendedSkipList = false, bool passIdentityType = false) where T : BaseModel
        {
            var oldConstraing = _ignoreEntityConstraints;
            _ignoreEntityConstraints = true;

            // ReSharper disable once RedundantAssignment
            T res = item;//HACK: (resharper warning) value assigned not used in any execution path

            var type = item.GetType();
            var defination = type.ToDefination();// .ToModelDefination();

            //if (defination.IsUpdateable)
            {


                switch (item.State)
                {
                    case EntityState.NewModified:
                        {

                            #region Tracking Fields
                            if (!extendedSkipList)
                                HandleTrackingFields(item, type, true);

                            #endregion

                            res = Insert(item, defination, useIdentityType, extendedSkipList);
                            if (defination.HasIdentity)
                            {
                                //var id = defination.GetId(res);
                                //defination.SetChildIds(item); //, id);//mode part of IdInjector
                            }
                            if (_uow == null)
                                res.State = EntityState.NotModified;
                            break;
                        }
                    case EntityState.DataModified:
                        {
                            #region Tracking Fields

                            //moved to update method
                            //HandleTrackingFields(item, context, type, false);

                            #endregion

                            res = Update(item, defination, () => HandleTrackingFields(item, type, false), extendedSkipList);
                            if (_uow == null)
                                res.State = EntityState.NotModified;
                            break;
                        }
                    case EntityState.Delete:
                        {
                            OnDeleting(item);

                            //TODO: delete cascade at db level? -- or any other option to go with
                            //Note: Delete in reverse order (Always) to avoid referential integrity exception
                            var revChilds = defination.GetChilds(item); // item.GetChildsReverse();
                            foreach (var child in revChilds)
                            {
                                //TODO: update row status to delete??
                                if (child.State != EntityState.New && child.State != EntityState.NewModified)
                                {
                                    child.State = EntityState.Delete;
                                    Persist(child, useIdentityType);
                                }

                            }
                            // ReSharper disable once UnusedVariable
                            var idVals = defination.GetIds(item);

                            #region Concurrency

                            var concurrenyModel = item as IConcurrentModel;
                            if (concurrenyModel != null)
                            {
                                idVals.Add(nameof(concurrenyModel.UPDT_DTE), concurrenyModel.UPDT_DTE);
                            }

                            var rowsAffected = Delete<BaseModel>(defination, idVals);

                            if (rowsAffected <= 0 && concurrenyModel != null)
                            {
                                throw new DBConcurrencyException("Concurrency issue: no row updated : " +
                                                                 item.GetType().Name + " (" +
                                                                 string.Join(",",
                                                                     idVals.Select(i => i.Key + ":" + i.Value.ToString())) +
                                                                 ")");
                            }

                            #endregion


                            if (rowsAffected <= 0)
                                throw new OperationCanceledException("no row deleted : " + item.GetType().Name + " (" + string.Join(",", idVals.Select(i => i.Key + ":" + i.Value.ToString())) + ")");

                            OnDeleted(item);

                            return item;
                        }
                    case EntityState.New: //TODO: can new entity have childs, if no then return here
                    case EntityState.NotModified:
                        res = item;
                        break;

                    default:
                        throw new NotSupportedException("state not implemented");
                }
            }

            if (defination.HasChilds && defination.HasIdentity
                && item.State != EntityState.NewModified //new modified entities auto inject ids in child items. no need to update again
                )
            {
                defination.UpdateChildIds(item);
            }

            var childs = defination.GetChilds(item); //item.GetChilds();

            foreach (var child in childs)
            {
                Persist(child, (passIdentityType || (SequenceScopeFunc?.Invoke(child.GetType()) ?? false)) ? 
                    useIdentityType : InsertIdentityType.ScopeIdentity, extendedSkipList);
            }

            _ignoreEntityConstraints = oldConstraing;
            return res;
        }

        /// <summary>
        /// Bulk Insert
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="items"> List of Bulk Entities</param>
        /// <param name="sqlBulkCopyOptions">SQL Bulk Copy Option</param>
        /// <param name="batchSize">Batch Size</param>
        /// <param name="notifyAfter">Notify After</param>
        /// <param name="handler">Notify Event handler</param>
        /// <returns></returns>
        /// <para>[WB] 11/05/2018  1.0 Method created.</para>
        public virtual bool BulkInsert<T>(List<T> items, SqlBulkCopyOptions sqlBulkCopyOptions, int batchSize, int notifyAfter, SqlRowsCopiedEventHandler handler) where T : BaseModel
        {
            var type = typeof(T);
            var defination = type.ToDefination();
            //HandleBulkTrackingFields(items, type, true);

            var res = _dbContext
                .BulkInsert(items, defination.GetClrMapping().ToList(), defination.UpdateTableName, batchSize)
                .SetEventHandler(notifyAfter, handler);
            res.Execute();
            BulkInsert(items, sqlBulkCopyOptions, 0, 0, null);
            return true;
        }
        /// <summary>
        /// Bulk Insert Aggregate
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="items">List of Bulk Entries</param>
        /// <param name="handleTracking">Handle Tracking Fields or Not</param>
        /// <param name="sqlBulkCopyOptions">Sql Bulk Copy Option</param>
        /// <param name="batchSize">Batch Size</param>
        /// <param name="notifyAfter">Notify After</param>
        /// <param name="handler">Notify Event Handler</param>
        /// <returns></returns>
        public virtual List<T> BulkInsertAggregate<T>(IEnumerable<T> items, bool handleTracking, SqlBulkCopyOptions sqlBulkCopyOptions, int batchSize,
                            int notifyAfter, SqlRowsCopiedEventHandler handler) where T : BaseModel
        {
            var type = typeof(T);
            var defination = type.ToDefination();
            var itemsToBeInserted = items.Where(p => p.State == EntityState.NewModified).ToList();

            if (itemsToBeInserted.Count() > 0)
            {
                if (handleTracking) HandleBulkTrackingFields(itemsToBeInserted, type, true);
              //  var count = GetTableCount(defination.UpdateTableName);
                var identIncrement = GetIdentIncrement(defination.UpdateTableName);
                //var identCurrent = GetCurrentIdentity(defination.UpdateTableName);
                //var nextId = identCurrent + (count > 0 ? identIncrement : 0);

                var res = _dbContext
                    .BulkInsert(itemsToBeInserted, defination.GetClrMapping().ToList(), defination.UpdateTableName, batchSize)
                    .SetEventHandler(notifyAfter, handler)
                    .SetBulkCopyOption(sqlBulkCopyOptions);
                res.ExecuteMany();

                var lastId = GetScopeIdentity(defination.UpdateTableName);
                var ids = CheckIdentiyDiff(defination.UpdateTableName, defination.IdentityColumn, lastId, identIncrement, itemsToBeInserted.Count());

                for (int i = 0; i < itemsToBeInserted.Count(); i++)
                {
                    defination.IdInjector(itemsToBeInserted[i], ids[i]);
                    OnIdGenerated(itemsToBeInserted[i], ids[i]);
                    itemsToBeInserted[i].State = EntityState.NotModified;
                }
            }
            var childs = defination.GetChildsColl(items);
            foreach (var child in childs)
            {
                if (child != null && child.Any())
                {
                    MethodInfo method = typeof(DbController).GetMethod("BulkInsertAggregate");
                    MethodInfo generic = method.MakeGenericMethod(child.First().GetType());
                    generic.Invoke(this, new object[] { child, handleTracking, sqlBulkCopyOptions, batchSize, notifyAfter, handler });

                }
            }
            return items.ToList();
        }

        private void HandleTrackingFields<T>(T item, Type type, bool isInsert) where T : BaseModel
        {
            Context context = LogContext.ContextToLog;
            var p = ReflectionHelper.GetProperties(type);
            PropertyInfo property;

            if (isInsert)
            {
                if (p.TryGetValue(TrackingFieldNames.InsrBy, out property))
                {
                    if (context != null)
                        property?.SetValue(item, context.UserName); //SetPropertyValue(field, property, item, value);
                }

                if (p.TryGetValue(TrackingFieldNames.InsrDte, out property))
                {
                    property?.SetValue(item, SystemDateTime.UtcNow);
                }
            }
            if (p.TryGetValue(TrackingFieldNames.UpdtBy, out property))
            {
                if (context != null) property?.SetValue(item, context.UserName);
            }

            if (p.TryGetValue(TrackingFieldNames.UpdtDte, out property))
            {
                property?.SetValue(item, SystemDateTime.UtcNow);
            }
        }

        private void HandleBulkTrackingFields<T>(IEnumerable<T> items, Type type, bool isInsert) where T : BaseModel
        {
            Context context = LogContext.ContextToLog;
            var p = ReflectionHelper.GetProperties(type);
            PropertyInfo property;
            foreach (var item in items)
            {
                if (isInsert)
                {
                    if (p.TryGetValue(TrackingFieldNames.InsrBy, out property))
                    {
                        if (context != null)
                            property?.SetValue(item, context.UserName); //SetPropertyValue(field, property, item, value);
                    }

                    if (p.TryGetValue(TrackingFieldNames.InsrDte, out property))
                    {
                        property?.SetValue(item, SystemDateTime.UtcNow);
                    }
                }
                if (p.TryGetValue(TrackingFieldNames.UpdtBy, out property))
                {
                    if (context != null) property?.SetValue(item, context.UserName);
                }

                if (p.TryGetValue(TrackingFieldNames.UpdtDte, out property))
                {
                    property?.SetValue(item, SystemDateTime.UtcNow);
                }
            }
        }

        //public virtual void PersistComposite(ICompositeEntity compositeEntity)
        //{
        //    if (compositeEntity != null)
        //        foreach (var baseModel in compositeEntity.GetEntities())
        //        {
        //            Persist(baseModel);
        //        }
        //}


        #endregion

        #region Helper
        /// <summary>
        /// Prevent sql injection
        /// </summary>
        //HACK: commented unused method
        //string ToDbParamValue(object obj)
        //{
        //    if (obj == null || obj == DBNull.Value)
        //        return "NULL";

        //    string qt = "'";

        //    if (IsNumeric(obj))
        //    {
        //        //qt = string.Empty;
        //        return obj.ToString();
        //    }
        //    else
        //    {
        //        var ret = obj.ToString()
        //            .Trim()
        //            .Replace("'", "''")
        //            .Replace("--", string.Empty)
        //            .Replace(" ", string.Empty);

        //        return qt + ret + qt;
        //    }
        //}

        //HACK: commented unused method
        //bool IsNumeric(object obj)
        //{
        //    if (obj == null)
        //        return false;

        //    switch (Type.GetTypeCode(obj.GetType()))
        //    {
        //        case TypeCode.Byte:
        //        case TypeCode.SByte:
        //        case TypeCode.UInt16:
        //        case TypeCode.UInt32:
        //        case TypeCode.UInt64:
        //        case TypeCode.Int16:
        //        case TypeCode.Int32:
        //        case TypeCode.Int64:
        //        case TypeCode.Decimal:
        //        case TypeCode.Double:
        //        case TypeCode.Single:
        //            return true;
        //        default:
        //            return false;
        //    }
        //}

        void SetStateObj<T>(params T[] models) where T : BaseModel
        {
            if (models != null)
                foreach (var baseModel in models)
                {
                    baseModel.Commit(EntityState.NotModified);
                }
        }

        void SetState<T>(IEnumerable<T> models) where T : BaseModel
        {
            if (models != null)
                foreach (var baseModel in models)
                {
                    baseModel.Commit(EntityState.NotModified);
                }
        }

        private void OnSqlStatementGenerated(string sql, IEnumerable<object> ids)
        {
            if(GlobalConfig.Configurations.EnableSqlLogging)
                GlobalConfig.Configurations.SqlLogger?.LogSql(sql, ids as object[] ?? ids?.ToArray());

        }

        #endregion


        #region Dispose
        /// <summary>
        /// Performs cleanup
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// <para>[AQ] 03/07/2017  2.0 Method modified.</para>
        /// </remarks>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Custom Dispose(bool) Implementation. Takes care of Managed and Unmanaged resources
        /// </summary>
        /// <param name="isDisposing">A true value directs the function to clean managed resources along with unmanaged resources. A false value directs the function to clean native/un-managed resources only</param>
        /// <remarks>
        /// <para>[AQ] 03/07/2017  1.0 Method created.</para>
        /// <para>[AQ] 06/07/2017  1.1 Method modified.</para>
        /// </remarks>
        private void Dispose(bool isDisposing)
        {

            if (!this._isDisposed)
            {
                if (isDisposing)
                {
                    //Dispose managed resource only
                    _dbContext?.Dispose();
                    //Unnecessary
                    //_uow?.Dispose();

                }
                //Dispose any unmanaged resources
                //Dispose any native resources
                //A function that disposes native/unmanaged resources only can be called here.
                _isDisposed = true;
            }

        }
        #endregion

        /// <summary>
        /// Set ChildSelector delegate
        /// </summary>
        /// <param name="entityScopeFunc"></param>
        /// <returns></returns>
        public DbController WithEntityScope(Func<Type, string, string, string, bool> entityScopeFunc)
        {
            EntityScopeFunc = entityScopeFunc;
            return this;
        }

        /// <summary>
        /// Set Sequence Selector Delegate
        /// </summary>
        /// <param name="sequenceScopeFunc"></param>
        /// <returns></returns>
        public DbController WithSequenceScope(Func<Type, bool> sequenceScopeFunc)
        {
            SequenceScopeFunc = sequenceScopeFunc;
            return this;
        }
        private int GetNextSequence(string seqTable)
        {
            _dbContext = _dbContext.UseTransaction(true);
            var sSql = _dbContext.Data.FluentDataProvider.TableSequenceQuery;
            if (!string.IsNullOrEmpty(sSql))
            {
                var sql = string.Format(sSql, seqTable + "_SEQ");
                var seq = _dbContext.Sql(sql).QueryMany<int>().FirstOrDefault();
                return seq;
            }
            return 0;
        }

        private int GetTableCount(string tableName)
        {
            _dbContext = _dbContext.UseTransaction(true);
            var cSql = _dbContext.Data.FluentDataProvider.TableRecordExist;
            if (!string.IsNullOrEmpty(cSql))
            {
                var sql = string.Format(cSql, tableName);
                var count = _dbContext.Sql(sql).QueryMany<int>().FirstOrDefault();
                return count;
            }
            //var namedParameters = new Dictionary<string, object>();
            // namedParameters.Add("objname", tableName);

            //CountInfo list=null;
            //SpCallInternal("sp_spaceused", namedParameters, command =>
            //{
            //    var def = typeof(CountInfo).ToDefination();
            //    list = command.QueryMany<CountInfo>(def.CustomMapper).FirstOrDefault();
            //});
            //if (list != null)
            //    return Convert.ToInt32(list.ROWS);
            return 0;

        }

        private int GetIdentIncrement(string tableName)
        {
            _dbContext = _dbContext.UseTransaction(true);
            var iSql = _dbContext.Data.FluentDataProvider.TableIdentityIncrementQuery;
            if (!string.IsNullOrEmpty(iSql))
            {
                var sql = string.Format(iSql, tableName);
                var identIncrement = _dbContext.Sql(sql).QueryMany<int>().FirstOrDefault();
                return identIncrement;
            }
            return 0;
        }

        private int GetCurrentIdentity(string tableName)
        {
            _dbContext = _dbContext.UseTransaction(true);
            var cSql = _dbContext.Data.FluentDataProvider.TableCurrentIdentityQuery;
            if (!string.IsNullOrEmpty(cSql))
            {
                var sql = string.Format(cSql, tableName);
                var currentIdentity = _dbContext.Sql(sql).QueryMany<int>().FirstOrDefault();
                return currentIdentity;
            }
            return 0;
        }

        private int GetScopeIdentity(string tableName)
        {
            _dbContext = _dbContext.UseTransaction(true);
            var scSql = _dbContext.Data.FluentDataProvider.TableScopeIdentityQuery;

            if (!string.IsNullOrEmpty(scSql))
            {
                var scopeIdentity = _dbContext.Sql(scSql).QueryMany<int>().FirstOrDefault();
                return scopeIdentity;
            }
            return 0;
        }
        
        private List<int> CheckIdentiyDiff(string tableName,string pkColumnName,int lastId,int incr,int itemsCount)
        {
            //_dbContext = _dbContext.UseTransaction(true);
            //var query = $"SELECT {pkColumnName} From {tableName} WHERE {pkColumnName} >= {nextId} and {pkColumnName} <= {lastId}";
            //var ids = _dbContext.Sql(query).QueryMany <int>();
            var ids = new List<int>();
            var nextid = itemsCount * incr;
            var count = itemsCount- incr;
            for(int i= 0; i < itemsCount;i++)
            {
                ids.Add(lastId- count);
                count -= incr;
            }
            if (ids.Count != itemsCount)
            {
                throw new ArgumentException("More id values generated than we had entities. Something went wrong, try again.");
            }

            return ids;
        }

        private void HookEvents()
        {
            if (GlobalConfig.Configurations.EnableSqlDeepLogging)
            {
                _dbContext.OnExecuting(a =>
                {
                    //a.Tag= timer
                    GlobalConfig.Configurations.SqlLogger?.LogDeepSql(a.Command.CommandText,
                        a.Command.Parameters?.OfType<DbParameter>().ToDictionary(p => p.ParameterName, p => p.Value));//.Select(p=> (object) $"[{p.ParameterName} : {p.Value} ]").ToArray());
                });

                //_dbContext.OnExecuted(a =>
                //{

                //});

            }
        }

        private bool IsUpdatedQuery(string query)
        {
            if (query.ToLower(System.Globalization.CultureInfo.InvariantCulture).Contains("update")) return true;
            return false;
        }

    }
}
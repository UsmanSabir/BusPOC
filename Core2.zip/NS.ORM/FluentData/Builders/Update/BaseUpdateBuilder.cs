﻿using System.Diagnostics;
using NS.ORM.FluentData.Command;

namespace NS.ORM.FluentData.Builders
{
	internal abstract class BaseUpdateBuilder
	{
		public BuilderData Data { get; set; }
		protected ActionsHandler Actions { get; set; }

	    // ReSharper disable once UnusedParameter.Local
		public BaseUpdateBuilder(IDbProvider provider, IDbCommand command, string name)
		{
			Data =  new BuilderData(command, name);
			Actions = new ActionsHandler(Data);
		}

		public int Execute()
		{
			if (Data.Columns.Count == 0
					   || Data.Where.Count == 0)
				throw new FluentDataException("Columns or where filter have not yet been added.");

			Data.Command.ClearSql.Sql(Data.Command.Data.Context.Data.FluentDataProvider.GetSqlForUpdateBuilder(Data));
		
            Debug.WriteLine(Data.Command.Data.Sql);
		    if (GlobalConfig.Configurations.EnableSqlLogging)
		        GlobalConfig.Configurations.SqlLogger?.LogSql(Data.Command.Data.Sql.ToString());

            return Data.Command.Execute();
		}
	}
}

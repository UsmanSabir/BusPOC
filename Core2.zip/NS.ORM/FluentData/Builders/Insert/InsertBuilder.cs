﻿using System;
using NS.ORM.FluentData.Command;

namespace NS.ORM.FluentData.Builders
{
	internal sealed class InsertBuilder : BaseInsertBuilder, IInsertBuilder, IInsertUpdateBuilder
	{
		internal InsertBuilder(IDbCommand command, string name,bool setIdentity)
			: base(command, name, setIdentity)
		{
		}

		public IInsertBuilder Column(string columnName, object value, DataTypes parameterType, int size)
		{
			Actions.ColumnValueAction(columnName, value, parameterType, size);
			return this;
		}

		IInsertUpdateBuilder IInsertUpdateBuilder.Column(string columnName, object value, DataTypes parameterType, int size)
		{
			Actions.ColumnValueAction(columnName, value, parameterType, size);
			return this;
		}

		public IInsertBuilder Fill(Action<IInsertUpdateBuilder> fillMethod)
		{
			fillMethod(this);
			return this;
		}
	}
}

﻿using System;
using NS.ORM.Definitions.Classes;

namespace NS.ORM.FluentData.Command
{
    internal sealed partial class DbCommand
    {
        public TEntity QuerySinglePartialMapping<TEntity>(Action<TEntity, IDbReader> partialMapperReader)
        {
            var item = default(TEntity);

            Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
            {
                item = new QueryHandler<TEntity>(Data).ExecuteSingle(null, null, partialMapperReader);
            });

            return item;
        }

        public TEntity QuerySinglePartialMapping<TEntity>(Action<TEntity, dynamic> partialMapperReader)
        {
            var item = default(TEntity);

            Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
            {
                //HACK: bug fixed, it was always calling IDbReader action
                //existing
                //item = new QueryHandler<TEntity>(Data).ExecuteSingle(customMapper, null);
                item = new QueryHandler<TEntity>(Data).ExecuteSingle(null, null, partialMapperReader);
            });

            return item;
        }
    }
}
﻿using System.Data;

namespace NS.ORM.FluentData.Command
{
    internal sealed partial class DbCommand
    {
        public DataTable QuerySchema()
        {
            var items = default(DataTable);

            Data.ExecuteQueryHandler.ExecuteQuery(true, () =>
            {
                items = Data.Reader.InnerReader.GetSchemaTable();
                //items = new QueryHandler<TEntity>(Data).ExecuteMany<TList>(null, null, customMapper);
            });

            return items;
        }

    }
}
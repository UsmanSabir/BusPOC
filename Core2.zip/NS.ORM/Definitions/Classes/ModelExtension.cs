﻿using System;

namespace NS.ORM.Definitions.Classes
{
    /// <summary>
    /// Resolves entity definition (see <see cref="BaseDefination"/>) from entity type (see <see cref="BaseModels.BaseModel"/>).
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public static class ModelExtension
    {
        /// <summary>
        /// Extenstion method for resolving entity type to definition.
        /// </summary>
        /// <param name="type">The entity type to resolve (see <see cref="BaseModels.BaseModel"/>).</param>
        /// <returns>The entity definition (see <see cref="BaseDefination"/>)</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public static BaseDefination ToDefination(this Type type)
        {
            return DefinitionsCollection.Instance.GetModelDefinationNext(type);
        }
    }
}
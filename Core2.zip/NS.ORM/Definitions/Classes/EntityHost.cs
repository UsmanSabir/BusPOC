﻿using System;
using System.Collections.Generic;

namespace NS.ORM.Definitions.Classes
{
    /// <summary>
    /// Holds the List of entiy objects
    /// </summary>
    /// <typeparam name="T">The type of entiy object (see <see cref="BaseModels.BaseModel"/>)</typeparam>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
    /// </remarks>
    public sealed class EntityHost<T>
    {
        private List<T> _items;

        private readonly List<Action<List<T>>> _actions;

        /// <summary>
        /// Constructor for EntityHost
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 constructor created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public EntityHost()
        {
            _actions = new List<Action<List<T>>>();
        }

        /// <summary>
        /// List of entity objects
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Property created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<T> Items => _items;

        /// <summary>
        /// Sets Items property (see <see cref="Items"/>)
        /// </summary>
        /// <param name="items">List of entity objects</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 26/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public void SetHostedItems(List<T> items)
        {
            _items = items;
        }

        /// <summary>
        /// Adds action to excute on hosted entity objects (see <see cref="Items"/>)
        /// </summary>
        /// <param name="action">Action to execute</param>
        /// <returns>EntityHost</returns>
        public EntityHost<T> AddAction(Action<List<T>> action)
        {
            _actions.Add(action);
            return this;
        }
        /// <summary>
        /// Invokes actions on hosted entity objects (see <see cref="AddAction"/> for adding actions)
        /// </summary>
        public void Invoke()
        {
            _actions.ForEach(a=>a?.Invoke(_items));
        }

    }
}

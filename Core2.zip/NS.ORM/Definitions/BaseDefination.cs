﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Xml;
using NS.BaseModels;
using NS.ExceptionHandling;
using NS.ORM.Definitions.Classes;
using NS.Utilities;
using NS.Utilities.Enums;

namespace NS.ORM.Definitions
{
    /// <summary>
    /// Base class for orm definition classes
    /// </summary>
    /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Class created.</para>
    /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
    /// <para>[ZA] 29/02/2016  1.0 GetId method removed and added GetIds method, KeyColumn property removed.</para>
    /// </remarks>
    public abstract class BaseDefination
    {
        #region Static
        private const string xmlModelDefinition = "ModelDefinition";
        //private const string XMLTABLENAME = nameof(TableName); // "TableName";
        //private const string xmlKeyColumn = nameof(KeyColumn);
        private const string xmlHasIdentity = nameof(HasIdentity);
        private const string xmlIdentityColumn = nameof(IdentityColumn);
        private const string xmlUseManualMapping = nameof(UseManualMapping);
        private const string xmlUpdatable = nameof(Updatable);
        private const string xmlUpdateMethod = "UpdateMethod";
        private const string xmlUpdateTableName = nameof(UpdateTableName);
        private const string xmlSelectQuery = nameof(SelectQuery);
        private const string xmlWhereSingle = nameof(Where);
        private const string xmlCountQuery = nameof(CountQuery);
        private const string xmlParameterNames = nameof(ParameterNames);

        #endregion

        #region Fields

        //private string _fields;
        //private string _selectQuery;
        private string _compiledSql;

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor for BaseDefination
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Constructor created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected BaseDefination()
        {
            //InsertIgnoreList = new List<string>();
            //InsertIgnoreList.Add(na);

            var definitionDir = ConfigurationManager.AppSettings["definitionPath"];
            if (!string.IsNullOrEmpty(definitionDir) && Directory.Exists(definitionDir))
            {
                var typeName = GetType().Name;

                var path = Path.Combine(definitionDir, $"{typeName}.xml");
                if (File.Exists(path))
                    _processDefinition(path);
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// EntityId
        /// </summary>
        public virtual string EntityId { get; protected set; } = "BaseModel";
        /// <summary>
        /// RootName
        /// </summary>
        public abstract string RootName { get; }
        /// <summary>
        /// HasChilds
        /// </summary>
        public virtual bool HasChilds { get; } = false;
        /// <summary>
        /// SelectQuery
        /// </summary>
        public abstract string SelectQuery { get; protected set; }
        //public abstract string TableName { get; protected set; }
        //public abstract string KeyColumn { get; protected set; }
        /// <summary>
        /// OrderBy 
        /// </summary>
        public virtual string OrderBy { get; set; }
        /// <summary>
        /// GroupBy 
        /// </summary>
        public virtual string GroupBy { get; set; }
        /// <summary>
        /// Having 
        /// </summary>
        public virtual string Having { get; set; }
        /// <summary>
        /// HasIdentity
        /// </summary>
        public virtual bool HasIdentity { get; protected set; }
        /// <summary>
        /// IdentityColumn
        /// </summary>
        public virtual string IdentityColumn { get; protected set; }
        /// <summary>
        /// Where
        /// </summary>
        public abstract string Where { get; protected set; }
        /// <summary>
        /// UseManualMapping
        /// </summary>
        public virtual bool UseManualMapping { get; protected set; }
        //public abstract string CustomSelectQuery { get; protected set; }
        /// <summary>
        /// CountQuery
        /// </summary>
        public abstract string CountQuery { get; protected set; }
        /// <summary>
        /// Updatable
        /// </summary>
        public abstract bool Updatable { get; protected set; }
        /// <summary>
        /// UpdateTableName
        /// </summary>
        public abstract string UpdateTableName { get; protected set; }
        /// <summary>
        /// UpdateMethod
        /// </summary>
        public virtual UpdateMethod UpdateMethod { get; protected set; } = UpdateMethod.Update;
        //public abstract string WhereCustom { get; protected set; }

        /// <summary>
        /// Is Entity updatable
        /// </summary>
        public virtual bool IsUpdateable { get; protected set; } = true;

        /// <summary>
        /// 
        /// </summary>
        public virtual HashSet<string> NStringsColl { get; protected set; } = new HashSet<string>();

        /// <summary>
        /// CompiledSelectSql
        /// </summary>
        public virtual string CompiledSelectSql
        {
            get
            {
                if (string.IsNullOrEmpty(_compiledSql))
                {
                    _compiledSql = SelectQuery + " WHERE " + Where;
                }
                return _compiledSql;
            }
        }



        #endregion

        #region Public Members

        //protected virtual string SelectQuery
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(_selectQuery))
        //            _selectQuery = string.Format(SelectQueryFormat, Fields, TableName, "{0}", "{1}");
        //        return _selectQuery;
        //    }
        //}

        /// <summary>
        /// Gets property names for use in update where clause.
        /// </summary>
        /// <typeparam name="T">The type of entity</typeparam>
        /// <param name="entity">Entity object</param>
        /// <returns>Enumeration of property names that will be used for update where clause.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual IEnumerable<string> GetUpdateWhere<T>(T entity)
        {
            return new List<string>();
        }

        //public virtual Dictionary<string, Func<T, object>> GetParamList<T>(T entity)
        //{
        //    return new Dictionary<string, Func<T, object>>();
        //}

        //public virtual void SatisfyModel(IEnumerable<BaseModel> target, ModelReader modelReader, DbBatch batch)
        //{
        //}


        //public virtual DbBatch GetSelectBatch(DbBatch batch, string column, Action<List<BaseModel>> postAction,
        //    params object[] ids)
        //{
        //    return batch;
        //}


        /// <summary>
        /// Resolves entity graph and build queries
        /// </summary>
        /// <param name="aggregateId">The entity key.</param>
        /// <param name="batch">The current batch</param>
        /// <param name="strJoin">The join string to append in query.</param>
        /// <param name="strWhere">The where clause string to append in query.</param>
        /// <param name="depth">Read entity children upto specified hierarchy levels. null read all entity children.</param>
        /// <param name="level"></param>
        /// <param name="postAction">Action</param>
        /// <returns>DbBatch. See <see cref="DbBatch"/></returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual DbBatch GetSelectBatch(string aggregateId, DbBatch batch, string strJoin, string strWhere,
            int? depth, int level,
            Action<List<BaseModel>> postAction
            )
        {
            return batch;
        }

        /// <summary>
        /// Resolves entity graph and build queries
        /// </summary>
        /// <param name="aggregateId">The entity key.</param>
        /// <param name="batch">The current batch</param>
        /// <param name="strJoin">The join string to append in query.</param>
        /// <param name="strWhere">The where clause string to append in query.</param>
        /// <param name="depth">Read entity children upto specified hierarchy levels. null read all entity children.</param>
        /// <param name="level"></param>
        /// <param name="postAction">Action</param>
        /// <param name="shouldAppendChild">A delegate to decide, should child entity be included in aggregate filling. Func Arguments are "Type entityChild, string entityParent, string aggregateId"</param>
        /// <returns>DbBatch. See <see cref="DbBatch"/></returns>
        /// <remarks>
        /// <para>[US] 27/07/2016  1.0 Method created.</para>
        /// </remarks>
        public virtual DbBatch GetSelectBatch(string aggregateId, DbBatch batch, string strJoin, string strWhere,
            int? depth, int level,
            Action<List<BaseModel>> postAction
            , Func<Type, string, string, bool> shouldAppendChild
            )
        {
            return GetSelectBatch(aggregateId, batch, strJoin, strWhere, depth, level, postAction); //route base method call to previous version
        }

        /// <summary>
        /// Resolves entity graph and build queries
        /// </summary>
        /// <param name="aggregateId">The entity key.</param>
        /// <param name="batch">The current batch</param>
        /// <param name="strJoin">The join string to append in query.</param>
        /// <param name="strWhere">The where clause string to append in query.</param>
        /// <param name="depth">Read entity children upto specified hierarchy levels. null read all entity children.</param>
        /// <param name="level"></param>
        /// <param name="postAction">Action</param>
        /// <param name="shouldAppendChild">A delegate to decide, should child entity be included in aggregate filling. Func Arguments are "Type entityChild, string entityParent, string aggregateId, string propertyName"</param>
        /// <returns>DbBatch. See <see cref="DbBatch"/></returns>
        /// <remarks>
        /// <para>[US] 27/07/2016  1.0 Method created.</para>
        /// </remarks>
        //string aggregateId, string propertyName, string where, int? depth, IList<string> prmNames
        public virtual DbBatch GetSelectBatchV2(string aggregateId, DbBatch batch, string strJoin, string strWhere, int? depth, int level, Action<List<BaseModel>> postAction,
            Func<Type, string, string, string, bool> shouldAppendChild)
        {
            //if (DefinitionVersion >= 2)
            var dbBatch = GetSelectBatch(aggregateId, batch, strJoin, strWhere, depth, level, postAction,
                (type, parent, aggregateName) => shouldAppendChild?.Invoke(type, parent, aggregateName, string.Empty) ?? true);
            if (dbBatch == null)
            {
                //older version
                dbBatch = GetSelectBatch(aggregateId, batch, strJoin, strWhere, depth, level, postAction); //route base method call to previous version

            }

            return dbBatch;
        }


        /// <summary>
        /// Fills parent child properties
        /// </summary>
        /// <typeparam name="T">The type of entity</typeparam>
        /// <param name="parentItems">List of parent entity to fill</param>
        /// <param name="childs">List of child entities</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual void ChildProcessor<T>(List<T> parentItems, List<BaseModel> childs) where T : BaseModel
        {
        }

        /// <summary>
        /// Runs child processer <seealso cref="ChildProcessor{T}"/>
        /// </summary>
        /// <typeparam name="T">The type of entity</typeparam>
        /// <param name="batch">The batch to process. See <see cref="DbBatch"/></param>
        /// <param name="ret">List of entity objects</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual void ProcessChildBatches<T>(DbBatch batch, List<T> ret) where T : BaseModel
        {
        }

        //public abstract Action<T, int> IdInjector<T>() { get; }

        /// <summary>
        /// Sets id in entity children
        /// </summary>
        /// <typeparam name="T">The type of entity.</typeparam>
        /// <param name="item">Entity object.</param>
        /// <param name="id">The value to be set.</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public abstract void IdInjector<T>(T item, int id) where T : BaseModel;

        /// <summary>
        /// Sets(update) id in entity childrens
        /// </summary>
        /// <typeparam name="T">The type of entity.</typeparam>
        /// <param name="item">Entity object.</param>
        /// <remarks>
        /// <para>[US] 19/04/2016  1.0 Method created.</para>
        /// </remarks>
        public virtual void UpdateChildIds<T>(T item) where T : BaseModel { }

        /// <summary>
        /// Get Childs from Collection of Parents
        /// </summary>
        /// <param name="items"></param>
        /// <para>[WB] 17/05/2018  1.0 Method created.</para>
        /// <returns></returns>
        public virtual IEnumerable<IEnumerable<BaseModel>> GetChildsColl(IEnumerable<BaseModel> items) 
        {
            return Enumerable.Empty<IEnumerable<BaseModel>>();
        }

        /// <summary>
        /// Gets the value of identity columns of the specified entity.
        /// </summary>
        /// <param name="model">Entity object</param>
        /// <returns>Collection of key value pair with property name as key and property value as value.</returns>
        /// <remarks>
        /// <para>[ZA] 29/02/2016  1.0 Method created.</para>
        /// </remarks>
        public virtual SerializableDictionary<string, object> GetIds(BaseModel model)
        {
            return null;

        }


        /// <summary>
        /// Holds datareader to object mappings and fills specified the object.
        /// </summary>
        /// <typeparam name="T">The type of object.</typeparam>
        /// <param name="item">The object to fill.</param>
        /// <param name="row">Datareader row. <see cref="IDbReader"/></param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual void CustomMapper<T>(T item, IDbReader row)
        {
        }

        /// <summary>
        /// This method will be used to provide manual mapping between database table and model
        /// </summary>
        /// <param name="item">model class object</param>
        /// <param name="row">dynamic type object with database table columns</param>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual void ManualMapping<T>(T item, dynamic row)
        {
        }

        //public virtual void SetFkVal(object target, string fkName, int fkVal)
        //{
        //    var t = target as IDictionary<string, object>;
        //    if (t == null) return;
        //    if (t.ContainsKey(fkName))
        //        t[fkName] = fkVal;
        //}


        /// <summary>
        /// Gets enumeration of property names to ignore when inserting data.
        /// </summary>
        /// <typeparam name="T">The type of object.</typeparam>
        /// <param name="entity">Entity object</param>
        /// <returns>Enumeration of property names to ignore when inserting data.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual IEnumerable<string> GetInsertIgnoreList<T>(T entity) where T : BaseModel
        {
            //if (HasIdentity)
            //{
            //    yield return KeyColumn;
            //}
            yield return nameof(entity.State);

            TrackableModel trackable = entity as TrackableModel;
            if (trackable != null)
                yield return nameof(trackable.ModifiedFields);
        }

        /// <summary>
        /// Get enumeration of property names need for bulk operations
        /// </summary>
        /// <returns>Enumeration of property names need for bulk operations</returns>
        /// <para>[WB] 11/05/2018  1.0 Method created.</para>
        public virtual IEnumerable<string> GetClrMapping()
        {
            return Enumerable.Empty<string>();
        }
        /// <summary>
        /// Gets enumeration of property names to ignore when inserting data.
        /// </summary>
        /// <typeparam name="T">The type of object.</typeparam>
        /// <param name="entity">Entity object</param>
        /// <returns>Enumeration of property names to ignore when inserting data.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual IEnumerable<string> GetInsertIgnoreListExtented()
        {
            yield return "INSR_BY";
            yield return "UPDT_BY";
            yield return "INSR_DTE";
            yield return "UPDT_DTE";
        }


        /// <summary>
        /// Gets enumeration of entity children.
        /// </summary>
        /// <param name="item">Entity object.</param>
        /// <returns>Enumeration of entity children.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual IEnumerable<BaseModel> GetChilds(BaseModel item)
        {
            return Enumerable.Empty<BaseModel>();
        }


        /// <summary>
        /// Resolves entity relation and builds query.
        /// </summary>
        /// <param name="parent">Parent entity object.</param>
        /// <param name="entityChild">The type of child entity object to resolve.</param>
        /// <param name="postAction">Action to execute after data loading completes.</param>
        /// <returns>Pair of query and parent entity ids.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual Tuple<string, IList<object>> GetChildSqlWithParams(BaseModel parent, Type entityChild,
            Action<List<BaseModel>> postAction = null)
        {
            return null;
        }

        /// <summary>
        /// Resolves entity relation and builds query.
        /// </summary>
        /// <param name="parent">Parent entity object.</param>
        /// <param name="entityChild">The type of child entity object to resolve.</param>
        /// <param name="aggregateName">Aggregate name</param>
        /// <param name="postAction">Action to execute after data loading completes.</param>
        /// <param name="propertyName">Property name</param>
        /// <returns>Pair of query and parent entity ids.</returns>
        /// <remarks>
        /// <para>[US] 19/08/2016  1.0 Method created.</para>
        /// </remarks>
        public virtual Tuple<string, IList<object>> GetChildSqlWithParamsV2(BaseModel parent, Type entityChild,
        string propertyName, string aggregateName, Action<List<BaseModel>> postAction = null)
        {
            return GetChildSqlWithParams(parent, entityChild, postAction);
        }

        /// <summary>
        /// Fill chils of aggregate
        /// </summary>
        /// <param name="items"></param>
        /// <param name="aggregateId"></param>
        /// <param name="batch"></param>
        /// <param name="depth"></param>
        /// <param name="level"></param>
        /// <param name="shouldAppendChild"></param>
        /// <returns></returns>
        public virtual DbBatch FillChilds(IEnumerable<BaseModel> items, string aggregateId, DbBatch batch, int? depth,
            int level, Func<Type, string, string, string, bool> shouldAppendChild)
        {
            return batch;
        }


        /// <summary>
        /// AcceptChildCollections
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public virtual IEnumerable<BaseModel> AcceptChildCollections(BaseModel item)
        {
            return Enumerable.Empty<BaseModel>();
        }

        /// <summary>
        /// AcceptChange
        /// </summary>
        /// <param name="item"></param>
        /// <param name="list"></param>
        /// <param name="action"></param>
        /// <typeparam name="T"></typeparam>
        protected void AcceptChange<T>(BaseModel item, List<T> list, Action<BaseModel, List<T>> action = null) where T : BaseModel
        {
            if (list == null || item == null)
                return;

            action?.Invoke(item, list);
            list.RemoveAll(p => p.State == EntityState.Delete || p.State == EntityState.New);
        }


        #endregion

        #region Private Members

        private void _processDefinition(string path)
        {
            var xmlReaderSettings = new XmlReaderSettings
            {
                IgnoreComments = true //IgnoreWhitespace = true,
            };
            try
            {
                using (var xmlReader = XmlReader.Create(path, xmlReaderSettings))
                {
                    while (xmlReader.Read())
                    {
                        if (!xmlReader.IsStartElement()) continue;
                        // ReSharper disable DoNotCallOverridableMethodsInConstructor
                        switch (xmlReader.Name)
                        {
                            case xmlModelDefinition:
                                break;
                            //case XMLTABLENAME:
                            //    TableName = xmlReader.ReadElementContentAsString();
                            //    break;
                            //case xmlKeyColumn:
                            //    KeyColumn = xmlReader.ReadElementContentAsString();
                            //    break;
                            case xmlHasIdentity:
                                HasIdentity = xmlReader.ReadElementContentAsBoolean();
                                //Convert.ToBoolean(xmlReader.ReadInnerXml());
                                break;
                            case xmlIdentityColumn:
                                IdentityColumn = xmlReader.ReadElementContentAsString();
                                break;
                            case xmlUseManualMapping:
                                UseManualMapping = xmlReader.ReadElementContentAsBoolean();
                                //Convert.ToBoolean(xmlReader.ReadInnerXml());
                                break;
                            case xmlUpdatable:
                                Updatable = xmlReader.ReadElementContentAsBoolean();
                                //Convert.ToBoolean(xmlReader.ReadInnerXml());
                                break;
                            case xmlUpdateMethod:
                                UpdateMethod = (UpdateMethod)xmlReader.ReadElementContentAsInt();
                                // Convert.ToInt32(xmlReader.ReadInnerXml());
                                break;
                            case xmlUpdateTableName:
                                UpdateTableName = xmlReader.ReadElementContentAsString();
                                break;
                            case xmlSelectQuery:
                                SelectQuery = xmlReader.ReadElementContentAsString();
                                break;
                            case xmlWhereSingle:
                                Where = xmlReader.ReadElementContentAsString();
                                break;
                            case xmlCountQuery:
                                CountQuery = xmlReader.ReadElementContentAsString();
                                break;

                            case xmlParameterNames:
                                var lstStr = xmlReader.ReadElementContentAsString();
                                if (!string.IsNullOrWhiteSpace(lstStr))
                                {
                                    try
                                    {
                                        var paramNames = lstStr.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                                        //if (paramNames.Length > 0)
                                        ParameterNames = paramNames.ToList();

                                    }
                                    catch (Exception ex)
                                    {
                                        ExceptionHandler.HandleException(ex,
                                            ExceptionHandlingPolicy.LogOnlyPolicy);
                                    }
                                }
                                break;
                        }
                        // ReSharper restore DoNotCallOverridableMethodsInConstructor
                    }
                }
            }
            catch (Exception ex)
            {
                //TODO: add exception handling
                Debug.WriteLine(ex.ToString());
            }

            if (!string.IsNullOrEmpty(SelectQuery))
            {
                var whereVal = Where ?? string.Empty;
                SelectQuery = SelectQuery
                    .Replace($"{xmlWhereSingle}", whereVal)
                    .Replace("{", "")
                    .Replace("}", "")
                    .Replace("&gt;", ">")
                    .Replace("&lt;", "<");
            }
        }

        #endregion

        /// <summary>
        /// Holds entity relation graph.
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Property created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected Dictionary<string, List<Type>> EntityChilds { get; set; }

        //protected Dictionary<string, Tuple<string, string, string, Type, Func<dynamic, IList<object>>>> TypeRelationV2;

        /// <summary>
        /// Aggregate childs/relations collection. for version 2 and above
        /// </summary>
        protected Dictionary<string, List<string>> AggregateChildsV2 { get; set; }

        /// <summary>
        /// Definition File Version
        /// </summary>
        public int DefinitionVersion { get; protected set; } = 1;

        /// <summary>
        /// Holds entity relation
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Property created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        protected Dictionary<Type, Tuple<string, string, string, Func<dynamic, IList<object>>>> TypeRelation { get; set; }

        /// <summary>
        /// Store table name for columns having "Ambiguous Column error"
        /// </summary>
        public ReadOnlyDictionary<string, string> ColumnTable { get; protected set; }

        /// <summary>
        /// Collection containing secondary sql statements to read entity
        /// </summary>
        public ReadOnlyDictionary<string, string> SqlCollection { get; protected set; }



        //TODO protected Dictionary<string, Tuple<string, string, string, Func<dynamic, IList<object>>>> Relations { get; set; }

        /// <summary>
        /// Holds the named parameters
        /// </summary>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Property created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public List<string> ParameterNames { get; set; }

        //public virtual Dictionary<string,string> CustomSqlCommands { get; set; }

        //protected  Dictionary<Type, Tuple<string, string>> TypeRelation { get; set; }

        /// <summary>
        /// Checks if entity exists in specified entity graph.
        /// </summary>
        /// <param name="entityId">The entity graph key to search.</param>
        /// <param name="type">The entity type to search.</param>
        /// <returns>True, if entity found in specifed entity graph.</returns>
        /// <remarks>
        /// <para>[US] 23/02/2016  1.0 Method created.</para>
        /// <para>[ZA] 25/02/2016  1.0 Comments added.</para>
        /// </remarks>
        public virtual bool HaveType(string entityId, Type type)
        {
            //return false;

            if (EntityChilds == null || EntityChilds.ContainsKey(entityId) == false)
            {
                return false;
            }

            var types = EntityChilds[entityId];
            if (types.Any(t => t == type))
                return true;

            var haveType = types.Any(t =>
            {
                var def = t.ToDefination();
                var haveT = def.HaveType(entityId, type);
                return haveT;
            });
            return haveType;
        }






    }

    /// <summary>
    /// Relation Details Info Storage class
    /// </summary>
    public class RelationDetails
    {
        /// <summary>
        /// Join
        /// </summary>
        public string Join { get; set; }

        /// <summary>
        /// Where
        /// </summary>
        public string Where { get; set; }

        /// <summary>
        /// Custom Where
        /// </summary>
        public string CustomWhere { get; set; }

        /// <summary>
        /// Child Type
        /// </summary>
        public Type ChildType { get; set; }

        /// <summary>
        /// Property Name
        /// </summary>
        public string PropertyName { get; set; }

        /// <summary>
        /// Aggregate Name
        /// </summary>
        public string AggregateName { get; set; }
        /// <summary>
        /// Parent Where
        /// </summary>
        public bool UseParentWhere { get; set; }

        /// <summary>
        /// Alternate join string to participate in aggregate join in-case single column is used with parent in relation
        /// </summary>
        public string ConditionalJoin { get; set; }
    }
}
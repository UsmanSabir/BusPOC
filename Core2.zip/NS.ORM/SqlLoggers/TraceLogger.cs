﻿using System.Collections.Generic;
using System.Linq;

namespace NS.ORM.SqlLoggers
{
    /// <summary>
    /// SlqLogger write to Debug listeners 
    /// </summary>
    public class TraceLogger:ISqlLogger
    {
        /// <summary>
        /// LogSql
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        public void LogSql(string sql, params object[] parameters)
        {
            System.Diagnostics.Trace.WriteLine($"{sql} --{string.Join(", ", (parameters ?? new object[] {}).Select(p => p?.ToString()??"NULL"))}");

        }

        
        /// <summary>
        /// LogDeepSql
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        public void LogDeepSql(string sql, Dictionary<string, object> parameters)
        {
            System.Diagnostics.Trace.WriteLine(
                $"{sql} -- DEEP -- {string.Join(", ", (parameters ?? new Dictionary<string,object>()).Select(p => $"[ {p.Key} : {p.Value??"NULL"} ]"))}");

        }
    }
}
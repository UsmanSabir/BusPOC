﻿
using System.Runtime.Serialization;
using System.Collections.Generic;

namespace NS.BaseModels
{
    /// <summary>
    /// Class to hold Output/Result parameters of a Workflow (Microflow)
    /// </summary>
    public sealed class WorkflowOutputParams
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowOutputParams"/> class.
        /// </summary>
        public WorkflowOutputParams()
        {
            Outputs = new List<KeyValuePair<string, object>>();
            ErrorMessages = new List<string>();
        }
        /// <summary>
        /// Dictionary to hold output values
        /// </summary>
        /// <value>The outputs.</value>
        [DataMember]
        public List<KeyValuePair<string, object>> Outputs { set; get; }
        /// <summary>
        /// Holds Error information (If an error occurs during workflow execution)
        /// </summary>
        /// <value>The error.</value>
        [DataMember]
        public string Error { set; get; }
        /// <summary>
        /// Hold List of Error Messages (Returned in case of Microflow)
        /// </summary>
        /// <value>The error messages.</value>
        [DataMember]
        public List<string> ErrorMessages { set; get; }
        ///// <summary>
        ///// Holds Error Details
        ///// </summary>
        //[DataMember]
        //public string ErrorDetail { set; get; }
        /// <summary>
        /// Bool value that depicts if a workflow executed successfully or not
        /// </summary>
        /// <value><c>true</c> if [execution successful]; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool ExecutionSuccessful { set; get; }
    }
}

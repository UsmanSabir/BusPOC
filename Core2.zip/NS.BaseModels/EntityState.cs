﻿namespace NS.BaseModels
{
    /// <summary>
    /// Enum to specify entity state.
    /// </summary>
    /// /// <remarks>
    /// <para>[US] 23/02/2016  1.0 Enum created.</para>
    /// <para>[ZA] 24/02/2016  1.0 Documentation added.</para>
    /// </remarks>
    public enum EntityState
    {
        /// <summary>
        /// New entity
        /// </summary>
        /// <remarks>
        /// <para>[ZA]  24/02/2016  1.0 Documentation added.</para>
        /// </remarks>
        New,

        /// <summary>
        /// New entity with modified data
        /// </summary>
        /// <remarks>
        /// <para>[ZA]  24/02/2016  1.0 Documentation added.</para>
        /// </remarks>
        NewModified,

        /// <summary>
        /// Entity with no change (non-modified entity)
        /// </summary>
        /// <remarks>
        /// <para>[ZA]  24/02/2016  1.0 Documentation added.</para>
        /// </remarks>
        NotModified,

        /// <summary>
        /// Entity with modified data
        /// </summary>
        /// <remarks>
        /// <para>[ZA]  24/02/2016  1.0 Documentation added.</para>
        /// </remarks>
        DataModified,

        /// <summary>
        /// Entity marked for deletion
        /// </summary>
        /// <remarks>
        /// <para>[ZA]  24/02/2016  1.0 Documentation added.</para>
        /// </remarks>
        Delete
    }
}
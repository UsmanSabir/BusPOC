using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("NFS.BaseModels")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("NFS.BaseModels")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("01dd4de2-9f8a-425e-871a-7554ee595e09")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("02.00.00.00")]
[assembly: AssemblyFileVersion("02.00.00.00")]

[assembly: InternalsVisibleTo("NS.ORM, PublicKey=002400000480000094000000060200000024000052534131000400000100010049125c9138e2b2e632b96e5da5fb559e27b974d023dc6ad9e12b4b3d4b88af10132f812c5f71186770140ccdd2d0164d227f6683ca32e46ea234b081aea9a50f5df5e5faedf47c7f39ccd9419c50e2fa519e740294cf3147feb3d4f19a4f8c54cc276b4e3b0df5303fcaee08edae77bfefbf0a706f71ce647510b69458841baf", AllInternalsVisible = true)]

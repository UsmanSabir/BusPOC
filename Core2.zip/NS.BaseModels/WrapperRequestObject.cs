﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NS.BaseModels
{
    public class WrapperRequestObject<T>
    {
        #region Private Members

        private int _subTenantId;
        private T _data;

        #endregion

        #region Public Properties

        public int SubTenantId
        {
            get { return _subTenantId; }
            set { _subTenantId = value; }
        }

        public T Data
        {
            get { return _data; }
            set { _data = value; }
        }

        #endregion
    }
}

﻿
using System.Runtime.Serialization;

namespace NS.BaseModels
{
    /// <summary>
    /// Class NullObject.
    /// </summary>
    [DataContract]
    public sealed class NullObject
    {
    }
}

﻿using System.Collections.Generic;

// ReSharper disable once CheckNamespace
namespace NS.Validation.Engine
{
    internal sealed class Rule
    {
        public string MemberName
        {
            get;
            set;
        }

        public string Operator
        {
            get;
            set;
        }

        public string TargetValue
        {
            get;
            set;
        }

        public string RuleName { get; set; }

        public List<string> Actions { get; set; }
        public string ControlId { get; set; }
        public Rule(string memberName, string oprator, string targetValue, string ruleName, List<string> actions,string controlId)
        {
            MemberName = memberName;
            Operator = oprator;
            TargetValue = targetValue;
            RuleName = ruleName;
            Actions = actions;
            ControlId = controlId;
        }
    }
}
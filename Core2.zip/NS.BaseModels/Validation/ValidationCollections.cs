﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using NS.BaseModels;
using System.Reflection;

// ReSharper disable once CheckNamespace
namespace NS.Validation
{
    internal sealed class ValidationCollections
    {
        // ReSharper disable once InconsistentNaming
        private static readonly Lazy<ValidationCollections> _instance=new Lazy<ValidationCollections>();
        public static ValidationCollections Instance => _instance.Value;// ?? (_instance = new ValidationCollections());

        private readonly ConcurrentDictionary<Type, Lazy<BaseValidation>> _typeValidations;

        public ValidationCollections()
        {
            _typeValidations=new ConcurrentDictionary<Type, Lazy<BaseValidation>>();
        }

        public BaseValidation GetModelValidation(Type type)
        {
            if (type == null)
                return null;

            if (_typeValidations.ContainsKey(type))
                return _typeValidations[type].Value;

            var pDef = type.Name + "Validator";

            Type orDefault;
            var asmbs = type.Assembly; //validation file is placed in same assembly of entity file
            try
            {
                orDefault = asmbs.GetTypes().FirstOrDefault(a => a != null && a.Name == pDef);
            }
            catch (ReflectionTypeLoadException ex)
            {
                orDefault = ex.Types.FirstOrDefault(x => x != null && x.Name == pDef);
            }
            if (orDefault != null)
            {
                _typeValidations.TryAdd(type, new Lazy<BaseValidation>(() => (BaseValidation)Activator.CreateInstance(orDefault)));
                return _typeValidations[type].Value;
            }

            //throw new KeyNotFoundException("Validation not found for type " + type.FullName);
            
            return null; 
            
        }


    }
}
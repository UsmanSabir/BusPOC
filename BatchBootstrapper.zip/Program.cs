﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BatchBootstrapper.Process;
using BusImpl;
using BusImpl.Redis;
using BusLib;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.PubSub;
using BusLib.BatchEngineCore.Volume;
using BusLib.Infrastructure;
using BusLib.ProcessLocks;

namespace BatchBootstrapper
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ready");

            Bootstrap.Initialize();

            var redisConnection = "localhost";// "172.31.15.19";

            var serializer = Bootstrap.GetSerializer();

            IProcessDataStorage storage=new RedisProcessStorage(NodeSettings.Instance.Name, redisConnection, serializer);

            IPubSubFactory factory= new RedisPubSubFactory(redisConnection);
            IDistributedMutexFactory mutexFactory=new DistributedMutexFactory(redisConnection);
            

            BatchEngineService service =new BatchEngineService(new StatePersistenceService(), new EntityFactory(), new VolumeHandler(), storage, factory, mutexFactory);
            try
            {
                service.Start();

                //service.SubmitSingleProcess<TestDDProcess>(new ProcessExecutionCriteria() { BranchId = 1, CompanyId = 1, ProcessingDate = DateTime.Now, ReferenceId = 1, SubTenantId = 1 }, false);
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine("Done");
            Console.ReadLine();
        }
    }
}

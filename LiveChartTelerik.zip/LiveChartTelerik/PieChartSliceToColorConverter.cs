﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace LiveChartTelerik
{
    public class PieChartSliceToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var result = "Transparent";
            Telerik.Charting.PieDataPoint dataPoint= (Telerik.Charting.PieDataPoint)value;
            HealthMonitoring valueee = (HealthMonitoring)dataPoint.DataItem;
            result = valueee.ProcessKey.Contains("Free")? "#A8B4BC" : "#309ADA";
            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}

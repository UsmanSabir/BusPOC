﻿using System;

namespace LiveChartTelerik
{
    public class PerformanceMonitoring
    {
        private decimal _loadTotalCurrent;
        private decimal _speedCurrent;
        private DateTime _category;
        private decimal _loadUsageCurrent;
        public decimal SpeedCurrent
        {
            get
            {
                return this._speedCurrent;
            }
            set
            {
                this._speedCurrent = value;
            }
        }
        public decimal LoadTotalCurrent
        {
            get
            {
                return this._loadTotalCurrent;
            }
            set
            {
                this._loadTotalCurrent = value;
            }
        }

        public decimal LoadUsageCurrent
        {
            get
            {
                return this._loadUsageCurrent;
            }
            set
            {
                this._loadUsageCurrent = value;
            }
        }
        public DateTime Category
        {
            get
            {
                return this._category;
            }
            set
            {
                this._category = value;
            }
        }

    }
}

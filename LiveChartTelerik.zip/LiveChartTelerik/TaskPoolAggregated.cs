﻿using System;

namespace LiveChartTelerik
{
    public class TaskPoolAggregated
    {
        private DateTime _category;
        private int _totalActiveProcesses;
        private int _totalExecutingProcesses;
        private int _totalQueueSize;
        public int TotalActiveProcesses
        {
            get
            {
                return this._totalActiveProcesses;
            }
            set
            {
                this._totalActiveProcesses = value;
            }
        }
        public int TotalExecutingProcesses
        {
            get
            {
                return this._totalExecutingProcesses;
            }
            set
            {
                this._totalExecutingProcesses = value;
            }
        }
        public int TotalQueueSize
        {
            get
            {
                return this._totalQueueSize;
            }
            set
            {
                this._totalQueueSize = value;
            }
        }
       
        public DateTime Category
        {
            get
            {
                return this._category;
            }
            set
            {
                this._category = value;
            }
        }
    }
}

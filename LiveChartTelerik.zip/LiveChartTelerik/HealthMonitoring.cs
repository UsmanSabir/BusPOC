﻿using System;
using System.Collections.ObjectModel;

namespace LiveChartTelerik
{
    public class HealthMonitoring
    {
        private string _processKey;
        private DateTime _category;
        private decimal _processValue;

        public string ProcessKey
        {
            get
            {
                return this._processKey;
            }
            set
            {
                this._processKey = value;
            }
        }

        public decimal ProcessValue
        {
            get
            {
                return this._processValue;
            }
            set
            {
                this._processValue = value;
            }
        }

        public DateTime Category
        {
            get
            {
                return this._category;
            }
            set
            {
                this._category = value;
            }
        }

        public ObservableCollection<HealthMonitoring> SubItems
        {
            get;
            set;
        }
    }
}

﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace LiveChartTelerik
{
    public class RedisServerToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var result = "Transparent";
            bool IsHealthly = (bool)value;
            result = IsHealthly == true ? "#027615" : "IndianRed";
            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}

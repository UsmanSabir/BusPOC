﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace LiveChartTelerik
{
    public class MemoryAlertToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var result = "Transparent";
            if (value != null)
            {
                string usedMemoryAlertValue = (string)value;
                decimal usedValue = System.Convert.ToDecimal(usedMemoryAlertValue.Split('|')[0]);
                decimal alertValue = System.Convert.ToDecimal(usedMemoryAlertValue.Split('|')[1]);
                result = usedValue >= alertValue ? "IndianRed" : "#309ADA";
            }
            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}

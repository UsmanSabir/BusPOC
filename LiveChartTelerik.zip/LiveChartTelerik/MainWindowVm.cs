﻿using System;
using System.Windows.Threading;
using Telerik.Windows.Controls;
using Telerik.Windows.Data;
using SampleDashboardP;
using BusLib.BatchEngineCore.PubSub;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;

namespace LiveChartTelerik
{
    public class MainWindowVm : ViewModelBase
    {
        private DashboardService _dashboardService;
        private DispatcherTimer timer;
        List<HealthMessage> healthMessage = new List<HealthMessage>();
        private List<HealthBlock> allMatrixs { get; set; }
        private int nodeObjExpiryInterval = Convert.ToInt32(ConfigurationSettings.AppSettings.Get("NodeObjExpiryInMins"));
        private string cacheServerIp = ConfigurationSettings.AppSettings.Get("CacheServerIp");
        private int timerInterval = Convert.ToInt32(ConfigurationSettings.AppSettings.Get("DispatcherTimerInSec"));
        private int nodeLinkDownWaitInterval = Convert.ToInt32(ConfigurationSettings.AppSettings.Get("NodeLinkDownWaitInSec"));
        public MainWindowVm()
        {
            this.timer = new DispatcherTimer();
            this.timer.Interval = TimeSpan.FromSeconds(timerInterval);
            this.timer.Tick += this.OnTimer;
            TaskExecPoolCollection = new RadObservableCollection<TaskPoolAggregated>();
            TaskExecPoolCollectionTemp = new RadObservableCollection<TaskExecutingPool>();
            TaskExecPoolCollectionPermanent = new RadObservableCollection<TaskExecutingPool>();
            PrcsMonitoring = new RadObservableCollection<PerformanceMonitoring>();
            AllProcessesCollection = new RadObservableCollection<string>();
            NodesCollection = new RadObservableCollection<NodesData>();
            HealthMessageCollection = new RadObservableCollection<HealthMessage>();
            this.FillData();
        }
        private DateTime _lastDate;
        public DateTime LastDate
        {
            get
            {
                return this._lastDate;
            }
            set
            {
                this._lastDate = value;
                this.OnPropertyChanged("LastDate");
            }
        }
        private string _nodeLastUpdated { get; set; }
        public string NodeLastUpdated
        {
            get
            {
                return this._nodeLastUpdated;
            }
            set
            {
                this._nodeLastUpdated = value;
                this.OnPropertyChanged("NodeLastUpdated");
            }
        }
        private string _node;
        public string Node
        {
            get
            {
                return this._node;
            }
            set
            {
                if (this._node != value)
                {
                    this._node = value;
                    this.OnPropertyChanged("Node");
                }  
            }
        }

        private decimal _totalMemory;
        public decimal TotalMemory
        {
            get
            {
                return this._totalMemory;
            }
            set
            {
                this._totalMemory = value;
                this.OnPropertyChanged("TotalMemory");
            }
        }
        private decimal _usedMemory;
        public decimal UsedMemory
        {
            get
            {
                return this._usedMemory;
            }
            set
            {
                this._usedMemory = value;
                this.OnPropertyChanged("UsedMemory");
            }
        }
        private string _usedMemoryWithSuffix;
        public string UsedMemoryWithSuffix
        {
            get
            {
                return this._usedMemoryWithSuffix;
            }
            set
            {
                this._usedMemoryWithSuffix = value;
                this.OnPropertyChanged("UsedMemoryWithSuffix");
            }
        }
        private string _freeMemoryWithSuffix;
        public string FreeMemoryWithSuffix
        {
            get
            {
                return this._freeMemoryWithSuffix;
            }
            set
            {
                this._freeMemoryWithSuffix = value;
                this.OnPropertyChanged("FreeMemoryWithSuffix");
            }
        }
        private decimal _memoryAlertValue;
        public decimal MemoryAlertValue
        {
            get
            {
                return this._memoryAlertValue;
            }
            set
            {
                this._memoryAlertValue = value;
                this.OnPropertyChanged("MemoryAlertValue");
            }
        }
        private string _usedMemoryAlertValue;
        public string UsedMemoryAlertValue
        {
            get
            {
                return this._usedMemoryAlertValue;
            }
            set
            {
                this._usedMemoryAlertValue = value;
                this.OnPropertyChanged("UsedMemoryAlertValue");
            }
        }
        
        private string _sender;
        public string Sender
        {
            get
            {
                return this._sender;
            }
            set
            {
                this._sender = value;
                this.OnPropertyChanged("Sender");
            }
        }

        private string _selectedProcessToShow;
        public string SelectedProcessToShow
        {
            get
            {
                return this._selectedProcessToShow;
            }
            set
            {
                this._selectedProcessToShow = value==null?this.SelectedProcessToShow:value;
                this.OnPropertyChanged("SelectedProcessToShow");
                SetProcessRelatedInfo(this.SelectedProcessToShow);
            }
        }

        private void SetProcessRelatedInfo(string processKey)
        {
            //var procesId = Convert.ToInt32(processId.Split('_')[1]);
            var processData = TaskExecPoolCollectionPermanent.LastOrDefault(x => x.ProcessKey == processKey);
            if(processData!=null)
            {
                this.SelctProcessItemIndex = AllProcessesCollection.IndexOf(this.SelectedProcessToShow);
                this.TaskExecuting = processData.Executing;
                this.QueueSize = processData.QueueSize;
                this.IsStopped = processData.IsStopped;
            }
        }

        private int _nodeThrottling;
        public int NodeThrottling
        {
            get
            {
                return this._nodeThrottling;
            }
            set
            {
                this._nodeThrottling = value;
                this.OnPropertyChanged("NodeThrottling");
            }
        }

        private int _cores;
        public int Cores
        {
            get
            {
                return this._cores;
            }
            set
            {
                this._cores = value;
                this.OnPropertyChanged("Cores");
            }
        }

        private int _activeProcesses;
        public int ActiveProcesses
        {
            get
            {
                return this._activeProcesses;
            }
            set
            {
                this._activeProcesses = value;
                this.OnPropertyChanged("ActiveProcesses");
            }
        }
        private int _taskExecuting;
        public int TaskExecuting
        {
            get
            {
                return this._taskExecuting;
            }
            set
            {
                this._taskExecuting = value;
                this.OnPropertyChanged("TaskExecuting");
            }
        }
        private int _queueSize;
        public int QueueSize
        {
            get
            {
                return this._queueSize;
            }
            set
            {
                this._queueSize = value;
                this.OnPropertyChanged("QueueSize");
            }
        }
        private bool _isStopped;
        public bool IsStopped
        {
            get
            {
                return this._isStopped;
            }
            set
            {
                this._isStopped = value;
                this.OnPropertyChanged("IsStopped");
            }
        }

        private bool _taskProducerState;
        public bool TaskProducerState
        {
            get
            {
                return this._taskProducerState;
            }
            set
            {
                this._taskProducerState = value;
                this.OnPropertyChanged("TaskProducerState");
            }
        }
        private bool _dbHealth;
        public bool DBHealth
        {
            get
            {
                return this._dbHealth;
            }
            set
            {
                this._dbHealth = value;
                this.OnPropertyChanged("DBHealth");
            }

        }
        private bool _dbHealthIndicator;
        public bool DBHealthIndicator
        {
            get
            {
                return this._dbHealthIndicator;
            }
            set
            {
                this._dbHealthIndicator = value;
                this.OnPropertyChanged("DBHealthIndicator");
            }

        }
        private bool _isCacheServerConnected;
        public bool IsCacheServerConnected
        {
            get
            {
                return this._isCacheServerConnected;
            }
            set
            {
                this._isCacheServerConnected = value;
                this.OnPropertyChanged("IsCacheServerConnected");
            }

        }
        

        private bool _cacheHealth;
        public bool CacheHealth
        {
            get
            {
                return this._cacheHealth;
            }
            set
            {
                this._cacheHealth = value;
                this.OnPropertyChanged("CacheHealth");
            }
        }
        private RadObservableCollection<PerformanceMonitoring> _prcsMonitoring;
        public RadObservableCollection<PerformanceMonitoring> PrcsMonitoring
        {
            get
            {
                return this._prcsMonitoring;
            }
            set
            {
                this._prcsMonitoring = value;
                this.OnPropertyChanged("PrcsMonitoring");
            }
        }


        private RadObservableCollection<HealthMonitoring> _diskValues;
        public RadObservableCollection<HealthMonitoring> DiskValues
        {
            get
            {
                return this._diskValues;
            }
            set
            {
                this._diskValues = value;
                this.OnPropertyChanged("DiskValues");
            }
        }

        private RadObservableCollection<HealthMonitoring> _memoryValues;
        public RadObservableCollection<HealthMonitoring> MemoryValues
        {
            get
            {
                return this._memoryValues;
            }
            set
            {
                this._memoryValues = value;
                this.OnPropertyChanged("MemoryValues");
            }
        }
       
        private RadObservableCollection<string> _allProcessesCollection;
        public RadObservableCollection<string> AllProcessesCollection
        {
            get
            {
                return this._allProcessesCollection;
            }
            set
            {
                this._allProcessesCollection = value;
                this.OnPropertyChanged("AllProcessesCollection");
            }
        }
        private List<decimal> _allProcessValuesList;
        public List<decimal> AllProcessValuesList
        {
            get
            {
                return this._allProcessValuesList;
            }
            set
            {
                this._allProcessValuesList = value;
                this.OnPropertyChanged("AllProcessValuesList");
            }
        }
        private int _maxYAxis;
        public int MaxYAxis
        {
            get
            {
                return this._maxYAxis;
            }
            set
            {
                this._maxYAxis = value;
                this.OnPropertyChanged("MaxYAxis");
            }
        }
        private decimal _loadTotalCurrentValue;
        public decimal LoadTotalCurrentValue
        {
            get
            {
                return this._loadTotalCurrentValue;
            }
            set
            {
                this._loadTotalCurrentValue = value;
                this.OnPropertyChanged("LoadTotalCurrentValue");
            }
        }

        private DateTime? _alignmentDate;
        public DateTime? AlignmentDate
        {
            get
            {
                return this._alignmentDate;
            }
            set
            {
                this._alignmentDate = value;
                this.OnPropertyChanged("AlignmentDate");
            }
        }

        private RadObservableCollection<NodesData> _nodesCollection;
        public RadObservableCollection<NodesData> NodesCollection
        {
            get
            {
                return this._nodesCollection;
            }
            set
            {
                this._nodesCollection = value;
                this.OnPropertyChanged("NodesCollection");
            }
        }

        private int _selctItemIndex;
        public int SelctItemIndex
        {
            get
            {
                return this._selctItemIndex;
            }
            set
            {
                this._selctItemIndex = value;
                this.OnPropertyChanged("SelctItemIndex");
            }
        }
        private int _selctProcessItemIndex;
        public int SelctProcessItemIndex
        {
            get
            {
                return this._selctProcessItemIndex;
            }
            set
            {
                this._selctProcessItemIndex = value;
                this.OnPropertyChanged("SelctProcessItemIndex");
            }
        }

        private string _selectedNode;
        public string SelectedNode
        {
            get
            {
                return this._selectedNode;
            }
            set
            {
                if(this._selectedNode!=value)
                {
                    this._selectedNode = value;
                    this.OnPropertyChanged("SelectedNode");
                    AllProcessesCollection.Clear();
                    this.ActiveProcesses = 0;
                    this.QueueSize = 0;
                    this.TaskExecuting = 0;
                    this.IsStopped = true;
                    TaskExecPoolCollectionPermanent.Clear();
                }
            }
        }

        public RadObservableCollection<TaskExecutingPool> _taskExecPoolCollectionTemp;
        public RadObservableCollection<TaskExecutingPool> TaskExecPoolCollectionTemp
        {
            get
            {
                return this._taskExecPoolCollectionTemp;
            }
            set
            {
                this._taskExecPoolCollectionTemp = value;
                this.OnPropertyChanged("TaskExecPoolCollectionTemp");
            }
        }
        public RadObservableCollection<TaskExecutingPool> _taskExecPoolCollectionPermanent;
        public RadObservableCollection<TaskExecutingPool> TaskExecPoolCollectionPermanent
        {
            get
            {
                return this._taskExecPoolCollectionPermanent;
            }
            set
            {
                this._taskExecPoolCollectionPermanent = value;
                this.OnPropertyChanged("TaskExecPoolCollectionPermanent");
            }
        }

        public RadObservableCollection<TaskPoolAggregated> _taskExecPoolCollection;
        public RadObservableCollection<TaskPoolAggregated> TaskExecPoolCollection
        {
            get
            {
                return this._taskExecPoolCollection;
            }
            set
            {
                this._taskExecPoolCollection = value;
                this.OnPropertyChanged("TaskExecPoolCollection"); 
            }
        }

        public RadObservableCollection<HealthMessage> _healthMessageCollection;
        public RadObservableCollection<HealthMessage> HealthMessageCollection
        {
            get
            {
                return this._healthMessageCollection;
            }
            set
            {
                this._healthMessageCollection = value;
                this.OnPropertyChanged("HealthMessageCollection");
            }
        }
        private void LoadChartData(string matrixValue)
        {
            HealthMonitoring healthMonitoring = new HealthMonitoring();
            TaskExecutingPool taskExecPool = new TaskExecutingPool();
            HealthMessage lastAvailableData = new HealthMessage();
            PerformanceMonitoring perfMonitoring = new PerformanceMonitoring();
            List<HealthBlock> healthBlock = new List<HealthBlock>();
            HealthMessageCollection.AddRange(healthMessage);
            var currentUtcDateTime = DateTime.UtcNow;
            bool selectedNodeLinkDown = false;
            var nodeLinkWaitTime = nodeLinkDownWaitInterval * timerInterval;
            var expiredNodesListToRemove = HealthMessageCollection.Where(x=> currentUtcDateTime.Subtract(x.Time).TotalMinutes>=nodeObjExpiryInterval).ToList();
            if(expiredNodesListToRemove.Count>0)
            {
                expiredNodesListToRemove.OrderByDescending(x => x.Time);
                var groupedNodesData = expiredNodesListToRemove.GroupBy(x => x.NodeKey);
                foreach (var nodeCollection in groupedNodesData)
                {
                    if(HealthMessageCollection.Where(x=>x.NodeKey== nodeCollection.Key).Count()== nodeCollection.Count())
                    {
                        HealthMessageCollection.RemoveRange(nodeCollection.Take(nodeCollection.Count()-1));
                    }
                    else
                    {
                        HealthMessageCollection.RemoveRange(nodeCollection);
                    }
                }
            }
            var healthMessageList = HealthMessageCollection.ToList();
            try
            {
                _dashboardService = new DashboardService(cacheServerIp.ToString(), OnMessageReceivedCustom);
                _dashboardService.Publish();
                this.IsCacheServerConnected = true; 
            }
            catch
            {
                this.IsCacheServerConnected = false;
            }
            foreach(var healthMesg in healthMessage)
            {
                if ((!NodesCollection.Any(x => x.NodeText == healthMesg.NodeKey)) && (!string.IsNullOrEmpty(healthMesg.NodeKey)))
                {
                    bool watchDogIndicator = false;
                    var watchDogMatrix = healthMesg.Matrix.FirstOrDefault(x => x.Name == "ProcessWatchDog");
                    if (watchDogMatrix != null)
                    {
                        watchDogIndicator = Convert.ToBoolean(watchDogMatrix.Matrix[0].Value);
                    }
                    if (watchDogIndicator == true)
                    {
                        NodesCollection.ToList().ForEach(i => i.WatchDogIndicator = false);
                    }
                    NodesCollection.Add(new NodesData() { NodeText = healthMesg.NodeKey, WatchDogIndicator = watchDogIndicator });
                }
            }
            if (string.IsNullOrEmpty(SelectedNode))
            {
                if(healthMessage.Count>0)
                {
                    this.SelctItemIndex = 0;
                    this.Node = healthMessage[0].NodeKey;
                    this.NodeThrottling = healthMessage[0].NodeThrottling;
                    this.Sender = healthMessage[0].Sender == null ? "" : healthMessage[0].Sender.ToString();
                    this.SelectedNode = healthMessage[0].NodeKey;
                    this.NodeLastUpdated = healthMessage[0].Time.ToLocalTime().ToString();
                    allMatrixs = new List<HealthBlock>();
                    allMatrixs = healthMessage[0].Matrix;
                }
            }
            else
            {
                if (healthMessageList.Count == 0)
                {
                    lastAvailableData = null;
                    allMatrixs = new List<HealthBlock>();
                }
                else
                {
                    lastAvailableData = healthMessageList.LastOrDefault(x => x.NodeKey == this.SelectedNode);
                    if(lastAvailableData != null)
                    {
                        if (DateTime.UtcNow.Subtract(lastAvailableData.Time).TotalSeconds >= nodeLinkWaitTime)
                        {
                            selectedNodeLinkDown = true;
                        }
                        allMatrixs = new List<HealthBlock>();
                        allMatrixs = lastAvailableData.Matrix;
                        this.Node = lastAvailableData.NodeKey;
                        this.NodeThrottling = lastAvailableData.NodeThrottling;
                        this.Sender = lastAvailableData.Sender == null ? "" : lastAvailableData.Sender.ToString();
                        this.NodeLastUpdated = lastAvailableData.Time.ToLocalTime().ToString();
                    }
                    else
                    {
                        allMatrixs = new List<HealthBlock>();
                    }
                }
            }
            if (allMatrixs != null && allMatrixs.Count > 0)
            {
                var memoryMatrix = allMatrixs.Find(x => x.Name == "Memory");
                if (memoryMatrix != null)
                {
                    MemoryValues = new RadObservableCollection<HealthMonitoring>();
                    foreach (var memMatrix in memoryMatrix.Matrix)
                    {
                        string valueWithSize = SizeSuffix((Int64)memMatrix.Value);
                        if (memMatrix.Key != "Total")
                        {
                            if (memMatrix.Key == "Remaining" || memMatrix.Key == "Used")
                            {
                                this.UsedMemory = Convert.ToDecimal(valueWithSize.Split(' ')[0]);
                                this.UsedMemoryWithSuffix = "Used:" + " " + valueWithSize;
                            }
                            else
                            {
                                this.FreeMemoryWithSuffix = "Free:" + " " + valueWithSize;
                            }
                        }
                        else
                        {
                            decimal mtrxValue = Convert.ToDecimal(valueWithSize.Split(' ')[0]);
                            this.TotalMemory = mtrxValue;
                            this.MemoryAlertValue = mtrxValue - 1;
                        }
                    }
                    this.UsedMemoryAlertValue = this.UsedMemory + "|" + this.MemoryAlertValue;
                }
                var cacheMatrix = allMatrixs.Find(x => x.Name == "Cache");
                if (cacheMatrix != null)
                {
                    CacheHealth = (bool)cacheMatrix.Matrix[0].Value;
                }
                var dBMatrix = allMatrixs.Find(x => x.Name == "Database");
                if (dBMatrix != null)
                {
                    DBHealth = (bool)dBMatrix.Matrix[0].Value;
                }
                var dBHealthMatrix = allMatrixs.Find(x => x.Name == "DatabaseHealth");
                if (dBHealthMatrix != null)
                {
                    DBHealthIndicator = (bool)dBHealthMatrix.Matrix[0].Value;
                }
                else
                {
                    DBHealthIndicator = true;
                }
                var taskProducerMatrix = allMatrixs.Find(x => x.Name == "TaskProducer");
                if (taskProducerMatrix != null)
                {
                    TaskProducerState = (bool)taskProducerMatrix.Matrix[0].Value;
                }
                var diskMatrix = allMatrixs.Find(x => x.Name == "Disk");
                if (diskMatrix != null)
                {
                    DiskValues = new RadObservableCollection<HealthMonitoring>();
                    foreach (var diskMatx in diskMatrix.Details)
                    {
                        healthMonitoring = new HealthMonitoring();
                        healthMonitoring.SubItems = new System.Collections.ObjectModel.ObservableCollection<HealthMonitoring>();
                        foreach (var details in diskMatx.Matrix)
                        {
                            string valueWithSize = SizeSuffix((Int64)details.Value);
                            if (details.Key== "SizeTotalFree")
                            {
                                healthMonitoring.SubItems.Add(new HealthMonitoring() { ProcessKey = diskMatx.Name + " " + "Free" + ":" + valueWithSize, ProcessValue = Convert.ToDecimal(valueWithSize.Split(' ')[0]) });
                            }
                            else if(details.Key== "SizeUsageCurrent")
                            {
                                healthMonitoring.SubItems.Add(new HealthMonitoring() { ProcessKey = diskMatx.Name + " " + "Used" + ":" + valueWithSize, ProcessValue = Convert.ToDecimal(valueWithSize.Split(' ')[0]) });
                            }
                        }
                        DiskValues.Add(healthMonitoring);
                    }
                }
                var processorMatrix = allMatrixs.Find(x => x.Name == "Processor");
                if (processorMatrix != null)
                {
                    var LoadTotal = decimal.Zero;
                    var SpeedCurrent = decimal.Zero;
                    var LoadUsage = decimal.Zero;
                    int CoreCount = 0;
                    foreach (var details in processorMatrix.Details)
                    {
                        CoreCount++;
                        foreach (var detailsMtrx in details.Matrix)
                        {
                            if (detailsMtrx.Key == "LoadTotalCurrent")
                            {
                                LoadTotal += Convert.ToDecimal(String.Format("{0:0.00}", Convert.ToDecimal(detailsMtrx.Value)));
                            }
                            //else if (detailsMtrx.Key == "SpeedCurrent")
                            //{
                            //    SpeedCurrent += Convert.ToDecimal(String.Format("{0:0.00}", Convert.ToDecimal(detailsMtrx.Value)));
                            //}
                            //else
                            //{
                            //    LoadUsage += Convert.ToDecimal(String.Format("{0:0.00}", Double.IsNaN(Convert.ToDouble(detailsMtrx.Value)) == true ? 0 : Convert.ToDecimal(detailsMtrx.Value)));
                            //}
                        }
                    }
                    if(selectedNodeLinkDown==true)
                    {
                        perfMonitoring = new PerformanceMonitoring() { LoadTotalCurrent = 0, SpeedCurrent = 0, LoadUsageCurrent = 0, Category = this.LastDate };
                    }
                    else
                    {
                        perfMonitoring = new PerformanceMonitoring() { LoadTotalCurrent = LoadTotal / CoreCount, SpeedCurrent = SpeedCurrent / CoreCount, LoadUsageCurrent = LoadUsage / CoreCount, Category = this.LastDate };
                    }
                    this.Cores = CoreCount;
                    this.LoadTotalCurrentValue = Convert.ToDecimal(String.Format("{0:0.00}", LoadTotal / CoreCount));
                    PrcsMonitoring.Add(perfMonitoring);
                }
                var releventMatrix = allMatrixs.Find(x => x.Name == matrixValue);
                if (releventMatrix != null)
                {
                    AllProcessValuesList = new List<decimal>();
                    TaskExecPoolCollectionTemp = new RadObservableCollection<TaskExecutingPool>();
                    AllProcessesCollection.Clear();
                    foreach (var d in releventMatrix.Matrix)
                    {
                        taskExecPool = new TaskExecutingPool();
                        if (d.Value is sbyte || d.Value is byte || d.Value is short || d.Value is ushort || d.Value is int || d.Value is uint || d.Value is long || d.Value is ulong || d.Value is float || d.Value is double || d.Value is decimal)
                        {
                            var ProcessValue = Convert.ToInt32(d.Value);
                            this.ActiveProcesses = ProcessValue;
                            taskExecPool.ActiveProcessConsumersCount = ProcessValue;
                        }
                        else
                        {
                            var NestedMatrixValue = Newtonsoft.Json.JsonConvert.DeserializeObject<HealthBlock>(d.Value.ToString());
                            foreach (var mtrx in NestedMatrixValue.Matrix)
                            {
                                var ProcessValue = Convert.ToInt32(mtrx.Value);
                                if (mtrx.Key == "ProcessId")
                                {
                                    taskExecPool.ProcessId = ProcessValue;
                                }
                                else if (mtrx.Key == "Executing")
                                {
                                    taskExecPool.Executing = ProcessValue;
                                }
                                else if (mtrx.Key == "QueueSize")
                                {
                                    taskExecPool.QueueSize = ProcessValue;
                                }
                                else if(mtrx.Key=="IsStopped")
                                {
                                    taskExecPool.IsStopped = Convert.ToBoolean(ProcessValue);
                                }
                            }
                        }
                        taskExecPool.Category = this.LastDate;
                        taskExecPool.ProcessKey = d.Key;
                        var existingElement = TaskExecPoolCollectionPermanent.Where(x=>x.ProcessKey==d.Key).FirstOrDefault();
                        if(existingElement!=null)
                        {
                            TaskExecPoolCollectionPermanent.Remove(existingElement);
                            TaskExecPoolCollectionPermanent.Add(taskExecPool);
                        }
                        else
                        {
                            TaskExecPoolCollectionPermanent.Add(taskExecPool);
                        }
                        TaskExecPoolCollectionTemp.Add(taskExecPool);
                        if (d.Key != "ActiveProcessConsumersCount")
                        {
                            if(!AllProcessesCollection.Contains(d.Key))
                            {
                                AllProcessesCollection.Add(d.Key);
                            }
                        }
                    }
                    var activeProcessCount = TaskExecPoolCollectionTemp.Sum(a => a.ActiveProcessConsumersCount);
                    var totalExecutingCount = TaskExecPoolCollectionTemp.Sum(e => e.Executing);
                    var totalQueueSizeCount = TaskExecPoolCollectionTemp.Sum(q => q.QueueSize);

                    //TaskExecPoolCollection.Where(x => AllProcessesCollection.Contains("Process_"+x.ProcessId.ToString())).ToList().ForEach(x => x.TotalActiveProcesses = activeProcessCount);
                    //TaskExecPoolCollection.Where(x => AllProcessesCollection.Contains("Process_" + x.ProcessId.ToString())).ToList().ForEach(x => x.TotalExecutingProcesses = totalExecutingCount);
                    //TaskExecPoolCollection.Where(x => AllProcessesCollection.Contains("Process_" + x.ProcessId.ToString())).ToList().ForEach(x => x.TotalQueueSize = totalQueueSizeCount);

                    //TaskExecPoolCollection.ToList().ForEach(x => x.TotalActiveProcesses = activeProcessCount);
                    //TaskExecPoolCollection.ToList().ForEach(x => x.TotalExecutingProcesses = totalExecutingCount);
                    //TaskExecPoolCollection.ToList().ForEach(x => x.TotalQueueSize = totalQueueSizeCount);
                    TaskPoolAggregated tskPoolAggr = new TaskPoolAggregated();
                    tskPoolAggr.Category = this.LastDate;
                    tskPoolAggr.TotalActiveProcesses = selectedNodeLinkDown==true?0:activeProcessCount;
                    tskPoolAggr.TotalExecutingProcesses = selectedNodeLinkDown==true?0:totalExecutingCount;
                    tskPoolAggr.TotalQueueSize = selectedNodeLinkDown == true ? 0 : totalQueueSizeCount;
                    TaskExecPoolCollection.Add(tskPoolAggr);

                    AllProcessValuesList.Add(activeProcessCount);
                    AllProcessValuesList.Add(totalExecutingCount);
                    AllProcessValuesList.Add(totalQueueSizeCount);
                    AllProcessValuesList.Sort();
                    var TempVal = AllProcessValuesList[AllProcessValuesList.Count - 1];
                    this.MaxYAxis = (int)TempVal + 10;
                    if(string.IsNullOrEmpty(SelectedProcessToShow))
                    {
                        if(AllProcessesCollection.Count>0)
                        {
                            this.SelctProcessItemIndex = 0;
                            this.SelectedProcessToShow = AllProcessesCollection[0];
                            SetProcessRelatedInfo(AllProcessesCollection[0]);
                        }
                    }
                    else
                    {
                        if (AllProcessesCollection.Count > 0)
                        {
                            if (AllProcessesCollection.Contains(this.SelectedProcessToShow))
                            {
                                //this.SelctProcessItemIndex = AllProcessesCollection.ToList().FindIndex(a => a.ProcessText == this.SelectedProcessToShow);
                                this.SelctProcessItemIndex = AllProcessesCollection.IndexOf(this.SelectedProcessToShow);
                                SetProcessRelatedInfo(this.SelectedProcessToShow);
                            }
                            else
                            {
                                this.SelctProcessItemIndex = 0;
                                this.SelectedProcessToShow = AllProcessesCollection[0];
                                SetProcessRelatedInfo(AllProcessesCollection[0]);
                            }
                        }
                    }
                }
            }
        }
        public void StartTimer()
        {
            this.timer.Start();
        }
        public void StopTimer()
        {
            this.timer.Stop();
        }
        private void FillData()
        {
            this.LastDate = DateTime.Now;
            this.AlignmentDate = this.LastDate;
            this.LastDate = this.LastDate.AddSeconds(timerInterval);
            this.LoadChartData("TaskExecutorPool");
        }
      
        private void OnTimer(object sender, EventArgs e)
        {
            this.LastDate = this.LastDate.AddSeconds(timerInterval);
            this.TaskExecPoolCollection.SuspendNotifications();
            if (TaskExecPoolCollection.Count > 4)
            {
                this.TaskExecPoolCollection.RemoveAt(0);
            }
            if (PrcsMonitoring.Count > 4)
            {
                this.PrcsMonitoring.RemoveAt(0);
            }
            this.LoadChartData("TaskExecutorPool");
            this.TaskExecPoolCollection.ResumeNotifications();
        }
        void OnMessageReceivedCustom(string obj)
        {
            healthMessage = new List<HealthMessage>();
            Dispatcher.CurrentDispatcher.Invoke((Action)(() =>
            {
                if(obj.StartsWith("["))
                {
                    healthMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<List<HealthMessage>>(obj);
                }
                else
                {
                    obj = "["+obj+"]";
                    healthMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<List<HealthMessage>>(obj);
                }
            }));
        }
       
        static readonly string[] SizeSuffixes =
                  { "bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB" };

        static string SizeSuffix(Int64 value, int decimalPlaces = 1)
        {
            if (value < 0) { return "-" + SizeSuffix(-value); }

            int i = 0;
            decimal dValue = (decimal)value;
            while (Math.Round(dValue, decimalPlaces) >= 1000)
            {
                dValue /= 1024;
                i++;
            }
            return string.Format("{0:n" + decimalPlaces + "} {1}", dValue, SizeSuffixes[i]);
        }
    }
}

﻿using System;

namespace LiveChartTelerik
{
    public class TaskExecutingPool
    {
        private int _activeProcessConsumersCount;
        private int _processId;
        private DateTime _category;
        private int _executing;
        private int _queueSize;
        private bool _isStopped;
        private string _processKey;

        public string ProcessKey
        {
            get
            {
                return this._processKey;
            }
            set
            {
                this._processKey = value;
            }
        }
        public int ActiveProcessConsumersCount
        {
            get
            {
                return this._activeProcessConsumersCount;
            }
            set
            {
                this._activeProcessConsumersCount = value;
            }
        }
        public int ProcessId
        {
            get
            {
                return this._processId;
            }
            set
            {
                this._processId = value;
            }
        }

        public int Executing
        {
            get
            {
                return this._executing;
            }
            set
            {
                this._executing = value;
            }
        }

        public int QueueSize
        {
            get
            {
                return this._queueSize;
            }
            set
            {
                this._queueSize = value;
            }
        }

        public bool IsStopped
        {
            get
            {
                return this._isStopped;
            }
            set
            {
                this._isStopped = value;
            }
        }
        public DateTime Category
        {
            get
            {
                return this._category;
            }
            set
            {
                this._category = value;
            }
        }
    }
}

﻿using System.Windows;
using System.Windows.Controls;
using Telerik.Windows;
using Telerik.Windows.Controls;

namespace LiveChartTelerik
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainWindowVm();
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            (this.DataContext as MainWindowVm).StartTimer();
        }

        private void UserControl_Unloaded(object sender, RoutedEventArgs e)
        {
            (this.DataContext as MainWindowVm).StopTimer();
        }

        private void NodeSelection_Selected(object sender, RoutedEventArgs e)
        {
            NodesData NodeData = radComboBox.SelectedItem as NodesData;
            (this.DataContext as MainWindowVm).SelectedNode = NodeData.NodeText.ToString();
        }

        //private void radListBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    if(e.AddedItems.Count>0)
        //    {
        //        ProcessesData PoolData = e.AddedItems[0] as ProcessesData;
        //        (this.DataContext as MainWindowVm).SelectedProcessToShow = PoolData.ToString();
        //    }
        //}
    }
}

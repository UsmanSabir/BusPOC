﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace FinancialSeriesWPF
{
    public class GrowthPercentageToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double growthPercentage = System.Convert.ToDouble(value);

            var result = growthPercentage > 0 ? "Green" : growthPercentage < 0 ? "Red" : null; 
            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}

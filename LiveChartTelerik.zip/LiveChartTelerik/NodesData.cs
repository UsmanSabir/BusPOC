﻿namespace LiveChartTelerik
{
    public class NodesData
    {
        public string NodeText{get;set;}
        public bool WatchDogIndicator{ get; set;}
    }
}

﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using BusLib.BatchEngineCore.PubSub;
using BusLib.Helper;
using StackExchange.Redis.Extensions.Core;
using StackExchange.Redis.Extensions.Core.Configuration;

namespace BusImpl.Redis
{
    abstract class RedisClient: SafeDisposable
    {
        private readonly string _connection;
        private StackExchangeRedisCacheClient _redis;
        private readonly RedisSerializer _serializer;
        protected const string PubChannel = "BPEMChannel";

        protected RedisClient(string connection)
        {
            _connection = connection;
            this._serializer = new RedisSerializer();

            CreateClient();
        }

        private void CreateClient()
        {
            _redis = new StackExchangeRedisCacheClient(_serializer, _connection);
            OnClientCreated(_redis);
        }

        protected abstract void OnClientCreated(StackExchangeRedisCacheClient redis);

        protected StackExchangeRedisCacheClient GetClient()
        {
            try
            {
                _redis.Get<object>("ping");
            }
            catch (Exception e)
            {
                _redis?.Dispose();
                _redis = null;

                while (_redis==null)
                {
                    try
                    {
                        CreateClient();
                    }
                    catch (Exception exception)
                    {
                        //todo log
                        Thread.Sleep(500);
                        _redis = null;
                    }
                }
            }
            return _redis;
        }

        protected override void Dispose(bool disposing)
        {
            _redis?.Dispose();
            base.Dispose(disposing);
        }
    }

    internal class RedisPublisher:RedisClient, IDistributedMessagePublisher
    {
        public RedisPublisher(string connection) : base(connection)
        {

        }

        protected override void OnClientCreated(StackExchangeRedisCacheClient redis)
        {
            
        }

        public void PublishMessage(string message)
        {
            var count = GetClient().Publish(PubChannel, message);
            Console.WriteLine(count);
        }
        
    }

    class RedisSubscriber : RedisClient, IDistributedMessageSubscriber
    {
        ConcurrentBag<KeyValuePair<string, Action<string>>> _subscriptions = new ConcurrentBag<KeyValuePair<string, Action<string>>>();

        public RedisSubscriber(string connection):base(connection)
        {
            
        }

        protected override void OnClientCreated(StackExchangeRedisCacheClient redis)
        {
            foreach (var pair in _subscriptions)
            {
                redis.Subscribe(pair.Key, pair.Value);
            }
        }

        public void Subscribe(string message, Action<string> action)
        {
            GetClient().Subscribe(PubChannel, action);
            _subscriptions.Add(new KeyValuePair<string, Action<string>>(message, action));
        }

        protected override void Dispose(bool disposing)
        {
            _subscriptions = null;
            base.Dispose(disposing);
        }
    }
}
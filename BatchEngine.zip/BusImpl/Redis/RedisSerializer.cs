﻿using System.IO;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using Jil;
using StackExchange.Redis.Extensions.Core;

namespace BusImpl.Redis
{
    public class RedisSerializer:ISerializer
    {
        public byte[] Serialize(object item)
        {
            using (MemoryStream memoryStream = new MemoryStream())
            {
                TextWriter tx = new StreamWriter(memoryStream);
                JSON.Serialize(item, tx);
                tx.Flush();
                return memoryStream.ToArray();
            }
        }

        public Task<byte[]> SerializeAsync(object item)
        {
            return Task.Run(()=> Serialize(item));
        }

        public object Deserialize(byte[] serializedObject)
        {
            return Deserialize<object>(serializedObject);
        }

        public Task<object> DeserializeAsync(byte[] serializedObject)
        {
            return Task.Run(()=> Deserialize<object>(serializedObject));
        }

        public T Deserialize<T>(byte[] serializedObject)
        {
            using (MemoryStream memoryStream = new MemoryStream(serializedObject))
            {
                TextReader tx = new StreamReader(memoryStream);
                return JSON.Deserialize<T>(tx);
            }
        }

        public Task<T> DeserializeAsync<T>(byte[] serializedObject)
        {
            return Task.Run(() => Deserialize<T>(serializedObject));
        }
    }
}
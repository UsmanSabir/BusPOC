﻿using BusLib.Infrastructure;
using StackExchange.Redis;
using StackExchange.Redis.Extensions.Core;

namespace BusImpl.Redis
{
    public class RedisProcessStorage: IProcessDataStorage
    {
        readonly IDatabase Db;
        readonly ICacheClient _redis;
        private readonly string _name;

        public RedisProcessStorage(string name, string connection)//, int port= 6379)
        {
            _name = name;
            RedisSerializer serializer=new RedisSerializer();


            //ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(connection);
            //Db = redis.GetDatabase();
            //Db.HashSet("user:user1", new HashEntry[] { new HashEntry("12", "13"), new HashEntry("14", "15") });

            //var config = ConfigurationOptions.Parse(connection);
            //var mux = ConnectionMultiplexer.Connect(config);

            //Db = mux.GetDatabase();


            ////var connectionString = mux.ToString();

            this._redis =  new StackExchangeRedisCacheClient(serializer, connection); //redis0:6380
            //Db = _redis.Database;
        }

        string GetHashKey(string processId)
        {
            return $"{_name}_process{processId}";
        }
        
        public void AddOrUpdateProcessData<T>(long processStateId, string key, T value)
        {
            var k = GetHashKey(processStateId.ToString());

            //Db.HashSet(k, new HashEntry[] { new HashEntry(key, value)}); //, new HashEntry("14", "15") })};

            _redis.HashSet(k, key, value);
        }

        public T GetProcessData<T>(long processStateId, string key)
        {
            var k = GetHashKey(processStateId.ToString());
            var item = _redis.HashGet<T>(k, key);
            return item;
        }

        public void CleanProcessData(string processId)
        {
            var k = GetHashKey(processId);
            _redis.Remove(k);
            //_redis.HashDelete(k)
        }
    }
}
﻿using BusLib.BatchEngineCore.PubSub;

namespace BusImpl.Redis
{
    public class RedisPubSubFactory: IPubSubFactory
    {
        private readonly string _connection;

        public RedisPubSubFactory(string connection)
        {
            _connection = connection;
        }
        public IDistributedMessagePublisher GetPublisher()
        {
            return new RedisPublisher(_connection);
        }

        public IDistributedMessageSubscriber GetSubscriber()
        {
            return new RedisSubscriber(_connection);
        }
    }
}
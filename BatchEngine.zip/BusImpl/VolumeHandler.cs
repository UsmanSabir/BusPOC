﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using BatchEngine.Models.BusStateWrapper;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;
using BusLib.BatchEngineCore.Volume;
using BusLib.Serializers;
using NS.ORM;
using NS.ORM.FluentData;
using NS.ORM.UoW;
using NS.Utilities.Helper;

namespace BusImpl
{
    internal class VolumeHandler: IVolumeHandler
    {
        private readonly ISerializersFactory _serializersFactory;

        public VolumeHandler(ISerializersFactory serializersFactory)
        {
            _serializersFactory = serializersFactory;
        }

        public void Handle<T>(IEnumerable<T> volume, IProcessExecutionContext processContext)
        {
            var serializer = _serializersFactory.GetSerializer<T>();
            int currentCount = 0;
            int batchSize = 100;

            var ext = EntityContextExt<BatchTaskState>.Create();
            using (var unitOfWork = ext.InitiateUnitOfWork(IsolationLevel.Snapshot)) //todo check isolation level with db team, is it enabled by default
            {
                foreach (var v in volume)
                {
                    var payLoad = serializer.SerializeToString(v);
                    var state = ext.CreateNew();

                    state.PAYLOAD = payLoad;
                    state.PROCESSID = processContext.ProcessState.Id;
                    //state.CURRENTSTATE = ;

                    currentCount++;
                    if (currentCount >= batchSize)
                    {
                        ext.Persist();
                        currentCount = 0;
                        ext.Entity.Clear();//remove persisted items
                    }
                }
                ext.Persist();
                unitOfWork.Save();
            }
        }

        public ITaskState GetNextTaskWithTransaction(out ITransaction transaction)
        {
            IUnitOfWork unitOfWork = null;
            transaction = null;

            try
            {
                var ext = EntityContextExt<BatchTaskState>.Create();
                unitOfWork = ext.InitiateUnitOfWork();

                ext.ReadWithSql(Constant.SQLReadDataQueue);
                if (ext.Entity.Count > 0)
                {
                    transaction= new TransactionWrapper(unitOfWork); //todo what if db connection lost
                    return new BatchTaskWrapper(ext.Entity.First());
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                unitOfWork?.Dispose();
                throw;
            }
        }
    }
}
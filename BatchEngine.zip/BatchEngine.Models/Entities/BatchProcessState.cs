
/* /m
   This file is generated from NFS ORM VS Extension v2.1.0, compatible with Visual Studio 2015 Update 3
   Any change to this class can cause unexpected behavior. Therefore, it is higly recommended not to change the contents of this file.
*/

// ReSharper disable All
#pragma warning disable CS1591

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NS.BaseModels;
#if RICHCLIENT
using System.Collections.ObjectModel;
#endif



namespace BatchEngine.Models.Entities
{

	///BatchProcessState
	public partial class BatchProcessState : BaseModel
	{
		
				private Int64 _id;
				private Guid _correlationid;
				private DateTime? _updatedon;
				private Int32 _retrycount;
				private Int32 _companyid;
				private Int32 _branchid;
				private DateTime _processingdate;
				private Int32 _processkey;
				private Boolean _isvolumegenerated;
				private Int64? _parentid;
				private Int32 _groupid;
				private Boolean _isfinished;
				private Boolean _isstopped;
				private String _criteria;
				private DateTime? _starttime;
				private String _currentstate;
		
		//public BatchProcessState BatchProcessState { get { return this; } } //Self reference property

		
		public Int64 ID
		{
			get { return _id; }
			set
			{
				CheckSetProperty(ref _id, value);
			}
		}

		
		public Guid CORRELATIONID
		{
			get { return _correlationid; }
			set
			{
				CheckSetProperty(ref _correlationid, value);
			}
		}

		
		public DateTime? UPDATEDON
		{
			get { return _updatedon; }
			set
			{
				CheckSetProperty(ref _updatedon, value);
			}
		}

		
		public Int32 RETRYCOUNT
		{
			get { return _retrycount; }
			set
			{
				CheckSetProperty(ref _retrycount, value);
			}
		}

		
		public Int32 COMPANYID
		{
			get { return _companyid; }
			set
			{
				CheckSetProperty(ref _companyid, value);
			}
		}

		
		public Int32 BRANCHID
		{
			get { return _branchid; }
			set
			{
				CheckSetProperty(ref _branchid, value);
			}
		}

		
		public DateTime PROCESSINGDATE
		{
			get { return _processingdate; }
			set
			{
				CheckSetProperty(ref _processingdate, value);
			}
		}

		
		public Int32 PROCESSKEY
		{
			get { return _processkey; }
			set
			{
				CheckSetProperty(ref _processkey, value);
			}
		}

		
		public Boolean ISVOLUMEGENERATED
		{
			get { return _isvolumegenerated; }
			set
			{
				CheckSetProperty(ref _isvolumegenerated, value);
			}
		}

		
		public Int64? PARENTID
		{
			get { return _parentid; }
			set
			{
				CheckSetProperty(ref _parentid, value);
			}
		}

		
		public Int32 GROUPID
		{
			get { return _groupid; }
			set
			{
				CheckSetProperty(ref _groupid, value);
			}
		}

		
		public Boolean ISFINISHED
		{
			get { return _isfinished; }
			set
			{
				CheckSetProperty(ref _isfinished, value);
			}
		}

		
		public Boolean ISSTOPPED
		{
			get { return _isstopped; }
			set
			{
				CheckSetProperty(ref _isstopped, value);
			}
		}

		
		public String CRITERIA
		{
			get { return _criteria; }
			set
			{
				CheckSetProperty(ref _criteria, value);
			}
		}

		
		public DateTime? STARTTIME
		{
			get { return _starttime; }
			set
			{
				CheckSetProperty(ref _starttime, value);
			}
		}

		
		public String CURRENTSTATE
		{
			get { return _currentstate; }
			set
			{
				CheckSetProperty(ref _currentstate, value);
			}
		}

		

		
	}

		public class BatchProcessStateValidator : BaseValidation
	{

	
		public override List<string> MandatoryFields { get; protected set; } 
			= new List<string>() { "ID", "CORRELATIONID", "RETRYCOUNT", "COMPANYID", "BRANCHID", "PROCESSINGDATE", "PROCESSKEY", "ISVOLUMEGENERATED", "GROUPID", "ISFINISHED", "ISSTOPPED", "CRITERIA", "CURRENTSTATE"  };

		public override Dictionary<string, int> MaxLengthFields { get; protected set; } = new Dictionary<string, int>()
		{
		                ["CRITERIA"] = 500
		   , ["CURRENTSTATE"] = 50
		 
		};

		
	

	}//end validator class

#pragma warning restore CS1591

}//end namespace
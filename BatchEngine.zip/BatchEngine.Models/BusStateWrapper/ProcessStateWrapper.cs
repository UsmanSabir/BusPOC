﻿using System;
using BatchEngine.Models.Entities;
using BusLib.BatchEngineCore;

namespace BatchEngine.Models.BusStateWrapper
{
    public class ProcessStateWrapper:IProcessState
    {
        internal readonly BatchProcessState State;

        public ProcessStateWrapper(BatchProcessState state)
        {
            State = state;
        }

        public long Id => State.ID;

        public Guid CorrelationId => State.CORRELATIONID;

        public DateTime? UpdatedOn => State.UPDATEDON;

        public ProcessStatus Status => ProcessStatus.FromName(State.CURRENTSTATE);

        public int RetryCount => State.RETRYCOUNT;

        public int CompanyId => State.COMPANYID;

        public int BranchId => State.BRANCHID;

        public int SubTenantId => throw new NotImplementedException();

        public DateTime ProcessingDate => State.PROCESSINGDATE;

        public int ProcessKey => State.PROCESSKEY;

        public bool IsVolumeGenerated => State.ISVOLUMEGENERATED;

        public long? ParentId => State.PARENTID;

        public int GroupId => State.GROUPID;

        public bool IsFinished => State.ISFINISHED;

        public bool IsStopped => State.ISSTOPPED;

        public string Criteria => State.CRITERIA;

        public DateTime? StartTime => State.STARTTIME;
    }
}
﻿using System.Collections.Concurrent;

namespace BusLib.BatchEngineCore.Groups
{
    internal class GroupSaga
    {

        public void RegisterProcess(IBaseProcess process)
        {

        }

        public void RegisterProcessByKey(string key)
        {

        }

    }
}
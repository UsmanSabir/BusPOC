﻿namespace BusLib.BatchEngineCore.PubSub
{
    public interface IPubSubFactory
    {
        IDistributedMessagePublisher GetPublisher();

        IDistributedMessageSubscriber GetSubscriber();
    }
}